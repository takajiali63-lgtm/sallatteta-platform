// v8.3 admin — «المدير الذكي (AI)»: the owner's switches (global, per category), monthly allowances (messages, voice
// minutes), unit costs for the cost report, workflow timings, usage & cost per subscriber, actions log, approvals overview.
// Telephone calls and marketing sending stay OFF in this version (shown, not switchable). Prices are in «الأسعار».
(() => {
  const CATN = { shops: 'المطاعم والمتاجر', online: 'البائعون أونلاين', crafts: 'الحرفيون', drivers: 'السائقون' };
  const money = (c) => `${(Number(c || 0) / 100).toFixed(2)}$`;
  const when = (s) => { try { return new Date(s).toLocaleString('ar-LB', { dateStyle: 'short', timeStyle: 'short' }); } catch { return s || ''; } };
  window.dxExtra = window.dxExtra || {};
  window.dxExtra.ai = async function aiSection(view = 'config') {
    const { api, esc, $, $$, toast, fail, pane } = window.dxKit;
    const tabs = `<div class="tabs">${[['config', '⚙️ الإعدادات'], ['usage', '📈 الاستعمال والكلفة'], ['actions', '📒 سجلّ الأعمال'], ['approvals', '✅ الموافقات']].map(([k, n]) => `<button data-av="${k}" class="${k === view ? 'on' : ''}">${n}</button>`).join('')}</div>`;
    let body = '';
    if (view === 'config') {
      const { config: c, provider: p } = await api('GET', '/api/admin/ai/config');
      body = `<div class="card ${p.name === 'local' ? 'warnc' : ''}"><h3>🧠 مزوّد الذكاء الاصطناعي</h3>
          <p class="small">${p.name === 'local' ? '⏸ يعمل الآن بالوضع المجاني المحلي (فهم أوامر بسيطة بالعربي/اللبناني والإنكليزي والفرنسي والإسباني، بلا كلفة). للمساعد الكامل ضع ANTHROPIC_API_KEY في Render — لا يُفعَّل أي اشتراك مدفوع من هنا.' : `✅ ${esc(p.name)}${p.keyConfigured ? '' : ' — ⚠️ المفتاح غير موجود'}${p.model ? ` · ${esc(p.model)}` : ''}`}</p></div>
        <form id="aif" class="card"><h3>المفاتيح</h3>
          <label class="check"><input type="checkbox" name="enabled" ${c.enabled ? 'checked' : ''}><span><b>تشغيل المدير الذكي في المنصة</b><br><small class="mute">الإطفاء يوقف أدوات الذكاء فوراً لكل المشتركين، والطلبات العادية تعمل كالمعتاد.</small></span></label>
          ${Object.keys(CATN).map((k) => `<label class="check"><input type="checkbox" name="cat_${k}" ${c.categories[k] ? 'checked' : ''}><span>${CATN[k]}</span></label>`).join('')}
          <h3>الحصة الشهرية لكل مشترك</h3>
          ${Object.keys(CATN).map((k) => `<div class="grid2"><label class="f">${CATN[k]} — رسائل<input class="in" type="number" min="0" name="msg_${k}" value="${c.limits[k].messages}"></label><label class="f">دقائق صوت<input class="in" type="number" min="0" name="voice_${k}" value="${c.limits[k].voiceMinutes}"></label></div>`).join('')}
          <h3>الكلفة (لتقرير الكلفة فقط، بالسنت)</h3>
          <div class="grid2"><label class="f">مليون رمز داخل<input class="in" type="number" min="0" name="tokenInPerMillionCents" value="${c.costs.tokenInPerMillionCents}"></label><label class="f">مليون رمز خارج<input class="in" type="number" min="0" name="tokenOutPerMillionCents" value="${c.costs.tokenOutPerMillionCents}"></label>
            <label class="f">كل رسالة<input class="in" type="number" min="0" name="messageCents" value="${c.costs.messageCents}"></label><label class="f">كل دقيقة صوت<input class="in" type="number" min="0" name="voiceMinuteCents" value="${c.costs.voiceMinuteCents}"></label></div>
          <h3>توقيت المتابعة التلقائية (دقيقة)</h3>
          <div class="grid2"><label class="f">طلب جديد لم يُقبل بعد<input class="in" type="number" min="1" name="waitMin" value="${c.workflow.waitMin}"></label><label class="f">تأخر التحضير بعد<input class="in" type="number" min="1" name="prepMin" value="${c.workflow.prepMin}"></label>
            <label class="f">تذكير قبل الموعد<input class="in" type="number" min="1" name="bookingRemindMin" value="${c.workflow.bookingRemindMin}"></label><label class="f">أقصى محاولات فاشلة<input class="in" type="number" min="1" name="maxFailures" value="${c.workflow.maxFailures}"></label></div>
          <h3>قنوات مستقبلية</h3>
          <p class="small">📞 الاتصالات الهاتفية: <span class="chip">مطفأة</span> · 📣 إرسال التسويق: <span class="chip">مطفأة</span><br><small class="mute">تحتاج مزوّداً معتمداً وموافقتك وقواعد الموافقة القانونية؛ لا تعمل في هذه النسخة.</small></p>
          <button class="btn">حفظ</button></form>`;
    } else if (view === 'usage') {
      const u = await api('GET', '/api/admin/ai/usage');
      body = `<div class="stat"><b>${money(u.totalCents)}</b><span>الكلفة التقديرية لشهر ${esc(u.month)}</span></div>
        <div class="grid2">${Object.entries(u.byCategory).map(([k, x]) => `<div class="stat"><b>${x.subscribers}</b><span>${CATN[k]} · ${x.messages} رسالة · ${Math.round(x.voiceSeconds / 60)} د · ${money(x.costCents)}</span></div>`).join('')}</div>
        <div class="tablewrap"><table class="inv"><thead><tr><th>المشترك</th><th>الفئة</th><th>رسائل</th><th>أدوات</th><th>صوت</th><th>الكلفة</th></tr></thead><tbody>
        ${u.subscribers.map((s) => `<tr><td>${s.ownerType === 'store' ? '🏪' : '🛵'} ${esc(s.name || '')}</td><td>${CATN[s.category] || esc(s.category)}</td><td>${s.messages}</td><td>${s.toolCalls}</td><td>${Math.round(s.voiceSeconds / 60)} د</td><td>${money(s.costCents)}</td></tr>`).join('')}</tbody></table></div>
        ${u.subscribers.length ? '' : '<div class="empty">لا استعمال هذا الشهر</div>'}`;
    } else if (view === 'actions') {
      const { actions } = await api('GET', '/api/admin/ai/actions');
      body = `<p class="small mute">كل ما فعله المدير الذكي أو حاول فعله، مع القرار (نُفّذ، بانتظار الموافقة، مرفوض بسبب الصلاحيات…).</p>
        <div class="tablewrap"><table class="inv"><thead><tr><th>الوقت</th><th>المشترك</th><th>الأداة</th><th>القرار</th></tr></thead><tbody>
        ${actions.map((a) => `<tr><td>${esc(when(a.created_at))}</td><td>${a.owner_type === 'store' ? '🏪' : '🛵'} ${esc(a.name || '')}</td><td>${esc(a.tool)}</td><td>${esc(a.decision)}</td></tr>`).join('')}</tbody></table></div>`;
    } else {
      const d = await api('GET', '/api/admin/ai/approvals');
      body = `<div class="grid2">${Object.entries(d.counts).map(([k, n]) => `<div class="stat"><b>${n}</b><span>${esc(k)}</span></div>`).join('')}</div>
        <p class="small mute">الموافقة يعطيها المشترك نفسه من صفحته؛ هنا للاطلاع فقط.</p>
        ${d.pending.map((a) => `<div class="card"><div class="row"><b>${a.owner_type === 'store' ? '🏪' : '🛵'} ${esc(a.name || '')}</b><span class="tiny mute">${esc(when(a.created_at))}</span></div><p class="small">${esc(a.tool)}${a.reason ? ` — ${esc(a.reason)}` : ''}</p></div>`).join('') || '<div class="empty">لا شيء بانتظار الموافقة</div>'}`;
    }
    pane().innerHTML = `<p class="mute small">🤖 المدير الذكي لكل مشترك معزول عن غيره، ولا يلمس المال ولا يعدّل إلا عبر أدوات مضبوطة بصلاحيات يحدّدها المشترك. المشترك الأساسي (بدون AI) لا يصل إليه.</p>${tabs}${body}`;
    $$('[data-av]').forEach((b) => { b.onclick = () => aiSection(b.dataset.av).catch(fail); });
    $('#aif')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      const n = (name) => Math.round(Number(f[name].value) || 0);
      const body2 = {
        enabled: f.enabled.checked,
        categories: Object.fromEntries(Object.keys(CATN).map((k) => [k, f[`cat_${k}`].checked])),
        limits: Object.fromEntries(Object.keys(CATN).map((k) => [k, { messages: n(`msg_${k}`), voiceMinutes: n(`voice_${k}`) }])),
        costs: { tokenInPerMillionCents: n('tokenInPerMillionCents'), tokenOutPerMillionCents: n('tokenOutPerMillionCents'), messageCents: n('messageCents'), voiceMinuteCents: n('voiceMinuteCents') },
        workflow: { waitMin: n('waitMin'), prepMin: n('prepMin'), bookingRemindMin: n('bookingRemindMin'), maxFailures: n('maxFailures') },
      };
      try { await api('PUT', '/api/admin/ai/config', body2); toast('تم الحفظ — يُطبَّق فوراً'); } catch (x) { fail(x); }
    });
  };
})();
