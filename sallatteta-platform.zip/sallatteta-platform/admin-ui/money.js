// v8 admin — money between drivers and stores (the platform never holds it; it only records and, when the owner decides,
// pays a store for a driver). Views used by «المال: من عليه لمن» (finance tab in delivery.js):
//   v8pay   — payments waiting for the other side / under review (amounts differ) → confirm an amount or reject
//   v8inv   — every invoice (open / archive), goods and delivery fee apart
//   v8admin — pay a store for a driver (all or part), the drivers who owe the platform, «settled with the driver»
//   v8comp  — financial complaints from stores (full file: driver papers stay private to the owner)
(() => {
  const K = () => window.dxKit;
  const money = (n) => `${Math.round(Number(n || 0) * 100) / 100}$`;
  const when = (s) => { try { return new Date(s).toLocaleString('ar-LB', { dateStyle: 'short', timeStyle: 'short' }); } catch { return s || ''; } };
  const key = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const PST = { pending: ['بانتظار الطرف الآخر', 'w'], review: ['مراجعة: المبلغان مختلفان', 'b'], confirmed: ['مؤكَّدة', 'g'], rejected: ['مرفوضة', ''], cancelled: ['ملغاة', ''] };
  const IST = { open: 'مفتوحة', partial: 'مدفوعة جزئياً', in_settlement: 'بانتظار', settled: 'مسدّدة', reversed: 'ملغاة' };
  const CST = { open: ['جديدة', 'b'], reviewing: ['قيد المراجعة', 'w'], resolved: ['حُسمت', 'g'], rejected: ['رُفضت', ''] };
  const METHODS = [['cash', 'نقداً'], ['whish', 'Whish'], ['omt', 'OMT'], ['bank', 'تحويل بنكي'], ['other', 'غير ذلك']];
  const methodSel = (name = 'method') => `<select class="in" name="${name}">${METHODS.map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select>`;
  const invRow = (i) => `<tr><td>${K().esc(i.ref)}<br><small>${K().esc(i.orderRef)}</small></td><td>🛵 ${K().esc(i.driver)}<br>🏪 ${K().esc(i.store)}</td><td>${money(i.goods)}<br><small class="mute">توصيل ${money(i.deliveryFee)}</small></td><td>${money(i.paid)}</td><td><b>${money(i.remaining)}</b></td><td>${IST[i.status] || i.status}${i.exception ? '<br><span class="chip a">استثناء</span>' : ''}</td></tr>`;

  const views = {
    async v8pay(status = 'review') {
      const { api, esc } = K();
      const { payments } = await api('GET', `/api/admin/finance/payments?status=${status}`);
      return {
        html: `<p class="small">الدفعة تتأكّد وحدها عندما يقول السائق «دفعت» والمتجر «استلمت» بالمبلغ نفسه. إذا اختلف المبلغان تصل إليك هنا: أكّد المبلغ الصحيح (بعد التواصل مع الطرفين) أو ارفض.</p>
          <div class="tabs">${[['review', 'للمراجعة'], ['pending', 'بانتظار الطرف الآخر'], ['all', 'الكل']].map(([k, n]) => `<button data-pst="${k}" class="${k === status ? 'on' : ''}">${n}</button>`).join('')}</div>
          ${payments.map((p) => `<div class="card ${p.status === 'review' ? 'hl' : ''}"><div class="row"><b>${esc(p.ref)} — 🛵 ${esc(p.driver)} ← 🏪 ${esc(p.store)}</b><span class="chip ${PST[p.status]?.[1] || ''}">${PST[p.status]?.[0] || p.status}</span></div>
            <p class="small">السائق يقول: <b>${p.driverSays == null ? '—' : money(p.driverSays)}</b> · المتجر يقول: <b>${p.storeSays == null ? '—' : money(p.storeSays)}</b>${p.kind === 'admin' ? ' · دفعته الإدارة' : ''} · ${esc(when(p.at))}</p>
            <p class="small">📱 <a href="tel:+${esc(p.driverPhone)}" dir="ltr">+${esc(p.driverPhone)}</a></p>
            ${p.status === 'review' ? `<div class="grid2"><button class="btn" data-pok="${p.id}" data-a="${p.driverSays ?? ''}" data-b="${p.storeSays ?? ''}">✅ تأكيد مبلغ</button><button class="btn bad" data-pno="${p.id}">✖️ رفض الدفعة</button></div>` : ''}</div>`).join('') || '<div class="empty">لا شيء 👌</div>'}`,
        bind: () => {
          const { $$, toast, fail } = K();
          $$('[data-pst]').forEach((b) => { b.onclick = () => window.dxFinance(`v8pay:${b.dataset.pst}`); });
          $$('[data-pok]').forEach((b) => { b.onclick = async () => {
            const v = prompt(`المبلغ الذي تأكّدت أنه دُفع فعلاً (السائق: ${b.dataset.a || '—'} · المتجر: ${b.dataset.b || '—'})`, b.dataset.b || b.dataset.a);
            if (v == null) return;
            try { const r = await K().api('POST', `/api/admin/finance/payments/${b.dataset.pok}/resolve`, { decision: 'confirm', amount: Number(v) }); toast(`تأكّد ${money(r.amount)} — المتبقّي ${money(r.left)}`); window.dxFinance('v8pay'); } catch (e) { fail(e); }
          }; });
          $$('[data-pno]').forEach((b) => { b.onclick = async () => {
            const note = prompt('سبب الرفض (يصل للطرفين)') ?? null;
            if (note === null) return;
            try { await K().api('POST', `/api/admin/finance/payments/${b.dataset.pno}/resolve`, { decision: 'reject', note }); toast('رُفضت الدفعة'); window.dxFinance('v8pay'); } catch (e) { fail(e); }
          }; });
        },
      };
    },
    async v8inv(state = 'open') {
      const { api } = K();
      const { invoices } = await api('GET', `/api/admin/finance/invoices?state=${state}`);
      const total = invoices.reduce((a, i) => a + Math.round((state === 'open' ? i.remaining : i.goods) * 100), 0) / 100;
      return {
        html: `<p class="small">فاتورة لكل طلب قبض السائق ثمنه نقداً: قيمة البضاعة للمتجر، وأجرة التوصيل للسائق وحده (لا تدخل في الدين).</p>
          <div class="tabs">${[['open', 'المفتوحة'], ['archive', 'المسدّدة']].map(([k, n]) => `<button data-ist="${k}" class="${k === state ? 'on' : ''}">${n}</button>`).join('')}</div>
          <div class="stat"><b>${money(total)}</b><span>${state === 'open' ? 'المتبقّي للمتاجر' : 'المسدّد'} (${invoices.length} فاتورة)</span></div>
          <div class="tablewrap"><table class="inv"><thead><tr><th>الفاتورة</th><th>الطرفان</th><th>البضاعة</th><th>المدفوع</th><th>المتبقّي</th><th>الحالة</th></tr></thead><tbody>${invoices.map(invRow).join('')}</tbody></table></div>
          ${invoices.length ? '' : '<div class="empty">لا فواتير</div>'}`,
        bind: () => { K().$$('[data-ist]').forEach((b) => { b.onclick = () => window.dxFinance(`v8inv:${b.dataset.ist}`); }); },
      };
    },
    async v8admin() {
      const { api, esc } = K();
      const [{ invoices }, { debts, history }] = await Promise.all([api('GET', '/api/admin/finance/invoices?state=open'), api('GET', '/api/admin/finance/admin-debts')]);
      // pairs driver → store that still have something to pay
      const pairs = new Map();
      for (const i of invoices) {
        const k = `${i.driverId}:${i.storeId}`;
        const p = pairs.get(k) || { driverId: i.driverId, storeId: i.storeId, driver: i.driver, store: i.store, owed: 0, n: 0 };
        p.owed = Math.round((p.owed + i.remaining) * 100) / 100; p.n += 1; pairs.set(k, p);
      }
      return {
        html: `<div class="note b small">⚠️ عندما تدفع للمتجر عن السائق يصبح السائق مديناً للإدارة بالمبلغ نفسه، وأي دين للإدارة (ولو 1$) يوقف عنه كل الطلبات (نقداً وبالبطاقة) حتى تضغط «تمّت التسوية» بالمبلغ كاملاً.</div>
          <h3>🏛 دفعتُ للمتجر نيابة عن السائق</h3>
          ${[...pairs.values()].map((p) => `<form class="card" data-pay="${p.driverId}:${p.storeId}"><div class="row"><b>🛵 ${esc(p.driver)} ← 🏪 ${esc(p.store)}</b><b>${money(p.owed)}</b></div>
            <p class="small mute">${p.n} فاتورة مفتوحة</p>
            <div class="grid2"><label class="f">المبلغ<input class="in" name="amount" type="number" step="0.01" min="0.01" max="${p.owed}" value="${p.owed}" required></label><label class="f">الوسيلة${methodSel()}</label></div>
            <label class="f">رقم العملية / الإثبات (اختياري)<input class="in" name="proof" maxlength="120"></label>
            <label class="f">ملاحظة<input class="in" name="note" maxlength="300"></label>
            <button class="btn">💵 دفعتُ للمتجر نيابة عن السائق</button></form>`).join('') || '<div class="empty">لا فواتير مفتوحة</div>'}
          <h3>⛔ سائقون مدينون للإدارة (موقوفون عن الطلبات)</h3>
          ${debts.filter((d) => d.amount > 0).map((d) => `<form class="card warnc" data-settle="${d.driverId}"><div class="row"><b>🛵 ${esc(d.driver)} <small class="mute">D${d.driverId}</small></b><b>${money(d.amount)}</b></div>
            <p class="small">📱 <a href="tel:+${esc(d.phone)}" dir="ltr">+${esc(d.phone)}</a> · آخر حركة ${esc(when(d.last))}</p>
            <div class="grid2"><label class="f">المبلغ المسترد<input class="in" name="amount" type="number" step="0.01" min="0.01" max="${d.amount}" value="${d.amount}" required></label><label class="f">الوسيلة${methodSel()}</label></div>
            <label class="f">رقم العملية / الإثبات<input class="in" name="proof" maxlength="120"></label>
            <button class="btn acc">✅ تمّت التسوية بين الإدارة والسائق</button></form>`).join('') || '<div class="empty">لا أحد مدين للإدارة 👌</div>'}
          <details><summary>📒 سجلّ مدفوعات الإدارة</summary><table class="inv"><thead><tr><th>#</th><th>السائق</th><th>المبلغ</th><th>الوسيلة</th><th>الوقت</th></tr></thead><tbody>${history.map((h) => `<tr><td>${h.id}</td><td>D${h.driver_id}</td><td>${money(Number(h.cents) / 100)}</td><td>${esc(h.method || '')}${h.proof ? ` · ${esc(h.proof)}` : ''}</td><td>${esc(when(h.created_at))}</td></tr>`).join('')}</tbody></table></details>`,
        bind: () => {
          const { $$, toast, fail } = K();
          $$('[data-pay]').forEach((f) => f.addEventListener('submit', async (e) => {
            e.preventDefault();
            const [driverId, storeId] = f.dataset.pay.split(':').map(Number);
            const amount = Number(f.amount.value);
            if (!confirm(`تأكيد: دفعتَ ${money(amount)} للمتجر عن هذا السائق؟ سيصبح السائق مديناً للإدارة وتتوقّف عنه الطلبات حتى التسوية.`)) return;
            try { const r = await K().api('POST', '/api/admin/finance/pay-for-driver', { driverId, storeId, amount, method: f.method.value, proof: f.proof.value, note: f.note.value, idem: key() }); toast(`سُجّل. المتبقّي للمتجر ${money(r.leftForStore)} · السائق مدين للإدارة ${money(r.driverOwesPlatform)}`); window.dxFinance('v8admin'); } catch (x) { fail(x); }
          }));
          $$('[data-settle]').forEach((f) => f.addEventListener('submit', async (e) => {
            e.preventDefault();
            try { const r = await K().api('POST', `/api/admin/finance/drivers/${f.dataset.settle}/settle-debt`, { amount: Number(f.amount.value), method: f.method.value, proof: f.proof.value, idem: key() }); toast(r.unblocked ? '✅ تمّت التسوية — عاد السائق لاستقبال الطلبات' : `بقي ${money(r.left)} — السائق ما زال موقوفاً`); window.dxFinance('v8admin'); } catch (x) { fail(x); }
          }));
        },
      };
    },
    async v8comp(status = 'open') {
      const { api, esc } = K();
      const { complaints } = await api('GET', `/api/admin/finance/complaints?status=${status}`);
      return {
        html: `<p class="small">شكاوى المتاجر على سائقين لم يدفعوا. الشكوى وحدها لا توقف السائق؛ القرار لك.</p>
          <div class="tabs">${[['open', 'المفتوحة'], ['closed', 'المحسومة'], ['all', 'الكل']].map(([k, n]) => `<button data-cst="${k}" class="${k === status ? 'on' : ''}">${n}</button>`).join('')}</div>
          ${complaints.map((c) => `<div class="card"><div class="row"><b>${esc(c.ref)} — 🏪 ${esc(c.store)} ضد 🛵 ${esc(c.driver)}</b><span class="chip ${CST[c.status]?.[1] || ''}">${CST[c.status]?.[0] || c.status}</span></div>
            <p class="small">${money(c.amount)}${c.orderRef ? ` · ${esc(c.orderRef)}` : ''} · ${esc(when(c.at))}</p><p class="small" dir="auto">📝 ${esc(c.body)}</p>
            ${c.decision ? `<p class="small">⚖️ ${esc(c.decision)}</p>` : ''}<button class="btn sm alt" data-cfile="${c.id}">📂 الملف الكامل</button></div>`).join('') || '<div class="empty">لا شكاوى 👌</div>'}`,
        bind: () => {
          const { $$ } = K();
          $$('[data-cst]').forEach((b) => { b.onclick = () => window.dxFinance(`v8comp:${b.dataset.cst}`); });
          $$('[data-cfile]').forEach((b) => { b.onclick = () => complaintFile(Number(b.dataset.cfile)); });
        },
      };
    },
  };

  async function complaintFile(id) {
    const { api, esc, toast, fail, pane } = K();
    let r;
    try { r = await api('GET', `/api/admin/finance/complaints/${id}`); } catch (e) { return fail(e); }
    const c = r.complaint, d = r.driver, s = r.store;
    const DOCN = { selfie: 'صورة شخصية', idFront: 'الهوية (أمام)', idBack: 'الهوية (خلف)', idCard: 'الهوية', license: 'رخصة القيادة', vehicleFront: 'المركبة (أمام)', vehicleBack: 'المركبة (خلف)', registration: 'دفتر المركبة', criminalRecord: 'السجل العدلي' };
    pane().innerHTML = `<button class="btn sm alt" id="cback">→ رجوع للشكاوى</button>
      <div class="card"><div class="row"><h2>${esc(c.ref)}</h2><span class="chip ${CST[c.status]?.[1] || ''}">${CST[c.status]?.[0] || c.status}</span></div>
        <p>${money(c.amount)}${c.orderRef ? ` · ${esc(c.orderRef)}` : ''} · ${esc(when(c.at))}</p><p dir="auto">📝 ${esc(c.body)}</p></div>
      <div class="card"><h3>🏪 المتجر</h3><p>${esc(s.name)} · 📱 <a href="tel:+${esc(s.phone)}" dir="ltr">+${esc(s.phone)}</a></p></div>
      <div class="card"><h3>🛵 السائق</h3><p>${esc(d.name)} <small class="mute">D${d.id}</small> · 📱 <a href="tel:+${esc(d.phone)}" dir="ltr">+${esc(d.phone)}</a></p>
        <p class="small">${esc(d.vehicle || '')}${d.plate ? ` · لوحة ${esc(d.plate)}` : ''} · مسجّل منذ ${esc(when(d.since))} · الحالة ${esc(d.status)}</p>
        <p class="small mute">🔒 الوثائق للإدارة فقط ولا تظهر للمتجر أو الزبون:</p>
        <div class="grid2">${d.documents.map((x) => `<button class="btn sm alt" data-doc="${esc(x.url)}">📄 ${DOCN[x.kind] || esc(x.kind)}</button>`).join('') || '<span class="mute small">لا وثائق</span>'}</div></div>
      ${r.invoice ? `<div class="card"><h3>🧾 ${esc(r.invoice.ref)}</h3><p class="small">البضاعة ${money(r.invoice.goods)} · التوصيل ${money(r.invoice.deliveryFee)} · المدفوع ${money(r.invoice.paid)} · المتبقّي <b>${money(r.invoice.remaining)}</b> · ${IST[r.invoice.status] || r.invoice.status}</p></div>` : ''}
      <div class="card"><h3>🔔 التذكيرات</h3>${r.reminders.map((x) => `<p class="small">${x.kind === 'store_remind' ? 'المتجر ذكّر السائق' : 'السائق ذكّر المتجر'} · ${esc(when(x.created_at))}</p>`).join('') || '<p class="small mute">لا تذكيرات</p>'}</div>
      <div class="card"><h3>💱 التأكيدات والدفعات</h3>${r.payments.map((p) => `<p class="small">${esc(p.ref)} · السائق ${p.driverSays == null ? '—' : money(p.driverSays)} · المتجر ${p.storeSays == null ? '—' : money(p.storeSays)} · ${PST[p.status]?.[0] || p.status}</p>`).join('') || '<p class="small mute">لا شيء</p>'}</div>
      <div class="card"><h3>📒 سجلّ المراجعة</h3>${r.log.map((l) => `<p class="small">${esc(l.actor)} · ${esc(l.action)}${l.note ? ` — ${esc(l.note)}` : ''} · ${esc(when(l.created_at))}</p>`).join('')}</div>
      ${['open', 'reviewing'].includes(c.status) ? `<form class="card" id="cdec"><h3>⚖️ قرار الإدارة</h3><label class="f">الحالة<select class="in" name="status"><option value="reviewing">قيد المراجعة</option><option value="resolved">حُسمت</option><option value="rejected">رُفضت</option></select></label>
        <label class="f">القرار / الملاحظة<textarea class="in" name="decision" maxlength="1000"></textarea></label><button class="btn">حفظ</button></form>` : ''}`;
    K().$('#cback').onclick = () => window.dxFinance('v8comp');
    K().$$('[data-doc]').forEach((b) => { b.onclick = () => window.openPrivateImage?.(b.dataset.doc); });
    K().$('#cdec')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      try { await api('POST', `/api/admin/finance/complaints/${id}/decision`, { status: e.target.status.value, decision: e.target.decision.value }); toast('حُفظ القرار'); complaintFile(id); } catch (x) { fail(x); }
    });
  }

  window.dxMoney = views;
})();
