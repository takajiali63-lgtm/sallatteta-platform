// لوحة الإدارة — اشتراكات Google Play وApple (للمالك فقط).
// لا يُفعَّل أي اشتراك لأن الهاتف قال «دفعت»: الخادم يسأل Google أو يتحقق من توقيع Apple بنفسه.
(() => {
  const SUBJECT = { store: 'متجر', driver: 'سائق' };
  const GROUP = { shops: 'المتاجر', online: 'المتاجر الإلكترونية', crafts: 'الحِرفيون', drivers: 'السائقون' };
  const GROUPS = { store: ['shops', 'online', 'crafts'], driver: ['drivers'] };
  const TIER = { basic: 'أساسي', ai: 'المدير الذكي AI' };
  const STATE = { active: 'فعّال', grace: 'مهلة سماح', on_hold: 'معلّق (فشل الدفع)', paused: 'متوقف مؤقتًا', cancelled: 'أُلغي التجديد (فعّال حتى النهاية)', expired: 'منتهٍ', refunded: 'مُستردّ', revoked: 'مسحوب', pending: 'بانتظار الدفع' };
  const PLATFORM = { google: 'Google Play', apple: 'Apple' };
  const ENV_HELP = {
    GOOGLE_PLAY_PACKAGE: 'اسم حزمة تطبيق Android (مثل net.aklatak.app)',
    GOOGLE_PLAY_SERVICE_ACCOUNT_JSON: 'مفتاح حساب الخدمة (JSON أو base64)',
    GOOGLE_RTDN_TOKEN: 'كلمة سرّ طويلة في رابط إشعارات Google',
    GOOGLE_RTDN_AUDIENCE: 'اختياري: الجمهور (audience) لتوقيع Google على الإشعارات',
    APPLE_BUNDLE_ID: 'معرّف تطبيق iPhone (Bundle ID)',
    APPLE_ENVIRONMENT: 'Production أو Sandbox',
  };
  const when = (s) => { if (!s) return '—'; try { return new Date(s).toLocaleString('ar-LB', { dateStyle: 'short', timeStyle: 'short' }); } catch { return s; } };
  let filt = { state: '', platform: '' };

  window.dxExtra = window.dxExtra || {};
  window.dxExtra.billing = async () => {
    const { api, esc, $, $$, toast, fail, pane } = window.dxKit;
    const cfg = await api('GET', '/api/admin/billing/config');
    const qs = new URLSearchParams(Object.entries(filt).filter(([, v]) => v)).toString();
    const [{ entitlements }, { events }] = await Promise.all([
      api('GET', `/api/admin/billing/entitlements${qs ? `?${qs}` : ''}`), api('GET', '/api/admin/billing/events'),
    ]);
    let rows = Object.entries(cfg.products).map(([id, m]) => ({ id, ...m }));
    const envVal = (v) => (v === 'ok' || v === true ? '<b class="ok">✅ مضبوط</b>' : v === 'invalid' ? '<b class="bad">⚠️ موجود لكنه غير صالح</b>' : '<span class="mute">❌ غير مضبوط</span>');
    const opt = (map, cur, keys = Object.keys(map)) => keys.map((k) => `<option value="${k}" ${k === cur ? 'selected' : ''}>${esc(map[k])}</option>`).join('');

    // one small card per product (fits a phone screen; a wide table does not)
    function productRows() {
      return rows.map((r, i) => `<div class="card" data-i="${i}">
        <label class="f small">معرّف المنتج<input class="in" data-f="id" value="${esc(r.id)}" dir="ltr" maxlength="100" placeholder="aklatak.shop.ai.monthly"></label>
        <div class="grid2">
          <label class="f small">لمن<select class="in" data-f="subject">${opt(SUBJECT, r.subject)}</select></label>
          <label class="f small">الفئة<select class="in" data-f="group">${opt(GROUP, r.group, GROUPS[r.subject])}</select></label>
          <label class="f small">الباقة<select class="in" data-f="tier">${opt(TIER, r.tier)}</select></label>
          <label class="f small">أشهر<select class="in" data-f="months">${[1, 3, 6, 12].map((m) => `<option value="${m}" ${m === Number(r.months) ? 'selected' : ''}>${m}</option>`).join('')}</select></label>
        </div>
        <button class="btn sm alt" data-del="${i}">حذف هذا المنتج</button></div>`).join('');
    }

    pane().innerHTML = `
      <div class="card"><h3>⚙️ حالة الإعداد</h3>
        <p class="small mute">تُضبط في Render ← Environment. هنا يظهر فقط إن كانت مضبوطة — لا تظهر قيمها أبدًا.</p>
        ${Object.entries(cfg.env).map(([k, v]) => `<p><span dir="ltr"><b>${esc(k)}</b></span><br>${envVal(v)} <span class="small mute">— ${esc(ENV_HELP[k] || '')}</span></p>`).join('')}
        <p>Google Play: ${cfg.google ? '✅ جاهز' : '❌ غير جاهز'} · الإشعارات الفورية: ${cfg.rtdn ? '✅ جاهزة' : '❌ غير جاهزة'} · Apple: ${cfg.apple ? `✅ جاهز (${esc(cfg.appleEnvironment)})` : '❌ غير جاهز'}</p>
        <p class="small">رابط إشعارات Google (Pub/Sub push) — ضع مكان … قيمة GOOGLE_RTDN_TOKEN:<input class="in" readonly dir="ltr" value="${esc(cfg.urls.rtdn)}"></p>
        <p class="small">رابط إشعارات Apple (App Store Server Notifications V2):<input class="in" readonly dir="ltr" value="${esc(cfg.urls.apple)}"></p>
      </div>

      <div class="card"><h3>🧾 المنتجات (معرّف المنتج في المتجر ← ماذا يعطي)</h3>
        <p class="small mute">اكتب نفس معرّف المنتج الذي أنشأته في Play Console / App Store Connect. التطبيق يقرأ هذه القائمة — لا شيء مكتوب داخله.</p>
        <div id="bpRows">${productRows()}</div>
        <div class="row"><button class="btn alt" id="bpAdd">+ منتج</button><button class="btn" id="bpSave">حفظ المنتجات</button></div>
      </div>

      <div class="card"><h3>📱 الاشتراكات المشتراة من التطبيق</h3>
        <div class="row">
          <select class="in" id="bfState"><option value="">كل الحالات</option>${opt(STATE, filt.state)}</select>
          <select class="in" id="bfPlat"><option value="">كل المنصّات</option>${opt(PLATFORM, filt.platform)}</select>
        </div>
        <div class="scrollx"><table class="tbl"><tr><th>#</th><th>المنصّة</th><th>الحساب</th><th>المنتج</th><th>الحالة</th><th>ينتهي</th><th>تجديد تلقائي</th><th>آخر حدث</th><th></th></tr>
        ${entitlements.map((e) => `<tr><td>${e.id}</td><td>${esc(PLATFORM[e.platform])}${e.environment && e.environment !== 'production' && e.environment !== 'Production' ? ` <span class="small mute">(${esc(e.environment)})</span>` : ''}</td>
          <td>${e.owner_type ? `${esc(SUBJECT[e.owner_type])} #${e.owner_id} ${esc(e.owner_name || '')}` : '<span class="mute">غير مربوط بعد</span>'}</td>
          <td dir="ltr" class="small">${esc(e.product_id)}</td><td>${esc(STATE[e.state] || e.state)}${e.reason ? ` <span class="small mute">(${esc(e.reason)})</span>` : ''}</td>
          <td>${when(e.expires_at)}</td><td>${Number(e.auto_renew) ? 'نعم' : 'لا'}</td><td class="small">${when(e.last_event_at)}</td>
          <td><button class="btn sm alt" data-ev="${e.id}">السجل</button>${e.platform === 'google' ? ` <button class="btn sm alt" data-sync="${e.id}">تحديث من Google</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="9" class="mute">لا شيء بعد</td></tr>'}
        </table></div>
      </div>

      <div class="card"><h3>📜 سجل الأحداث</h3><div class="scrollx" id="bEvents">${eventsTable(events)}</div></div>`;

    function eventsTable(list) {
      return `<table class="tbl"><tr><th>الوقت</th><th>المنصّة</th><th>النوع</th><th>الاشتراك</th><th>من ← إلى</th><th>التفاصيل</th></tr>
        ${list.map((v) => `<tr><td class="small">${when(v.created_at)}</td><td>${esc(PLATFORM[v.platform] || v.platform)}</td><td dir="ltr" class="small">${esc(v.type)}</td>
          <td>${v.entitlement_id ? `#${v.entitlement_id}` : '—'}</td><td>${esc(STATE[v.state_before] || v.state_before || '—')} ← ${esc(STATE[v.state_after] || v.state_after || '—')}</td>
          <td dir="ltr" class="small">${esc(String(v.details || '').slice(0, 300))}</td></tr>`).join('') || '<tr><td colspan="6" class="mute">لا أحداث</td></tr>'}</table>`;
    }
    const readRows = () => $$('#bpRows [data-i]').forEach((tr) => {
      const r = rows[Number(tr.dataset.i)];
      for (const el of $$('[data-f]', tr)) r[el.dataset.f] = el.dataset.f === 'months' ? Number(el.value) : el.value.trim();
      if (!GROUPS[r.subject].includes(r.group)) r.group = GROUPS[r.subject][0];
    });
    function bindRows() {
      $$('#bpRows [data-f="subject"]').forEach((el) => { el.onchange = () => { readRows(); $('#bpRows').innerHTML = productRows(); bindRows(); }; });
      $$('#bpRows [data-del]').forEach((b) => { b.onclick = () => { readRows(); rows.splice(Number(b.dataset.del), 1); $('#bpRows').innerHTML = productRows(); bindRows(); }; });
    }
    bindRows();
    $('#bpAdd').onclick = () => { readRows(); rows.push({ id: '', subject: 'store', group: 'shops', tier: 'basic', months: 1 }); $('#bpRows').innerHTML = productRows(); bindRows(); };
    $('#bpSave').onclick = async () => {
      readRows();
      const bad = rows.find((r) => !/^[a-z0-9][a-z0-9._]{1,99}$/.test(r.id));
      if (bad) return toast(`معرّف غير صالح: «${bad.id || 'فارغ'}» — أحرف إنكليزية صغيرة وأرقام ونقطة و _ فقط`);
      if (new Set(rows.map((r) => r.id)).size !== rows.length) return toast('معرّف مكرّر');
      const products = Object.fromEntries(rows.map((r) => [r.id, { subject: r.subject, group: r.group, tier: r.tier, months: Number(r.months) }]));
      try { await api('PUT', '/api/admin/billing/products', { products }); toast('حُفظت المنتجات'); } catch (e) { fail(e); }
    };
    $('#bfState').onchange = (e) => { filt.state = e.target.value; window.dxExtra.billing().catch(fail); };
    $('#bfPlat').onchange = (e) => { filt.platform = e.target.value; window.dxExtra.billing().catch(fail); };
    $$('[data-ev]').forEach((b) => { b.onclick = async () => {
      try { const { events: ev } = await api('GET', `/api/admin/billing/events?entitlement=${b.dataset.ev}`); $('#bEvents').innerHTML = eventsTable(ev); $('#bEvents').scrollIntoView({ behavior: 'smooth' }); } catch (e) { fail(e); }
    }; });
    $$('[data-sync]').forEach((b) => { b.onclick = async () => {
      b.disabled = true;
      try { const r = await api('POST', `/api/admin/billing/entitlements/${b.dataset.sync}/resync`, {}); toast(`الحالة الآن: ${STATE[r.state] || r.state}`); window.dxExtra.billing().catch(fail); }
      catch (e) { b.disabled = false; fail(e); }
    }; });
  };
})();
