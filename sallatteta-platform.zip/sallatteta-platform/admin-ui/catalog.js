// v8.4 admin — «الكتالوج والخدمات»: drivers' allowed service types (what independent drivers may offer customers, never
// passengers or forbidden items), every driver's listed service (stop one that breaks the rules), and live counters
// (promotions, product options, open quotes).
(() => {
  window.dxExtra = window.dxExtra || {};
  const money = (c) => `${(Number(c || 0) / 100).toFixed(2)}$`;
  const ERR = { forbidden_service: 'هذا النوع ممنوع (نقل ركاب أو مواد غير قانونية)', validation_failed: 'تحقّق من المفاتيح: أحرف إنكليزية صغيرة وأرقام فقط' };
  window.dxExtra.catalog = async function catalogSection() {
    const { api, esc, $, $$, toast, fail, pane } = window.dxKit;
    const [{ types }, o] = await Promise.all([api('GET', '/api/admin/catalog/service-types'), api('GET', '/api/admin/catalog/overview')]);
    pane().innerHTML = `<div class="grid2">
        <div class="stat"><b>${o.promotionsLive}</b><span>🏷 عروض سارية الآن</span></div>
        <div class="stat"><b>${o.optionGroups}</b><span>➕ مجموعات خيارات وإضافات</span></div>
        <div class="stat"><b>${o.driversListed}</b><span>🛵 سائقون يعرضون خدماتهم</span></div>
        <div class="stat"><b>${o.quotesOpen + o.visitQuotesOpen}</b><span>💬 عروض أسعار مفتوحة</span></div></div>
      <form id="stf" class="card"><h3>🧰 أنواع خدمات السائقين المسموحة</h3>
        <p class="small mute">يختار السائق منها ما يقدّمه ويحدّد سعره. نقل الركاب والمواد الممنوعة مرفوضة تلقائياً. الطلبات المباشرة منفصلة تماماً عن طلبات المطاعم.</p>
        <div id="stl">${types.map((x, i) => row(x, i, esc)).join('')}</div>
        <button type="button" class="btn alt" id="stAdd">➕ نوع جديد</button> <button class="btn">حفظ الأنواع</button></form>
      <div class="card"><h3>📋 خدمات السائقين المنشورة</h3>
        ${o.services.map((s) => `<div class="row item"><span>${s.active ? '🟢' : '⏸'} <b>${esc(s.full_name)}</b> <small class="mute">D${s.driver_id} · ${esc(s.country)}</small><br><small>${esc(s.type)} — ${esc(s.description || '')} · ${s.price_mode === 'quote' ? 'بعرض سعر' : money(s.price_cents)}</small></span>
          <button class="btn sm ${s.active ? 'bad' : ''}" data-sv="${s.id}" data-to="${s.active ? 'disable' : 'enable'}">${s.active ? 'إيقاف' : 'تشغيل'}</button></div>`).join('') || '<div class="empty">لا خدمات بعد</div>'}</div>`;
    $('#stAdd').onclick = () => { const l = $('#stl'); l.insertAdjacentHTML('beforeend', row({ key: '', errand: 'service', names: {} }, l.children.length, esc)); };
    $('#stl').addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) b.closest('.strow').remove(); });
    $('#stf').addEventListener('submit', async (e) => {
      e.preventDefault();
      const list = $$('.strow').map((r) => ({ key: r.querySelector('[data-k=key]').value.trim(), errand: r.querySelector('[data-k=errand]').value, names: Object.fromEntries(['ar', 'en', 'fr', 'es'].map((l) => [l, r.querySelector(`[data-k=${l}]`).value.trim()])) }));
      try { await api('PUT', '/api/admin/catalog/service-types', { types: list }); toast('تم الحفظ'); catalogSection().catch(fail); } catch (x) { toast(ERR[x.code] || 'حدث خطأ'); }
    });
    $$('[data-sv]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/catalog/driver-services/${b.dataset.sv}/${b.dataset.to}`, {}); toast('تم'); catalogSection().catch(fail); } catch (x) { fail(x); } }; });
  };
  function row(x, i, esc) {
    return `<div class="card strow"><div class="grid2"><label class="f">المفتاح (إنكليزي)<input class="in" data-k="key" dir="ltr" maxlength="30" value="${esc(x.key)}" required></label>
      <label class="f">النوع<select class="in" data-k="errand"><option value="deliver" ${x.errand === 'deliver' ? 'selected' : ''}>توصيل غرض</option><option value="buy" ${x.errand === 'buy' ? 'selected' : ''}>شراء وإحضار</option><option value="service" ${x.errand === 'service' ? 'selected' : ''}>خدمة</option></select></label>
      <label class="f">العربية<input class="in" data-k="ar" maxlength="40" value="${esc(x.names?.ar || '')}"></label><label class="f">English<input class="in" data-k="en" dir="ltr" maxlength="40" value="${esc(x.names?.en || '')}"></label>
      <label class="f">Français<input class="in" data-k="fr" dir="ltr" maxlength="40" value="${esc(x.names?.fr || '')}"></label><label class="f">Español<input class="in" data-k="es" dir="ltr" maxlength="40" value="${esc(x.names?.es || '')}"></label></div>
      <button type="button" class="btn sm bad" data-rm>حذف</button></div>`;
  }
})();
