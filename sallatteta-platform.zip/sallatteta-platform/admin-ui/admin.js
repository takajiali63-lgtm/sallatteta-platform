import { initI18n, t, api, errorText, esc, applyI18n, fmtNumber } from '/assets/i18n.js?v=232';
import { areaSearch, servedAreasEditor, starsHtml } from '/assets/ui.js?v=232';

const $ = (s, r = document) => r.querySelector(s);
const FILTERS = ['pending', 'active', 'expired', 'suspended', 'rejected', 'no_subscription', 'all', 'feedback'];
const st = { filter: 'pending', fbStatus: 'new', q: '', config: null, current: null };

const dateOnly = (v) => (v ? new Date(v).toISOString().slice(0, 10) : '');
const fmtDate = (v) => (v ? new Date(v).toLocaleDateString('ar-LB-u-nu-latn', { year: 'numeric', month: 'short', day: 'numeric' }) : '—');
const pill = (s) => `<span class="pill ${esc(s)}">${esc(t(`status.${s}`))}</span>`;

/* ---------- auth ---------- */
async function boot() {
  await initI18n();
  st.config = await api('/api/config');
  $('#districtSel').innerHTML = st.config.districts.map((d) => `<option value="${d.key}">${esc(d.name)}</option>`).join('');
  try {
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch { showLogin(); }
}
function showLogin() { $('#loginView').hidden = false; $('#dashView').hidden = true; $('#logoutBtn').hidden = true; $('#u').focus(); }
async function showDash() {
  $('#loginView').hidden = true; $('#dashView').hidden = false; $('#logoutBtn').hidden = false;
  renderTabs();
  await Promise.all([loadStats(), loadView()]);
}
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginError').hidden = true;
  try {
    await api('/api/admin/login', { method: 'POST', body: { username: e.target.username.value, password: e.target.password.value } });
    e.target.reset();
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch (err) { $('#loginError').textContent = errorText(err); $('#loginError').hidden = false; }
});
$('#logoutBtn').addEventListener('click', async () => { await api('/api/admin/logout', { method: 'POST', body: {} }).catch(() => {}); showLogin(); });

async function call(path, opts) {
  try { return await api(path, opts); }
  catch (err) { if (err.status === 401) { $('#dlg').close(); showLogin(); } throw err; }
}

/* ---------- dashboard ---------- */
async function loadStats() {
  const s = await call('/api/admin/stats');
  st.newFeedback = s.new_feedback;
  const items = [
    [s.active_cooks, 'admin.stats.active'], [s.pending_applications, 'admin.stats.pending'], [s.new_feedback, 'admin.stats.feedback'],
    [s.searches_30d, 'admin.stats.searches'], [s.whatsapp_clicks_30d, 'admin.stats.clicks'], [s.empty_searches_30d, 'admin.stats.empty'],
  ];
  $('#stats').innerHTML = items.map(([n, k]) => `<div class="stat"><b>${fmtNumber(n)}</b><span>${esc(t(k))}</span></div>`).join('');
  renderTabs();
}

function renderTabs() {
  $('#tabs').innerHTML = FILTERS.map((f) => {
    const label = f === 'feedback' ? t('admin.feedbackTab') : t(`admin.filters.${f}`);
    const badge = f === 'feedback' && st.newFeedback ? `<em>${st.newFeedback}</em>` : '';
    return `<button type="button" role="tab" data-f="${f}" aria-selected="${f === st.filter}">${esc(label)}${badge}</button>`;
  }).join('');
}
$('#tabs').addEventListener('click', (e) => {
  const b = e.target.closest('[data-f]');
  if (!b) return;
  st.filter = b.dataset.f;
  renderTabs();
  loadView();
});
let qTimer;
$('#q').addEventListener('input', (e) => { clearTimeout(qTimer); qTimer = setTimeout(() => { st.q = e.target.value; loadView(); }, 250); });

function loadView() {
  const fb = st.filter === 'feedback';
  $('#feedbackView').hidden = !fb;
  $('#list').hidden = fb;
  $('#emptyList').hidden = true;
  return fb ? loadFeedback() : loadList();
}

async function loadList() {
  const { cooks } = await call(`/api/admin/cooks?filter=${st.filter}&q=${encodeURIComponent(st.q)}`);
  $('#emptyList').hidden = cooks.length > 0;
  $('#list').innerHTML = cooks.map((c) => `
    <li><button class="admin-row" type="button" data-id="${c.id}">
      <span>
        <span class="cook-name">${esc(c.fullName)}</span>
        <span class="cook-meta">${esc(c.area)} — <span dir="ltr">+${esc(c.whatsapp)}</span></span>
        <span class="cook-meta">${starsHtml(c.rating)} ${c.warnings ? ` · ${esc(t('admin.warningsCount', { n: c.warnings }))}` : ''} ${c.openFeedback ? ` · <b class="warn">${esc(t('admin.openFeedback', { n: c.openFeedback }))}</b>` : ''}</span>
      </span>
      <span class="nums">
        ${pill(c.effectiveStatus)}<br>
        ${c.expiryDate ? esc(t('admin.expires', { date: fmtDate(c.expiryDate) })) : c.requestedPlan ? esc(t(`plans.${c.requestedPlan}`)) : ''}<br>
        ${esc(t('admin.impressions'))}: ${c.impressions} — WhatsApp: ${c.whatsappClicks}
      </span>
    </button></li>`).join('');
}
$('#list').addEventListener('click', (e) => { const b = e.target.closest('[data-id]'); if (b) openCook(Number(b.dataset.id)); });
$('#addBtn').addEventListener('click', () => openNew());

/* ---------- complaints & notes ---------- */
async function loadFeedback() {
  $('#fbTabs').innerHTML = [['new', 'admin.newFeedback'], ['resolved', 'admin.resolved'], ['all', 'admin.allFeedback']]
    .map(([k, l]) => `<button type="button" data-s="${k}" aria-selected="${k === st.fbStatus}">${esc(t(l))}</button>`).join('');
  const { feedback } = await call(`/api/admin/feedback?status=${st.fbStatus}`);
  $('#fbEmpty').hidden = feedback.length > 0;
  $('#fbList').innerHTML = feedback.map((f) => `
    <li class="fb-item">
      <div class="fb-head"><span class="pill ${f.kind === 'complaint' ? 'expired' : 'active'}">${esc(t(`admin.${f.kind}`))}</span>
        <button class="btn-text" type="button" data-cook="${f.cook_id}">${esc(f.cook_name)}</button>
        <span class="fine">${fmtDate(f.created_at)}${f.cook_warnings ? ` · ${esc(t('admin.warningsCount', { n: f.cook_warnings }))}` : ''}</span></div>
      <p class="fb-msg">${esc(f.message)}</p>
      <p class="fine">${esc(t('admin.customer'))}: ${esc(f.customer_name || '—')} ${f.customer_phone ? `· <a dir="ltr" href="https://wa.me/${esc(f.customer_phone)}" target="_blank" rel="noopener">+${esc(f.customer_phone)}</a>` : ''}</p>
      ${f.admin_note ? `<p class="fine">${esc(t('admin.adminNote'))}: ${esc(f.admin_note)}</p>` : ''}
      <div class="actions">
        <button class="btn btn-danger" type="button" data-warn="${f.id}" data-cookid="${f.cook_id}" data-name="${esc(f.cook_name)}" data-msg="${esc(f.message)}" data-n="${f.cook_warnings + 1}">${esc(t('admin.warn'))}</button>
        <button class="btn btn-ghost" type="button" data-fb="${f.id}" data-to="${f.status === 'new' ? 'resolved' : 'new'}">${esc(t(f.status === 'new' ? 'admin.resolve' : 'admin.reopen'))}</button>
      </div>
    </li>`).join('');
}
$('#fbTabs').addEventListener('click', (e) => { const b = e.target.closest('[data-s]'); if (b) { st.fbStatus = b.dataset.s; loadFeedback(); } });
$('#fbList').addEventListener('click', async (e) => {
  const cookBtn = e.target.closest('[data-cook]');
  if (cookBtn) return openCook(Number(cookBtn.dataset.cook));
  const fbBtn = e.target.closest('[data-fb]');
  if (fbBtn) { await call(`/api/admin/feedback/${fbBtn.dataset.fb}`, { method: 'PATCH', body: { status: fbBtn.dataset.to } }); loadFeedback(); loadStats(); return; }
  const w = e.target.closest('[data-warn]');
  if (w) openWarning({ cookId: Number(w.dataset.cookid), name: w.dataset.name, message: w.dataset.msg, n: Number(w.dataset.n), feedbackId: Number(w.dataset.warn) });
});

/* ---------- dialog ---------- */
const dlg = $('#dlg');
$('#dlgClose').addEventListener('click', () => dlg.close());
dlg.addEventListener('close', () => { loadView(); loadStats(); });
function msg(text, ok = true) { const m = $('#dlgMsg'); m.textContent = text; m.className = `alert ${ok ? 'ok' : ''}`; m.hidden = !text; if (text) m.scrollIntoView({ block: 'nearest' }); }
function errMsg(err) {
  const fields = Object.entries(err.fields || {}).map(([k, v]) => `${k}: ${t(`errors.${v}`)}`).join(' — ');
  msg(`${errorText(err)}${fields ? ' — ' + fields : ''}`, false);
}

function openWarning({ cookId, name, message, n, feedbackId }) {
  msg('');
  $('#dlgTitle').textContent = `${t('admin.warn')} — ${name}`;
  const text = t('wa.warning', { name, message: message || '…', n });
  $('#dlgBody').innerHTML = `<div class="panel"><form id="warnForm">
    <div class="field"><textarea class="input" name="message" rows="9">${esc(text)}</textarea></div>
    <button class="btn btn-danger" type="submit">${esc(t('admin.warnSend'))}</button></form></div>`;
  $('#warnForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await call(`/api/admin/cooks/${cookId}/warnings`, { method: 'POST', body: { message: e.target.message.value, feedbackId: feedbackId || undefined } });
      window.open(r.whatsappUrl, '_blank', 'noopener');
      await openCook(cookId);
      msg(t('admin.saved'));
    } catch (err) { errMsg(err); }
  });
  if (!dlg.open) dlg.showModal();
}

function buildForm(cook) {
  const frag = $('#cookFormTpl').content.cloneNode(true);
  const form = $('form', frag);
  applyI18n(frag);
  let homeId = cook?.area_id || null;
  $('[data-services]', form).innerHTML = st.config.serviceTypes.map((k) =>
    `<label class="chip"><input type="checkbox" name="services" value="${k}" ${cook?.services?.includes(k) ? 'checked' : ''}><span>${esc(t(`services.${k}`))}</span></label>`).join('');
  const editor = servedAreasEditor($('[data-served]', form), { initial: cook?.servedAreas || [], point: cook ? { lat: cook.lat, lng: cook.lng } : null, districts: st.config.districts });
  const homeLabel = $('[data-home]', form);
  homeLabel.textContent = cook ? t('location.picked', { area: cook.area_label }) : '';
  areaSearch(form.areaSearch, { onPick: (a) => { homeId = a.id; homeLabel.textContent = t('location.picked', { area: a.name }); editor.setPoint(a.lat, a.lng).catch(() => {}); } });
  if (cook) {
    form.fullName.value = cook.full_name;
    form.whatsapp.value = '+' + cook.whatsapp;
    form.lat.value = cook.lat; form.lng.value = cook.lng;
    form.bio.value = cook.bio || '';
    form.adminNotes.value = cook.admin_notes || '';
    if (cook.has_photo) {
      $('[data-photo-field]', form).hidden = false;
      $('[data-photo]', form).src = `/api/admin/cooks/${cook.id}/photo?ts=${Date.now()}`;
    }
  } else {
    $('[data-activate-block]', form).hidden = false;
  }
  $('[data-submit]', form).textContent = t(cook ? 'admin.save' : 'admin.create');
  let removePhoto = false;
  $('[data-photo-remove]', form)?.addEventListener('click', () => { removePhoto = true; $('[data-photo-field]', form).hidden = true; });
  form.readBody = () => {
    const b = {
      fullName: form.fullName.value, whatsapp: form.whatsapp.value, areaId: homeId,
      bio: form.bio.value, adminNotes: form.adminNotes.value,
      services: [...form.querySelectorAll('input[name="services"]:checked')].map((i) => i.value),
      servedAreaIds: editor.ids(),
    };
    const latChanged = cook && (String(form.lat.value) !== String(cook.lat) || String(form.lng.value) !== String(cook.lng));
    if ((!cook || latChanged) && form.lat.value !== '' && form.lng.value !== '') { b.lat = Number(form.lat.value); b.lng = Number(form.lng.value); }
    if (removePhoto) b.photo = null;
    return b;
  };
  return form;
}

function subscriptionPanel(c) {
  const s = c.subscription;
  const planOpts = st.config.plans.map((p) => `<option value="${p}" ${p === (s?.plan || c.requested_plan) ? 'selected' : ''}>${esc(t(`plans.${p}`))}</option>`).join('');
  const payOpts = ['paid', 'unpaid', 'waived'].map((p) => `<option value="${p}" ${p === (s?.payment_status === 'unpaid' ? 'paid' : s?.payment_status || 'paid') ? 'selected' : ''}>${esc(t(`payment.${p}`))}</option>`).join('');
  return `
  <div class="panel">
    <h3>${esc(t('admin.subscription'))}</h3>
    ${s ? `<dl class="kv">
      <dt>${esc(t('admin.status'))}</dt><dd>${pill(c.effectiveStatus)}</dd>
      <dt>${esc(t('admin.plan'))}</dt><dd>${esc(t(`plans.${s.plan}`))}</dd>
      <dt>${esc(t('admin.paymentStatus'))}</dt><dd>${esc(t(`payment.${s.payment_status}`))}</dd>
      <dt>${esc(t('admin.startDate'))}</dt><dd>${fmtDate(s.start_date)}</dd>
      <dt>${esc(t('admin.expiryDate'))}</dt><dd>${fmtDate(s.expiry_date)}</dd>
    </dl>` : `<p class="fine">${esc(t('admin.noSubscription'))}</p>`}
    <form id="subForm">
      <div class="grid2">
        <div class="field"><label>${esc(t('admin.plan'))}</label><select class="input" name="plan">${planOpts}</select></div>
        <div class="field"><label>${esc(t('admin.paymentStatus'))}</label><select class="input" name="paymentStatus">${payOpts}</select></div>
      </div>
      <div class="grid2">
        <div class="field"><label>${esc(t('admin.startDate'))}</label><input class="input" type="date" name="startDate" value="${dateOnly(s?.start_date) || dateOnly(new Date())}"></div>
        <div class="field"><label>${esc(t('admin.expiryDate'))}</label><input class="input" type="date" name="expiryDate" value="${dateOnly(s?.expiry_date)}"><span class="hint">${esc(t('admin.expiryAuto'))}</span></div>
      </div>
      <div class="actions">
        <button class="btn btn-gold" type="button" data-act="activate">${esc(t('admin.activate'))}</button>
        ${s ? `<button class="btn btn-ghost" type="button" data-act="renew">${esc(t('admin.renew'))}</button>
        <button class="btn btn-ghost" type="button" data-act="saveDates">${esc(t('admin.saveDates'))}</button>
        <button class="btn btn-danger" type="button" data-act="suspend">${esc(t('admin.suspend'))}</button>
        <button class="btn btn-danger" type="button" data-act="expire">${esc(t('admin.expireNow'))}</button>` : ''}
      </div>
    </form>
  </div>`;
}

async function openCook(id) {
  msg('');
  let c;
  try { c = await call(`/api/admin/cooks/${id}`); } catch { return; }
  st.current = c;
  $('#dlgTitle').textContent = c.full_name;
  const r = c.stats.rating;
  $('#dlgBody').innerHTML = `
    <div class="panel">
      <dl class="kv">
        <dt>${esc(t('admin.status'))}</dt><dd>${pill(c.effectiveStatus)}</dd>
        <dt>WhatsApp</dt><dd><a dir="ltr" href="https://wa.me/${esc(c.whatsapp)}" target="_blank" rel="noopener">+${esc(c.whatsapp)}</a></dd>
        <dt>${esc(t('admin.ratingLabel'))}</dt><dd>${starsHtml(r)}</dd>
        <dt>${esc(t('account.views'))}</dt><dd>${c.stats.views_total}</dd>
        <dt>${esc(t('account.likes'))}</dt><dd>${c.stats.likes}</dd>
        <dt>${esc(t('admin.impressions'))}</dt><dd>${c.stats.impressions}</dd>
        <dt>${esc(t('admin.clicks'))}</dt><dd>${c.stats.whatsapp_clicks}</dd>
        ${c.requested_plan ? `<dt>${esc(t('admin.requestedPlan'))}</dt><dd>${esc(t(`plans.${c.requested_plan}`))}</dd>` : ''}
        <dt>${esc(t('admin.createdAt'))}</dt><dd>${fmtDate(c.created_at)}</dd>
      </dl>
      <div class="actions">
        ${c.status !== 'approved' ? `<button class="btn btn-ghost" type="button" data-act="approve">${esc(t('admin.approve'))}</button>` : ''}
        ${c.status !== 'rejected' ? `<button class="btn btn-danger" type="button" data-act="reject">${esc(t('admin.reject'))}</button>` : ''}
        <a class="btn btn-ghost" href="/c/${c.id}" target="_blank" rel="noopener">${esc(t('results.viewProfile'))}</a>
      </div>
    </div>
    ${subscriptionPanel(c)}
    <div class="panel">
      <h3>${esc(t('account.loginTitle'))}</h3>
      <p class="fine">${esc(t(c.has_password ? 'admin.hasPassword' : 'admin.noPassword'))}</p>
      <p class="fine" id="pwOut"></p>
      <button class="btn btn-gold" type="button" data-act="password">${esc(t('admin.passwordBtn'))}</button>
    </div>
    <div class="panel">
      <h3>${esc(t('admin.warningsTitle'))} (${c.warnings.length})</h3>
      ${c.warnings.map((w) => `<p class="fine">${fmtDate(w.created_at)} — ${esc(w.message.slice(0, 140))}${w.message.length > 140 ? '…' : ''}</p>`).join('')}
      <button class="btn btn-danger" type="button" data-act="warn">${esc(t('admin.warn'))}</button>
    </div>
    <div class="panel">
      <h3>${esc(t('admin.photosTitle'))} (${c.photos.length})</h3>
      <div class="photo-grid">${c.photos.map((p) => `<figure><img src="${esc(p.url)}" alt=""><button class="del" type="button" data-delphoto="${p.id}">${esc(t('admin.deletePhoto'))}</button><figcaption>${esc(p.caption)}</figcaption></figure>`).join('')}</div>
    </div>
    <div class="panel"><h3>${esc(t('admin.info'))}</h3><div id="editSlot"></div></div>`;
  const form = buildForm(c);
  $('#editSlot').appendChild(form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await call(`/api/admin/cooks/${c.id}`, { method: 'PATCH', body: form.readBody() }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
  });
  $('#dlgBody').querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', () => act(b.dataset.act)));
  $('#dlgBody').querySelectorAll('[data-delphoto]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm(t('account.confirmDelete'))) return;
    await call(`/api/admin/photos/${b.dataset.delphoto}`, { method: 'DELETE' });
    await openCook(c.id);
  }));
  if (!dlg.open) dlg.showModal();
}

async function act(action) {
  const c = st.current;
  if (action === 'warn') return openWarning({ cookId: c.id, name: c.full_name, message: '', n: c.warnings.length + 1 });
  if (action === 'password') {
    try {
      const r = await call(`/api/admin/cooks/${c.id}/password`, { method: 'POST', body: {} });
      $('#pwOut').textContent = t('admin.passwordSet', { p: r.password });
      window.open(r.whatsappUrl, '_blank', 'noopener');
    } catch (err) { errMsg(err); }
    return;
  }
  const f = $('#subForm');
  const sub = { plan: f.plan.value, paymentStatus: f.paymentStatus.value, startDate: f.startDate.value || undefined, expiryDate: f.expiryDate.value || undefined };
  const confirms = { reject: 'admin.confirmReject', suspend: 'admin.confirmSuspend', expire: 'admin.confirmExpire' };
  if (confirms[action] && !confirm(t(confirms[action]))) return;
  const base = `/api/admin/cooks/${c.id}`;
  const req = {
    approve: [`${base}/approve`, 'POST', {}],
    reject: [`${base}/reject`, 'POST', {}],
    activate: [`${base}/subscription/activate`, 'POST', sub],
    renew: [`${base}/subscription/renew`, 'POST', { plan: sub.plan, paymentStatus: sub.paymentStatus }],
    saveDates: [`${base}/subscription`, 'PATCH', { plan: sub.plan, paymentStatus: sub.paymentStatus, startDate: sub.startDate, expiryDate: sub.expiryDate }],
    suspend: [`${base}/subscription/suspend`, 'POST', {}],
    expire: [`${base}/subscription/expire`, 'POST', {}],
  }[action];
  try { await call(req[0], { method: req[1], body: req[2] }); await openCook(c.id); msg(t('admin.saved')); }
  catch (err) { errMsg(err); }
}

function openNew() {
  msg('');
  st.current = null;
  $('#dlgTitle').textContent = t('admin.addCook');
  $('#dlgBody').innerHTML = '<div class="panel" id="newSlot"></div>';
  const form = buildForm(null);
  $('#newSlot').appendChild(form);
  const planSel = st.config.plans.map((p) => `<option value="${p}">${esc(t(`plans.${p}`))}</option>`).join('');
  $('[data-activate-block]', form).insertAdjacentHTML('beforeend',
    `<div class="grid2"><div class="field"><label>${esc(t('admin.plan'))}</label><select class="input" name="plan">${planSel}</select></div>
     <div class="field"><label>${esc(t('admin.startDate'))}</label><input class="input" type="date" name="startDate" value="${dateOnly(new Date())}"></div></div>`);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = form.readBody();
    if (form.activateNow.checked) b.activate = { plan: form.plan.value, startDate: form.startDate.value, paymentStatus: 'paid' };
    try { const c = await call('/api/admin/cooks', { method: 'POST', body: b }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
  });
  dlg.showModal();
}

$('#areaForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    await call('/api/admin/areas', { method: 'POST', body: { nameAr: f.nameAr.value, district: f.district.value, lat: f.lat.value || undefined, lng: f.lng.value || undefined } });
    f.reset();
    $('#areaMsg').textContent = t('admin.areaAdded');
  } catch (err) { $('#areaMsg').textContent = errorText(err); }
});

boot();
