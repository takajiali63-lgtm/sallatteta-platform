import { initI18n, t, api, errorText, esc, applyI18n, fmtNumber } from '/assets/i18n.js';

const $ = (s, r = document) => r.querySelector(s);
const FILTERS = ['pending', 'active', 'expired', 'suspended', 'rejected', 'no_subscription', 'all'];
const st = { filter: 'pending', q: '', config: null, cooks: [], current: null };

const dateOnly = (v) => (v ? new Date(v).toISOString().slice(0, 10) : '');
const fmtDate = (v) => (v ? new Date(v).toLocaleDateString('ar-LB-u-nu-latn', { year: 'numeric', month: 'short', day: 'numeric' }) : '—');
const pill = (s) => `<span class="pill ${esc(s)}">${esc(t(`status.${s}`))}</span>`;

/* ---------- auth ---------- */
async function boot() {
  await initI18n();
  st.config = await api('/api/config');
  try {
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch {
    showLogin();
  }
}
function showLogin() { $('#loginView').hidden = false; $('#dashView').hidden = true; $('#logoutBtn').hidden = true; $('#u').focus(); }
async function showDash() {
  $('#loginView').hidden = true; $('#dashView').hidden = false; $('#logoutBtn').hidden = false;
  renderTabs();
  await Promise.all([loadStats(), loadList()]);
}
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginError').hidden = true;
  try {
    await api('/api/admin/login', { method: 'POST', body: { username: e.target.username.value, password: e.target.password.value } });
    e.target.reset();
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch (err) {
    $('#loginError').textContent = errorText(err);
    $('#loginError').hidden = false;
  }
});
$('#logoutBtn').addEventListener('click', async () => { await api('/api/admin/logout', { method: 'POST', body: {} }).catch(() => {}); showLogin(); });

async function call(path, opts) {
  try { return await api(path, opts); }
  catch (err) { if (err.status === 401) { $('#dlg').close(); showLogin(); } throw err; }
}

/* ---------- dashboard ---------- */
async function loadStats() {
  const s = await call('/api/admin/stats');
  const items = [
    [s.active_cooks, 'admin.stats.active'], [s.pending_applications, 'admin.stats.pending'],
    [s.searches_30d, 'admin.stats.searches'], [s.whatsapp_clicks_30d, 'admin.stats.clicks'], [s.empty_searches_30d, 'admin.stats.empty'],
  ];
  $('#stats').innerHTML = items.map(([n, k]) => `<div class="stat"><b>${fmtNumber(n)}</b><span>${esc(t(k))}</span></div>`).join('');
}

function renderTabs() {
  $('#tabs').innerHTML = FILTERS.map((f) => `<button type="button" role="tab" data-f="${f}" aria-selected="${f === st.filter}">${esc(t(`admin.filters.${f}`))}</button>`).join('');
}
$('#tabs').addEventListener('click', (e) => {
  const b = e.target.closest('[data-f]');
  if (!b) return;
  st.filter = b.dataset.f;
  renderTabs();
  loadList();
});
let qTimer;
$('#q').addEventListener('input', (e) => { clearTimeout(qTimer); qTimer = setTimeout(() => { st.q = e.target.value; loadList(); }, 250); });

async function loadList() {
  const { cooks } = await call(`/api/admin/cooks?filter=${st.filter}&q=${encodeURIComponent(st.q)}`);
  st.cooks = cooks;
  $('#emptyList').hidden = cooks.length > 0;
  $('#list').innerHTML = cooks.map((c) => `
    <li><button class="admin-row" type="button" data-id="${c.id}">
      <span>
        <span class="cook-name">${esc(c.fullName)}</span>
        <span class="cook-meta">${esc(c.area)} — ${esc(t('common.km', { d: c.radiusKm }))} — <span dir="ltr">+${esc(c.whatsapp)}</span></span>
      </span>
      <span class="nums">
        ${pill(c.effectiveStatus)}<br>
        ${c.expiryDate ? esc(t('admin.expires', { date: fmtDate(c.expiryDate) })) : c.requestedPlan ? esc(t(`plans.${c.requestedPlan}`)) : ''}<br>
        ${esc(t('admin.impressions'))}: ${c.impressions} — WhatsApp: ${c.whatsappClicks}
      </span>
    </button></li>`).join('');
}
$('#list').addEventListener('click', (e) => { const b = e.target.closest('[data-id]'); if (b) openCook(Number(b.dataset.id)); });
$('#addBtn').addEventListener('click', () => openNew());

/* ---------- dialog ---------- */
const dlg = $('#dlg');
$('#dlgClose').addEventListener('click', () => dlg.close());
dlg.addEventListener('close', () => { loadList(); loadStats(); });
function msg(text, ok = true) { const m = $('#dlgMsg'); m.textContent = text; m.className = `alert ${ok ? 'ok' : ''}`; m.hidden = !text; if (text) m.scrollIntoView({ block: 'nearest' }); }
function errMsg(err) {
  const fields = Object.entries(err.fields || {}).map(([k, v]) => `${k}: ${t(`errors.${v}`)}`).join(' — ');
  msg(`${errorText(err)}${fields ? ' — ' + fields : ''}`, false);
}

function buildForm(cook) {
  const frag = $('#cookFormTpl').content.cloneNode(true);
  const form = $('form', frag);
  applyI18n(frag);
  form.areaId.innerHTML = st.config.areas.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join('');
  $('[data-services]', form).innerHTML = st.config.serviceTypes.map((k) =>
    `<label class="chip"><input type="checkbox" name="services" value="${k}" ${cook?.services?.includes(k) ? 'checked' : ''}><span>${esc(t(`services.${k}`))}</span></label>`).join('');
  if (cook) {
    form.fullName.value = cook.full_name;
    form.whatsapp.value = '+' + cook.whatsapp;
    if (cook.area_id) form.areaId.value = cook.area_id;
    form.radiusKm.value = cook.service_radius_km;
    form.lat.value = cook.lat; form.lng.value = cook.lng;
    form.bio.value = cook.bio || '';
    form.adminNotes.value = cook.admin_notes || '';
    if (cook.has_photo) {
      $('[data-photo-field]', form).hidden = false;
      $('[data-photo]', form).src = `/api/admin/cooks/${cook.id}/photo?ts=${Date.now()}`;
    }
  } else {
    form.radiusKm.value = 5;
    $('[data-activate-block]', form).hidden = false;
  }
  $('[data-submit]', form).textContent = t(cook ? 'admin.save' : 'admin.create');
  let removePhoto = false;
  $('[data-photo-remove]', form)?.addEventListener('click', () => { removePhoto = true; $('[data-photo-field]', form).hidden = true; });
  form.readBody = () => {
    const b = {
      fullName: form.fullName.value, whatsapp: form.whatsapp.value, areaId: Number(form.areaId.value),
      radiusKm: Number(form.radiusKm.value), bio: form.bio.value, adminNotes: form.adminNotes.value,
      services: [...form.querySelectorAll('input[name="services"]:checked')].map((i) => i.value),
      lat: form.lat.value === '' ? null : Number(form.lat.value), lng: form.lng.value === '' ? null : Number(form.lng.value),
    };
    // Changing the area without touching coordinates → use the new area's centre.
    if (cook && Number(form.areaId.value) !== cook.area_id && String(form.lat.value) === String(cook.lat) && String(form.lng.value) === String(cook.lng)) { b.lat = null; b.lng = null; }
    if (removePhoto) b.photo = null;
    return b;
  };
  return form;
}

function subscriptionPanel(c) {
  const s = c.subscription;
  const planOpts = st.config.plans.map((p) => `<option value="${p}" ${p === (s?.plan || c.requested_plan) ? 'selected' : ''}>${esc(t(`plans.${p}`))}</option>`).join('');
  const payOpts = ['paid', 'unpaid', 'waived'].map((p) => `<option value="${p}" ${p === (s?.payment_status === 'unpaid' ? 'paid' : s?.payment_status || 'paid') ? 'selected' : ''}>${esc(t(`payment.${p}`))}</option>`).join('');
  return `
  <div class="panel">
    <h3>${esc(t('admin.subscription'))}</h3>
    ${s ? `<dl class="kv">
      <dt>${esc(t('admin.status'))}</dt><dd>${pill(c.effectiveStatus)}</dd>
      <dt>${esc(t('admin.plan'))}</dt><dd>${esc(t(`plans.${s.plan}`))}</dd>
      <dt>${esc(t('admin.paymentStatus'))}</dt><dd>${esc(t(`payment.${s.payment_status}`))}</dd>
      <dt>${esc(t('admin.startDate'))}</dt><dd>${fmtDate(s.start_date)}</dd>
      <dt>${esc(t('admin.expiryDate'))}</dt><dd>${fmtDate(s.expiry_date)}</dd>
    </dl>` : `<p class="fine">${esc(t('admin.noSubscription'))}</p>`}
    <form id="subForm">
      <div class="grid2">
        <div class="field"><label>${esc(t('admin.plan'))}</label><select class="input" name="plan">${planOpts}</select></div>
        <div class="field"><label>${esc(t('admin.paymentStatus'))}</label><select class="input" name="paymentStatus">${payOpts}</select></div>
      </div>
      <div class="grid2">
        <div class="field"><label>${esc(t('admin.startDate'))}</label><input class="input" type="date" name="startDate" value="${dateOnly(s?.start_date) || dateOnly(new Date())}"></div>
        <div class="field"><label>${esc(t('admin.expiryDate'))}</label><input class="input" type="date" name="expiryDate" value="${dateOnly(s?.expiry_date)}"><span class="hint">${esc(t('admin.expiryAuto'))}</span></div>
      </div>
      <div class="actions">
        <button class="btn btn-gold" type="button" data-act="activate">${esc(t('admin.activate'))}</button>
        ${s ? `<button class="btn btn-ghost" type="button" data-act="renew">${esc(t('admin.renew'))}</button>
        <button class="btn btn-ghost" type="button" data-act="saveDates">${esc(t('admin.saveDates'))}</button>
        <button class="btn btn-danger" type="button" data-act="suspend">${esc(t('admin.suspend'))}</button>
        <button class="btn btn-danger" type="button" data-act="expire">${esc(t('admin.expireNow'))}</button>` : ''}
      </div>
    </form>
  </div>`;
}

async function openCook(id) {
  msg('');
  let c;
  try { c = await call(`/api/admin/cooks/${id}`); } catch (err) { return; }
  st.current = c;
  $('#dlgTitle').textContent = c.full_name;
  const body = $('#dlgBody');
  body.innerHTML = `
    <div class="panel">
      <dl class="kv">
        <dt>${esc(t('admin.status'))}</dt><dd>${pill(c.effectiveStatus)}</dd>
        <dt>WhatsApp</dt><dd><a dir="ltr" href="https://wa.me/${esc(c.whatsapp)}" target="_blank" rel="noopener">+${esc(c.whatsapp)}</a></dd>
        <dt>${esc(t('admin.impressions'))}</dt><dd>${c.stats.impressions}</dd>
        <dt>${esc(t('admin.clicks'))}</dt><dd>${c.stats.whatsapp_clicks}</dd>
        ${c.requested_plan ? `<dt>${esc(t('admin.requestedPlan'))}</dt><dd>${esc(t(`plans.${c.requested_plan}`))}</dd>` : ''}
        <dt>${esc(t('admin.createdAt'))}</dt><dd>${fmtDate(c.created_at)}</dd>
      </dl>
      ${c.status !== 'approved' || c.effectiveStatus === 'pending' ? `<div class="actions">
        ${c.status !== 'approved' ? `<button class="btn btn-ghost" type="button" data-act="approve">${esc(t('admin.approve'))}</button>` : ''}
        ${c.status !== 'rejected' ? `<button class="btn btn-danger" type="button" data-act="reject">${esc(t('admin.reject'))}</button>` : ''}
      </div>` : ''}
    </div>
    ${subscriptionPanel(c)}
    <div class="panel"><h3>${esc(t('admin.info'))}</h3><div id="editSlot"></div></div>`;
  const form = buildForm(c);
  $('#editSlot').appendChild(form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await call(`/api/admin/cooks/${c.id}`, { method: 'PATCH', body: form.readBody() }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
  });
  body.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', () => act(b.dataset.act)));
  if (!dlg.open) dlg.showModal();
}

async function act(action) {
  const c = st.current;
  const f = $('#subForm');
  const sub = { plan: f.plan.value, paymentStatus: f.paymentStatus.value, startDate: f.startDate.value || undefined, expiryDate: f.expiryDate.value || undefined };
  const confirms = { reject: 'admin.confirmReject', suspend: 'admin.confirmSuspend', expire: 'admin.confirmExpire' };
  if (confirms[action] && !confirm(t(confirms[action]))) return;
  const base = `/api/admin/cooks/${c.id}`;
  const req = {
    approve: [`${base}/approve`, 'POST', {}],
    reject: [`${base}/reject`, 'POST', {}],
    activate: [`${base}/subscription/activate`, 'POST', sub],
    renew: [`${base}/subscription/renew`, 'POST', { plan: sub.plan, paymentStatus: sub.paymentStatus }],
    saveDates: [`${base}/subscription`, 'PATCH', { plan: sub.plan, paymentStatus: sub.paymentStatus, startDate: sub.startDate, expiryDate: sub.expiryDate }],
    suspend: [`${base}/subscription/suspend`, 'POST', {}],
    expire: [`${base}/subscription/expire`, 'POST', {}],
  }[action];
  try { await call(req[0], { method: req[1], body: req[2] }); await openCook(c.id); msg(t('admin.saved')); }
  catch (err) { errMsg(err); }
}

function openNew() {
  msg('');
  st.current = null;
  $('#dlgTitle').textContent = t('admin.addCook');
  const body = $('#dlgBody');
  body.innerHTML = '<div class="panel" id="newSlot"></div>';
  const form = buildForm(null);
  $('#newSlot').appendChild(form);
  const planSel = st.config.plans.map((p) => `<option value="${p}">${esc(t(`plans.${p}`))}</option>`).join('');
  $('[data-activate-block]', form).insertAdjacentHTML('beforeend',
    `<div class="grid2"><div class="field"><label>${esc(t('admin.plan'))}</label><select class="input" name="plan">${planSel}</select></div>
     <div class="field"><label>${esc(t('admin.startDate'))}</label><input class="input" type="date" name="startDate" value="${dateOnly(new Date())}"></div></div>`);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = form.readBody();
    if (form.activateNow.checked) b.activate = { plan: form.plan.value, startDate: form.startDate.value, paymentStatus: 'paid' };
    try { const c = await call('/api/admin/cooks', { method: 'POST', body: b }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
  });
  dlg.showModal();
}

boot();
