import { initI18n, t, api, errorText, esc, applyI18n, fmtNumber, fmtDate as fmtD, setRegion } from '/assets/i18n.js?v=432';
import { areaSearch, servedAreasEditor, starsHtml, resizeImage } from '/assets/ui.js?v=432';

const $ = (s, r = document) => r.querySelector(s);
const FILTERS = ['pending', 'active', 'expired', 'suspended', 'rejected', 'no_subscription', 'hidden', 'all', 'feedback', 'support'];
const st = { filter: 'pending', fbStatus: 'new', q: '', config: null, current: null, kind: 'cook', country: '' };

const dateOnly = (v) => (v ? new Date(v).toISOString().slice(0, 10) : '');
const fmtDate = (v) => fmtD(v, { year: 'numeric', month: 'short', day: 'numeric' });
const pill = (s) => `<span class="pill ${esc(s)}">${esc(t(`status.${s}`))}</span>`;

/* ---------- auth ---------- */
async function boot() {
  await initI18n();
  st.config = await api('/api/config');
  setRegion(st.config.country);
  $('#districtSel').innerHTML = st.config.districts.map((d) => `<option value="${d.key}">${esc(d.name)}</option>`).join('');
  const names = (() => { try { return new Intl.DisplayNames([document.documentElement.lang || 'ar'], { type: 'region' }); } catch { return null; } })();
  const flag = (c) => String.fromCodePoint(...[...c].map((ch) => 0x1f1e6 + ch.charCodeAt(0) - 65));
  const countryOpts = (st.config.countries || [])
    .map((c) => ({ c, n: names?.of(c) || c }))
    .sort((a, b) => a.n.localeCompare(b.n, document.documentElement.lang || 'ar'))
    .map(({ c, n }) => `<option value="${c}">${flag(c)} ${esc(n)}</option>`).join('');
  $('#countryFilter').innerHTML = `<option value="">${esc(t('admin.allCountries'))}</option>${countryOpts}`;
  $('#importCountry').innerHTML = countryOpts;
  $('#importCountry').value = st.config.country?.code || 'LB';
  try {
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch { showLogin(); }
}
function showLogin() { $('#loginView').hidden = false; $('#dashView').hidden = true; $('#logoutBtn').hidden = true; $('#u').focus(); }
async function showDash() {
  if ($('#securityPanel')?.open) loadSecurity();
  call('/api/admin/settings').then((r) => { st.settings = r; }).catch(() => {});
  $('#loginView').hidden = true; $('#dashView').hidden = false; $('#logoutBtn').hidden = false;
  renderTabs();
  await Promise.all([loadStats(), loadView()]);
}
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginError').hidden = true;
  try {
    const r = await api('/api/admin/login', { method: 'POST', body: { username: e.target.username.value, password: e.target.password.value } });
    if (r.mfa) { st.mfa = r; $('#loginForm').hidden = true; $('#mfaStep').hidden = false; return; }
    e.target.reset();
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch (err) { $('#loginError').textContent = errorText(err); $('#loginError').hidden = false; }
});
/* ---------- passkeys (WebAuthn) helpers ---------- */
const toBuf = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));
const toB64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const credJson = (c) => ({
  id: c.id, rawId: toB64u(c.rawId), type: c.type,
  response: Object.fromEntries(['clientDataJSON', 'attestationObject', 'authenticatorData', 'signature', 'userHandle']
    .filter((k) => c.response[k]).map((k) => [k, toB64u(c.response[k])])),
});
async function finishLogin(path, body) {
  try {
    await api(path, { method: 'POST', body });
    $('#mfaStep').hidden = true; $('#loginForm').hidden = false; $('#loginForm').reset();
    const me = await api('/api/admin/me');
    $('#adminWarn').hidden = me.adminWhatsappConfigured;
    showDash();
  } catch (err) {
    $('#loginError').textContent = errorText(err); $('#loginError').hidden = false;
    if (err.code === 'login_expired') { $('#mfaStep').hidden = true; $('#loginForm').hidden = false; }
  }
}
$('#passkeyLogin').addEventListener('click', async () => {
  const o = st.mfa.options;
  try {
    const cred = await navigator.credentials.get({ publicKey: {
      challenge: toBuf(o.challenge), rpId: o.rpId, timeout: o.timeout, userVerification: o.userVerification,
      allowCredentials: o.allowCredentials.map((c) => ({ type: 'public-key', id: toBuf(c.id) })),
    } });
    await finishLogin('/api/admin/login/passkey', { token: st.mfa.token, credential: credJson(cred) });
  } catch (err) { if (err?.name !== 'NotAllowedError') { $('#loginError').textContent = errorText(err); $('#loginError').hidden = false; } }
});
$('#backupForm').addEventListener('submit', (e) => { e.preventDefault(); finishLogin('/api/admin/login/backup', { token: st.mfa.token, code: e.target.code.value }); });

$('#logoutBtn').addEventListener('click', async () => { await api('/api/admin/logout', { method: 'POST', body: {} }).catch(() => {}); showLogin(); });

async function call(path, opts) {
  try { return await api(path, opts); }
  catch (err) { if (err.status === 401) { $('#dlg').close(); showLogin(); } throw err; }
}

/* ---------- dashboard ---------- */
async function loadStats() {
  const s = await call('/api/admin/stats');
  st.newFeedback = s.new_feedback;
  st.newSupport = s.new_support || 0;
  const items = [
    [s.active_cooks, 'admin.stats.active'], [s.active_restaurants || 0, 'admin.stats.activeRestaurants'],
    [s.pending_applications, 'admin.stats.pending'], [s.pending_restaurants || 0, 'admin.stats.pendingRestaurants'],
    [s.new_feedback, 'admin.stats.feedback'], [s.new_support || 0, 'admin.stats.support'],
    [s.searches_30d, 'admin.stats.searches'], [s.whatsapp_clicks_30d, 'admin.stats.clicks'], [s.empty_searches_30d, 'admin.stats.empty'],
  ];
  $('#stats').innerHTML = items.map(([n, k]) => `<div class="stat"><b>${fmtNumber(n)}</b><span>${esc(t(k))}</span></div>`).join('');
  renderTabs();
}

function renderTabs() {
  $('#tabs').innerHTML = FILTERS.map((f) => {
    const label = f === 'feedback' ? t('admin.feedbackTab') : f === 'support' ? t('admin.supportTab') : t(`admin.filters.${f}`);
    const n = f === 'feedback' ? st.newFeedback : f === 'support' ? st.newSupport : 0;
    const badge = n ? `<em>${n}</em>` : '';
    return `<button type="button" role="tab" data-f="${f}" aria-selected="${f === st.filter}">${esc(label)}${badge}</button>`;
  }).join('');
}
$('#tabs').addEventListener('click', (e) => {
  const b = e.target.closest('[data-f]');
  if (!b) return;
  st.filter = b.dataset.f;
  renderTabs();
  loadView();
});
$('#kindTabs').addEventListener('click', (e) => {
  const b = e.target.closest('[data-kind]');
  if (!b) return;
  st.kind = b.dataset.kind;
  document.querySelectorAll('#kindTabs [data-kind]').forEach((x) => x.setAttribute('aria-selected', String(x === b)));
  $('#addBtn').textContent = t(st.kind === 'restaurant' ? 'admin.addRestaurant' : 'admin.addCook');
  if (st.filter === 'support' || st.filter === 'feedback') st.filter = 'all';
  renderTabs();
  loadView();
});
$('#countryFilter').addEventListener('change', (e) => { st.country = e.target.value; loadView(); });
let qTimer;
$('#q').addEventListener('input', (e) => { clearTimeout(qTimer); qTimer = setTimeout(() => { st.q = e.target.value; loadView(); }, 250); });

function loadView() {
  const fb = st.filter === 'feedback';
  const sup = st.filter === 'support';
  $('#feedbackView').hidden = !fb;
  $('#supportView').hidden = !sup;
  $('#list').hidden = fb || sup;
  if (sup) { $('#moreBtn').hidden = true; $('#listTotal').textContent = ''; $('#emptyList').hidden = true; return loadSupport(); }
  $('#moreBtn').hidden = true;
  $('#listTotal').textContent = '';
  $('#emptyList').hidden = true;
  return fb ? loadFeedback() : loadList();
}

const rowHtml = (c) => `
    <li><button class="admin-row" type="button" data-id="${c.id}">
      <span>
        <span class="cook-name">${esc(c.fullName)}${c.hidden ? ` <span class="pill suspended">${esc(t('admin.hiddenBadge'))}</span>` : ''}</span>
        <span class="cook-meta">${c.country ? `${esc(c.country)} · ` : ''}${esc(c.area)} — <span dir="ltr">+${esc(c.whatsapp)}</span></span>
        <span class="cook-meta">${starsHtml(c.rating)} ${c.warnings ? ` · ${esc(t('admin.warningsCount', { n: c.warnings }))}` : ''} ${c.openFeedback ? ` · <b class="warn">${esc(t('admin.openFeedback', { n: c.openFeedback }))}</b>` : ''}</span>
      </span>
      <span class="nums">
        ${pill(c.effectiveStatus)}<br>
        ${c.expiryDate ? esc(t('admin.expires', { date: fmtDate(c.expiryDate) })) : c.requestedPlan ? esc(t(`plans.${c.requestedPlan}`)) : ''}<br>
        ${esc(t('admin.impressions'))}: ${c.impressions} — WhatsApp: ${c.whatsappClicks}
      </span>
    </button></li>`;

// 50 at a time; "show more" loads the next page.
async function loadList(append = false) {
  if (!append) st.offset = 0;
  const r = await call(`/api/admin/cooks?filter=${st.filter}&kind=${st.kind}&country=${st.country}&q=${encodeURIComponent(st.q)}&limit=50&offset=${st.offset}`);
  st.offset += r.cooks.length;
  $('#emptyList').hidden = r.total > 0;
  $('#listTotal').textContent = r.total ? t('admin.totalCount', { n: r.total }) : '';
  const html = r.cooks.map(rowHtml).join('');
  if (append) $('#list').insertAdjacentHTML('beforeend', html); else $('#list').innerHTML = html;
  $('#moreBtn').hidden = !r.hasMore;
}
$('#moreBtn').addEventListener('click', () => loadList(true));
$('#list').addEventListener('click', (e) => { const b = e.target.closest('[data-id]'); if (b) openCook(Number(b.dataset.id)); });
$('#addBtn').addEventListener('click', () => openNew());

/* ---------- complaints & notes ---------- */
async function loadFeedback() {
  $('#fbTabs').innerHTML = [['new', 'admin.newFeedback'], ['resolved', 'admin.resolved'], ['all', 'admin.allFeedback']]
    .map(([k, l]) => `<button type="button" data-s="${k}" aria-selected="${k === st.fbStatus}">${esc(t(l))}</button>`).join('');
  const { feedback } = await call(`/api/admin/feedback?status=${st.fbStatus}`);
  $('#fbEmpty').hidden = feedback.length > 0;
  $('#fbList').innerHTML = feedback.map((f) => `
    <li class="fb-item">
      <div class="fb-head"><span class="pill ${f.kind === 'complaint' ? 'expired' : 'active'}">${esc(t(`admin.${f.kind}`))}</span>
        <button class="btn-text" type="button" data-cook="${f.cook_id}">${esc(f.cook_name)}</button>
        <span class="fine">${fmtDate(f.created_at)}${f.cook_warnings ? ` · ${esc(t('admin.warningsCount', { n: f.cook_warnings }))}` : ''}</span></div>
      <p class="fb-msg">${esc(f.message)}</p>
      <p class="fine">${esc(t('admin.customer'))}: ${esc(f.customer_name || '—')} ${f.customer_phone ? `· <a dir="ltr" href="https://wa.me/${esc(f.customer_phone)}" target="_blank" rel="noopener">+${esc(f.customer_phone)}</a>` : ''}</p>
      ${f.admin_note ? `<p class="fine">${esc(t('admin.adminNote'))}: ${esc(f.admin_note)}</p>` : ''}
      <div class="actions">
        <button class="btn btn-danger" type="button" data-warn="${f.id}" data-cookid="${f.cook_id}" data-name="${esc(f.cook_name)}" data-msg="${esc(f.message)}" data-n="${f.cook_warnings + 1}">${esc(t('admin.warn'))}</button>
        <button class="btn btn-ghost" type="button" data-fb="${f.id}" data-to="${f.status === 'new' ? 'resolved' : 'new'}">${esc(t(f.status === 'new' ? 'admin.resolve' : 'admin.reopen'))}</button>
      </div>
    </li>`).join('');
}
$('#fbTabs').addEventListener('click', (e) => { const b = e.target.closest('[data-s]'); if (b) { st.fbStatus = b.dataset.s; loadFeedback(); } });
$('#fbList').addEventListener('click', async (e) => {
  const cookBtn = e.target.closest('[data-cook]');
  if (cookBtn) return openCook(Number(cookBtn.dataset.cook));
  const fbBtn = e.target.closest('[data-fb]');
  if (fbBtn) { await call(`/api/admin/feedback/${fbBtn.dataset.fb}`, { method: 'PATCH', body: { status: fbBtn.dataset.to } }); loadFeedback(); loadStats(); return; }
  const w = e.target.closest('[data-warn]');
  if (w) openWarning({ cookId: Number(w.dataset.cookid), name: w.dataset.name, message: w.dataset.msg, n: Number(w.dataset.n), feedbackId: Number(w.dataset.warn) });
});

/* ---------- dialog ---------- */
const dlg = $('#dlg');
$('#dlgClose').addEventListener('click', () => dlg.close());
dlg.addEventListener('close', () => { loadView(); loadStats(); });
function msg(text, ok = true) { const m = $('#dlgMsg'); m.textContent = text; m.className = `alert ${ok ? 'ok' : ''}`; m.hidden = !text; if (text) m.scrollIntoView({ block: 'nearest' }); }
function errMsg(err) {
  const fields = Object.entries(err.fields || {}).map(([k, v]) => `${k}: ${t(`errors.${v}`)}`).join(' — ');
  msg(`${errorText(err)}${fields ? ' — ' + fields : ''}`, false);
}

async function openWarning({ cookId, name, message, n, feedbackId }) {
  msg('');
  $('#dlgTitle').textContent = `${t('admin.warn')} — ${name}`;
  const text = await warningText(st.current?.locale, { name, message: message || '…', n });
  $('#dlgBody').innerHTML = `<div class="panel"><form id="warnForm">
    <div class="field"><textarea class="input" name="message" rows="9">${esc(text)}</textarea></div>
    <button class="btn btn-danger" type="submit">${esc(t('admin.warnSend'))}</button></form></div>`;
  $('#warnForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await call(`/api/admin/cooks/${cookId}/warnings`, { method: 'POST', body: { message: e.target.message.value, feedbackId: feedbackId || undefined } });
      window.open(r.whatsappUrl, '_blank', 'noopener');
      await openCook(cookId);
      msg(t('admin.saved'));
    } catch (err) { errMsg(err); }
  });
  if (!dlg.open) dlg.showModal();
}

function buildForm(cook) {
  const frag = $('#cookFormTpl').content.cloneNode(true);
  const form = $('form', frag);
  applyI18n(frag);
  let homeId = cook?.area_id || null;
  const formKind = cook?.kind || st.kind;
  $('[data-specialty-field]', form).hidden = formKind !== 'restaurant';
  $('[data-services-field]', form).hidden = formKind === 'restaurant';
  form.specialty.value = cook?.specialty || '';
  $('[data-services]', form).innerHTML = st.config.serviceTypes.map((k) =>
    `<label class="chip"><input type="checkbox" name="services" value="${k}" ${cook?.services?.includes(k) ? 'checked' : ''}><span>${esc(t(`services.${k}`))}</span></label>`).join('');
  const editor = servedAreasEditor($('[data-served]', form), { initial: cook?.servedAreas || [], point: cook ? { lat: cook.lat, lng: cook.lng } : null, districts: st.config.districts });
  const homeLabel = $('[data-home]', form);
  homeLabel.textContent = cook ? t('location.picked', { area: cook.area_label }) : '';
  areaSearch(form.areaSearch, { onPick: (a) => { homeId = a.id; homeLabel.textContent = t('location.picked', { area: a.name }); editor.setPoint(a.lat, a.lng).catch(() => {}); } });
  if (cook) {
    form.fullName.value = cook.full_name;
    form.whatsapp.value = '+' + cook.whatsapp;
    form.lat.value = cook.lat; form.lng.value = cook.lng;
    form.bio.value = cook.bio || '';
    form.adminNotes.value = cook.admin_notes || '';
    if (cook.has_photo) {
      $('[data-photo-field]', form).hidden = false;
      $('[data-photo]', form).src = `/api/admin/cooks/${cook.id}/photo?ts=${Date.now()}`;
    }
  } else {
    $('[data-activate-block]', form).hidden = false;
  }
  $('[data-submit]', form).textContent = t(cook ? 'admin.save' : 'admin.create');
  let removePhoto = false;
  $('[data-photo-remove]', form)?.addEventListener('click', () => { removePhoto = true; $('[data-photo-field]', form).hidden = true; });
  form.readBody = () => {
    const b = {
      fullName: form.fullName.value, whatsapp: form.whatsapp.value, areaId: homeId,
      bio: form.bio.value, adminNotes: form.adminNotes.value,
      services: [...form.querySelectorAll('input[name="services"]:checked')].map((i) => i.value),
      servedAreaIds: editor.ids(),
      ...(formKind === 'restaurant' ? { specialty: form.specialty.value } : {}),
      ...(!cook ? { kind: formKind } : {}),
    };
    const latChanged = cook && (String(form.lat.value) !== String(cook.lat) || String(form.lng.value) !== String(cook.lng));
    if ((!cook || latChanged) && form.lat.value !== '' && form.lng.value !== '') { b.lat = Number(form.lat.value); b.lng = Number(form.lng.value); }
    if (removePhoto) b.photo = null;
    return b;
  };
  return form;
}

function subscriptionPanel(c) {
  const s = c.subscription;
  const planOpts = st.config.plans.map((p) => `<option value="${p}" ${p === (s?.plan || c.requested_plan) ? 'selected' : ''}>${esc(t(`plans.${p}`))}</option>`).join('');
  const payOpts = ['paid', 'unpaid', 'waived'].map((p) => `<option value="${p}" ${p === (s?.payment_status === 'unpaid' ? 'paid' : s?.payment_status || 'paid') ? 'selected' : ''}>${esc(t(`payment.${p}`))}</option>`).join('');
  return `
  <div class="panel">
    <h3>${esc(t('admin.subscription'))}</h3>
    ${s ? `<dl class="kv">
      <dt>${esc(t('admin.status'))}</dt><dd>${pill(c.effectiveStatus)}</dd>
      <dt>${esc(t('admin.plan'))}</dt><dd>${esc(t(`plans.${s.plan}`))}</dd>
      <dt>${esc(t('admin.paymentStatus'))}</dt><dd>${esc(t(`payment.${s.payment_status}`))}</dd>
      <dt>${esc(t('admin.startDate'))}</dt><dd>${fmtDate(s.start_date)}</dd>
      <dt>${esc(t('admin.expiryDate'))}</dt><dd>${fmtDate(s.expiry_date)}</dd>
    </dl>` : `<p class="fine">${esc(t('admin.noSubscription'))}</p>`}
    <form id="subForm">
      <div class="grid2">
        <div class="field"><label>${esc(t('admin.plan'))}</label><select class="input" name="plan">${planOpts}</select></div>
        <div class="field"><label>${esc(t('admin.paymentStatus'))}</label><select class="input" name="paymentStatus">${payOpts}</select></div>
      </div>
      <div class="grid2">
        <div class="field"><label>${esc(t('admin.startDate'))}</label><input class="input" type="date" name="startDate" value="${dateOnly(s?.start_date) || dateOnly(new Date())}"></div>
        <div class="field"><label>${esc(t('admin.expiryDate'))}</label><input class="input" type="date" name="expiryDate" value="${dateOnly(s?.expiry_date)}"><span class="hint">${esc(t('admin.expiryAuto'))}</span></div>
      </div>
      <div class="actions">
        <button class="btn btn-gold" type="button" data-act="activate">${esc(t('admin.activate'))}</button>
        ${s ? `<button class="btn btn-ghost" type="button" data-act="renew">${esc(t('admin.renew'))}</button>
        <button class="btn btn-ghost" type="button" data-act="saveDates">${esc(t('admin.saveDates'))}</button>
        <button class="btn btn-danger" type="button" data-act="suspend">${esc(t('admin.suspend'))}</button>
        <button class="btn btn-danger" type="button" data-act="expire">${esc(t('admin.expireNow'))}</button>` : ''}
      </div>
    </form>
  </div>`;
}

async function openCook(id) {
  msg('');
  let c;
  try { c = await call(`/api/admin/cooks/${id}`); } catch { return; }
  st.current = c;
  $('#dlgTitle').textContent = c.full_name;
  const r = c.stats.rating;
  $('#dlgBody').innerHTML = `
    <div class="panel">
      <dl class="kv">
        <dt>${esc(t('admin.status'))}</dt><dd>${pill(c.effectiveStatus)}</dd>
        <dt>WhatsApp</dt><dd><a dir="ltr" href="https://wa.me/${esc(c.whatsapp)}" target="_blank" rel="noopener">+${esc(c.whatsapp)}</a></dd>
        <dt>${esc(t('admin.ratingLabel'))}</dt><dd>${starsHtml(r)}</dd>
        <dt>${esc(t('account.views'))}</dt><dd>${c.stats.views_total}</dd>
        <dt>${esc(t('account.likes'))}</dt><dd>${c.stats.likes}</dd>
        <dt>${esc(t('admin.impressions'))}</dt><dd>${c.stats.impressions}</dd>
        <dt>${esc(t('admin.clicks'))}</dt><dd>${c.stats.whatsapp_clicks}</dd>
        ${c.requested_plan ? `<dt>${esc(t('admin.requestedPlan'))}</dt><dd>${esc(t(`plans.${c.requested_plan}`))}</dd>` : ''}
        <dt>${esc(t('admin.createdAt'))}</dt><dd>${fmtDate(c.created_at)}</dd>
      </dl>
      <div class="actions">
        ${c.status !== 'approved' ? `<button class="btn btn-ghost" type="button" data-act="approve">${esc(t('admin.approve'))}</button>` : ''}
        ${c.status !== 'rejected' ? `<button class="btn btn-danger" type="button" data-act="reject">${esc(t('admin.reject'))}</button>` : ''}
        <a class="btn btn-ghost" href="/c/${c.id}" target="_blank" rel="noopener">${esc(t('results.viewProfile'))}</a>
        ${Number(c.is_hidden) ? `<button class="btn btn-gold" type="button" data-act="unhide">${esc(t('admin.unhide'))}</button>`
          : `<button class="btn btn-ghost" type="button" data-act="hide">${esc(t('admin.hide'))}</button>`}
      </div>
      ${Number(c.is_hidden) ? `<p class="alert">${esc(t('admin.hiddenNote'))}</p>` : ''}
    </div>
    ${subscriptionPanel(c)}
    <div class="panel">
      <h3>${esc(t('account.loginTitle'))}</h3>
      <p class="fine">${esc(t(c.has_password ? 'admin.hasPassword' : 'admin.noPassword'))}</p>
      <p class="fine" id="pwOut"></p>
      <button class="btn btn-gold" type="button" data-act="password">${esc(t('admin.passwordBtn'))}</button>
      <button class="btn btn-ghost" type="button" data-act="trial">${esc(t('admin.trialBtn', { days: trialDays(c) }))}</button>
      <button class="btn btn-ghost" type="button" data-act="support">${esc(t('admin.supportTab'))}${c.unreadSupport ? ` (${c.unreadSupport})` : ''}</button>
    </div>
    <div class="panel">
      <h3>${esc(t('admin.warningsTitle'))} (${c.warnings.length})</h3>
      ${c.warnings.map((w) => `<p class="fine">${fmtDate(w.created_at)} — ${esc(w.message.slice(0, 140))}${w.message.length > 140 ? '…' : ''}</p>`).join('')}
      <button class="btn btn-danger" type="button" data-act="warn">${esc(t('admin.warn'))}</button>
    </div>
    <div class="panel">
      ${c.kind === 'restaurant' ? `<p class="fine"><b>${esc(t('admin.specialty'))}:</b> ${esc(c.specialty || '—')}</p>
        <h3>${esc(t('admin.menuTitle'))} (${c.menu.length})</h3>
        ${c.menu.map((it) => `<p class="fine review-row">${esc(it.name)}${it.price != null ? ` — ${it.price} ${esc(it.currency || '')}` : ''} ${it.available ? '' : esc(t('admin.hiddenItem'))}
          <button class="btn-text" type="button" data-delitem="${it.id}">${esc(t('admin.deletePhoto'))}</button></p>`).join('')}` : ''}
      <h3>${esc(t('admin.photosTitle'))} (${c.photos.length})</h3>
      <div class="photo-grid">${c.photos.map((p) => `<figure${p.hidden ? ' class="is-hidden"' : ''}><img src="${esc(p.url)}" alt="">
        <button class="del" type="button" data-delphoto="${p.id}">${esc(t('admin.deletePhoto'))}</button>
        <button class="del del-2" type="button" data-hidephoto="${p.id}" data-hidden="${p.hidden ? 0 : 1}">${esc(t(p.hidden ? 'admin.showItem' : 'admin.hideItem'))}</button>
        <figcaption>${esc(p.caption)} ${p.hidden ? esc(t('admin.hiddenItem')) : ''}</figcaption></figure>`).join('')}</div>
    </div>
    <div class="panel">
      <h3>${esc(t('admin.reviewsTitle'))} (${c.reviews.length})</h3>
      ${c.reviews.map((r) => `<p class="fine review-row">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)} — ${fmtDate(r.createdAt)} ${r.hidden ? esc(t('admin.hiddenItem')) : ''}
        <button class="btn-text" type="button" data-hidereview="${r.id}" data-hidden="${r.hidden ? 0 : 1}">${esc(t(r.hidden ? 'admin.showItem' : 'admin.hideItem'))}</button></p>`).join('')}
    </div>
    <div class="panel danger-zone">
      <button class="btn btn-danger" type="button" data-act="delete">${esc(t('admin.deleteAccount'))}</button>
    </div>
    <div class="panel"><h3>${esc(t('admin.info'))}</h3><div id="editSlot"></div></div>`;
  const form = buildForm(c);
  $('#editSlot').appendChild(form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await call(`/api/admin/cooks/${c.id}`, { method: 'PATCH', body: form.readBody() }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
  });
  $('#dlgBody').querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', () => act(b.dataset.act)));
  $('#dlgBody').querySelectorAll('[data-delitem]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm(t('account.confirmDelete'))) return;
    await call(`/api/admin/menu/${b.dataset.delitem}`, { method: 'DELETE' });
    await openCook(c.id);
  }));
  $('#dlgBody').querySelectorAll('[data-hidephoto]').forEach((b) => b.addEventListener('click', async () => {
    await call(`/api/admin/photos/${b.dataset.hidephoto}`, { method: 'PATCH', body: { hidden: b.dataset.hidden === '1' } });
    await openCook(c.id);
  }));
  $('#dlgBody').querySelectorAll('[data-hidereview]').forEach((b) => b.addEventListener('click', async () => {
    await call(`/api/admin/reviews/${b.dataset.hidereview}`, { method: 'PATCH', body: { hidden: b.dataset.hidden === '1' } });
    await openCook(c.id);
  }));
  $('#dlgBody').querySelectorAll('[data-delphoto]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm(t('account.confirmDelete'))) return;
    await call(`/api/admin/photos/${b.dataset.delphoto}`, { method: 'DELETE' });
    await openCook(c.id);
  }));
  if (!dlg.open) dlg.showModal();
}

async function act(action) {
  const c = st.current;
  if (action === 'warn') return openWarning({ cookId: c.id, name: c.full_name, message: '', n: c.warnings.length + 1 });
  if (action === 'trial') {
    try { await call(`/api/admin/cooks/${c.id}/subscription/trial`, { method: 'POST', body: {} }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
    return;
  }
  if (action === 'support') return openSupport(c.id, c.full_name);
  if (action === 'hide' || action === 'unhide') {
    if (action === 'hide' && !confirm(t('admin.confirmHide'))) return;
    try { await call(`/api/admin/cooks/${c.id}/${action}`, { method: 'POST', body: {} }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
    return;
  }
  if (action === 'delete') {
    if (!confirm(t('admin.confirmDeleteSimple'))) return;
    try { await call(`/api/admin/cooks/${c.id}`, { method: 'DELETE' }); dlg.close(); loadView(); loadStats(); }
    catch (err) { errMsg(err); }
    return;
  }
  if (action === 'password') {
    try {
      const r = await call(`/api/admin/cooks/${c.id}/password`, { method: 'POST', body: {} });
      $('#pwOut').textContent = t('admin.passwordSet', { p: r.password });
      window.open(r.whatsappUrl, '_blank', 'noopener');
    } catch (err) { errMsg(err); }
    return;
  }
  const f = $('#subForm');
  const sub = { plan: f.plan.value, paymentStatus: f.paymentStatus.value, startDate: f.startDate.value || undefined, expiryDate: f.expiryDate.value || undefined };
  const confirms = { reject: 'admin.confirmReject', suspend: 'admin.confirmSuspend', expire: 'admin.confirmExpire' };
  if (confirms[action] && !confirm(t(confirms[action]))) return;
  const base = `/api/admin/cooks/${c.id}`;
  const req = {
    approve: [`${base}/approve`, 'POST', {}],
    reject: [`${base}/reject`, 'POST', {}],
    activate: [`${base}/subscription/activate`, 'POST', sub],
    renew: [`${base}/subscription/renew`, 'POST', { plan: sub.plan, paymentStatus: sub.paymentStatus }],
    saveDates: [`${base}/subscription`, 'PATCH', { plan: sub.plan, paymentStatus: sub.paymentStatus, startDate: sub.startDate, expiryDate: sub.expiryDate }],
    suspend: [`${base}/subscription/suspend`, 'POST', {}],
    expire: [`${base}/subscription/expire`, 'POST', {}],
  }[action];
  try { await call(req[0], { method: req[1], body: req[2] }); await openCook(c.id); msg(t('admin.saved')); }
  catch (err) { errMsg(err); }
}

function openNew() {
  msg('');
  st.current = null;
  $('#dlgTitle').textContent = t(st.kind === 'restaurant' ? 'admin.addRestaurant' : 'admin.addCook');
  $('#dlgBody').innerHTML = '<div class="panel" id="newSlot"></div>';
  const form = buildForm(null);
  $('#newSlot').appendChild(form);
  const planSel = st.config.plans.map((p) => `<option value="${p}">${esc(t(`plans.${p}`))}</option>`).join('');
  $('[data-activate-block]', form).insertAdjacentHTML('beforeend',
    `<div class="grid2"><div class="field"><label>${esc(t('admin.plan'))}</label><select class="input" name="plan">${planSel}</select></div>
     <div class="field"><label>${esc(t('admin.startDate'))}</label><input class="input" type="date" name="startDate" value="${dateOnly(new Date())}"></div></div>`);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = form.readBody();
    if (form.activateNow.checked) b.activate = { plan: form.plan.value, startDate: form.startDate.value, paymentStatus: 'paid' };
    try { const c = await call('/api/admin/cooks', { method: 'POST', body: b }); await openCook(c.id); msg(t('admin.saved')); }
    catch (err) { errMsg(err); }
  });
  dlg.showModal();
}

$('#areaForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    await call('/api/admin/areas', { method: 'POST', body: { nameAr: f.nameAr.value, district: f.district.value, lat: f.lat.value || undefined, lng: f.lng.value || undefined } });
    f.reset();
    $('#areaMsg').textContent = t('admin.areaAdded');
  } catch (err) { $('#areaMsg').textContent = errorText(err); }
});

/* ---------- import all villages of the country ---------- */
let importTimer = null;
async function showImport() {
  const r = await call(`/api/admin/areas/import?country=${$('#importCountry').value}`);
  const el = $('#importStatus');
  const vars = { found: r.found, added: r.added, total: r.totalAreas, error: r.error };
  el.textContent = t({ running: 'admin.importRunning', done: 'admin.importDone', failed: 'admin.importFailed' }[r.state] || 'admin.importNever', vars);
  $('#importBtn').disabled = r.state === 'running';
  clearTimeout(importTimer);
  if (r.state === 'running') importTimer = setTimeout(showImport, 5000);
}
$('#importPanel').addEventListener('toggle', (e) => { if (e.target.open) showImport(); });
$('#importBtn').addEventListener('click', async () => {
  await call('/api/admin/areas/import', { method: 'POST', body: { country: $('#importCountry').value } });
  showImport();
});

/* ---------- whole-site settings ---------- */
async function loadSettings() {
  const r = await call('/api/admin/settings');
  const f = $('#settingsForm');
  f.brandName.value = r.brandName || '';
  f.brandName.placeholder = r.effectiveBrand?.name || '';
  f.brandNameEn.value = r.brandNameEn || '';
  f.brandNameEn.placeholder = r.effectiveBrand?.nameEn || '';
  f.announcement.value = r.announcement || '';
  f.adminWhatsapp.value = r.adminWhatsapp ? '+' + r.adminWhatsapp : '';
  f.adminWhatsapp.placeholder = r.effectiveAdminWhatsapp ? '+' + r.effectiveAdminWhatsapp : '';
  for (const k of ['nearby', 'regions', 'dishes', 'nameSearch', 'cooksSlider', 'restaurants']) f[`sec_${k}`].checked = r.sections?.[k] !== false;
  f.sec_globalCounters.checked = !!r.sections?.globalCounters;
  st.settings = r;
  // prices: one table per kind (plans × USD/EUR)
  $('#pricesGrid').innerHTML = ['cook', 'restaurant'].map((kind) => `
    <p class="label">${esc(t(kind === 'cook' ? 'admin.pricesCook' : 'admin.pricesRestaurant'))}</p>
    <div class="price-table">${st.config.plans.map((plan) => `
      <span>${esc(t(`plans.${plan}`))}</span>
      <input class="input" type="number" min="0" step="0.01" dir="ltr" placeholder="USD" data-price="${kind}.${plan}.usd" value="${r.prices?.[kind]?.[plan]?.usd ?? ''}">
      <input class="input" type="number" min="0" step="0.01" dir="ltr" placeholder="EUR" data-price="${kind}.${plan}.eur" value="${r.prices?.[kind]?.[plan]?.eur ?? ''}">`).join('')}
    </div>`).join('');
  $('#trialGrid').innerHTML = ['cook', 'restaurant'].map((kind) => `
    <div class="field"><span class="label">${esc(t(kind === 'cook' ? 'admin.kindCooks' : 'admin.kindRestaurants'))}</span>
      <label class="chip"><input type="checkbox" data-trial-on="${kind}" ${r.trial?.[kind]?.enabled ? 'checked' : ''}><span>${esc(t('admin.trialEnabled'))}</span></label>
      <label class="fine">${esc(t('admin.trialDays'))} <input class="input" type="number" min="1" max="365" dir="ltr" data-trial-days="${kind}" value="${r.trial?.[kind]?.days ?? 14}"></label>
    </div>`).join('');
  f.appAndroid.value = r.appLinks?.android || '';
  f.appIos.value = r.appLinks?.ios || '';
  f.lim_cookPhotos.value = r.limits?.cookPhotos ?? 12;
  f.lim_restaurantPhotos.value = r.limits?.restaurantPhotos ?? 30;
  f.lim_menuItems.value = r.limits?.menuItems ?? 150;
}
$('#settingsPanel').addEventListener('toggle', (e) => { if (e.target.open) loadSettings(); });
$('#settingsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  const sections = {};
  for (const k of ['nearby', 'regions', 'dishes', 'nameSearch', 'cooksSlider', 'restaurants', 'globalCounters']) sections[k] = f[`sec_${k}`].checked;
  const prices = { cook: {}, restaurant: {} };
  document.querySelectorAll('[data-price]').forEach((i) => {
    const [kind, plan, cur] = i.dataset.price.split('.');
    (prices[kind][plan] ||= {})[cur] = i.value;
  });
  const trial = {};
  for (const kind of ['cook', 'restaurant']) {
    trial[kind] = { enabled: document.querySelector(`[data-trial-on="${kind}"]`).checked, days: Number(document.querySelector(`[data-trial-days="${kind}"]`).value) || 14 };
  }
  const limits = { cookPhotos: f.lim_cookPhotos.value, restaurantPhotos: f.lim_restaurantPhotos.value, menuItems: f.lim_menuItems.value };
  try {
    st.settings = await call('/api/admin/settings', { method: 'PUT', body: {
      brandName: f.brandName.value, brandNameEn: f.brandNameEn.value, announcement: f.announcement.value, adminWhatsapp: f.adminWhatsapp.value, sections, prices, trial, limits,
      appLinks: { android: f.appAndroid.value, ios: f.appIos.value },
    } });
    $('#settingsMsg').textContent = t('admin.settingsSaved');
  } catch (err) { $('#settingsMsg').textContent = errorText(err); }
});

/* ---------- messages to a subscriber go out in THEIR language ---------- */
const localeCache = {};
async function warningText(lang, vars) {
  const l = (st.config?.locales || []).includes(lang) ? lang : null;
  if (!l || l === document.documentElement.lang) return t('wa.warning', vars);
  localeCache[l] ||= await fetch(`/locales/${l}.json`).then((r) => r.json()).catch(() => ({}));
  const tpl = localeCache[l]?.wa?.warning || t('wa.warning');
  return String(tpl).replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? '');
}

/* ---------- trial days (from settings) ---------- */
function trialDays(c) {
  const k = c.kind === 'restaurant' ? 'restaurant' : 'cook';
  return st.settings?.trial?.[k]?.days || 14;
}

/* ---------- support conversations ---------- */
async function loadSupport() {
  const { threads } = await call('/api/admin/support');
  $('#supportEmpty').hidden = threads.length > 0;
  $('#supportList').innerHTML = threads.map((th) => `
    <li><button class="admin-row" type="button" data-thread="${th.cookId}" data-name="${esc(th.name)}">
      <span><span class="cook-name">${esc(th.name)} ${th.kind === 'restaurant' ? `<span class="pill active">${esc(t('admin.kindRestaurants'))}</span>` : ''}</span>
        <span class="cook-meta">${esc((th.lastBody || '').slice(0, 90))}</span></span>
      <span class="nums">${th.unread ? `<b class="warn">${th.unread}</b><br>` : ''}${fmtDate(th.lastAt)}</span>
    </button></li>`).join('');
}
$('#supportList').addEventListener('click', (e) => {
  const b = e.target.closest('[data-thread]');
  if (b) openSupport(Number(b.dataset.thread), b.dataset.name);
});
async function openSupport(cookId, name) {
  msg('');
  $('#dlgTitle').textContent = t('admin.supportFrom', { name });
  const { messages } = await call(`/api/admin/support/${cookId}`);
  $('#dlgBody').innerHTML = `<div class="panel">
    <div class="thread">${messages.map((m) => `<div class="bubble ${m.fromAdmin ? 'team' : 'me'}"><small>${esc(m.fromAdmin ? t('account.supportTeam') : name)} · ${fmtDate(m.createdAt)}</small>${esc(m.body)}</div>`).join('')}</div>
    <form id="replyForm"><textarea class="input" name="body" rows="3" maxlength="2000" placeholder="${esc(t('admin.supportPlaceholder'))}"></textarea>
      <button class="btn btn-gold" type="submit">${esc(t('admin.supportReply'))}</button></form></div>`;
  $('#replyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = e.target.body.value.trim();
    if (!body) return;
    try { await call(`/api/admin/support/${cookId}`, { method: 'POST', body: { body } }); await openSupport(cookId, name); } catch (err) { errMsg(err); }
  });
  if (!dlg.open) dlg.showModal();
  loadStats();
}

/* ---------- ads & logos ---------- */
/** Shrink a photo until it is small enough to upload (phone photos can be several MB). */
async function compressForUpload(file, maxChars = 900_000) {
  for (const [w, q] of [[1600, 0.85], [1400, 0.8], [1200, 0.75], [1000, 0.7], [800, 0.65], [700, 0.6]]) {
    const data = await resizeImage(file, w, q);
    if (data.length <= maxChars) return data;
  }
  return resizeImage(file, 600, 0.55);
}
async function loadBanners() {
  const r = await call('/api/admin/banners');
  $('#bannerPlacement').innerHTML = r.placements.map((p) => `<option value="${p}">${esc(t(`admin.place_${p}`))}</option>`).join('');
  $('#bannerList').innerHTML = r.banners.map((b) => `
    <div class="banner-admin">
      <img src="${esc(b.imageUrl)}" alt="">
      <div>
        <select class="input" data-bplace="${b.id}">${r.placements.map((p) => `<option value="${p}" ${p === b.placement ? 'selected' : ''}>${esc(t(`admin.place_${p}`))}</option>`).join('')}</select>
        <p class="fine">${esc(b.title)} ${b.linkUrl ? `· <span dir="ltr">${esc(b.linkUrl)}</span>` : ''}</p>
        <button class="btn-text" type="button" data-btoggle="${b.id}" data-to="${b.active ? 0 : 1}">${esc(t(b.active ? 'admin.bannerShown' : 'admin.bannerOff'))}</button>
        <button class="btn-text" type="button" data-bdel="${b.id}">${esc(t('admin.deletePhoto'))}</button>
      </div>
    </div>`).join('');
}
$('#bannersPanel').addEventListener('toggle', (e) => { if (e.target.open) loadBanners(); });
$('#bannerFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const f = $('#bannerForm');
  try {
    const image = await compressForUpload(file);
    await call('/api/admin/banners', { method: 'POST', body: { image, placement: f.placement.value, title: f.title.value, linkUrl: f.linkUrl.value } });
    f.title.value = ''; f.linkUrl.value = '';
    $('#bannerMsg').textContent = t('admin.bannerAdded');
    loadBanners();
  } catch (err) { $('#bannerMsg').textContent = errorText(err) + (err.fields ? ' — ' + Object.entries(err.fields).map(([k, v]) => `${k}: ${t(`errors.${v}`)}`).join(', ') : ''); }
  finally { e.target.value = ''; }
});
$('#bannerList').addEventListener('change', async (e) => {
  const s2 = e.target.closest('[data-bplace]');
  if (s2) { await call(`/api/admin/banners/${s2.dataset.bplace}`, { method: 'PATCH', body: { placement: s2.value } }); loadBanners(); }
});
$('#bannerList').addEventListener('click', async (e) => {
  const tg = e.target.closest('[data-btoggle]'); const del = e.target.closest('[data-bdel]');
  if (tg) await call(`/api/admin/banners/${tg.dataset.btoggle}`, { method: 'PATCH', body: { active: tg.dataset.to === '1' } });
  else if (del) { if (!confirm(t('account.confirmDelete'))) return; await call(`/api/admin/banners/${del.dataset.bdel}`, { method: 'DELETE' }); }
  else return;
  loadBanners();
});

/* ---------- site texts editor ---------- */
let textsTimer;
async function loadTexts() {
  const lang = $('#textsLang').value || 'ar';
  const q = $('#textsQ').value.trim();
  const r = await call(`/api/admin/texts?lang=${lang}&q=${encodeURIComponent(q)}`);
  if (!$('#textsLang').options.length) {
    $('#textsLang').innerHTML = r.langs.map((l) => `<option value="${l}">${l.toUpperCase()}</option>`).join('');
    // start with the language this browser shows the site in (edits in another language are invisible to you)
    const seen = (() => { try { return localStorage.getItem('st_lang'); } catch { return null; } })() || document.documentElement.lang || 'ar';
    if (r.langs.includes(seen) && seen !== lang) { $('#textsLang').value = seen; return loadTexts(); }
  }
  $('#textsSeen').textContent = t('admin.textsSeen', { lang: (document.documentElement.lang || 'ar').toUpperCase() });
  $('#textsList').innerHTML = r.items.map((it) => `
    <div class="text-item" data-key="${esc(it.key)}">
      <small dir="ltr">${esc(it.key)}${it.value !== null ? ` · <b>${esc(t('admin.textsEdited'))}</b>` : ''}</small>
      <textarea class="input" rows="${Math.min(10, Math.max(2, Math.ceil((it.value ?? it.base).length / 60)))}" dir="auto">${esc(it.value ?? it.base)}</textarea>
      <div><button class="btn-text" type="button" data-tsave>${esc(t('admin.textsSave'))}</button>
        ${it.value !== null ? `<button class="btn-text" type="button" data-treset>${esc(t('admin.textsReset'))}</button>` : ''}
        <span class="fine" data-tmsg></span></div>
    </div>`).join('');
}
$('#textsPanel').addEventListener('toggle', (e) => { if (e.target.open) loadTexts(); });
$('#textsQ').addEventListener('input', () => { clearTimeout(textsTimer); textsTimer = setTimeout(loadTexts, 300); });
$('#textsLang').addEventListener('change', loadTexts);
$('#textsList').addEventListener('click', async (e) => {
  const item = e.target.closest('.text-item');
  if (!item) return;
  const save = e.target.closest('[data-tsave]'); const reset = e.target.closest('[data-treset]');
  if (!save && !reset) return;
  const value = reset ? null : item.querySelector('textarea').value;
  try {
    await call('/api/admin/texts', { method: 'PUT', body: { lang: $('#textsLang').value || 'ar', key: item.dataset.key, value, allLangs: $('#textsAll').checked } });
    if (reset) loadTexts(); else item.querySelector('[data-tmsg]').textContent = t('admin.textsSaved');
  } catch (err) { item.querySelector('[data-tmsg]').textContent = errorText(err); }
});

/* ---------- my account security ---------- */
async function loadSecurity() {
  const r = await call('/api/admin/security');
  $('#passkeyList').innerHTML = r.passkeys.length
    ? r.passkeys.map((k) => `<p class="fine review-row">🔑 <b>${esc(k.name)}</b> · ${fmtDate(k.createdAt)}${k.lastUsedAt ? ` · ${esc(t('admin.lastUsed', { date: fmtDate(k.lastUsedAt) }))}` : ''}
        <button class="btn-text" type="button" data-delkey="${k.id}">${esc(t('admin.deletePhoto'))}</button></p>`).join('')
    : `<p class="fine">${esc(t('admin.noPasskeys'))}</p>`;
  $('#backupLeft').textContent = t('admin.backupLeft', { n: r.backupCodesLeft });
  $('#mfaToggle').checked = r.mfaRequired;
  $('#loginList').innerHTML = r.logins.map((l) => `<p class="fine">${l.ok ? '✅' : '⛔'} ${fmtDate(l.at)} · ${esc(t(`admin.method_${l.method}`))} · <span dir="ltr">${esc(deviceName(l.device))}</span></p>`).join('');
  try { const h = await (await fetch('/readyz')).json(); $('#fingerprint').textContent = `v${h.version || ''} · ${h.fingerprint || '—'}`; } catch { /* ignore */ }
}
const deviceName = (ua) => (/iPhone/.test(ua) ? 'iPhone' : /Android/.test(ua) ? 'Android' : /Mac/.test(ua) ? 'Mac' : /Windows/.test(ua) ? 'Windows' : 'Other') + (/Chrome/.test(ua) ? ' · Chrome' : /Safari/.test(ua) ? ' · Safari' : /Firefox/.test(ua) ? ' · Firefox' : '');
$('#securityPanel').addEventListener('toggle', (e) => { if (e.target.open) loadSecurity(); });
$('#addPasskey').addEventListener('click', async () => {
  try {
    const o = await call('/api/admin/passkeys/options', { method: 'POST', body: {} });
    const cred = await navigator.credentials.create({ publicKey: {
      ...o, challenge: toBuf(o.challenge), user: { ...o.user, id: toBuf(o.user.id) },
      excludeCredentials: o.excludeCredentials.map((c) => ({ type: 'public-key', id: toBuf(c.id) })),
    } });
    const name = prompt(t('admin.passkeyName'), /iPhone/.test(navigator.userAgent) ? 'iPhone' : /Android/.test(navigator.userAgent) ? 'Android' : 'Passkey') || 'Passkey';
    await call('/api/admin/passkeys', { method: 'POST', body: { credential: credJson(cred), name } });
    $('#secMsg').textContent = t('admin.passkeyAdded');
    loadSecurity();
  } catch (err) { if (err?.name !== 'NotAllowedError') $('#secMsg').textContent = errorText(err); }
});
$('#passkeyList').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-delkey]');
  if (!b || !confirm(t('account.confirmDelete'))) return;
  try { await call(`/api/admin/passkeys/${b.dataset.delkey}`, { method: 'DELETE' }); loadSecurity(); }
  catch (err) { $('#secMsg').textContent = t(`errors.${err.code}`) !== `errors.${err.code}` ? t(`errors.${err.code}`) : errorText(err); }
});
$('#newCodes').addEventListener('click', async () => {
  if (!confirm(t('admin.newCodesConfirm'))) return;
  const r = await call('/api/admin/backup-codes', { method: 'POST', body: {} });
  $('#codesBox').textContent = `${t('admin.codesSaveNow')}\n\n${r.codes.join('\n')}`;
  $('#codesBox').hidden = false;
  loadSecurity();
});
$('#mfaToggle').addEventListener('change', async (e) => {
  try { await call('/api/admin/mfa', { method: 'POST', body: { required: e.target.checked } }); $('#secMsg').textContent = t('admin.saved'); }
  catch (err) { e.target.checked = false; $('#secMsg').textContent = t(`errors.${err.code}`); }
});

/* ---------- full backup & restore ---------- */
$('#restoreFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  $('#restoreMsg').textContent = t('common.loading');
  try {
    const res = await fetch('/api/admin/restore', { method: 'POST', headers: { 'Content-Type': 'application/zip', 'X-Requested-With': 'fetch' }, body: file });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error), { code: data.error });
    $('#restoreMsg').textContent = t('admin.restoreDone', { rows: data.rows });
    setTimeout(() => location.reload(), 4000);
  } catch (err) { $('#restoreMsg').textContent = t(`errors.${err.code}`) !== `errors.${err.code}` ? t(`errors.${err.code}`) : errorText(err); }
  finally { e.target.value = ''; }
});

boot();
