// لوحة الإدارة — ربط Claude (v8.3): مفتاح سري يُنشأ هنا ويظهر مرة واحدة، يُلغى فوراً، وسجلّ بكل ما فعله Claude.
(() => {
  const TOOL = {
    overview: 'نظرة عامة على اليوم', list_stores: 'البحث عن المتاجر', get_prices: 'قراءة الأسعار', set_prices: 'تعديل الأسعار',
    set_category_plan: 'أسعار وحدود قسم', get_ai_config: 'قراءة إعدادات المدير الذكي', set_ai_config: 'تعديل إعدادات المدير الذكي',
    get_delivery_settings: 'قراءة إعدادات التوصيل', set_delivery_settings: 'تعديل إعدادات التوصيل', list_pending: 'ما ينتظر قرارك',
    decide_renewal: 'قبول/رفض تجديد', store_ai: 'المدير الذكي لمتجر', suspend_account: 'إيقاف/تفعيل حساب', broadcast: 'رسالة للسائقين أو المتاجر',
  };
  const when = (s) => { if (!s) return '—'; try { return new Date(s).toLocaleString('ar-LB', { dateStyle: 'short', timeStyle: 'short' }); } catch { return s; } };
  const val = (v) => (v == null ? '—' : typeof v === 'object' ? JSON.stringify(v) : String(v));

  window.dxExtra = window.dxExtra || {};
  window.dxExtra.claude = async () => {
    const { api, esc, $, toast, fail, pane } = window.dxKit;
    const d = await api('GET', '/api/admin/mcp');
    const url = `${location.origin}/mcp`;
    pane().innerHTML = `
      <div class="card"><h3>🔌 ربط Claude بلوحة الإدارة</h3>
        <p class="small">بعد الربط تكتب لـ Claude من تطبيقه: «شو في طلبات ناطرة؟»، «غيّر سعر الاشتراك الشهري لـ 20$»، «أعطِ مطعم فلان المدير الذكي شهرين»… فيعرض عليك <b>قبل ← بعد</b>، ولا يحفظ شيئاً إلا بعد موافقتك.</p>
        <p class="small mute">ممنوع عليه: حذف الحسابات أو البيانات، تحويل الأموال أو السحوبات، أرقام Whish/OMT، كلمات السر. كل ما يفعله يُسجَّل أدناه باسم Claude.</p>
        <label class="f small">عنوان الربط (URL)<input class="in" readonly dir="ltr" id="mcpUrl" value="${esc(url)}"></label>
        <button class="btn sm alt" id="mcpCopyUrl">نسخ العنوان</button>
      </div>

      <div class="card"><h3>🔑 المفاتيح</h3>
        ${d.tokens.length ? d.tokens.map((t) => `<div class="mcp-row">
          <span><b>${esc(t.label)}</b> <span class="mute small" dir="ltr">${esc(t.hint || '')}</span><br><small class="mute">أُنشئ ${when(t.createdAt)} · آخر استخدام ${when(t.lastUsedAt)}</small></span>
          <button class="btn sm danger" data-revoke="${esc(t.id)}">إلغاء المفتاح</button></div>`).join('') : '<p class="mute small">لا يوجد مفتاح بعد.</p>'}
        <label class="f small">اسم المفتاح<input class="in" id="mcpLabel" value="Claude" maxlength="40"></label>
        <button class="btn" id="mcpNew">➕ إنشاء مفتاح جديد</button>
        <div id="mcpShow"></div>
      </div>

      <div class="card"><h3>📜 ما فعله Claude</h3>
        ${d.log.length ? d.log.map((l) => `<div class="mcp-log">
          <b>${esc(TOOL[l.tool] || l.tool || '—')}</b> · ${l.error ? `<span class="bad">❌ ${esc(l.error)}</span>` : l.applied ? '<span class="ok">✅ نُفِّذ</span>' : !(l.changes || []).length ? '<span class="mute">لا تغيير (القيم نفسها)</span>' : '<span class="mute">👁 معاينة فقط</span>'} <small class="mute">${when(l.at)}</small>
          ${(l.changes || []).map((c) => `<div class="small" dir="auto">• ${esc(c.field)}: <s class="mute">${esc(val(c.before))}</s> ← <b>${esc(val(c.after))}</b></div>`).join('')}</div>`).join('') : '<p class="mute small">لا شيء بعد.</p>'}
      </div>`;

    const copy = async (text) => { try { await navigator.clipboard.writeText(text); toast('نُسخ ✅'); } catch { toast('انسخه يدوياً'); } };
    $('#mcpCopyUrl').onclick = () => copy(url);
    $('#mcpNew').onclick = async () => {
      try {
        const r = await api('POST', '/api/admin/mcp/tokens', { label: $('#mcpLabel').value });
        const header = `Bearer ${r.token}`;
        $('#mcpShow').innerHTML = `<div class="card mcp-new">
          <p><b>⚠️ انسخه الآن — لن يظهر مرة ثانية.</b></p>
          <p class="small">في Claude: الإعدادات ← Connectors ← Add custom connector ← الاسم «أكلتك» والعنوان أعلاه، ثم «No sign in»، وتحت Request headers أضِف:</p>
          <label class="f small">Header name<input class="in" readonly dir="ltr" value="Authorization"></label>
          <label class="f small">Value<input class="in" readonly dir="ltr" id="mcpTok" value="${esc(header)}"></label>
          <button class="btn sm" id="mcpCopyTok">نسخ القيمة</button></div>`;
        $('#mcpCopyTok').onclick = () => copy(header);
        toast('أُنشئ المفتاح');
      } catch (e) { fail(e); }
    };
    pane().querySelectorAll('[data-revoke]').forEach((b) => { b.onclick = async () => {
      if (!confirm('إلغاء هذا المفتاح؟ يتوقف Claude عن الوصول فوراً.')) return;
      try { await api('DELETE', `/api/admin/mcp/tokens/${b.dataset.revoke}`); toast('أُلغي المفتاح'); window.dxExtra.claude(); } catch (e) { fail(e); }
    }; });
  };
})();
