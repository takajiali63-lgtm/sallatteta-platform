// لوحة الإدارة — مدير الأصوات (للمالك فقط). مكتبة الأصوات، ربط كل حدث بصوت، الأدوار، مستوى الصوت، التجربة قبل التفعيل.
// كل حفظ يرفع رقم الإصدار، فتجلب التطبيقات الإعداد الجديد ولا تُشغّل صوتاً قديماً. كل تغيير مسجّل في سجل الإدارة.
(() => {
  window.dxExtra = window.dxExtra || {};
  const ROLE_AR = { customer: 'زبون', store: 'متجر', driver: 'سائق' };
  const ERR_AR = { invalid_type: 'نوع الملف غير مسموح (mp3 / ogg / wav / m4a / aac فقط)', too_large: 'الملف أكبر من 300 كيلوبايت', invalid: 'ملف غير صالح' };
  const EXT_MIME = { mp3: 'audio/mpeg', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', wav: 'audio/wav', m4a: 'audio/mp4', mp4: 'audio/mp4', aac: 'audio/aac' };
  let data = null, q = '', cat = '';
  let player = null;

  const kb = (n) => `${Math.round(Number(n || 0) / 102.4) / 10} KB`;
  function preview(url, vol) {
    try { player?.pause(); } catch { /* ignore */ }
    player = new Audio(url);
    player.volume = Math.max(0, Math.min(1, vol));
    player.play().catch(() => window.dxKit.toast('تعذّر تشغيل الصوت على هذا الجهاز'));
  }
  // Reads a picked file as a data URL; phones sometimes give no MIME type, then we label it from the extension
  // (the server still checks the real bytes).
  function readFile(file) {
    return new Promise((resolve, reject) => {
      const ext = String(file.name).toLowerCase().split('.').pop();
      if (!EXT_MIME[ext]) return reject(Object.assign(new Error('type'), { msg: ERR_AR.invalid_type }));
      if (file.size > data.maxBytes) return reject(Object.assign(new Error('size'), { msg: ERR_AR.too_large }));
      const r = new FileReader();
      r.onload = () => {
        let url = String(r.result);
        if (!url.startsWith('data:audio/')) url = url.replace(/^data:[^;,]*/, `data:${EXT_MIME[ext]}`);
        resolve({ dataUrl: url, fileName: file.name });
      };
      r.onerror = () => reject(Object.assign(new Error('read'), { msg: 'تعذّرت قراءة الملف' }));
      r.readAsDataURL(file);
    });
  }
  // Like dxKit.api but keeps the server's field errors, so an upload refusal says exactly why (type / size).
  async function send(method, path, body) {
    const r = await fetch(path, { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    let d = null; try { d = await r.json(); } catch { /* empty */ }
    if (!r.ok) throw Object.assign(new Error(d?.error || 'error'), { status: r.status, code: d?.error, fields: d?.fields });
    return d;
  }
  const showErr = (e) => {
    const { toast, fail } = window.dxKit;
    if (e.msg) return toast(e.msg);
    const f = e.fields && (e.fields.dataUrl || e.fields.volume || e.fields.roles || e.fields.sound);
    if (f && ERR_AR[f]) return toast(ERR_AR[f]);
    if (e.code === 'validation_failed') return toast('تحقّق من البيانات أو من نوع الملف وحجمه');
    if (e.code === 'payload_too_large') return toast(ERR_AR.too_large);
    fail(e);
  };

  async function upload(file, extra = {}) {
    const { toast } = window.dxKit;
    const f = await readFile(file);
    const name = extra.name || file.name.replace(/\.[^.]+$/, '').slice(0, 60);
    data = await send('POST', '/api/admin/sounds/files', { name, ...f, ...(extra.event ? { event: extra.event } : {}) });
    toast('رُفع الصوت ✓');
  }

  function soundOptions(sel) {
    const { esc } = window.dxKit;
    const opt = (s) => `<option value="${esc(s.ref)}" ${s.ref === sel ? 'selected' : ''}>${esc(s.name)}</option>`;
    return `<optgroup label="أصوات جاهزة">${data.library.filter((s) => s.builtin).map(opt).join('')}</optgroup>
      ${data.library.some((s) => !s.builtin) ? `<optgroup label="أصواتك المرفوعة">${data.library.filter((s) => !s.builtin).map(opt).join('')}</optgroup>` : ''}`;
  }

  function rows() {
    const { esc } = window.dxKit;
    const needle = q.trim().toLowerCase();
    const list = data.events.filter((e) => (!cat || e.category === cat) && (!needle || e.name.toLowerCase().includes(needle) || e.key.includes(needle)));
    if (!list.length) return '<tr><td colspan="9" class="mute">لا نتائج</td></tr>';
    return list.map((e) => `<tr data-k="${esc(e.key)}">
      <td><b>${esc(e.name)}</b><div class="chips"><span class="chip">${esc(e.key)}</span>${e.priority === 'high' ? '<span class="chip b">تنبيه حرج</span>' : ''}${e.changed ? '<span class="chip a">معدّل</span>' : ''}</div></td>
      <td><span class="chip g">${esc(data.categories[e.category] || e.category)}</span></td>
      <td>${data.roles.map((r) => `<label class="small"><input type="checkbox" data-role="${r}" ${e.roles.includes(r) ? 'checked' : ''}> ${ROLE_AR[r]}</label>`).join('<br>')}</td>
      <td><select class="in" data-f="sound">${soundOptions(e.sound)}</select></td>
      <td><label class="small"><input type="checkbox" data-f="enabled" ${e.enabled ? 'checked' : ''}> مفعّل</label></td>
      <td><input class="in" type="range" min="0" max="100" step="1" value="${e.volume}" data-f="volume"><span class="small" data-vol>${e.volume}%</span></td>
      <td><button class="btn sm alt" data-a="play" aria-label="تجربة">▶</button></td>
      <td><label class="btn sm alt">⤴ استبدال<input type="file" accept=".mp3,.ogg,.oga,.opus,.wav,.m4a,.aac,audio/*" data-a="replace" hidden></label></td>
      <td><button class="btn sm" data-a="save">حفظ</button></td></tr>`).join('');
  }

  function bindRows() {
    const { $, $$, api, toast } = window.dxKit;
    $$('#sndRows tr[data-k]').forEach((tr) => {
      const key = tr.dataset.k;
      const vol = $('[data-f="volume"]', tr);
      vol.oninput = () => { $('[data-vol]', tr).textContent = `${vol.value}%`; };
      // preview = what is selected in the row right now, before saving (try before activating)
      $('[data-a="play"]', tr).onclick = () => {
        const ref = $('[data-f="sound"]', tr).value;
        const s = data.library.find((x) => x.ref === ref);
        if (s) preview(s.url, Number(vol.value) / 100);
      };
      $('[data-a="save"]', tr).onclick = async () => {
        try {
          data = await api('PUT', `/api/admin/sounds/events/${key}`, {
            enabled: $('[data-f="enabled"]', tr).checked,
            volume: Number(vol.value),
            roles: $$('[data-role]', tr).filter((c) => c.checked).map((c) => c.dataset.role),
            sound: $('[data-f="sound"]', tr).value,
          });
          toast('حُفظ ✓ — تصل التغييرات للتطبيقات تلقائياً');
          draw();
        } catch (e) { showErr(e); }
      };
      $('[data-a="replace"]', tr).onchange = async (ev) => {
        const file = ev.target.files?.[0];
        if (!file) return;
        try { await upload(file, { event: key }); draw(); } catch (e) { showErr(e); }
      };
    });
  }

  function library() {
    const { esc } = window.dxKit;
    const mine = data.library.filter((s) => !s.builtin);
    return `<div class="card"><h3>📚 مكتبة الأصوات</h3>
      <p class="small mute">المسموح: mp3 و ogg و wav و m4a/aac، حتى 300 كيلوبايت للملف. يُفحص محتوى الملف نفسه، لا اسمه فقط. جرّب الصوت ▶ قبل ربطه بأي حدث.</p>
      <div class="row"><input class="in" id="sndName" maxlength="60" placeholder="اسم الصوت (اختياري)">
        <label class="btn sm">⤴ رفع صوت جديد<input type="file" id="sndUp" accept=".mp3,.ogg,.oga,.opus,.wav,.m4a,.aac,audio/*" hidden></label></div>
      <div class="scrollx"><table class="tbl"><tr><th>الاسم</th><th>النوع</th><th>الحجم</th><th></th><th></th><th></th></tr>
      ${mine.map((s) => `<tr data-id="${s.id}"><td>${esc(s.name)}</td><td>${esc(s.mime)}</td><td>${kb(s.size)}</td>
        <td><button class="btn sm alt" data-a="lplay" data-url="${esc(s.url)}">▶</button></td>
        <td><label class="btn sm alt">استبدال الملف<input type="file" data-a="lrep" accept=".mp3,.ogg,.oga,.opus,.wav,.m4a,.aac,audio/*" hidden></label></td>
        <td><button class="btn sm alt" data-a="ldel">حذف</button></td></tr>`).join('') || '<tr><td colspan="6" class="mute">لم تُرفع أصوات بعد — الأصوات الجاهزة تعمل تلقائياً.</td></tr>'}
      </table></div>
      <details><summary class="small">الأصوات الجاهزة (${data.library.filter((s) => s.builtin).length})</summary><div class="chips">
        ${data.library.filter((s) => s.builtin).map((s) => `<button class="chip" data-a="lplay" data-url="${esc(s.url)}">▶ ${esc(s.name)}</button>`).join('')}</div></details></div>`;
  }

  function bindLibrary() {
    const { $, $$, api, toast } = window.dxKit;
    $$('[data-a="lplay"]').forEach((b) => { b.onclick = () => preview(b.dataset.url, 0.8); });
    $('#sndUp').onchange = async (ev) => {
      const file = ev.target.files?.[0];
      if (!file) return;
      try { await upload(file, { name: $('#sndName').value.trim() }); draw(); } catch (e) { showErr(e); }
    };
    $$('tr[data-id]').forEach((tr) => {
      const id = tr.dataset.id;
      $('[data-a="lrep"]', tr).onchange = async (ev) => {
        const file = ev.target.files?.[0];
        if (!file) return;
        try { const f = await readFile(file); data = await send('PUT', `/api/admin/sounds/files/${id}`, f); toast('استُبدل الملف ✓'); draw(); } catch (e) { showErr(e); }
      };
      $('[data-a="ldel"]', tr).onclick = async () => {
        if (!confirm('حذف هذا الصوت؟ الأحداث التي تستعمله تعود إلى صوتها الجاهز.')) return;
        try { data = await api('DELETE', `/api/admin/sounds/files/${id}`); toast('حُذف'); draw(); } catch (e) { showErr(e); }
      };
    });
  }

  function draw() {
    const { esc, $, pane, api, toast } = window.dxKit;
    pane().innerHTML = `<div class="card"><h3>🔊 مدير الأصوات</h3>
        <label class="row"><input type="checkbox" id="sndAll" ${data.enabled ? 'checked' : ''}> <b>كل المؤثرات الصوتية مفعّلة</b></label>
        <p class="small mute">الإصدار الحالي: ${data.version}. أي حفظ يصل إلى تطبيقات الزبائن والمتاجر والسائقين تلقائياً. أصوات إشعارات الهاتف (والتطبيق مغلق) يحدّدها نظام الهاتف ولا تتغيّر من هنا.</p>
        <button class="btn sm alt" id="sndReset">↺ استعادة الإعدادات الافتراضية</button></div>
      ${library()}
      <div class="card"><h3>الأحداث</h3>
        <div class="row"><input class="in" id="sndQ" placeholder="ابحث باسم الحدث…" value="${esc(q)}">
          <select class="in" id="sndCat"><option value="">كل الفئات</option>${Object.entries(data.categories).map(([k, v]) => `<option value="${k}" ${k === cat ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></div>
        <div class="scrollx"><table class="tbl"><thead><tr><th>الحدث</th><th>الفئة</th><th>يسمعه</th><th>الصوت</th><th>تشغيل</th><th>مستوى الصوت</th><th>تجربة</th><th>استبدال</th><th></th></tr></thead>
        <tbody id="sndRows">${rows()}</tbody></table></div></div>`;
    $('#sndAll').onchange = async (ev) => {
      try { data = await api('PUT', '/api/admin/sounds/settings', { enabled: ev.target.checked }); toast(ev.target.checked ? 'شُغّلت الأصوات ✓' : 'أُوقفت كل الأصوات'); draw(); } catch (e) { showErr(e); draw(); }
    };
    $('#sndReset').onclick = async () => {
      if (!confirm('استعادة كل الأحداث إلى أصواتها وإعداداتها الافتراضية؟ تبقى ملفاتك المرفوعة في المكتبة.')) return;
      try { data = await api('POST', '/api/admin/sounds/restore', { confirm: true }); toast('استُعيدت الإعدادات الافتراضية ✓'); draw(); } catch (e) { showErr(e); }
    };
    $('#sndQ').oninput = (ev) => { q = ev.target.value; $('#sndRows').innerHTML = rows(); bindRows(); };
    $('#sndCat').onchange = (ev) => { cat = ev.target.value; $('#sndRows').innerHTML = rows(); bindRows(); };
    bindLibrary();
    bindRows();
  }

  window.dxExtra.sounds = async () => {
    const { api, pane } = window.dxKit;
    pane().innerHTML = '<div class="skel cover"></div>';
    data = await api('GET', '/api/admin/sounds');
    draw();
  };
})();
