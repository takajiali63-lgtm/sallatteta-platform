// لوحة الإدارة — التوصيل (للمالك فقط). كل قسم وحده، بلا عجقة.
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => `${Math.round(Number(n || 0) * 100) / 100}$`;
const when = (s) => { try { return new Date(s).toLocaleString('ar-LB', { dateStyle: 'short', timeStyle: 'short' }); } catch { return s; } };
const ERR = { unauthorized: 'سجّل الدخول إلى لوحة الإدارة أولاً', forbidden: 'هذا القسم للمالك فقط', invalid_state: 'تغيّرت الحالة، حدّث الصفحة', not_found: 'غير موجود', validation_failed: 'تحقّق من البيانات' };

async function api(method, path, body) {
  const r = await fetch(path, { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  let d = null; try { d = await r.json(); } catch { /* binary */ }
  if (!r.ok) { const e = new Error(d?.error || 'error'); e.status = r.status; e.code = d?.error; throw e; }
  return d;
}
function toast(m) { let el = $('.toast'); if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); } el.textContent = m; el.classList.remove('hide'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.add('hide'), 3000); }
const fail = (e) => { if (e.status === 401) { location.href = './'; return; } toast(ERR[e.code] || 'حدث خطأ'); };
function sheet(html) {
  const bg = document.createElement('div'); bg.className = 'sheet-bg'; bg.innerHTML = `<div class="sheet">${html}</div>`;
  bg.addEventListener('click', (e) => { if (e.target === bg || e.target.closest('[data-close]')) bg.remove(); });
  document.body.appendChild(bg); return { el: bg.querySelector('.sheet'), close: () => bg.remove() };
}
function ask(title, label, { min = 3 } = {}) {
  return new Promise((resolve) => {
    const s = sheet(`<h2>${esc(title)}</h2><form><label class="f">${esc(label)}<input class="in" name="v" required minlength="${min}"></label><button class="btn">تأكيد</button></form>`);
    $('form', s.el).addEventListener('submit', (e) => { e.preventDefault(); const v = e.target.v.value.trim(); s.close(); resolve(v); });
  });
}
async function openPrivateImage(url) {
  const r = await fetch(url, { credentials: 'same-origin' });
  if (!r.ok) return toast('تعذّر فتح الصورة');
  const blobUrl = URL.createObjectURL(await r.blob());
  sheet(`<img src="${blobUrl}" alt=""><button class="btn alt" data-close>إغلاق</button>`);
}

const TABS = [
  ['overview', '📊 نظرة عامة'], ['orders', '🧾 الطلبات'], ['drivers', '🛵 السائقون'], ['stores', '🏪 المتاجر'], ['customers', '👤 الزبائن'],
  ['topups', '💳 شحن الرصيد'], ['payouts', '💸 السحوبات'], ['complaints', '⚠️ الشكاوى'], ['settings', '⚙️ الإعدادات'],
];
let tab = new URLSearchParams(location.hash.slice(1)).get('t') || 'overview';
let country = '';
let COUNTRIES = [];
const cq = (sep = '?') => (country ? `${sep}country=${country}` : '');
async function confirmDel(msg, url, then) { if (!confirm(msg)) return; try { await api('DELETE', url); toast('حُذف'); then?.(); } catch (e) { fail(e); } }
const STATUS = { pending: 'بانتظار المتجر', rejected: 'مرفوض', preparing: 'قيد التحضير', searching: 'يبحث عن سائق', assigned: 'السائق متجه للمتجر', picked_up: 'في الطريق', delivered: 'تم التسليم', cancelled: 'ملغى', active: 'مفعّل', suspended: 'موقوف', due: 'مستحقة', paid: 'مدفوعة', approved: 'مقبول', open: 'مفتوحة', warned: 'أُرسل إنذار', dismissed: 'مرفوضة' };
const MODE = { delivery: 'سائقو المنصة', self: 'توصيل خاص', none: 'واتساب فقط' };
const TYPE = { store: 'متجر', driver: 'سائق', customer: 'زبون' };
const DOC = { selfie: 'صورة شخصية', idCard: 'الهوية', license: 'رخصة القيادة', vehicleFront: 'المركبة من الأمام', vehicleBack: 'المركبة من الخلف', registration: 'دفتر المركبة', criminalRecord: 'السجل العدلي' };

function frame() {
  document.body.innerHTML = `<main class="wrap wide"><div class="row"><h1>التوصيل</h1><a class="btn sm alt" href="./">← لوحة الإدارة</a></div>
    <label class="small">البلد <select class="in" id="cty"><option value="">كل البلدان</option>${COUNTRIES.map((c) => `<option value="${c}" ${c === country ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
    <div class="tabs">${TABS.map(([k, n]) => `<button data-t="${k}" class="${k === tab ? 'on' : ''}">${n}</button>`).join('')}</div><div id="pane"><div class="skel cover"></div></div></main>`;
  $$('[data-t]').forEach((b) => { b.onclick = () => { tab = b.dataset.t; location.hash = `t=${tab}`; frame(); }; });
  $('#cty').onchange = (e) => { country = e.target.value; frame(); };
  ({ overview, orders, drivers, stores, customers, topups, payouts, complaints, settings }[tab] || overview)().catch(fail);
}
const pane = () => $('#pane');

async function overview() {
  const o = await api('GET', `/api/admin/delivery/overview${cq()}`);
  const box = (n, l, t) => `<button class="stat" data-go="${t}"><b>${n}</b><span>${l}</span></button>`;
  pane().innerHTML = `<div class="grid2">${box(o.ordersToday, 'طلبات اليوم', 'orders')}${box(o.activeOrders, 'طلبات جارية', 'orders')}${box(o.driversAvailable, 'سائقون متاحون الآن', 'drivers')}${box(o.driversPending, 'سائقون بانتظار المراجعة', 'drivers')}
    ${box(o.topupsPending, 'طلبات شحن بانتظارك', 'topups')}${box(o.payoutsDue, 'طلبات سحب بانتظارك', 'payouts')}${box(o.complaintsOpen, 'شكاوى مفتوحة', 'complaints')}</div>`;
  $$('[data-go]').forEach((b) => { b.onclick = () => { tab = b.dataset.go; frame(); }; });
}

async function orders() {
  const { orders: rows } = await api('GET', `/api/admin/orders${cq()}`);
  const { errands } = await api('GET', `/api/admin/errands${cq()}`);
  pane().innerHTML = `<div class="scrollx"><table class="tbl"><tr><th>#</th><th>المتجر</th><th>الزبون</th><th>السائق</th><th>الحالة</th><th>المبلغ</th><th>الأجرة</th><th>الوقت</th></tr>
    ${rows.map((o) => `<tr><td>${o.id}</td><td>${esc(o.store)}</td><td>${esc(o.customer)}</td><td>${esc(o.driver || '—')}</td><td>${esc(STATUS[o.status] || o.status)}</td><td>${money(o.total)}</td><td>${o.delivery_fee ? money(o.delivery_fee) : '—'}</td><td class="small">${esc(when(o.created_at))}</td><td><button class="btn sm bad" data-do="${o.id}">✕</button></td></tr>`).join('')}</table></div>
    <h2>🛵 طلبات الزبائن المباشرة للسائقين</h2>
    <div class="scrollx"><table class="tbl"><tr><th>#</th><th>النوع</th><th>الزبون</th><th>السائق</th><th>الحالة</th><th>السعر</th><th>المشتريات</th><th>الوقت</th></tr>
    ${errands.map((e) => `<tr><td>${e.id}</td><td>${{ deliver: '📦 توصيل', buy: '🛍️ جلب من محل', service: '🧾 خدمة' }[e.kind]}</td><td>${esc(e.customer)}</td><td>${esc(e.driver || '—')}</td><td>${esc({ searching: 'يبحث عن سائق', assigned: 'قَبِل السائق', picked_up: 'في الطريق', delivered: 'تم', cancelled: 'ملغى' }[e.status])}</td><td>${money(e.price)}</td><td>${e.purchase_value != null ? money(e.purchase_value) : '—'}</td><td class="small">${esc(when(e.created_at))}</td><td><button class="btn sm bad" data-de="${e.id}">✕</button></td></tr>`).join('')}</table></div>`;
  $$('[data-do]').forEach((b) => { b.onclick = () => confirmDel(`حذف الطلب #${b.dataset.do} نهائياً؟`, `/api/admin/orders/${b.dataset.do}`, orders); });
  $$('[data-de]').forEach((b) => { b.onclick = () => confirmDel(`حذف طلب السائق #${b.dataset.de} مع الدردشة نهائياً؟`, `/api/admin/errands/${b.dataset.de}`, orders); });
}

async function drivers(filter = 'pending') {
  const { drivers: rows } = await api('GET', `/api/admin/drivers${filter ? `?status=${filter}${cq('&')}` : cq()}`);
  pane().innerHTML = `<div class="tabs">${[['pending', 'بانتظار المراجعة'], ['active', 'مفعّلون'], ['suspended', 'موقوفون'], ['', 'الكل']].map(([k, n]) => `<button data-f="${k}" class="${k === filter ? 'on' : ''}">${n}</button>`).join('')}</div>
    ${rows.length ? rows.map((d) => `<div class="card"><div class="row"><b>${esc(d.full_name)}</b><span class="chip ${d.status === 'active' ? 'g' : d.status === 'suspended' ? 'b' : 'w'}">${esc(STATUS[d.status] || d.status)}</span></div>
      <p class="small">📞 +${esc(d.phone)} · ${d.vehicle === 'car' ? 'سيارة' : 'دراجة نارية'} ${esc(d.plate || '')} · ${esc((d.wallet_provider || '').toUpperCase())} ${esc(d.wallet_number || '')}</p>
      <p class="small">الرصيد: <b>${money(d.balance)}</b> · الإنذارات: ${d.warnings} · ${d.available ? '🟢 متاح' : '⚪ غير متاح'}</p>
      <button class="btn sm alt" data-open="${d.id}">الوثائق والتفاصيل</button></div>`).join('') : '<div class="empty">لا يوجد</div>'}`;
  $$('[data-f]').forEach((b) => { b.onclick = () => drivers(b.dataset.f).catch(fail); });
  $$('[data-open]').forEach((b) => { b.onclick = () => driverSheet(Number(b.dataset.open), filter).catch(fail); });
}
async function driverSheet(id, filter) {
  const { driver: d, documents } = await api('GET', `/api/admin/drivers/${id}`);
  const s = sheet(`<h2>${esc(d.full_name)}</h2><p class="small">📞 +${esc(d.phone)} · وافق على الشروط: ${esc(when(d.terms_accepted_at))}</p>
    <div class="docs">${documents.map((x) => `<button class="btn alt" data-doc="${x.id}">📄 ${esc(DOC[x.kind] || x.kind)}</button>`).join('')}</div>
    ${d.warnings.items.map((w) => `<p class="small">⚠️ ${esc(w.reason)} — ${esc(when(w.at))}</p>`).join('')}
    <div class="card"><b>اشتراك طلبات الزبائن</b><p class="small">${d.jobs_until && new Date(d.jobs_until) > new Date() ? `✅ فعّال حتى ${esc(when(d.jobs_until))}` : 'غير مفعّل — لا تصله طلبات الزبائن المباشرة'}</p>
      <div class="row"><select class="in" id="jm"><option value="1">شهر</option><option value="3">3 أشهر</option><option value="6">6 أشهر</option><option value="12">سنة</option><option value="0">إيقاف</option></select><button class="btn sm" id="jset">تطبيق</button></div></div>
    <div class="grid2">${d.status !== 'active' ? '<button class="btn" data-s="active">تفعيل</button>' : ''}${d.status === 'pending' ? '<button class="btn bad" data-s="rejected">رفض</button>' : ''}
    ${d.status === 'active' ? '<button class="btn bad" data-s="suspended">إيقاف وإخفاء</button>' : ''}<button class="btn acc" data-w>إنذار</button><button class="btn alt" data-lg>سجل الرصيد والسحوبات</button><button class="btn bad" data-xd>حذف الحساب نهائياً</button></div>
    <button class="btn alt" data-close>إغلاق</button>`);
  $$('[data-doc]', s.el).forEach((b) => { b.onclick = () => openPrivateImage(`/api/admin/drivers/${id}/documents/${b.dataset.doc}`); });
  $$('[data-s]', s.el).forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/drivers/${id}/status`, { status: b.dataset.s }); s.close(); toast('تم'); drivers(filter); } catch (e) { fail(e); } }; });
  $('[data-w]', s.el).onclick = () => warn('driver', id, () => { s.close(); drivers(filter); });
  $('[data-lg]', s.el).onclick = () => accountLog('driver', id).catch(fail);
  $('[data-xd]', s.el).onclick = () => confirmDel('حذف السائق مع وثائقه ورصيده وسجله نهائياً؟', `/api/admin/drivers/${id}`, () => { s.close(); drivers(filter); });
  $('#jset', s.el).onclick = async () => { try { await api('POST', `/api/admin/drivers/${id}/jobs`, { months: Number($('#jm', s.el).value) }); s.close(); toast('تم'); drivers(filter); } catch (e) { fail(e); } };
}
async function warn(type, id, then) {
  const reason = await ask(`إنذار ${TYPE[type]}`, 'سبب الإنذار');
  try { const r = await api('POST', '/api/admin/warnings', { type, id, reason }); toast(r.suspended ? `الإنذار ${r.count} من ${r.max} — أُوقف الحساب تلقائياً` : `الإنذار ${r.count} من ${r.max}`); then?.(); } catch (e) { fail(e); }
}

async function stores(q = '') {
  const { stores: rows } = await api('GET', `/api/admin/delivery/stores${q ? `?q=${encodeURIComponent(q)}${cq('&')}` : cq()}`);
  pane().innerHTML = `<div class="search"><span>🔍</span><input id="sq" placeholder="ابحث بالاسم أو الرقم" value="${esc(q)}"></div>
    ${rows.map((c) => `<div class="card"><div class="row"><b>${c.pinned ? '📌 ' : ''}${esc(c.full_name)}</b><span class="chip ${Number(c.suspended) ? 'b' : 'g'}">${Number(c.suspended) ? 'موقوف' : 'ظاهر'}</span></div>
      <p class="small">${esc(c.kind)} · ${esc(c.country || 'LB')} · رصيد ${money(c.balance)} · إنذارات ${c.warnings}</p>
      <div class="row"><label class="small">التوصيل <select class="in" data-mode="${c.id}">${Object.entries(MODE).map(([k, n]) => `<option value="${k}" ${c.delivery_mode === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label class="check"><input type="checkbox" data-book="${c.id}" ${Number(c.booking) ? 'checked' : ''}><span>المواعيد</span></label>
      <label class="check"><input type="checkbox" data-pin="${c.id}" ${Number(c.pinned) ? 'checked' : ''}><span>تثبيت</span></label></div>
      <div class="row"><button class="btn sm ${Number(c.suspended) ? '' : 'bad'}" data-sus="${c.id}" data-on="${Number(c.suspended) ? 0 : 1}">${Number(c.suspended) ? 'تفعيل' : 'إيقاف وإخفاء'}</button>
      <button class="btn sm acc" data-wr="${c.id}">إنذار</button><button class="btn sm alt" data-adj="${c.id}">تعديل الرصيد</button><button class="btn sm alt" data-lg="${c.id}">السجل</button><button class="btn sm bad" data-xs="${c.id}">حذف نهائي</button></div></div>`).join('')}`;
  let deb; $('#sq').oninput = (e) => { clearTimeout(deb); deb = setTimeout(() => stores(e.target.value.trim()).catch(fail), 400); };
  const set = (id, body) => api('POST', `/api/admin/stores/${id}/delivery`, body).then(() => toast('تم الحفظ')).catch(fail);
  $$('[data-mode]').forEach((s) => { s.onchange = () => set(s.dataset.mode, { mode: s.value }); });
  $$('[data-book]').forEach((s) => { s.onchange = () => set(s.dataset.book, { booking: s.checked }); });
  $$('[data-pin]').forEach((s) => { s.onchange = () => set(s.dataset.pin, { pinned: s.checked }); });
  $$('[data-sus]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/accounts/store/${b.dataset.sus}/${b.dataset.on === '1' ? 'suspend' : 'activate'}`, {}); stores(q); } catch (e) { fail(e); } }; });
  $$('[data-wr]').forEach((b) => { b.onclick = () => warn('store', Number(b.dataset.wr), () => stores(q)); });
  $$('[data-lg]').forEach((b) => { b.onclick = () => accountLog('store', Number(b.dataset.lg)).catch(fail); });
  $$('[data-xs]').forEach((b) => { b.onclick = async () => {
    if (!confirm('حذف المتجر مع منيوه وصوره وطلباته ورصيده وسجله نهائياً؟')) return;
    try { await api('DELETE', `/api/admin/delivery/stores/${b.dataset.xs}/leftovers`); await api('DELETE', `/api/admin/cooks/${b.dataset.xs}`); toast('حُذف'); stores(q); } catch (e) { fail(e); }
  }; });
  $$('[data-adj]').forEach((b) => { b.onclick = async () => {
    const amount = Number(await ask('تعديل رصيد المتجر', 'المبلغ (سالب للخصم)', { min: 1 }));
    const note = await ask('سبب التعديل', 'السبب');
    try { await api('POST', `/api/admin/stores/${b.dataset.adj}/wallet-adjust`, { amount, note }); stores(q); } catch (e) { fail(e); }
  }; });
}

async function customers(q = '') {
  const { customers: rows } = await api('GET', `/api/admin/customers${q ? `?q=${encodeURIComponent(q)}${cq('&')}` : cq()}`);
  pane().innerHTML = `<div class="search"><span>🔍</span><input id="cq" placeholder="ابحث بالاسم أو الرقم" value="${esc(q)}"></div>
    ${rows.map((c) => `<div class="card row"><span><b>${esc(c.name)}</b><br><small class="mute">+${esc(c.phone)} · ${esc(c.country || '')} · إنذارات ${c.warnings}</small></span>
      <span><button class="btn sm ${c.status === 'suspended' ? '' : 'bad'}" data-cs="${c.id}" data-on="${c.status === 'suspended' ? 0 : 1}">${c.status === 'suspended' ? 'تفعيل' : 'إيقاف'}</button> <button class="btn sm acc" data-cw="${c.id}">إنذار</button> <button class="btn sm bad" data-cx="${c.id}">حذف</button></span></div>`).join('')}`;
  $$('[data-cx]').forEach((b) => { b.onclick = () => confirmDel('حذف الزبون مع عناوينه وطلباته ودردشاته نهائياً؟', `/api/admin/customers/${b.dataset.cx}`, () => customers(q)); });
  let deb; $('#cq').oninput = (e) => { clearTimeout(deb); deb = setTimeout(() => customers(e.target.value.trim()).catch(fail), 400); };
  $$('[data-cs]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/accounts/customer/${b.dataset.cs}/${b.dataset.on === '1' ? 'suspend' : 'activate'}`, {}); customers(q); } catch (e) { fail(e); } }; });
  $$('[data-cw]').forEach((b) => { b.onclick = () => warn('customer', Number(b.dataset.cw), () => customers(q)); });
}

async function topups() {
  const { topups: rows } = await api('GET', '/api/admin/topups?status=pending');
  pane().innerHTML = rows.length ? rows.map((x) => `<div class="card"><div class="row"><b>${esc(x.store)}</b><span class="big">${money(x.amount)}</span></div>
    <p class="small">${esc(x.method.toUpperCase())} ${x.reference ? `· ${esc(x.reference)}` : ''} · ${esc(when(x.created_at))}</p>
    <div class="row"><button class="btn sm alt" data-rc="${x.id}">🧾 الإيصال</button><button class="btn sm" data-ok="${x.id}">تأكيد وإضافة الرصيد</button><button class="btn sm bad" data-no="${x.id}">رفض</button></div></div>`).join('') : '<div class="empty">لا توجد طلبات شحن بانتظارك</div>';
  $$('[data-rc]').forEach((b) => { b.onclick = () => openPrivateImage(`/api/admin/topups/${b.dataset.rc}/receipt`); });
  $$('[data-ok],[data-no]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/topups/${b.dataset.ok || b.dataset.no}/${b.dataset.ok ? 'approve' : 'reject'}`, {}); topups(); } catch (e) { fail(e); } }; });
}

async function payouts(filter = 'pending') {
  const { withdrawals: rows } = await api('GET', `/api/admin/withdrawals?status=${filter}`);
  pane().innerHTML = `<p class="mute small">السائق والمتجر يطلبان السحب إلى أي رقم Whish أو OMT بعد تأكيد كلمة سر الحساب. حوّل المبلغ ثم اضغط «تم التحويل». الرفض يعيد المبلغ إلى رصيده.</p>
    <div class="tabs">${[['pending', 'بانتظار التحويل'], ['paid', 'تم التحويل'], ['rejected', 'مرفوضة'], ['all', 'الكل']].map(([k, n]) => `<button data-f="${k}" class="${k === filter ? 'on' : ''}">${n}</button>`).join('')}</div>
    ${rows.length ? rows.map((w) => `<div class="card"><div class="row"><b>${w.account_type === 'driver' ? '🛵' : '🏪'} ${esc(w.name || '')}</b><span class="big">${money(w.amount)}</span></div>
      <p>${esc(w.provider.toUpperCase())}: <b>${esc(w.number)}</b> <button class="btn sm alt" data-copy="${esc(w.number)}">نسخ الرقم</button></p>
      <p class="small mute">${esc(when(w.created_at))} · هاتف الحساب +${esc(w.phone || '')}</p>
      ${w.status === 'pending' ? `<div class="grid2"><button class="btn" data-paid="${w.id}">تم التحويل</button><button class="btn bad" data-rej="${w.id}">رفض وإعادة المبلغ</button></div>` : `<span class="chip">${w.status === 'paid' ? 'تم التحويل' : 'مرفوض'}</span> <button class="btn sm bad" data-wdel="${w.id}">حذف من السجل</button>`}
      <button class="btn sm alt" data-log="${w.account_type}:${w.account_id}">سجل الحساب</button></div>`).join('') : '<div class="empty">لا يوجد</div>'}`;
  $$('[data-f]').forEach((b) => { b.onclick = () => payouts(b.dataset.f).catch(fail); });
  $$('[data-copy]').forEach((b) => { b.onclick = () => navigator.clipboard?.writeText(b.dataset.copy).then(() => toast('نُسخ الرقم')); });
  $$('[data-paid],[data-rej]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/withdrawals/${b.dataset.paid || b.dataset.rej}/${b.dataset.paid ? 'paid' : 'reject'}`, {}); payouts(filter); } catch (e) { fail(e); } }; });
  $$('[data-log]').forEach((b) => { const [t2, id] = b.dataset.log.split(':'); b.onclick = () => accountLog(t2, Number(id)).catch(fail); });
  $$('[data-wdel]').forEach((b) => { b.onclick = () => confirmDel('حذف هذا السحب من السجل؟', `/api/admin/withdrawals/${b.dataset.wdel}`, () => payouts(filter)); });
}
const WD = { pending: 'بانتظار التحويل', paid: 'تم التحويل', rejected: 'مرفوض' };
const KIND = { topup: 'شحن', hold: 'أجرة توصيل', release: 'استرجاع', adjust: 'تعديل', earning: 'أجرة', payout: 'سحب' };
async function accountLog(type, id) {
  const r = await api('GET', `/api/admin/ledger?type=${type}&id=${id}`);
  sheet(`<h2>سجل ${TYPE[type]} #${id}</h2><div class="stat"><b>${money(r.balance)}</b><span>الرصيد</span></div>
    <h3>الإنذارات</h3><div class="list">${(r.warnings || []).map((w) => `<div class="row item"><span>⚠️ ${esc(w.reason)}<br><small>${esc(when(w.at))}</small></span><button class="btn sm bad" data-wx="${w.id}">حذف</button></div>`).join('') || '<p class="mute">لا يوجد</p>'}</div>
    <h3>السحوبات</h3><div class="list">${r.withdrawals.map((w) => `<div class="row item"><span>${money(w.amount)} — ${esc(w.provider.toUpperCase())} ${esc(w.number)}<br><small>${esc(when(w.created_at))}</small></span><span class="chip">${esc(WD[w.status] || w.status)}</span></div>`).join('') || '<p class="mute">لا يوجد</p>'}</div>
    <h3>الحركات</h3><div class="list">${r.ledger.map((l) => `<div class="row item"><span>${KIND[l.kind] || l.kind}${l.order_id ? ` #${l.order_id}` : ''}<br><small>${esc(l.note || '')} ${esc(when(l.created_at))}</small></span><b>${money(l.amount)}</b></div>`).join('')}</div>
    <button class="btn alt" data-close>إغلاق</button>`);
  $$('[data-wx]').forEach((b) => { b.onclick = () => confirmDel('حذف هذا الإنذار؟ (إذا كان الحساب موقوفاً بسببه فعّله من جديد يدوياً)', `/api/admin/warnings/${b.dataset.wx}`, () => { $('.sheet-bg')?.remove(); accountLog(type, id); }); });
}

async function complaints() {
  const { complaints: rows } = await api('GET', '/api/admin/complaints?status=open');
  pane().innerHTML = rows.length ? rows.map((c) => `<div class="card"><div class="row"><b>${TYPE[c.from_type]} #${c.from_id} ← بحق ${TYPE[c.against_type]} #${c.against_id}</b><span class="small mute">${c.errand_id ? `طلب سائق مباشر #${c.errand_id}` : `طلب #${c.order_id ?? '—'}`}</span></div>
    <p>${esc(c.text)}</p><p class="small mute">${esc(when(c.created_at))}</p>
    <div class="row">${c.errand_id ? `<button class="btn sm alt" data-chat="${c.errand_id}">💬 الدردشة</button>` : ''}<button class="btn sm acc" data-cw="${c.id}">إرسال إنذار</button><button class="btn sm alt" data-cd="${c.id}">رفض الشكوى</button><button class="btn sm bad" data-cdel="${c.id}">حذف</button></div></div>`).join('') : '<div class="empty">لا توجد شكاوى مفتوحة</div>';
  $$('[data-cw]').forEach((b) => { b.onclick = async () => {
    const reason = await ask('إنذار', 'سبب الإنذار (يظهر لصاحب الحساب)');
    try { const r = await api('POST', `/api/admin/complaints/${b.dataset.cw}/warn`, { reason }); toast(r.suspended ? `الإنذار ${r.count} — أُوقف الحساب تلقائياً` : `الإنذار ${r.count} من ${r.max}`); complaints(); } catch (e) { fail(e); }
  }; });
  $$('[data-cdel]').forEach((b) => { b.onclick = () => confirmDel('حذف الشكوى؟', `/api/admin/complaints/${b.dataset.cdel}`, complaints); });
  $$('[data-chat]').forEach((b) => { b.onclick = async () => {
    try { const { messages } = await api('GET', `/api/admin/errands/${b.dataset.chat}/messages`); sheet(`<h2>الدردشة — طلب #${b.dataset.chat}</h2><div class="chat">${messages.map((m) => `<p class="${m.from_type === 'driver' ? 'me' : ''}"><b>${m.from_type === 'driver' ? 'السائق' : 'الزبون'}:</b> ${esc(m.body)}<br><small class="mute">${esc(when(m.created_at))}</small></p>`).join('') || '<p class="mute">لا توجد رسائل</p>'}</div><button class="btn alt" data-close>إغلاق</button>`); } catch (e) { fail(e); }
  }; });
  $$('[data-cd]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/admin/complaints/${b.dataset.cd}/dismiss`, {}); complaints(); } catch (e) { fail(e); } }; });
}

async function settings() {
  const { settings: s, smsVerification } = await api('GET', '/api/admin/delivery/settings');
  const F = [['payoutThreshold', 'الحد الأدنى لسحب السائق ($)'], ['storeMinWithdraw', 'الحد الأدنى لسحب المتجر ($)'], ['dailyWithdrawMax', 'أقصى سحب للحساب في اليوم ($)'], ['maxWarnings', 'عدد الإنذارات للإيقاف التلقائي'], ['warningMonths', 'مدة احتساب الإنذار (أشهر)'], ['dispatchRadiusKm', 'أبعد مسافة للسائق عن المتجر (كم)'], ['offerBatch', 'عدد السائقين الذين يصلهم الطلب'], ['raiseAfterSec', 'بعد كم ثانية يُعرض رفع الأجرة'], ['driverStaleSec', 'السائق غير متاح إذا لم يتحدّث موقعه خلال (ثانية)'], ['cartIdleMin', 'تُفرغ السلّة بعد الغياب (دقيقة)'], ['jobsPrice', 'سعر اشتراك طلبات الزبائن للسائق شهرياً ($)'], ['maxPurchaseValue', 'أقصى قيمة مشتريات في «أحضر لي من محل» ($)'], ['errandMinPrice', 'أقل سعر يعرضه الزبون على السائق ($)']];
  pane().innerHTML = `<form id="sf" class="card">${F.map(([k, l]) => `<label class="f">${l}<input class="in" name="${k}" type="number" min="0" step="any" value="${s[k]}"></label>`).join('')}<button class="btn">حفظ</button></form>
    <div class="card"><h3>🧹 تنظيف اللوحة</h3><p class="small mute">يحذف نهائياً الطلبات والطلبات المباشرة والشكاوى والسحوبات وطلبات الشحن والمواعيد المنتهية الأقدم من المدة المختارة. الأرصدة لا تتأثر.</p>
      <div class="row"><select class="in" id="cd"><option value="30">أقدم من 30 يوماً</option><option value="90">أقدم من 3 أشهر</option><option value="180">أقدم من 6 أشهر</option><option value="365">أقدم من سنة</option></select><button class="btn sm bad" id="clean">تنظيف</button></div></div>
    <div class="card"><h3>رمز التحقق بالـ SMS</h3><p class="${smsVerification ? '' : 'mute'}">${smsVerification ? '✅ مفعّل' : 'غير مفعّل — يعمل تلقائياً عند وضع مفاتيح SMS في Render (انظر docs/DELIVERY.md)'}</p></div>
    <div class="card"><h3>النصوص والأقسام والتصميم</h3><p class="small">كل نصوص التطبيق الجديد (بالأربع لغات) تحت المفتاح <b>dx</b> في محرّر النصوص. الأقسام وترتيبها وأسعار الاشتراكات من لوحة الإدارة الرئيسية.</p></div>`;
  $('#clean').onclick = async () => {
    if (!confirm('تأكيد الحذف النهائي للعناصر المنتهية القديمة؟')) return;
    try { const r = await api('POST', '/api/admin/delivery/cleanup', { days: Number($('#cd').value) }); toast(`حُذف: ${r.orders} طلب، ${r.errands} طلب سائق، ${r.complaints} شكوى، ${r.withdrawals} سحب`); } catch (e) { fail(e); }
  };
  $('#sf').addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(F.map(([k]) => [k, Number(e.target[k].value)]));
    try { await api('PUT', '/api/admin/delivery/settings', body); toast('تم الحفظ'); } catch (x) { fail(x); }
  });
}

window.addEventListener('hashchange', () => { const t2 = new URLSearchParams(location.hash.slice(1)).get('t'); if (t2 && t2 !== tab) { tab = t2; frame(); } });
(async () => { try { COUNTRIES = (await api('GET', '/api/config')).countries || []; } catch { /* ignore */ } frame(); })();
