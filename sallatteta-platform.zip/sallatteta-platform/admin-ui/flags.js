// v8.5 admin — «مفاتيح الأقسام والتقارير»: every optional module in one place (on/off), the main numbers that need the
// owner (renewals, money reviews, complaints, alerts) and the server's health. Turning a module off stops NEW actions
// only: what is already running (orders, invoices, debts) keeps going until it is finished or settled.
(() => {
  window.dxExtra = window.dxExtra || {};
  const money = (n) => `${Math.round(Number(n || 0) * 100) / 100}$`;
  window.dxExtra.flags = async function flagsSection() {
    const { api, esc, $, $$, toast, fail, pane } = window.dxKit;
    const p = await api('GET', '/api/admin/platform');
    const f = p.flags, n = p.numbers, sv = p.server;
    const sw = (id, on, title, hint) => `<label class="check"><input type="checkbox" data-sw="${id}" ${on ? 'checked' : ''}><span><b>${title}</b><br><small class="mute">${hint}</small></span></label>`;
    const info = (on, title, hint) => `<p class="small">${on ? '✅' : '⏸'} <b>${title}</b> — <span class="mute">${hint}</span></p>`;
    const go = (tab, label, num, warn) => `<button class="stat ${warn && num ? 'hl' : ''}" data-go="${tab}"><b>${num}</b><span>${label}</span></button>`;
    pane().innerHTML = `<p class="mute small">🎛 كل الأقسام الاختيارية في مكان واحد. الإطفاء يوقف الأعمال الجديدة فقط، وما بدأ (طلبات، فواتير، ديون) يكمل حتى ينتهي أو يُسوّى.</p>
      <div class="card"><h3>المفاتيح</h3>
        ${sw('driverService', f.driverService, '🛵 خدمة السائقين لطلبات المحلات', 'مطفأة أساساً: المحلات تدير توصيلها بنفسها، و«اطلب سائقاً» يبقى للزبائن.')}
        ${sw('exceptionOn', f.exceptionOn, '💵 الطلب الاستثنائي الكبير', 'فوق سقف دين السائق، بموافقة المتجر والسائق.')}
        ${sw('feeMode', f.feeByRoad, '🛣 أجرة التوصيل حسب مسافة الطريق', 'الأسعار من «إعدادات التوصيل».')}
        ${sw('expandOn', f.widening, '📍 توسيع نطاق السائقين تلقائياً', 'الخطوات والحد الأقصى من «إعدادات التوصيل».')}
        ${sw('ai', f.ai, '🤖 المدير الذكي', 'للمشتركين بالاشتراك الذكي فقط؛ الإطفاء لا يوقف الطلبات العادية.')}
        ${sw('sounds', f.sounds, '🔊 الأصوات', 'تفاصيل كل صوت من «مدير الأصوات».')}
        ${sw('platformMoney', f.platformMoney, '🏦 الدفع عبر المنصة (بطاقة وأرصدة)', 'مطفأ = المنصة لا تتدخّل بالمال.')}
        <h3>تكاملات تحتاج حساباً خارجياً</h3>
        ${info(f.aiProvider !== 'local', `مزوّد الذكاء: ${esc(f.aiProvider)}`, 'AI_PROVIDER=anthropic و ANTHROPIC_API_KEY في Render')}
        ${info(f.playBilling, 'اشتراكات Google Play', 'GOOGLE_PLAY_PACKAGE و GOOGLE_PLAY_SERVICE_ACCOUNT_JSON في Render + منتجات الاشتراك في Play Console')}
        ${info(f.appleBilling, 'اشتراكات Apple', 'APPLE_BUNDLE_ID عند نشر تطبيق iPhone')}
        ${info(f.roads, 'المسافات بالطريق (Geoapify)', 'GEOAPIFY_API_KEY')}
        <p class="small">📞 الاتصالات الهاتفية الذكية و📣 إرسال التسويق: <span class="chip">مطفأة — قيد التحضير</span></p></div>
      <h3>بحاجة إليك</h3>
      <div class="grid2">
        ${go('dx-renewals', '🧾 تجديدات بانتظار الموافقة', n.renewalsPending, true)}
        ${go('dx-finance:v8pay', '💱 دفعات للمراجعة', n.paymentsReview, true)}
        ${go('dx-finance:v8comp', '⚖️ شكاوى مالية مفتوحة', n.financeComplaints, true)}
        ${go('dx-finance:security', '🚨 تنبيهات أمنية', n.securityAlerts, true)}</div>
      <h3>الأرقام</h3>
      <div class="grid2">
        <div class="stat"><b>${n.storesActive}</b><span>🏪 اشتراكات فعّالة (منها 🤖 ${n.storesAi})</span></div>
        <div class="stat"><b>${n.driversActive}</b><span>🛵 سائقون فعّالون (منهم 🤖 ${n.driversAi})</span></div>
        <div class="stat"><b>${money(n.subscriptionRevenue30d)}</b><span>💰 إيرادات الاشتراكات (30 يوماً، المقبولة)</span></div>
        <div class="stat"><b>${n.ordersToday}</b><span>📦 طلبات آخر 24 ساعة</span></div>
        <div class="stat"><b>${money(n.invoicesOpen)}</b><span>🧾 فواتير مفتوحة (للمتاجر عند السائقين)</span></div>
        <div class="stat ${n.adminDebts ? 'hl' : ''}"><b>${money(n.adminDebts)}</b><span>🏛 ديون للإدارة على سائقين</span></div>
        <div class="stat"><b>${n.messages7d}</b><span>✉️ رسائل وبلاغات (7 أيام)</span></div></div>
      <h3>صحة الخادم</h3>
      <div class="card small">⏱ يعمل منذ ${sv.uptimeMin} دقيقة · 🧠 الذاكرة ${sv.memoryMb} MB (heap ${sv.heapMb}) · 🗄 ${esc(sv.db)}${sv.dbPool.total != null ? ` (اتصالات ${sv.dbPool.total}، فارغة ${sv.dbPool.idle}، تنتظر ${sv.dbPool.waiting})` : ''}<br>
        ⚡ زمن الاستجابة p95 ${sv.p95ms ?? '—'} ms · p99 ${sv.p99ms ?? '—'} ms · Node ${esc(sv.node)}</div>`;
    $$('[data-go]').forEach((b) => { b.onclick = () => { const [tab, v] = b.dataset.go.split(':'); window.adminGo?.(tab); if (v) setTimeout(() => window.dxFinance?.(v), 400); }; });
    $$('[data-sw]').forEach((c) => { c.onchange = async () => {
      const k = c.dataset.sw, on = c.checked;
      try {
        if (k === 'ai') await api('PUT', '/api/admin/ai/config', { enabled: on });
        else if (k === 'sounds') await api('PUT', '/api/admin/sounds/settings', { enabled: on });
        else await api('PUT', '/api/admin/delivery/settings', { [k]: on ? 1 : 0 });
        toast(on ? 'شُغّل' : 'أُطفئ');
      } catch (x) { c.checked = !on; fail(x); }
    }; });
  };
})();
