# سلة تيتا — المواصفات الكاملة (v2)

هالملف هو المرجع لبناء أي واجهة جديدة (تطبيق Android/iOS، أو موقع بتصميم تاني) فوق نفس السيرفر. كل شي بالموقع الحالي بيمشي عبر الـ API الموصوف هون، فالتطبيق بيقدر يعمل نفس الشي بالظبط.

---

## 1. الأدوار

| الدور | الدخول | شو بيعمل |
|---|---|---|
| زبونة | بدون حساب | بتطلب، بتختار ست، بتفتح WhatsApp، بتقيّم، بتعمل إعجاب، بتبعت شكوى |
| ست (طبّاخة) | رقم WhatsApp + كلمة سر (من الإدارة) | بتشوف أرقامها، بتنزّل صور، بتعدّل صفحتها وضيعها |
| إدارة | اسم مستخدم + كلمة سر | كل شي: قبول، اشتراكات، شكاوي، إنذارات، صور، ضيع |

الزبونة ما عندها حساب. التطبيق بيحفظ على الجهاز:
- `viewerId`: رمز عشوائي (8–64 حرف `[A-Za-z0-9_-]`) للإعجاب والزيارات.
- «طبّاخاتي»: لائحة `{id, name, reviewToken, at, rating}` للستات اللي تواصلت معهن.

---

## 2. الرحلات

### زبونة — طلب جديد
1. `GET /api/config` (أنواع الطلبات، الأقضية).
2. بتكتب الطلب (5–1000 حرف)، واختياري نوع الطلب.
3. الموقع: إما بتبحث عن ضيعتها `GET /api/areas/search?q=` وبتختار، أو GPS.
4. `POST /api/search` ← لائحة الستات اللي بيوصلوا على هالضيعة، الأقرب أولاً + `requestId`.
5. بتختار ست ← `POST /api/contact {requestId, cookId}` ← `whatsappUrl` + `reviewToken`.
6. التطبيق بيفتح `whatsappUrl` وبيحفظ الست بـ «طبّاخاتي» مع `reviewToken`.
7. بعدين: `POST /api/reviews {token, rating}`.

### زبونة — من صفحة ست
1. `GET /api/cooks/:id?viewerId=`، و`POST /api/cooks/:id/view {viewerId}`.
2. «اطلبي منها»: الطلب + ضيعتها ← `POST /api/cooks/:id/request {text, areaId}` ← `requestId`.
3. `POST /api/contact` متل فوق.

### ست — اشتراك
1. `/join`: الاسم، الرقم، ضيعتها (`areaId`)، الضيع اللي بتوصلها (`servedAreaIds` — الاقتراحات من `GET /api/areas/nearby?areaId=` بتطلع **مش مختارة**)، الخدمات، المدة، صورة ووصف اختياريين، «ما لقيت ضيعتي» (`missingVillage`).
2. `POST /api/cook-applications` ← `whatsappUrl` لرقم الإدارة، والرسالة جاهزة.
3. الإدارة بتفعّل الاشتراك وبتبعتلها كلمة سر.

### ست — حسابها
`POST /api/cook/login` ← كوكي `st_cook` (60 يوم) ← `GET /api/cook/me`، إلخ.

---

## 3. قاعدة البيانات

PostgreSQL بالإنتاج، SQLite محلياً والاختبارات (نفس SQL). التواريخ `TIMESTAMPTZ` (نص ISO بـ SQLite).

| الجدول | الوصف | أعمدة مهمة |
|---|---|---|
| `service_areas` | الضيع | `id, slug UNIQUE, name_ar, name_en, district, lat, lng, is_active` |
| `service_types` | أنواع الطلبات | `key`: home_cooking, pastries, sweets, mouneh, mezze, feasts |
| `cooks` | الستات | `full_name, whatsapp` (دولي، أرقام بس)`, area_id` (ضيعتها)`, lat, lng, bio, photo` (data URL)`, status` (pending/approved/rejected)`, password_hash, admin_notes`. (`service_radius_km` قديم، ما عاد مستعمل) |
| `cook_service_areas` | الضيع اللي بتوصلها كل ست | `(cook_id, area_id)` |
| `cook_service_types` | شو بتحضّر | `(cook_id, service_type_id)` |
| `subscriptions` | الاشتراكات | `plan` (monthly/quarterly/semiannual/yearly)`, status` (pending/active/expired/suspended)`, payment_status, start_date, expiry_date` |
| `requests` | كل طلب زبونة | `public_id, body, area_label, approx_lat/lng` (مقرّب)`, location_source` (gps/area/profile)`, results_count` |
| `request_impressions` | مين ظهر بكل طلب | `request_id, cook_id, distance_km, position` |
| `request_contact_events` | ضغطات WhatsApp | `request_id, cook_id, review_token UNIQUE` |
| `reviews` | النجوم | `cook_id, contact_event_id UNIQUE, rating 1–5, is_hidden` |
| `feedback` | شكاوي وملاحظات (إدارة بس) | `cook_id, kind` (complaint/note)`, message, customer_name, customer_phone, status` (new/resolved)`, admin_note` |
| `cook_warnings` | الإنذارات | `cook_id, admin_id, feedback_id, message` |
| `cook_likes` | الإعجابات | `(cook_id, viewer_hash)` |
| `cook_page_views` | زيارات الصفحة | `cook_id, viewer_hash, created_at` (مرة كل 12 ساعة لكل جهاز) |
| `cook_photos` | صور الأكل | `cook_id, data` (data URL)`, caption, is_hidden` — حد أقصى 12 |
| `cook_sessions`, `admin_sessions` | الجلسات | `token_hash, expires_at` |
| `admin_users`, `admin_actions` | الإدارة وسجل عملياتها | |
| `app_meta` | إعدادات داخلية | `seed_version` |

**متى بتظهر الست؟** `cooks.status='approved'` + اشتراك `active` و`start_date <= الآن < expiry_date` + (للبحث) سطر بـ `cook_service_areas` لضيعة الزبونة.

---

## 4. الـ API

- كل الطلبات والأجوبة JSON. اللغة من `?lang=` أو `Accept-Language` (ar الافتراضي).
- **الطلبات اللي بتغيّر شي** لحساب الست والإدارة لازم فيها الهيدر `X-Requested-With: fetch` (حماية CSRF). تطبيق موبايل بيبعتو دايماً.
- **الأخطاء:** `{ "error": "code", "fields": { "field": "code" } }`. الأكواد: `validation_failed` (422)، `rate_limited` (429، مع `retryAfterSec`)، `unauthorized` (401)، `not_found`، `cook_not_available`، `request_expired` (410)، `too_many_photos` (409)... والنصوص العربية بـ `locales/ar.json` ← `errors.*`.
- **الحماية ضد السبام** بالنماذج العامة: `website` لازم يكون فاضي، و`startedAt` (ms) إذا انبعت لازم يكون قبل 1.5 ثانية عالأقل.

### عام — الضيع
| | المسار | الجواب |
|---|---|---|
| GET | `/api/config` | `{serviceTypes[], plans[], districts[{key,name}], maxPhotos, adminContactConfigured}` |
| GET | `/api/areas/search?q=` | `{areas[{id,name,district,districtName}]}` (12 نتيجة) |
| GET | `/api/areas/nearby?areaId=&km=15` | `{areas[... ,distanceKm]}` الأقرب أولاً، والأولى هي نفسها |
| GET | `/api/areas/nearest?lat=&lng=` | `{area}` |
| GET | `/api/areas/district?key=` | `{areas[]}` كل ضيع القضاء |

### عام — الطلب والتواصل
| | المسار | الـ body | الجواب |
|---|---|---|---|
| POST | `/api/search` | `{text, serviceType?, location: {type:'area', areaId} \| {type:'gps', lat, lng}, website, startedAt}` | `{requestId, area, areaLabel, cooks[CookCard + distanceKm]}` |
| POST | `/api/cooks/:id/request` | `{text, areaId, website, startedAt}` | `{requestId}` |
| POST | `/api/contact` | `{requestId, cookId}` | `{whatsappUrl, reviewToken, cook{id,name}}` — الطلب صالح 48 ساعة، والست لازم تكون ظهرت فيه |

**CookCard:** `{id, name, area, services[], bio, photoUrl|null, rating{avg|null, count}, profileUrl, subscriptionStatus}` — **بلا رقم وبلا إحداثيات**.

### عام — الاكتشاف وصفحة الست
| | المسار | الجواب |
|---|---|---|
| GET | `/api/feed` | `{dishes[{photoUrl, caption, cookId, cookName, area, profileUrl}], cooks[CookCard]}` |
| GET | `/api/cooks/search?q=` | `{cooks[CookCard]}` (حرفين عالأقل) |
| GET | `/api/cooks/:id?viewerId=` | CookCard + `{servedAreas[{id,name}], photos[{id,url,caption}], likes, likedByMe}` — 404 إذا مش ظاهرة |
| POST | `/api/cooks/:id/view` | `{viewerId}` ← `{ok}` |
| POST | `/api/cooks/:id/like` | `{viewerId, like: true\|false}` ← `{likes, likedByMe}` |
| POST | `/api/reviews` | `{token, rating 1–5}` ← `{ok, cookId, rating}` — بيتعدّل إذا انبعت مرة تانية. صالح 60 يوم |
| POST | `/api/feedback` | `{cookId, kind: complaint\|note, message 5–1500, name?, phone?, website, startedAt}` ← 201 |
| POST | `/api/cook-applications` | `{fullName, whatsapp, areaId, servedAreaIds[], services[], plan, bio?, photo?, missingVillage?, lat?, lng?, website, startedAt}` ← `{applicationId, whatsappUrl}` |
| GET | `/media/cooks/:id.jpg`, `/media/photos/:id.jpg` | الصور (للستات الظاهرات بس) |
| GET | `/healthz` | `{ok:true}` |

### حساب الست (كوكي `st_cook`)
| | المسار | الـ body / الجواب |
|---|---|---|
| POST | `/api/cook/login` | `{whatsapp` (أي صيغة)`, password}` |
| POST | `/api/cook/logout` | |
| GET | `/api/cook/me` | `{id, name, whatsapp, area, bio, photoUrl, profileUrl, services[], servedAreas[], subscription{status,plan,startDate,expiryDate}, stats{views_total, views_30d, likes, impressions_total, impressions_30d, whatsapp_total, whatsapp_30d, rating}, photos[{id,url,caption,hidden}], maxPhotos}` — **بلا شكاوي وبلا إنذارات** |
| PATCH | `/api/cook/me` | أي من `{bio, photo, services[], servedAreaIds[]}` ← me. الاسم والرقم للإدارة بس |
| POST | `/api/cook/password` | `{current, next ≥ 6}` |
| POST | `/api/cook/photos` | `{data: "data:image/jpeg;base64,...", caption?}` (حد أقصى ~400 KB) ← me |
| DELETE | `/api/cook/photos/:id` | ← me |
| GET | `/api/cook/photo`, `/api/cook/photos/:id.jpg` | صورتها وصورها (حتى المخفية) |

### الإدارة (كوكي `st_admin`، 12 ساعة)
| | المسار | ملاحظات |
|---|---|---|
| POST | `/api/admin/login` | `{username, password}` — الاسم مش حسّاس للأحرف |
| GET | `/api/admin/stats` | يتضمّن `new_feedback` |
| GET | `/api/admin/cooks?filter=&q=` | filter: pending/active/expired/suspended/rejected/no_subscription/all — كل سطر فيه `rating, warnings, openFeedback` |
| GET/PATCH | `/api/admin/cooks/:id` | PATCH: `{fullName, whatsapp, areaId, servedAreaIds[], services[], bio, adminNotes, photo, lat, lng}` |
| POST | `/api/admin/cooks` | نفس الحقول + `activate?{plan, startDate}` |
| POST | `/api/admin/cooks/:id/approve\|reject` | |
| POST | `/api/admin/cooks/:id/password` | `{password?}` ← `{password, whatsappUrl}` (رسالة للست فيها معلومات الدخول) |
| POST | `/api/admin/cooks/:id/warnings` | `{message, feedbackId?}` ← `{whatsappUrl, cook}`، وبيقفل الشكوى |
| POST | `/api/admin/cooks/:id/subscription/activate\|renew\|suspend\|expire` | |
| PATCH | `/api/admin/cooks/:id/subscription` | تعديل التواريخ والمدة والدفع |
| GET | `/api/admin/feedback?status=new\|resolved\|all` | |
| PATCH | `/api/admin/feedback/:id` | `{status?, adminNote?}` |
| DELETE | `/api/admin/photos/:id` | |
| POST | `/api/admin/areas` | `{nameAr, nameEn?, district, lat?, lng?}` |

---

## 5. رسائل WhatsApp

النصوص كلها بـ `locales/ar.json` تحت `wa.*`:
- `customerMessage` — من الزبونة للست: الطلب + المنطقة.
- `adminApplication` — طلب اشتراك للإدارة: الاسم، الرقم، الضيعة، «بتوصل على»، الخدمات، المدة.
- `cookLogin` — معلومات دخول الست.
- `warning` — إنذار للست (الإدارة بتعدّلو قبل ما تبعتو).

الروابط `https://wa.me/<رقم>?text=<نص>`. على Android، إذا في WhatsApp وWhatsApp Business، التلفون بيفتح التطبيق الافتراضي.

---

## 6. ملاحظات لتطبيق الموبايل

- نفس الـ API بلا أي تغيير. للكوكيز استعملي مكتبة HTTP بتحفظها (أو WebView).
- الصور: صغّريها قبل الرفع (الموقع بيعمل 1000px بجودة 0.8).
- الإشعارات (Push) مش موجودة بعد. الست بتستلم الطلبات عالـ WhatsApp.
- الموقع فيه manifest، فالست بتقدر تزيد `/account` عشاشة تلفونها كتطبيق.
