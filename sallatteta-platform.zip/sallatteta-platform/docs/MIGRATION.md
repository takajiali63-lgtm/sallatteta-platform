# Aklatak — نقل المشروع إلى مزوّد آخر (MIGRATION.md)

> إذا اختفى Render أو Neon أو أي مزوّد، أو أردت الانتقال: كل شيء قابل للنقل. لا أسرار في هذا الملف.

## ما الذي تملكه
| الشيء | أين | كيف تنقله |
|---|---|---|
| الكود | ملف `sallatteta-platform.zip` على GitHub (يُنصح بمستودع Git) | أي استضافة Node.js 22 |
| قاعدة البيانات | Neon Postgres | `scripts/export-all.js` ← `scripts/import-all.js` |
| الصور | داخل القاعدة (افتراضياً) أو Cloudflare R2/S3 | داخل التصدير، أو نسخ الـ bucket + `scripts/rewrite-storage-urls.js` |
| الإعدادات | متغيّرات البيئة (انظر `.env.example`) | تُضبط في المزوّد الجديد |
| كلمات السر | مُجزّأة scrypt في القاعدة | تنتقل مع القاعدة؛ المستخدمون يدخلون بنفس كلمات السر |

## الخطوات
1. **تصدير القاعدة** (من جهازك أو أي مكان فيه Node 22):
   `DATABASE_URL=<الحالية> DATABASE_SSL=true node scripts/export-all.js ./backup-YYYY-MM-DD`
   ← مجلد فيه ملف لكل جدول + `manifest.json` (الأعداد).
2. **الصور**: إن كانت في القاعدة فهي ضمن التصدير. إن كانت على R2/S3: انسخ الـ bucket كاملاً إلى المزوّد الجديد.
3. **قاعدة جديدة**: أنشئ Postgres فارغة عند أي مزوّد (Neon، Supabase، RDS، خادم خاص…).
4. **الاسترجاع**:
   `DATABASE_URL=<الجديدة> node scripts/import-all.js ./backup-YYYY-MM-DD --yes`
   ← ينشئ الجداول، يعيد كل الصفوف بنفس الأرقام والعلاقات، ويصلح العدّادات، ويقارن الأعداد بالتصدير.
5. **الصور على نطاق جديد** (إن تغيّر):
   `node scripts/rewrite-storage-urls.js https://old-domain https://new-domain --yes`
6. **نشر السيرفر**: أي استضافة Node 22 — `npm install --omit=dev` ثم `npm start`. اضبط المتغيّرات من `.env.example` (`DATABASE_URL`, `SESSION_SECRET`, `ADMIN_WHATSAPP_NUMBER`, …).
7. **التحقّق**: `/healthz` و`/readyz`، دخول الإدارة، بحث تجريبي، فتح صفحة طبّاخ، رفع صورة.
8. **الدومين**: وجّه الـ DNS إلى المزوّد الجديد، واضبط `PUBLIC_BASE_URL`.

## اختبار النقل (PORTABILITY TEST)
`npm test` يتضمّن اختباراً يصدّر قاعدة كاملة (مطعم، منيو، صور، اشتراك، رسائل، مستخدم إدارة) ثم يسترجعها في قاعدة جديدة ويتحقّق من: الأعداد، العلاقات (foreign keys)، الصور، كلمات السر.

## ما لا يُنقل (عن قصد)
الجلسات (المستخدمون يدخلون من جديد)، عدّادات الحدود، أقفال المهام — كلها مؤقتة وتُبنى من جديد.

## المزوّدون الخارجيون وبدائلهم
| الخدمة | الحالي | البديل | الاستبدال |
|---|---|---|---|
| الاستضافة | Render | أي استضافة Node / Docker | نشر الكود + المتغيّرات |
| القاعدة | Neon | أي Postgres | التصدير/الاسترجاع |
| الصور | القاعدة / R2 | S3، Backblaze، MinIO | متغيّرات `S3_*` |
| البلدات | Geoapify ← OpenStreetMap ← Nominatim | Google Places، Mapbox | `src/services/placeProviders.js` |
| الرسائل | روابط WhatsApp | WhatsApp Business API | `src/services/messaging.js` |
| الدفع (لاحقاً) | — | Stripe / Paddle / Whish | طبقة مزوّد دفع واحدة؛ السجلات المالية في قاعدتنا |
