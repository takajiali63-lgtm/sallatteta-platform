# أكلتك (Aklatak) — ملف التسليم

> آخر تحديث: 12 تشرين الأول 2026 — النسخة **8.4.0**.
> **ابدأ من هنا.** هذا الملف لمن سيدير المنصة أو يطوّرها (مبرمج، شركة برمجة، أو جلسة AI جديدة).
> - كيف يعمل الكود: [`SPEC.md`](SPEC.md)
> - كل الـ API: [`API-ROUTES.md`](API-ROUTES.md) — كل الجداول: [`DB-SCHEMA.md`](DB-SCHEMA.md) (مولّدان من الكود)
> - سجل النسخ 8.x بالتفصيل: [`REPORT-v8.md`](REPORT-v8.md)
> - الحسابات وورقة الطوارئ: [`INVENTORY.md`](INVENTORY.md) — الأمان: [`SECURITY.md`](SECURITY.md) — النقل لاستضافة أخرى: [`MIGRATION.md`](MIGRATION.md) — التطبيق: [`MOBILE.md`](MOBILE.md)
> - النسخ القديمة من هذا الملف ومن README (أيام «سلة تيتا»): [`archive/`](archive/) — للتاريخ فقط.

---

## 1. ما هي المنصة

**أكلتك** منصة طلبات وتوصيل **بلا عمولة على الطلبات**، تعمل في لبنان أولاً (البقاع)، وجاهزة لبلدان أخرى. تربط ثلاثة أطراف:

- **الزبون:** يتصفّح المتاجر القريبة منه (مطاعم، سوبرماركت، صيدليات، حِرفيون…)، يطلب ويتابع طلبه. ويستطيع طلب سائق لتوصيل غرض أو إحضار شيء، فيرسل السائقون أسعارهم ويختار.
- **المتجر:** يستقبل الطلبات، يدير منتجاته (حتى آلاف المنتجات، مع المخزون والعروض)، فروعه، وتوصيله (بنفسه أو بسائقي أكلتك).
- **السائق:** يستقبل طلبات المتاجر وطلبات الزبائن القريبة منه، ويسجّل تسليم المال للمحلات.

**الدخل:** اشتراكات فقط (المتاجر والسائقون، والمدير الذكي اختياري)، **عبر Google Play وApp Store فقط**. المنصة لا تستلم ولا تحوّل أموال الطلبات أبداً.

---

## 2. الروابط

| الصفحة | الرابط |
|---|---|
| الموقع / تطبيق الزبون | https://sallatteta-platform.onrender.com |
| تسجيل متجر جديد | https://sallatteta-platform.onrender.com/join |
| لوحة المتجر | https://sallatteta-platform.onrender.com/store |
| تطبيق السائق | https://sallatteta-platform.onrender.com/driver |
| لوحة الإدارة | https://sallatteta-platform.onrender.com/admin/ (لا تُنشر) |
| ربط Claude (MCP) | https://sallatteta-platform.onrender.com/mcp (بمفتاح من الإدارة) |
| فحص الخادم | https://sallatteta-platform.onrender.com/readyz |

---

## 3. الحسابات والاستضافة

> ⚠️ **لا كلمات سر في هذا الملف.** أين يُحفظ كل سرّ وماذا تفعل إن ضاع: [`INVENTORY.md`](INVENTORY.md).

| الخدمة | الدور | المعرّف (ليس سراً) |
|---|---|---|
| GitHub | الكود (مستودع خاص) | `takajiali63-lgtm/sallatteta-platform` — فيه `README.md` و`sallatteta-platform.zip` |
| Render | تشغيل الموقع (خطة مجانية) | خدمة `srv-dau2rp2d0e5s73e1i2og` · workspace `tea-daphsa6k1f9s7393ulrg` · Ohio · نشر تلقائي عند كل رفع |
| Neon | قاعدة البيانات PostgreSQL (مع PostGIS) | قاعدة `neondb` · us-east-2 |
| Cloudflare R2 | الصور (عند ضبط `S3_*`) | — |
| Geoapify | العناوين والمسافات بالطريق | مشروع `Aklatak` |
| Anthropic | المدير الذكي | يُفعَّل بـ `AI_PROVIDER=anthropic` و`ANTHROPIC_API_KEY` |
| Google Play Console / App Store Connect | بيع الاشتراكات داخل التطبيق | معرّفات المنتجات في الإدارة ← «اشتراكات Google Play وApple» |

**البناء على Render:** `(unzip -o -q sallatteta-platform.zip || python3 -m zipfile -e sallatteta-platform.zip .) && cd sallatteta-platform && npm install --omit=dev`
**التشغيل:** `cd sallatteta-platform && npm start`

---

## 4. كيف ينزل تحديث (الطريقة الحالية)

1. نسخة جديدة كاملة باسم `sallatteta-platform.zip` (كل الاختبارات ناجحة قبلها).
2. GitHub ← المستودع ← **Add file ← Upload files** ← استبدال الملف ← **Commit changes**.
3. Render ينشر وحده خلال 3–5 دقائق. الترحيلات (جداول وأعمدة جديدة) تعمل وحدها عند التشغيل، وتُضيف فقط.
4. افحص Render ← Logs: يجب أن يظهر `Aklatak running` بلا أخطاء.
5. **الرجوع:** Render ← Deploys ← النسخة السابقة ← **Rollback**.

### للشركة أو المبرمج — طريقة العمل المقترحة
- **لا وصول للإنتاج مباشرة.** أعطِ كل مطوّر حساب GitHub خاصاً به بصلاحية على المستودع، ولا تعطِ كلمات سرّك. الصلاحيات تُسحب بنقرة.
- **بيئة تجريبية منفصلة:**
  - خدمة Render ثانية.
  - Neon branch (نسخة من القاعدة بنقرة).
  - مفاتيح تجريبية: Google Play test tracks، Apple Sandbox (`APPLE_ENVIRONMENT=Sandbox`)، مفتاح Anthropic منفصل بحدّ إنفاق.
- **فرع لكل عمل** ثم مراجعة قبل الدمج. شرطا الدمج:
  - `npm test` كلها ناجحة، وعددها لا ينقص.
  - تحديث `REPORT-v8.md` بقسم للنسخة.
- **نسخة احتياطية قبل كل تحديث كبير:** الإدارة ← «النسخ الاحتياطي»، أو Neon ← branch.
- **الأسرار** تبقى في Render بيد المالك فقط. لا تُكتب في الكود ولا في GitHub.
- يُفضَّل الانتقال من «رفع zip» إلى مستودع عادي (الملفات مباشرة على GitHub)، ليظهر كل تغيير سطراً بسطر. لا يغيّر شيئاً في التطبيق، فقط أمر البناء على Render.

---

## 5. متغيّرات البيئة (Render ← Environment)

**أساسية:**

| المتغير | الغرض |
|---|---|
| `NODE_ENV=production`، `NODE_VERSION=22`، `TRUST_PROXY=1` | التشغيل خلف Render |
| `DATABASE_URL`، `DATABASE_SSL=true` | قاعدة Neon |
| `SESSION_SECRET` (32 حرفاً أو أكثر) | الجلسات، **وتشفير مفاتيح Anthropic الخاصة بالمتاجر**. تغييره يُخرج الجميع ويُبطل تلك المفاتيح |
| `ADMIN_WHATSAPP_NUMBER` | رقم الإدارة لطلبات الانضمام |
| `ADMIN_BOOTSTRAP_USERNAME` / `ADMIN_BOOTSTRAP_PASSWORD` | أول تشغيل فقط |
| `ADMIN_RESET_USERNAME` / `ADMIN_RESET_PASSWORD` | طوارئ: إعادة كلمة سر الإدارة — **احذفهما فوراً بعد الاستعمال** |
| `GEOAPIFY_API_KEY` | العناوين والمسافات |
| `PUBLIC_BASE_URL` | عند ربط الدومين |

**حسب الحاجة:**

| المجال | المتغيرات |
|---|---|
| الصور على R2/S3 | `S3_ENDPOINT` `S3_BUCKET` `S3_ACCESS_KEY_ID` `S3_SECRET_ACCESS_KEY` `S3_PUBLIC_URL` `S3_REGION` |
| المدير الذكي | `AI_PROVIDER=anthropic` `ANTHROPIC_API_KEY` (اختياري: `AI_MODEL` `AI_MODEL_FAST` `AI_TIMEOUT_MS`) |
| Google Play | `GOOGLE_PLAY_PACKAGE` `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` `GOOGLE_RTDN_TOKEN` (`GOOGLE_RTDN_AUDIENCE` اختياري) |
| Apple | `APPLE_BUNDLE_ID` `APPLE_ENVIRONMENT` (`Production` / `Sandbox`)، و`IOS_APP_ID` لفتح الروابط في التطبيق |
| تطبيق Android | `ANDROID_PACKAGE_NAME` `ANDROID_SHA256_CERT_FINGERPRINTS` |
| الإشعارات | `VAPID_PUBLIC_KEY` `VAPID_PRIVATE_KEY` `VAPID_SUBJECT` (تُولَّد تلقائياً إن لم تُضبط) |
| رسائل SMS | `SMS_PROVIDER` `TWILIO_ACCOUNT_SID` `TWILIO_AUTH_TOKEN` `TWILIO_FROM` |
| واتساب (التقرير الشهري) | `WHATSAPP_TOKEN` `WHATSAPP_PHONE_ID` `WHATSAPP_REPORT_TEMPLATE` |
| الترجمة التلقائية | `DEEPL_API_KEY` |
| النسخ الخارجية | `BACKUP_S3_ENDPOINT` `BACKUP_S3_BUCKET` `BACKUP_S3_ACCESS_KEY_ID` `BACKUP_S3_SECRET_ACCESS_KEY` `BACKUP_S3_REGION` |
| الدفع عبر المنصة (**مطفأ** — المنصة لا تمسك المال) | `PAY_*` `WHISH_*` `OMT_*` `PAYOUT_*` |
| التوسّع | `DB_POOL_MAX` `REDIS_URL` `RATE_LIMIT_STORE` `RUN_JOBS` `POSTGIS` `METRICS_TOKEN` `SLOW_REQUEST_MS` |
| أخرى | `ADMIN_PATH` `BRAND_NAME` `BRAND_NAME_EN` `DEFAULT_COUNTRY` `LOG_FORMAT` |

> القائمة كاملة من الكود: `grep -rhoE "env\.[A-Z_]+" src | sort -u`.

---

## 6. قواعد ممنوع تنكسر

هذه قرارات المالك. أي تغيير فيها يحتاج موافقته صراحة، وأغلبها مغطّى باختبارات:

1. **المنصة لا تستلم ولا تحوّل أموال الطلبات.** الزبون يدفع نقداً. السائق يسلّم المحل، والمحل يؤكّد. التطبيق يسجّل فقط.
2. **السجلات المالية لا تُحذف ولا تُعدّل.** التصحيح بقيد عكسي.
3. **الاشتراكات عبر Google Play وApp Store فقط.** الخادم يتحقق بنفسه قبل أي تفعيل، ولا يصدّق الهاتف.
4. **المدير الذكي بلا خصم:** السعر الشهري × الأشهر × كل فرع. الاشتراك الأساسي له خصومات المدد.
5. **العزل الكامل:**
   - كل متجر وفرع وسائق وزبون يرى ما يخصّه فقط.
   - المساعد الذكي لا يرى متجراً آخر ولا زبوناً آخر.
   - كل بلد منفصل.
6. **الأسعار والمبالغ تُحسب على الخادم دائماً**، لا من الهاتف.
7. **لا مفاتيح سرّية في الواجهات** (الهاتف أو المتصفح).
8. **الاتصالات الهاتفية والإرسال التسويقي من المدير الذكي مطفأة.**
9. **لا تغيير للاسم أو الشعار أو الهوية** دون موافقة المالك.
10. **النصوص بالعربية الفصحى، بأربع لغات** (عربي، إنكليزي، فرنسي، إسباني). كل نص جديد يُضاف للأربع.
11. **ربط Claude:**
    - لا حذف، ولا مال، ولا كلمات سر.
    - كل تعديل يُعرض قبل التطبيق.
    - كل شيء مسجّل.
12. **الترحيلات تُضيف فقط.** لا حذف جداول أو أعمدة فيها بيانات.

---

## 7. ما بقي (بصراحة)

- **المدير الذكي الكامل** يحتاج حساب Anthropic مع رصيد، ثم المتغيّرين على Render. بدونهما يعمل بالوضع المجاني المحدود.
- **الاشتراكات داخل التطبيق** تحتاج:
  - إنشاء المنتجات في Play Console (والمتغيّرات أعلاه).
  - لنسخة iPhone: حساب Apple Developer، وبناء التطبيق مع الجسر الموصوف في `MOBILE.md`.
- **الخطة المجانية لـ Render:**
  - الخادم ينام بعد 15 دقيقة بلا زيارات، وأول زيارة بعدها بطيئة.
  - عند البدء الفعلي: خطة مدفوعة.
- **README والمواصفات:** حُدّثت في 8.4.0. أبقِها محدّثة مع كل نسخة (`node scripts/gen-spec.js` للقوائم).
- **التفاصيل والأفكار المؤجّلة:** `PLAN.md` (قسم «ما بقي») و`REPORT-v8.md`.

---

## 8. سجل النسخ (مختصر)

| النسخة | أهم ما فيها |
|---|---|
| 8.4.0 | مساعد ظاهر للزبون والمتجر والسائق، وضوح الخط في كل الثيمات، تفاوض على سعر السائق، إخفاء المدير الذكي، اختبار ضغط بالآلاف، README والمواصفات من جديد |
| 8.3.0 | كل الاشتراكات عبر Google Play / App Store، ربط Claude بالإدارة (MCP)، إصلاح رفع صورة الإيصال |
| 8.2.0 | المدير الذكي لا يتوقف، نموذجان (Haiku للزبائن، Sonnet للمالك)، ميزانيات وحماية من الصرف، صور المنتجات على R2 |
| 8.1.0 | المتاجر الكبيرة (رفع منتجات CSV/Excel، مخزون)، المدير الذكي لكل فرع بلا خصم، أموال المحلات عند السائقين |
| 8.0.x | دمج النسختين، التوصيل الكامل، المال المباشر بين السائق والمحل |
| قبل 8 | من «سلة تيتا» (طبخ منزلي) إلى أكلتك: انظر [`archive/HANDOVER-v4-v6.md`](archive/HANDOVER-v4-v6.md) و`PLAN.md` |

التفاصيل الكاملة لكل نسخة 8.x مع نتائج الاختبارات: [`REPORT-v8.md`](REPORT-v8.md).
