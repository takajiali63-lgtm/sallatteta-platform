import { initI18n, t, esc } from './i18n.js?v=422';
import { initMenu } from './ui.js?v=422';

// Terms / privacy / about — texts come from the language files and can be edited from the admin panel.
const slug = location.pathname.replace(/\/+$/, '').slice(1);
const allowed = ['terms', 'privacy', 'about'];

/** Tiny formatter: "## " → heading, "- " → bullet list, blank line → new paragraph. Text only (escaped). */
function render(body) {
  return String(body).split(/\n\s*\n/).map((block) => {
    const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
    if (!lines.length) return '';
    if (lines[0].startsWith('## ')) {
      const rest = lines.slice(1);
      return `<h2>${esc(lines[0].slice(3))}</h2>${rest.length ? render(rest.join('\n')) : ''}`;
    }
    if (lines.every((l) => l.startsWith('- '))) return `<ul>${lines.map((l) => `<li>${esc(l.slice(2))}</li>`).join('')}</ul>`;
    return `<p>${lines.map(esc).join('<br>')}</p>`;
  }).join('');
}

(async function boot() {
  await initI18n();
  initMenu();
  const key = allowed.includes(slug) ? slug : 'about';
  const title = t(`pages.${key}.title`);
  document.title = `${title} — ${t('brand.name')}`;
  document.getElementById('pageTitle').textContent = title;
  document.getElementById('pageBody').innerHTML = render(t(`pages.${key}.body`));
})();
