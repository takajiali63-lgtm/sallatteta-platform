import { initI18n, t, esc } from './i18n.js?v=452';
import { initMenu, getSiteConfig } from './ui.js?v=452';

// Terms / privacy / about — texts come from the language files and can be edited from the admin panel.
const slug = location.pathname.replace(/\/+$/, '').slice(1);
const allowed = ['terms', 'privacy', 'about'];

/** Tiny formatter: "## " → heading, "- " → bullet list, blank line → new paragraph. Text only (escaped). */
function render(body) {
  return String(body).split(/\n\s*\n/).map((block) => {
    const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
    if (!lines.length) return '';
    if (lines[0].startsWith('## ')) {
      const rest = lines.slice(1);
      return `<h2>${esc(lines[0].slice(3))}</h2>${rest.length ? render(rest.join('\n')) : ''}`;
    }
    if (lines.every((l) => l.startsWith('- '))) return `<ul>${lines.map((l) => `<li>${esc(l.slice(2))}</li>`).join('')}</ul>`;
    return `<p>${lines.map(esc).join('<br>')}</p>`;
  }).join('');
}

/** "Get the app": store links set by the admin + how to install the site as an app meanwhile. */
async function renderAppPage() {
  const cfg = await getSiteConfig();
  const links = cfg.site?.appLinks || {};
  document.title = `${t('app.title')} — ${t('brand.name')}`;
  document.getElementById('pageTitle').textContent = t('app.title');
  const ua = navigator.userAgent;
  const isIos = /iPhone|iPad|iPod/.test(ua);
  const btn = (href, label) => `<p><a class="btn btn-gold" href="${esc(href)}" rel="noopener">${esc(label)}</a></p>`;
  document.getElementById('pageBody').innerHTML = `
    <p class="lead">${esc(t('app.lead'))}</p>
    ${links.android ? btn(links.android, t('app.android')) : ''}
    ${links.ios ? btn(links.ios, t('app.ios')) : ''}
    <h2>${esc(t('app.installTitle'))}</h2>
    <p>${esc(t(isIos ? 'app.installIos' : 'app.installAndroid'))}</p>`;
}

(async function boot() {
  await initI18n();
  initMenu();
  if (slug === 'app') return renderAppPage();
  const key = allowed.includes(slug) ? slug : 'about';
  const title = t(`pages.${key}.title`);
  document.title = `${title} — ${t('brand.name')}`;
  document.getElementById('pageTitle').textContent = title;
  document.getElementById('pageBody').innerHTML = render(t(`pages.${key}.body`));
})();
