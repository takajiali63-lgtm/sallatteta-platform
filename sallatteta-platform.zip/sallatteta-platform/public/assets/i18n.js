// Shared i18n: all UI text lives in /locales/<lang>.json. Any file there is a language (ar, en, fr, es, ...).
// Missing keys fall back to Arabic, then to the key itself. Direction (RTL/LTR) follows the language.
const RTL = ['ar', 'fa', 'he', 'ur'];
let region = { code: 'LB', locale: 'ar-LB', units: 'km' };
let dict = {};
let fallback = {};
export let lang = 'ar';

const get = (obj, key) => key.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), obj);

function pickLang() {
  const q = new URLSearchParams(location.search).get('lang');
  let saved = null;
  try { saved = localStorage.getItem('st_lang'); } catch { /* storage may be blocked */ }
  const valid = (x) => /^[a-z]{2}$/.test(x || '');
  const l = valid(q) ? q : valid(saved) ? saved : 'ar';
  try { if (q) localStorage.setItem('st_lang', l); } catch { /* ignore */ }
  return l;
}

export async function initI18n() {
  lang = pickLang();
  fallback = await (await fetch('/locales/ar.json')).json();
  if (lang !== 'ar') {
    const r = await fetch(`/locales/${lang}.json`).catch(() => null);
    dict = r && r.ok ? await r.json().catch(() => ({})) : {};
    if (!r || !r.ok) lang = 'ar';
  }
  if (lang === 'ar') dict = fallback;
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL.includes(lang) ? 'rtl' : 'ltr';
  applyI18n(document);
}

/** Raw locale value (arrays/objects), with Arabic fallback. */
export const raw = (key) => get(dict, key) ?? get(fallback, key);

export function t(key, vars = {}) {
  const s = get(dict, key) ?? get(fallback, key) ?? key;
  return String(s).replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ''));
}

/** data-i18n="key" → textContent, data-i18n-placeholder / -aria / -title → attributes */
export function applyI18n(rootEl) {
  rootEl.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  rootEl.querySelectorAll('[data-i18n-placeholder]').forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  rootEl.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  rootEl.querySelectorAll('[data-i18n-title]').forEach((el) => { document.title = t(el.dataset.i18nTitle); });
}

/** Country settings from /api/config (dates, numbers, distance units). */
export function setRegion(country) { if (country) region = { ...region, ...country }; }
export const getRegion = () => region;
/** e.g. "ar-LB-u-nu-latn": the user's language + the platform country, Western digits. */
export const localeTag = () => `${lang}-${region.code}-u-nu-latn`;
export const fmtNumber = (n) => new Intl.NumberFormat(localeTag()).format(n);
export const fmtDate = (v, opts = { year: 'numeric', month: 'long', day: 'numeric' }) => (v ? new Date(v).toLocaleDateString(localeTag(), opts) : '—');
/** Distance for display, in km or miles depending on the country. */
export function fmtDistance(km) {
  if (region.units === 'mi') { const mi = Math.round(km * 0.621371 * 10) / 10; return mi < 1 ? t('common.miLess') : t('common.mi', { d: mi }); }
  return km < 1 ? t('common.kmLess') : t('common.km', { d: km });
}

/** JSON API call. Throws { code, fields, status } on failure. */
export async function api(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: {
        'X-Locale': lang,
        'X-Requested-With': 'fetch',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
    });
  } catch {
    throw { code: 'network' };
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, code: data.error || 'server_error', fields: data.fields || {} };
  return data;
}

export const errorText = (err) => t(`errors.${err?.code || 'server_error'}`);

/** Escape text for safe insertion into HTML strings. */
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Approximate position from the browser, rounded to ~100 m before it ever leaves the device. */
export function getApproxPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('unavailable'));
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: Math.round(p.coords.latitude * 1000) / 1000, lng: Math.round(p.coords.longitude * 1000) / 1000 }),
      reject,
      { enableHighAccuracy: false, timeout: 12000, maximumAge: 300000 },
    );
  });
}
