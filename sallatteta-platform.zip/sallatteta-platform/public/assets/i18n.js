// Shared i18n: all UI text lives in /locales/<lang>.json. Any file there is a language (ar, en, fr, es, ...).
// The language follows the visitor's COUNTRY (GPS / time zone), unless a ?lang= link was used.
// Missing keys fall back to English, then Arabic. Direction (RTL/LTR) follows the language.
const RTL = ['ar', 'fa', 'he', 'ur'];
let region = { code: 'LB', locale: 'ar-LB', units: 'km' };
let dict = {};
let fallback = { ar: {}, en: {} };
export let lang = 'ar';

const get = (obj, key) => key.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), obj);

/** Language the user chose explicitly (?lang=xx link); otherwise the language follows the country. */
function explicitLang() {
  const q = new URLSearchParams(location.search).get('lang');
  const valid = (x) => /^[a-z]{2}$/.test(x || '');
  try {
    if (valid(q)) { localStorage.setItem('st_lang', q); return q; }
    const saved = localStorage.getItem('st_lang');
    return valid(saved) ? saved : null;
  } catch { return valid(q) ? q : null; }
}

/** The visitor's country: last GPS result → CDN hint → device time zone → device locale region → platform default. */
function guessCountry(cfg) {
  let saved = null;
  try { saved = localStorage.getItem('st_country'); } catch { /* ignore */ }
  const known = (c) => (c && cfg.countries?.includes(c) ? c : null);
  let tz = '';
  try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch { /* ignore */ }
  const navRegion = (navigator.language || '').split('-')[1]?.toUpperCase();
  return known(saved) || known(cfg.countryHint) || known(cfg.countryTimezones?.[tz]) || known(navRegion) || cfg.country?.code || 'LB';
}

/** Remember the country found from GPS (used for language, currency and phone format from now on). */
export function rememberCountry(code) {
  if (!/^[A-Z]{2}$/.test(code || '')) return false;
  let prev = null;
  try { prev = localStorage.getItem('st_country'); localStorage.setItem('st_country', code); } catch { /* ignore */ }
  return prev !== code;
}

let configPromise = null;
/** Site configuration for the visitor's country (shared by every script on the page). */
export const getConfig = () => configPromise;

async function loadConfig() {
  let cfg = await (await fetch('/api/config', { headers: { 'X-Requested-With': 'fetch' } })).json();
  const c = guessCountry(cfg);
  if (c !== cfg.country?.code) cfg = await (await fetch(`/api/config?country=${c}`, { headers: { 'X-Requested-With': 'fetch' } })).json();
  return cfg;
}

export async function initI18n() {
  configPromise = configPromise || loadConfig();
  let cfg = null;
  try { cfg = await configPromise; } catch { /* offline: Arabic defaults */ }
  if (cfg) setRegion(cfg.country);
  const available = cfg?.locales || ['ar'];
  const countryLang = cfg?.country?.lang;
  const wanted = explicitLang() || (countryLang && available.includes(countryLang) ? countryLang : (cfg ? 'en' : 'ar'));
  lang = available.includes(wanted) ? wanted : (available.includes('en') ? 'en' : 'ar');
  // Missing keys: the chosen language → English → Arabic.
  const load = async (l) => { const r = await fetch(`/locales/${l}.json`).catch(() => null); return r && r.ok ? r.json().catch(() => ({})) : {}; };
  const ar = await load('ar');
  const en = lang === 'ar' ? {} : await load('en');
  dict = lang === 'ar' ? ar : lang === 'en' ? en : await load(lang);
  fallback = { ar, en };
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL.includes(lang) ? 'rtl' : 'ltr';
  applyI18n(document);
}

/** Raw locale value (arrays/objects), with Arabic fallback. */
export const raw = (key) => get(dict, key) ?? get(fallback.en, key) ?? get(fallback.ar, key);

export function t(key, vars = {}) {
  const s = get(dict, key) ?? get(fallback.en, key) ?? get(fallback.ar, key) ?? key;
  return String(s).replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ''));
}

/** data-i18n="key" → textContent, data-i18n-placeholder / -aria / -title → attributes */
export function applyI18n(rootEl) {
  rootEl.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  rootEl.querySelectorAll('[data-i18n-placeholder]').forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  rootEl.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  rootEl.querySelectorAll('[data-i18n-title]').forEach((el) => { document.title = t(el.dataset.i18nTitle); });
}

/** Country settings from /api/config (dates, numbers, distance units). */
export function setRegion(country) { if (country) region = { ...region, ...country }; }
export const getRegion = () => region;
/** e.g. "ar-LB-u-nu-latn": the user's language + the platform country, Western digits. */
export const localeTag = () => `${lang}-${region.code}-u-nu-latn`;
export const fmtNumber = (n) => new Intl.NumberFormat(localeTag()).format(n);
export const fmtDate = (v, opts = { year: 'numeric', month: 'long', day: 'numeric' }) => (v ? new Date(v).toLocaleDateString(localeTag(), opts) : '—');
/** Distance for display, in km or miles depending on the country. */
export function fmtDistance(km) {
  if (region.units === 'mi') { const mi = Math.round(km * 0.621371 * 10) / 10; return mi < 1 ? t('common.miLess') : t('common.mi', { d: mi }); }
  return km < 1 ? t('common.kmLess') : t('common.km', { d: km });
}

/** JSON API call. Throws { code, fields, status } on failure. */
export async function api(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: {
        'X-Locale': lang,
        'X-Requested-With': 'fetch',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
    });
  } catch {
    throw { code: 'network' };
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { status: res.status, code: data.error || 'server_error', fields: data.fields || {} };
  return data;
}

export const errorText = (err) => t(`errors.${err?.code || 'server_error'}`);

/** Escape text for safe insertion into HTML strings. */
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Approximate position from the browser, rounded to ~100 m before it ever leaves the device. */
export function getApproxPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('unavailable'));
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: Math.round(p.coords.latitude * 1000) / 1000, lng: Math.round(p.coords.longitude * 1000) / 1000 }),
      reject,
      { enableHighAccuracy: false, timeout: 12000, maximumAge: 300000 },
    );
  });
}

/** Money as people read it everywhere: $20, €45, £9.50 (Western digits), other currencies with their code. */
export function fmtMoney(v, currency = 'USD') {
  const sym = { USD: '$', EUR: '€', GBP: '£' }[currency];
  const n = new Intl.NumberFormat('en-US', { minimumFractionDigits: Number(v) % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(Number(v));
  return sym ? `${sym}${n}` : `${n} ${currency}`;
}
