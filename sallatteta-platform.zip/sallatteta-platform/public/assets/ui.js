// Shared UI building blocks used by the customer pages, the cook account and the admin panel.
import { t, api, esc } from './i18n.js';

export const $ = (s, r = document) => r.querySelector(s);

/* ---------- header back button: previous page on this site, otherwise home ---------- */
document.addEventListener('click', (e) => {
  if (!e.target.closest('[data-back]')) return;
  let sameSite = false;
  try { sameSite = !!document.referrer && new URL(document.referrer).origin === location.origin; } catch { /* ignore */ }
  if (sameSite && history.length > 1) history.back();
  else location.href = '/';
});

/** Radio chips for the delivery radius around the cook's home. */
export function radiusChips(container, options, value) {
  container.innerHTML = options.map((n) =>
    `<label class="chip"><input type="radio" name="radiusKm" value="${n}" ${Number(value) === n ? 'checked' : ''}><span>${esc(t('common.km', { d: n }))}</span></label>`).join('');
  return () => { const c = container.querySelector('input[name="radiusKm"]:checked'); return c ? Number(c.value) : undefined; };
}

/* ---------- device-local memory (no account needed for customers) ---------- */
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked */ } },
};

export function viewerId() {
  let id = store.get('st_vid', null);
  if (!id) {
    const b = crypto.getRandomValues(new Uint8Array(16));
    id = btoa(String.fromCharCode(...b)).replace(/[+/=]/g, (c) => ({ '+': '-', '/': '_', '=': '' }[c]));
    store.set('st_vid', id);
  }
  return id;
}

/** "My cooks": cooks this customer contacted, with the private token that lets her rate them. */
export const myCooks = {
  list() { return store.get('st_my_cooks', []); },
  remember({ id, name, reviewToken }) {
    const list = this.list().filter((c) => c.id !== id);
    list.unshift({ id, name, reviewToken, at: Date.now(), rating: null, dismissed: false });
    store.set('st_my_cooks', list.slice(0, 20));
  },
  update(id, patch) { store.set('st_my_cooks', this.list().map((c) => (c.id === id ? { ...c, ...patch } : c))); },
  get(id) { return this.list().find((c) => c.id === Number(id)) || null; },
};

/* ---------- stars ---------- */
export function starsHtml(rating, { size = '' } = {}) {
  if (!rating || !rating.count) return `<span class="stars-new">${esc(t('results.newCook'))}</span>`;
  return `<span class="stars ${size}" aria-label="${rating.avg} / 5"><span class="star-glyph" aria-hidden="true">★</span> ${rating.avg}<span class="stars-count"> (${rating.count})</span></span>`;
}

/** Interactive 1–5 star input. */
export function starInput(container, { value = 0, onPick }) {
  container.innerHTML = `<div class="star-input" role="radiogroup">${[1, 2, 3, 4, 5].map((n) =>
    `<button type="button" role="radio" aria-checked="${n === value}" aria-label="${n}" data-n="${n}" class="${n <= value ? 'on' : ''}">★</button>`).join('')}</div>`;
  container.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
    const n = Number(b.dataset.n);
    container.querySelectorAll('button').forEach((x) => { x.classList.toggle('on', Number(x.dataset.n) <= n); x.setAttribute('aria-checked', String(Number(x.dataset.n) === n)); });
    onPick(n);
  }));
}

/* ---------- avatar ---------- */
export function avatarHtml(c, cls = 'avatar') {
  return c.photoUrl
    ? `<img class="${cls}" src="${esc(c.photoUrl)}" alt="" loading="lazy">`
    : `<span class="${cls}" aria-hidden="true">${esc([...(c.name || '').trim()][0] || '')}</span>`;
}

/* ---------- images ---------- */
export function resizeImage(file, max = 900, quality = 0.8) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = reject;
    img.src = url;
  });
}

/* ---------- village search (autocomplete) ---------- */
/**
 * Turns a text input into a village search. Calls onPick({id, name, districtName}).
 * base = API prefix for lookups (same for everyone).
 */
export function areaSearch(input, { onPick, list = null }) {
  const box = list || document.createElement('ul');
  if (!list) { box.className = 'suggest'; input.insertAdjacentElement('afterend', box); }
  box.setAttribute('role', 'listbox');
  input.setAttribute('role', 'combobox');
  input.setAttribute('aria-autocomplete', 'list');
  input.setAttribute('autocomplete', 'off');
  let timer, items = [], active = -1, seq = 0;
  const close = () => { box.hidden = true; box.innerHTML = ''; items = []; active = -1; input.setAttribute('aria-expanded', 'false'); };
  const render = () => {
    box.innerHTML = items.length
      ? items.map((a, i) => `<li role="option" data-i="${i}" aria-selected="${i === active}"><b>${esc(a.name)}</b><span>${esc(a.districtName || '')}</span></li>`).join('')
      : `<li class="suggest-empty">${esc(t('location.noMatch'))}</li>`;
    box.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  };
  const pick = (a) => { input.value = a.name; close(); onPick(a); };
  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (!q) return close();
    timer = setTimeout(async () => {
      const my = ++seq;
      try {
        const r = await api(`/api/areas/search?q=${encodeURIComponent(q)}`);
        if (my !== seq) return;
        items = r.areas; active = items.length ? 0 : -1; render();
      } catch { /* ignore */ }
    }, 180);
  });
  input.addEventListener('keydown', (e) => {
    if (box.hidden || !items.length) return;
    if (e.key === 'ArrowDown') { active = (active + 1) % items.length; render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { active = (active - 1 + items.length) % items.length; render(); e.preventDefault(); }
    else if (e.key === 'Enter') { e.preventDefault(); pick(items[Math.max(0, active)]); }
    else if (e.key === 'Escape') close();
  });
  box.addEventListener('mousedown', (e) => e.preventDefault());
  box.addEventListener('click', (e) => { const li = e.target.closest('[data-i]'); if (li) pick(items[Number(li.dataset.i)]); });
  input.addEventListener('blur', () => setTimeout(close, 150));
  close();
  return { close };
}

/* ---------- "where do you deliver?" editor (cook signup, cook account, admin) ---------- */
/**
 * Nearby villages are suggested UNTICKED — the cook picks the ones she delivers to herself.
 * She can also search any village, or add a whole district.
 */
export function servedAreasEditor(root, { initial = [], homeAreaId = null, districts = [] } = {}) {
  const selected = new Map(initial.map((a) => [a.id, a]));
  root.innerHTML = `
    <p class="hint" data-role="hint"></p>
    <div class="chips" data-role="nearby"></div>
    <div class="area-add">
      <input class="input" data-role="search" placeholder="${esc(t('areasPicker.search'))}" aria-label="${esc(t('areasPicker.search'))}">
    </div>
    <div class="district-row" data-role="districtRow" hidden><button type="button" class="btn-text" data-role="district"></button></div>
    <div class="selected-head"><span class="label" data-role="count"></span><button type="button" class="btn-text" data-role="clear">${esc(t('areasPicker.clear'))}</button></div>
    <div class="chips" data-role="selected"></div>`;
  const nearbyBox = $('[data-role="nearby"]', root);
  const selBox = $('[data-role="selected"]', root);
  let nearby = [], currentDistrict = null;

  const renderSelected = () => {
    $('[data-role="count"]', root).textContent = t('areasPicker.selected', { n: selected.size });
    $('[data-role="clear"]', root).hidden = !selected.size;
    selBox.innerHTML = [...selected.values()].map((a) =>
      `<button type="button" class="chip-sel" data-id="${a.id}" aria-label="${esc(t('areasPicker.remove', { name: a.name }))}">${esc(a.name)} <span aria-hidden="true">×</span></button>`).join('');
  };
  const renderNearby = () => {
    $('[data-role="hint"]', root).textContent = nearby.length ? t('areasPicker.nearby') : t('areasPicker.noHome');
    nearbyBox.innerHTML = nearby.map((a) =>
      `<label class="chip"><input type="checkbox" value="${a.id}" ${selected.has(a.id) ? 'checked' : ''}><span>${esc(a.name)}</span></label>`).join('');
  };
  const add = (a) => { selected.set(a.id, a); renderSelected(); renderNearby(); };
  const remove = (id) => { selected.delete(id); renderSelected(); renderNearby(); };

  nearbyBox.addEventListener('change', (e) => {
    const id = Number(e.target.value);
    const a = nearby.find((x) => x.id === id);
    if (e.target.checked) add(a); else remove(id);
  });
  selBox.addEventListener('click', (e) => { const b = e.target.closest('[data-id]'); if (b) remove(Number(b.dataset.id)); });
  $('[data-role="clear"]', root).addEventListener('click', () => { selected.clear(); renderSelected(); renderNearby(); });
  const search = $('[data-role="search"]', root);
  areaSearch(search, { onPick: (a) => { add(a); search.value = ''; } });
  $('[data-role="district"]', root).addEventListener('click', async () => {
    if (!currentDistrict) return;
    const r = await api(`/api/areas/district?key=${encodeURIComponent(currentDistrict)}`);
    r.areas.forEach((a) => selected.set(a.id, a));
    renderSelected(); renderNearby();
  });

  async function setHome(areaId) {
    if (!areaId) { nearby = []; renderNearby(); $('[data-role="districtRow"]', root).hidden = true; return; }
    const r = await api(`/api/areas/nearby?areaId=${areaId}&km=15`);
    nearby = r.areas;
    const home = nearby[0];
    currentDistrict = home?.district || null;
    const d = districts.find((x) => x.key === currentDistrict);
    $('[data-role="districtRow"]', root).hidden = !d;
    if (d) $('[data-role="district"]', root).textContent = t('areasPicker.district', { name: d.name });
    renderNearby();
  }

  renderSelected();
  renderNearby();
  if (homeAreaId) setHome(homeAreaId);
  return { setHome, ids: () => [...selected.keys()], count: () => selected.size };
}
