import { initI18n, t, api, errorText, esc, rememberCountry, fmtDistanceM, fmtDistance } from './i18n.js?v=500';
import { $, avatarHtml, starsHtml, getPosition, initMenu, getSiteConfig, explainGpsError, catLabel } from './ui.js?v=500';

const mode = location.pathname.replace(/\/+$/, '').slice(1) || 'nearby';
const rawType = new URLSearchParams(location.search).get('type') || 'cook';
const type = /^[a-z][a-z0-9_]{1,30}$/.test(rawType) ? rawType : 'cook';
let siteCfg = null;
const distText = (c) => (c.distanceM != null ? fmtDistanceM(c.distanceM) : fmtDistance(c.distanceKm));
const cookRow = (c, withDistance) => `
  <li><a class="cook" href="${esc(c.profileUrl)}">${avatarHtml(c)}
    <span>
      <span class="cook-name">${esc(c.name)}</span>
      <span class="cook-meta">${esc(c.area || '')} · ${starsHtml(c.rating)}</span>
      <span class="cook-meta">${esc(c.services.map((k) => t(`services.${k}`)).join(' + '))}</span>
    </span>
    <span class="cook-dist">${withDistance ? esc(distText(c)) : '‹'}</span></a></li>`;

/* ---------- nearby: GPS → cooks who deliver here, nearest first ---------- */
async function nearby() {
  const st = $('#nearbyStatus');
  st.classList.remove('bad');
  st.textContent = t('location.locating');
  $('#nearbyBtn').disabled = true;
  try {
    const pos = await getPosition({ precise: true, maxWaitMs: 8000, goodEnough: 50 });
    st.textContent = t('location.searching');
    const r = await api(`/api/cooks/nearby?lat=${pos.lat}&lng=${pos.lng}&type=${type}`);
    st.textContent = r.area ? (r.area.distanceKm > 1.5 ? t('results.nearFar', { area: r.area.name, d: r.area.distanceKm }) : t('results.near', { area: r.area.name })) : '';
    if (r.country) rememberCountry(r.country);
    if (type === 'all') {
      // grouped by category (in the admin's order), each group nearest → farthest
      const cats = (siteCfg?.site?.categories || []);
      const order = new Map(cats.map((c, i) => [c.key, i]));
      const groups = new Map();
      for (const c of r.cooks) (groups.get(c.kind || 'cook') || groups.set(c.kind || 'cook', []).get(c.kind || 'cook')).push(c);
      $('#nearbyList').innerHTML = [...groups.entries()].sort((a, b) => (order.get(a[0]) ?? 99) - (order.get(b[0]) ?? 99)).map(([k, list]) => {
        const cat = cats.find((c) => c.key === k);
        return `<li class="near-group"><h2>${esc(cat?.icon || '📍')} ${esc(cat ? catLabel(cat, 'many') : k)} <small>(${list.length})</small></h2></li>`
          + list.map((c) => cookRow(c, true)).join('');
      }).join('');
    } else $('#nearbyList').innerHTML = r.cooks.map((c) => cookRow(c, true)).join('');
    $('#nearbyEmpty').hidden = r.cooks.length > 0;
    $('#nearbyBtn').textContent = t('join.gpsAgain');
  } catch (err) {
    if (typeof err?.code === 'string') { st.classList.add('bad'); st.textContent = errorText(err); }
    else explainGpsError(st, err, () => $('#nearbyBtn').click());
  } finally { $('#nearbyBtn').disabled = false; }
}

/* ---------- by governorate ---------- */
async function regions() {
  const cfg = await getSiteConfig();
  const { regions } = await api(`/api/cooks/by-region?country=${cfg.country?.code || ''}&type=${type}`);
  document.querySelectorAll('#typeSwitch [data-type]').forEach((a) => a.classList.toggle('on', a.dataset.type === type));
  $('#regions').innerHTML = regions.map((g) => `
    <section class="region">
      <h2 class="section-title"><span>${esc(g.name || t('browse.otherRegion'))}</span><small>${esc(t('browse.count', { n: g.cooks.length }))}</small></h2>
      ${g.cooks.length ? `<ul class="cook-list">${g.cooks.map((c) => cookRow(c, false)).join('')}</ul>` : `<p class="fine">${esc(t('browse.noneYet'))}</p>`}
    </section>`).join('');
}

/* ---------- dish photos: 10 at a time ---------- */
let offset = 0;
async function dishes() {
  const btn = $('#moreDishes');
  btn.disabled = true;
  try {
    const cfg = await getSiteConfig();
    const r = await api(`/api/dishes?offset=${offset}&limit=10&country=${cfg.country?.code || ''}`);
    offset += r.dishes.length;
    $('#dishFeed').insertAdjacentHTML('beforeend', r.dishes.map((d) => `
      <a class="dish-post" href="${esc(d.profileUrl)}">
        <img src="${esc(d.photoUrl)}" alt="${esc(d.caption)}" loading="lazy">
        <span class="dish-post-text">
          ${d.caption ? `<b>${esc(d.caption)}</b>` : ''}
          <span>${esc(t('feed.by', { name: d.cookName }))}${d.area ? ` · ${esc(d.area)}` : ''}</span>
        </span>
      </a>`).join(''));
    $('#dishesEmpty').hidden = offset > 0;
    btn.hidden = !r.hasMore;
  } catch (err) { $('#globalError').textContent = errorText(err); $('#globalError').hidden = false; }
  finally { btn.disabled = false; }
}

(async function boot() {
  await initI18n();
  initMenu();
  const cfg = await getSiteConfig();
  if (mode !== 'nearby' && cfg.site?.sections?.[mode] === false) { location.replace('/'); return; }
  // Nearby page of any category: "Pharmacies near you", empty text and title from the category's own names.
  siteCfg = cfg;
  const cat = type === 'all' ? { icon: '📍', key: 'all' } : (cfg.site?.categories || []).find((c) => c.key === type);
  if (mode === 'nearby' && !cat) { location.replace('/'); return; }
  if (mode === 'nearby' && type === 'all') {
    $('#nearbyTitle').textContent = `📍 ${t('home.allNear')}`;
    $('#nearbyEmpty').textContent = t('browse.allEmpty');
    document.title = `${t('home.allNear')} — ${t('brand.name')}`;
  } else if (mode === 'nearby') {
    $('#nearbyTitle').textContent = `${cat.icon} ${t('browse.nearTitle', { name: catLabel(cat, 'many') })}`;
    $('#nearbyEmpty').textContent = t('browse.nearEmpty', { name: catLabel(cat, 'many') });
    document.title = `${catLabel(cat, 'many')} — ${t('brand.name')}`;
  } else {
    const titles = { regions: 'menu.regions', dishes: 'menu.dishes' };
    document.title = `${t(titles[mode] || 'menu.regions')} — ${t('brand.name')}`;
  }
  const el = $(`#mode-${mode}`) || $('#mode-nearby');
  el.hidden = false;
  if (mode === 'regions') regions().catch((e) => { $('#globalError').textContent = errorText(e); $('#globalError').hidden = false; });
  else if (mode === 'dishes') { $('#moreDishes').addEventListener('click', dishes); dishes(); }
  else $('#nearbyBtn').addEventListener('click', nearby);
})();
