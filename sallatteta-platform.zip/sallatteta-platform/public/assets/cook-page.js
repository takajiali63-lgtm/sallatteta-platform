import { initI18n, t, api, errorText, esc, fmtMoney } from './i18n.js?v=604';
import { $, avatarHtml, starsHtml, starInput, viewerId, myCooks, getPosition, initMenu, explainGpsError, catLabel, getSiteConfig, actionButtons, directionsUrl, lastLocation, distanceLabel } from './ui.js?v=604';

const cookId = Number(location.pathname.split('/')[2]);
const vid = viewerId();
const startedAt = Date.now();
let cook = null, orderPos = null;

const close = (d) => d.close();
document.querySelectorAll('dialog').forEach((d) => {
  d.addEventListener('click', (e) => { if (e.target === d || e.target.closest('[data-close]')) close(d); });
});

async function render() {
  document.title = `${cook.name} — ${t('brand.name')}`;
  $('#cover').innerHTML = cook.photos[0] ? `<img src="${esc(cook.photos[0].url)}" alt="">` : '';
  $('#avatarSlot').innerHTML = avatarHtml(cook);
  $('#cookName').textContent = cook.name;
  if (cook.verified) $('#cookName').insertAdjacentHTML('beforeend', ` <span class="vbadge" title="${esc(t('admin.verified'))}">✓</span>`);
  $('#cookArea').textContent = [cook.area || '', distanceLabel(cook, { long: true })].filter(Boolean).join(' · ');
  $('#ratingSlot').innerHTML = cook.rating.count
    ? `${starsHtml(cook.rating, { size: 'lg' })}`
    : `<span class="stars-new">${esc(t('cookPage.noRating'))}</span>`;
  $('#likeCount').textContent = t('cookPage.likes', { n: cook.likes });
  $('#likeBtn').setAttribute('aria-pressed', String(!!cook.likedByMe));
  $('#cookBio').textContent = cook.bio;
  $('#cookBio').hidden = !cook.bio;
  $('#services').innerHTML = cook.services.map((s) => `<span class="chip"><span>${esc(t(`services.${s}`))}</span></span>`).join('');
  const isRest = true;   // every category has a menu / price list
  // The customer's choices, stacked, none mandatory:
  //   order on WhatsApp (delivery, no location sent) · order then go there · directions only · call
  const nav = directionsUrl(cook.nav);
  const closedNow = cook.openNow === false;
  if (cook.openNow !== null && cook.openNow !== undefined) {
    $('#cookArea').insertAdjacentHTML('afterend', `<p class="open-line ${closedNow ? 'is-closed' : 'is-open'}">${closedNow ? '🔴' : '🟢'} ${esc(t(closedNow ? 'hours.closedNow' : 'hours.openNow', { close: cook.hours?.close || '', open: cook.hours?.open || '' }))}</p>`);
  }
  const big = (cls, attrs, icon, title, sub) => `<a class="choice ${cls}" ${attrs}><b>${icon} ${esc(title)}</b><small>${esc(sub)}</small></a>`;
  const site = (await getSiteConfig().catch(() => ({}))).site || {};
  const craft = (site.categories || []).find((c) => c.key === cook.kind)?.group === 'crafts';
  $('#profileActs').innerHTML = craft ? [
    // craftspeople come to the customer: message · "come to me" (sends the customer's location, with consent) · call
    cook.canOrder !== false ? big('c-order', 'href="#" data-choice="order"', '💬', t('act.message'), t('act.orderSub')) : '',
    cook.canOrder !== false ? big('c-ordergo', 'href="#" data-choice="come"', '📍', t('act.comeToMe'), t('act.comeToMeSub')) : '',
    cook.callPhone ? big('c-call', `href="tel:+${esc(String(cook.callPhone).replace(/^\+/, ''))}"`, '📞', t('act.callHim'), '') : '',
  ].join('') : [
    cook.canOrder !== false ? big('c-order', 'href="#" data-choice="order"', '💬', t('act.order'), t('act.orderSub')) : '',
    cook.canOrder !== false && nav ? big('c-ordergo', 'href="#" data-choice="ordergo"', '🛵', t('act.orderGo'), t('act.orderGoSub')) : '',
    nav ? big('c-nav', `href="${esc(nav)}" target="_blank" rel="noopener"`, '🧭', t(cook.canOrder !== false ? 'act.directionsOnly' : 'act.directions'), t('act.directionsSub')) : '',
    cook.callPhone ? big('c-call', `href="tel:+${esc(String(cook.callPhone).replace(/^\+/, ''))}"`, '📞', t('act.call'), `\u2066+${String(cook.callPhone).replace(/^\+/, '')}\u2069`) : '',   // isolated left-to-right inside Arabic
    cook.canOrder === false ? `<p class="fine">${esc(t('act.noWhatsapp'))}</p>` : '',
  ].join('');
  { const cta = $('#orderBtn')?.closest('.sticky-cta'); if (cta) cta.hidden = true; }
  // 📅 pre-booking (add-on): choose a day (next 14, no closed days) and a time within the hours → WhatsApp message to the shop
  if (cook.booking && !document.getElementById('bookBtn')) {
    $('#profileActs').insertAdjacentHTML('afterbegin', `<a class="choice c-book" href="#" id="bookBtn"><b>📅 ${esc(t('booking.button'))}</b><small>${esc(t('booking.sub'))}</small></a>`);
    document.getElementById('bookBtn').addEventListener('click', async (e) => {
      e.preventDefault();
      const h = cook.hours || { allDay: true, closed: [] };
      const days = []; for (let i = 0; days.length < 14 && i < 30; i++) { const d = new Date(Date.now() + i * 864e5); if (!(h.closed || []).includes(d.getDay())) days.push(d); }
      const pick = prompt(`${t('booking.whichDay')}\n${days.map((d, i) => `${i + 1}. ${d.toLocaleDateString(document.documentElement.lang || 'ar', { weekday: 'long', day: 'numeric', month: 'long' })}`).join('\n')}`);
      const day = days[Number(pick) - 1]; if (!day) return;
      const slots = []; const toM = (s) => Number(s.slice(0, 2)) * 60 + Number(s.slice(3, 5));
      const o = h.allDay ? 0 : toM(h.open), cl = h.allDay ? 24 * 60 : toM(h.close), end = cl > o ? cl : cl + 24 * 60;
      for (let m = Math.ceil(o / 30) * 30; m < end; m += 30) slots.push(`${String(Math.floor(m / 60) % 24).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`);
      const tp = prompt(`${t('booking.whichTime')}\n${slots.map((s, i) => `${i + 1}. ${s}`).join('   ')}`);
      const time = slots[Number(tp) - 1]; if (!time) return;
      const name = prompt(t('booking.yourName')); if (!name || name.trim().length < 2) return;
      const note = prompt(t('booking.note')) || '';
      try {
        const r = await api('/api/booking', { method: 'POST', body: { cookId: cook.id, name: name.trim(), date: day.toISOString().slice(0, 10), time, note, website: '' } });
        window.location.href = r.whatsappUrl;
      } catch (err) { alert(errorText(err)); }
    });
  }
  if (!document.getElementById('reportBtn')) {
    $('#profileActs').insertAdjacentHTML('afterend', `<p class="report-row"><button type="button" class="btn-text" id="reportBtn">🚩 ${esc(t('report.button'))}</button></p>`);
    document.getElementById('reportBtn').addEventListener('click', async () => {
      const reasons = ['offensive', 'fake', 'scam', 'other'];
      const pick = prompt(`${t('report.ask')}\n${reasons.map((r, i) => `${i + 1}. ${t(`report.reason_${r}`)}`).join('\n')}`);
      const reason = reasons[Number(pick) - 1]; if (!reason) return;
      const note = prompt(t('report.note')) || '';
      try { await api('/api/report', { method: 'POST', body: { cookId: cook.id, reason, note, website: '' } }); alert(t('report.thanks')); } catch (err) { alert(errorText(err)); }
    });
  }   // the choices replace the single sticky button
  if (closedNow) {   // closed: ordering and calling wait; directions still work
    $('#profileActs').querySelectorAll('[data-choice], .c-call').forEach((a) => { a.classList.add('is-off'); a.removeAttribute('href'); a.removeAttribute('data-choice'); const sm = a.querySelector('small'); if (sm) sm.textContent = t('hours.notNow'); });
  }
  $('#profileActs').addEventListener('click', async (e) => {
    const ch = e.target.closest('[data-choice]'); if (!ch) return;
    e.preventDefault();
    sessionStorage.removeItem('st_come');
    if (ch.dataset.choice === 'ordergo') sessionStorage.setItem('st_go_after', nav); else sessionStorage.removeItem('st_go_after');
    if (ch.dataset.choice === 'come') {
      // the customer's location goes to the craftsman ONLY after the customer agrees
      if (!confirm(t('act.comeConfirm'))) return;
      try {
        const p = await getPosition({ precise: true, maxWaitMs: 10000, goodEnough: 30 });
        sessionStorage.setItem('st_come', `https://maps.google.com/?q=${p.lat.toFixed(6)},${p.lng.toFixed(6)}`);
      } catch (err) { alert(explainGpsError(err)); return; }
    }
    $('#orderBtn').click();   // the usual order sheet (dishes + optional note)
  });
  $('#servicesBlock').hidden = isRest || !cook.services.length;
  $('#specialtyBlock').hidden = !cook.specialty;
  $('#specialty').textContent = cook.specialty || '';
  // badge with the category's name (pharmacy, bakery…)
  getSiteConfig().then((cfg) => {
    const cat = (cfg.site?.categories || []).find((c) => c.key === (cook.kind || 'cook'));
    if (cat && cook.kind !== 'cook') $('#cookName').insertAdjacentHTML('beforeend', ` <span class="kind-badge">${esc(cat.icon)} ${esc(catLabel(cat, 'one'))}</span>`);
  });
  renderMenu();
  $('#serves').textContent = cook.servedAreas.map((a) => a.name).join('، ');
  $('#gallery').innerHTML = cook.photos.map((p, i) => `
    <figure><button type="button" data-i="${i}"><img src="${esc(p.url)}" alt="${esc(p.caption)}" loading="lazy"></button>${p.caption ? `<figcaption>${esc(p.caption)}</figcaption>` : ''}</figure>`).join('');
  $('#noPhotos').hidden = cook.photos.length > 0;
  $('#orderBtn').textContent = t('cookPage.order');
  $('#orderTitle').textContent = t('cookPage.orderTitle', { name: cook.name });
  renderRate();
}

function renderRate() {
  const mine = myCooks.get(cook.id);
  if (!mine?.reviewToken) {
    $('#rateStars').innerHTML = '';
    $('#rateNote').textContent = t('cookPage.rateOnlyAfter');
    return;
  }
  $('#rateNote').textContent = mine.rating ? t('cookPage.rated', { n: mine.rating }) : '';
  starInput($('#rateStars'), {
    value: mine.rating || 0,
    onPick: async (n) => {
      try {
        await api('/api/reviews', { method: 'POST', body: { token: mine.reviewToken, rating: n } });
        myCooks.update(cook.id, { rating: n });
        $('#rateNote').textContent = t('cookPage.rated', { n });
      } catch (err) { $('#rateNote').textContent = errorText(err); }
    },
  });
}

$('#gallery').addEventListener('click', (e) => {
  const b = e.target.closest('[data-i]');
  if (!b) return;
  const p = cook.photos[Number(b.dataset.i)];
  $('#lbImg').src = p.url; $('#lbCap').textContent = p.caption;
  $('#lightbox').showModal();
});
$('#lightbox').addEventListener('click', () => $('#lightbox').close());

$('#likeBtn').addEventListener('click', async () => {
  const like = !cook.likedByMe;
  try {
    const r = await api(`/api/cooks/${cook.id}/like`, { method: 'POST', body: { viewerId: vid, like } });
    cook.likes = r.likes; cook.likedByMe = r.likedByMe;
    $('#likeCount').textContent = t('cookPage.likes', { n: cook.likes });
    $('#likeBtn').setAttribute('aria-pressed', String(cook.likedByMe));
  } catch { /* ignore */ }
});

$('#shareBtn').addEventListener('click', async () => {
  const url = location.origin + location.pathname;
  try {
    if (navigator.share) await navigator.share({ title: cook.name, url });
    else { await navigator.clipboard.writeText(url); $('#shareBtn').textContent = t('cookPage.copied'); }
  } catch { /* cancelled */ }
});

/* ---------- order from her ---------- */
$('#orderBtn').addEventListener('click', () => {
  $('#orderError').hidden = true;
  if (true) {   // menu & optional note for every category
    const s = orderSummary();
    $('#orderLinesBox').hidden = false;
    $('#orderLines').textContent = s.count ? [...s.lines, s.total ? t('cookPage.total', { total: s.total }) : ''].filter(Boolean).join('\n') : t('cookPage.contactNoItems');
    $('#orderText').placeholder = t('cookPage.notePlaceholder');
  }
  $('#orderSheet').showModal();
});
$('#orderGps').addEventListener('click', async () => {
  const st = $('#orderGpsStatus');
  st.classList.remove('bad');
  st.textContent = t('location.locating');
  try {
    orderPos = await getPosition({ precise: true, maxWaitMs: 8000, goodEnough: 50 });
    const { area } = await api(`/api/areas/nearest?lat=${orderPos.lat}&lng=${orderPos.lng}`);
    st.textContent = t('location.gpsDone', { area: area?.name || '' });
    $('#orderGps').textContent = t('join.gpsAgain');
  } catch (gpsErr) { orderPos = null; explainGpsError(st, gpsErr, () => $('#orderGps').click()); }
});
$('#orderForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('#orderError');
  err.hidden = true;
  const text = $('#orderText').value.trim();
  const isRest = true;   // the order text is optional for everyone
  if (!orderPos) { err.textContent = t('errors.location_required'); err.hidden = false; return; }
  const btn = $('#orderSend');
  btn.disabled = true;
  try {
    const items = isRest ? [...cart].map(([id, qty]) => ({ id, qty })) : undefined;
    const { requestId } = await api(`/api/cooks/${cook.id}/request`, { method: 'POST', body: { text, items, lat: orderPos.lat, lng: orderPos.lng, accuracy: orderPos.accuracy, startedAt, website: '' } });
    const r = await api('/api/contact', { method: 'POST', body: { requestId, cookId: cook.id } });
    myCooks.remember({ id: cook.id, name: cook.name, reviewToken: r.reviewToken });
    // "come to me": the customer's location is added to the WhatsApp message
    const come = sessionStorage.getItem('st_come');
    if (come) {
      try {
        const u = new URL(r.whatsappUrl);
        u.searchParams.set('text', `${u.searchParams.get('text') || ''}\n📍 ${t('act.myLocation')}: ${come}`);
        r.whatsappUrl = u.toString();
      } catch { /* keep the message without the location */ }
      sessionStorage.removeItem('st_come');
    }
    const goAfter = sessionStorage.getItem('st_go_after');
    if (goAfter) showGoNow(goAfter);   // "order then go": directions start when the customer comes back from WhatsApp
    window.location.href = r.whatsappUrl;
  } catch (ex) { err.textContent = errorText(ex); err.hidden = false; }
  finally { btn.disabled = false; }
});

/* ---------- restaurant menu: choose dishes & quantities (optional) ---------- */
const cart = new Map(); // item id → qty
const money = (v, cur) => fmtMoney(v, cur);
function renderMenu() {
  const items = cook.menu || [];
  $('#menuBlock').hidden = !items.length;
  $('#menuList').innerHTML = items.map((it) => `
    <li class="menu-item">
      <span><b>${esc(it.name)}</b>${it.description ? `<small>${esc(it.description)}</small>` : ''}
        ${it.price != null ? `<span class="price">${esc(money(it.price, it.currency))}</span>` : ''}</span>
      <span class="qty"><button type="button" data-dec="${it.id}" aria-label="−">−</button><output>${cart.get(it.id) || 0}</output><button type="button" data-inc="${it.id}" aria-label="+">+</button></span>
    </li>`).join('');
  renderOrderBar();
}
function orderSummary() {
  const lines = []; const totals = new Map();
  for (const it of cook.menu || []) {
    const q = cart.get(it.id) || 0;
    if (!q) continue;
    lines.push(`${q} × ${it.name}${it.price != null ? ` — ${money(it.price * q, it.currency)}` : ''}`);
    if (it.price != null) totals.set(it.currency || 'USD', (totals.get(it.currency || 'USD') || 0) + it.price * q);
  }
  const total = [...totals].map(([c, v]) => money(Math.round(v * 100) / 100, c)).join(' + ');
  return { lines, total, count: [...cart.values()].reduce((a, b) => a + b, 0) };
}
function renderOrderBar() {
  const s = orderSummary();
  $('#orderBar').hidden = !s.count;
  $('#orderBar').textContent = s.count ? `${t('cookPage.selected', { n: s.count })}${s.total ? ' · ' + t('cookPage.total', { total: s.total }) : ''}` : '';
}
$('#menuList').addEventListener('click', (e) => {
  const inc = e.target.closest('[data-inc]'); const dec = e.target.closest('[data-dec]');
  if (!inc && !dec) return;
  const id = Number((inc || dec).dataset.inc || (inc || dec).dataset.dec);
  const q = Math.max(0, Math.min(99, (cart.get(id) || 0) + (inc ? 1 : -1)));
  if (q) cart.set(id, q); else cart.delete(id);
  (inc || dec).parentElement.querySelector('output').textContent = q;
  renderOrderBar();
});

/* ---------- complaint / note → admin only ---------- */
$('#feedbackBtn').addEventListener('click', () => { $('#fbError').hidden = true; $('#feedbackSheet').showModal(); });
$('#feedbackForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    await api('/api/feedback', {
      method: 'POST',
      body: { cookId: cook.id, kind: f.kind.value, message: f.message.value, name: f.name.value, phone: f.phone.value, website: f.website.value, startedAt },
    });
    f.innerHTML = `<div class="sheet-head"><h2 class="title">${esc(t('cookPage.feedbackTitle'))}</h2><button class="btn-text" type="button" data-close>${esc(t('common.close'))}</button></div>
      <div class="alert ok">${esc(t('cookPage.sent'))}</div>`;
  } catch (ex) {
    const fields = Object.values(ex.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    $('#fbError').textContent = fields || errorText(ex);
    $('#fbError').hidden = false;
  }
});

/** After "order then go": when the customer returns from WhatsApp, open the directions (once), with a button as a backup. */
function showGoNow(url) {
  const bar = document.createElement('div');
  bar.className = 'go-now';
  bar.innerHTML = `<a class="btn btn-gold" href="${esc(url)}" target="_blank" rel="noopener">🧭 ${esc(t('act.goNow'))}</a>`;
  document.body.appendChild(bar);
  const go = () => {
    if (document.visibilityState !== 'visible' || !sessionStorage.getItem('st_go_after')) return;
    sessionStorage.removeItem('st_go_after');
    window.location.href = url;
  };
  document.addEventListener('visibilitychange', go);
  window.addEventListener('pageshow', go);
}

(async function boot() {
  await initI18n();
  initMenu();
  try {
    const here = lastLocation();   // the customer's current position (same one the list used)
    cook = await api(`/api/cooks/${cookId}?viewerId=${encodeURIComponent(vid)}${here ? `&lat=${here.lat}&lng=${here.lng}` : ''}`);
  } catch {
    $('#notAvailable').hidden = false;
    return;
  }
  $('#profile').hidden = false;
  await render();   // the choices need the (cached) site config
  api(`/api/cooks/${cook.id}/view`, { method: 'POST', body: { viewerId: vid } }).catch(() => {});
})();

