import { initI18n, t, api, errorText, esc } from './i18n.js';
import { $, avatarHtml, starsHtml, starInput, viewerId, myCooks, getPosition } from './ui.js';

const cookId = Number(location.pathname.split('/')[2]);
const vid = viewerId();
const startedAt = Date.now();
let cook = null, orderPos = null;

const close = (d) => d.close();
document.querySelectorAll('dialog').forEach((d) => {
  d.addEventListener('click', (e) => { if (e.target === d || e.target.closest('[data-close]')) close(d); });
});

function render() {
  document.title = `${cook.name} — ${t('brand.name')}`;
  $('#cover').innerHTML = cook.photos[0] ? `<img src="${esc(cook.photos[0].url)}" alt="">` : '';
  $('#avatarSlot').innerHTML = avatarHtml(cook);
  $('#cookName').textContent = cook.name;
  $('#cookArea').textContent = cook.area || '';
  $('#ratingSlot').innerHTML = cook.rating.count
    ? `${starsHtml(cook.rating, { size: 'lg' })}`
    : `<span class="stars-new">${esc(t('cookPage.noRating'))}</span>`;
  $('#likeCount').textContent = t('cookPage.likes', { n: cook.likes });
  $('#likeBtn').setAttribute('aria-pressed', String(!!cook.likedByMe));
  $('#cookBio').textContent = cook.bio;
  $('#cookBio').hidden = !cook.bio;
  $('#services').innerHTML = cook.services.map((s) => `<span class="chip"><span>${esc(t(`services.${s}`))}</span></span>`).join('');
  $('#serves').textContent = cook.servedAreas.map((a) => a.name).join('، ');
  $('#gallery').innerHTML = cook.photos.map((p, i) => `
    <figure><button type="button" data-i="${i}"><img src="${esc(p.url)}" alt="${esc(p.caption)}" loading="lazy"></button>${p.caption ? `<figcaption>${esc(p.caption)}</figcaption>` : ''}</figure>`).join('');
  $('#noPhotos').hidden = cook.photos.length > 0;
  $('#orderBtn').textContent = t('cookPage.order');
  $('#orderTitle').textContent = t('cookPage.orderTitle', { name: cook.name });
  renderRate();
}

function renderRate() {
  const mine = myCooks.get(cook.id);
  if (!mine?.reviewToken) {
    $('#rateStars').innerHTML = '';
    $('#rateNote').textContent = t('cookPage.rateOnlyAfter');
    return;
  }
  $('#rateNote').textContent = mine.rating ? t('cookPage.rated', { n: mine.rating }) : '';
  starInput($('#rateStars'), {
    value: mine.rating || 0,
    onPick: async (n) => {
      try {
        await api('/api/reviews', { method: 'POST', body: { token: mine.reviewToken, rating: n } });
        myCooks.update(cook.id, { rating: n });
        $('#rateNote').textContent = t('cookPage.rated', { n });
      } catch (err) { $('#rateNote').textContent = errorText(err); }
    },
  });
}

$('#gallery').addEventListener('click', (e) => {
  const b = e.target.closest('[data-i]');
  if (!b) return;
  const p = cook.photos[Number(b.dataset.i)];
  $('#lbImg').src = p.url; $('#lbCap').textContent = p.caption;
  $('#lightbox').showModal();
});
$('#lightbox').addEventListener('click', () => $('#lightbox').close());

$('#likeBtn').addEventListener('click', async () => {
  const like = !cook.likedByMe;
  try {
    const r = await api(`/api/cooks/${cook.id}/like`, { method: 'POST', body: { viewerId: vid, like } });
    cook.likes = r.likes; cook.likedByMe = r.likedByMe;
    $('#likeCount').textContent = t('cookPage.likes', { n: cook.likes });
    $('#likeBtn').setAttribute('aria-pressed', String(cook.likedByMe));
  } catch { /* ignore */ }
});

$('#shareBtn').addEventListener('click', async () => {
  const url = location.origin + location.pathname;
  try {
    if (navigator.share) await navigator.share({ title: cook.name, url });
    else { await navigator.clipboard.writeText(url); $('#shareBtn').textContent = t('cookPage.copied'); }
  } catch { /* cancelled */ }
});

/* ---------- order from her ---------- */
$('#orderBtn').addEventListener('click', () => { $('#orderError').hidden = true; $('#orderSheet').showModal(); $('#orderText').focus(); });
$('#orderGps').addEventListener('click', async () => {
  const st = $('#orderGpsStatus');
  st.classList.remove('bad');
  st.textContent = t('location.locating');
  try {
    orderPos = await getPosition();
    const { area } = await api(`/api/areas/nearest?lat=${orderPos.lat}&lng=${orderPos.lng}`);
    st.textContent = t('location.gpsDone', { area: area?.name || '' });
    $('#orderGps').textContent = t('join.gpsAgain');
  } catch { orderPos = null; st.classList.add('bad'); st.textContent = t('location.gpsDenied'); }
});
$('#orderForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('#orderError');
  err.hidden = true;
  const text = $('#orderText').value.trim();
  if (text.length < 5) { err.textContent = t(text ? 'errors.too_short' : 'errors.required'); err.hidden = false; return; }
  if (!orderPos) { err.textContent = t('errors.location_required'); err.hidden = false; return; }
  const btn = $('#orderSend');
  btn.disabled = true;
  try {
    const { requestId } = await api(`/api/cooks/${cook.id}/request`, { method: 'POST', body: { text, lat: orderPos.lat, lng: orderPos.lng, startedAt, website: '' } });
    const r = await api('/api/contact', { method: 'POST', body: { requestId, cookId: cook.id } });
    myCooks.remember({ id: cook.id, name: cook.name, reviewToken: r.reviewToken });
    window.location.href = r.whatsappUrl;
  } catch (ex) { err.textContent = errorText(ex); err.hidden = false; }
  finally { btn.disabled = false; }
});

/* ---------- complaint / note → admin only ---------- */
$('#feedbackBtn').addEventListener('click', () => { $('#fbError').hidden = true; $('#feedbackSheet').showModal(); });
$('#feedbackForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    await api('/api/feedback', {
      method: 'POST',
      body: { cookId: cook.id, kind: f.kind.value, message: f.message.value, name: f.name.value, phone: f.phone.value, website: f.website.value, startedAt },
    });
    f.innerHTML = `<div class="sheet-head"><h2 class="title">${esc(t('cookPage.feedbackTitle'))}</h2><button class="btn-text" type="button" data-close>${esc(t('common.close'))}</button></div>
      <div class="alert ok">${esc(t('cookPage.sent'))}</div>`;
  } catch (ex) {
    const fields = Object.values(ex.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    $('#fbError').textContent = fields || errorText(ex);
    $('#fbError').hidden = false;
  }
});

(async function boot() {
  await initI18n();
  try {
    cook = await api(`/api/cooks/${cookId}?viewerId=${encodeURIComponent(vid)}`);
  } catch {
    $('#notAvailable').hidden = false;
    return;
  }
  $('#profile').hidden = false;
  render();
  api(`/api/cooks/${cook.id}/view`, { method: 'POST', body: { viewerId: vid } }).catch(() => {});
})();
