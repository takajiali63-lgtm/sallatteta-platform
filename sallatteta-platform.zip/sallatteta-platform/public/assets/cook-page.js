import { initI18n, t, api, errorText, esc, fmtMoney } from './i18n.js?v=432';
import { $, avatarHtml, starsHtml, starInput, viewerId, myCooks, getPosition, initMenu } from './ui.js?v=432';

const cookId = Number(location.pathname.split('/')[2]);
const vid = viewerId();
const startedAt = Date.now();
let cook = null, orderPos = null;

const close = (d) => d.close();
document.querySelectorAll('dialog').forEach((d) => {
  d.addEventListener('click', (e) => { if (e.target === d || e.target.closest('[data-close]')) close(d); });
});

function render() {
  document.title = `${cook.name} — ${t('brand.name')}`;
  $('#cover').innerHTML = cook.photos[0] ? `<img src="${esc(cook.photos[0].url)}" alt="">` : '';
  $('#avatarSlot').innerHTML = avatarHtml(cook);
  $('#cookName').textContent = cook.name;
  $('#cookArea').textContent = cook.area || '';
  $('#ratingSlot').innerHTML = cook.rating.count
    ? `${starsHtml(cook.rating, { size: 'lg' })}`
    : `<span class="stars-new">${esc(t('cookPage.noRating'))}</span>`;
  $('#likeCount').textContent = t('cookPage.likes', { n: cook.likes });
  $('#likeBtn').setAttribute('aria-pressed', String(!!cook.likedByMe));
  $('#cookBio').textContent = cook.bio;
  $('#cookBio').hidden = !cook.bio;
  $('#services').innerHTML = cook.services.map((s) => `<span class="chip"><span>${esc(t(`services.${s}`))}</span></span>`).join('');
  const isRest = cook.kind === 'restaurant';
  $('#servicesBlock').hidden = isRest || !cook.services.length;
  $('#specialtyBlock').hidden = !cook.specialty;
  $('#specialty').textContent = cook.specialty || '';
  if (isRest) $('#cookName').insertAdjacentHTML('beforeend', ` <span class="kind-badge">${esc(t('cookPage.restaurant'))}</span>`);
  renderMenu();
  $('#serves').textContent = cook.servedAreas.map((a) => a.name).join('، ');
  $('#gallery').innerHTML = cook.photos.map((p, i) => `
    <figure><button type="button" data-i="${i}"><img src="${esc(p.url)}" alt="${esc(p.caption)}" loading="lazy"></button>${p.caption ? `<figcaption>${esc(p.caption)}</figcaption>` : ''}</figure>`).join('');
  $('#noPhotos').hidden = cook.photos.length > 0;
  $('#orderBtn').textContent = t('cookPage.order');
  $('#orderTitle').textContent = t('cookPage.orderTitle', { name: cook.name });
  renderRate();
}

function renderRate() {
  const mine = myCooks.get(cook.id);
  if (!mine?.reviewToken) {
    $('#rateStars').innerHTML = '';
    $('#rateNote').textContent = t('cookPage.rateOnlyAfter');
    return;
  }
  $('#rateNote').textContent = mine.rating ? t('cookPage.rated', { n: mine.rating }) : '';
  starInput($('#rateStars'), {
    value: mine.rating || 0,
    onPick: async (n) => {
      try {
        await api('/api/reviews', { method: 'POST', body: { token: mine.reviewToken, rating: n } });
        myCooks.update(cook.id, { rating: n });
        $('#rateNote').textContent = t('cookPage.rated', { n });
      } catch (err) { $('#rateNote').textContent = errorText(err); }
    },
  });
}

$('#gallery').addEventListener('click', (e) => {
  const b = e.target.closest('[data-i]');
  if (!b) return;
  const p = cook.photos[Number(b.dataset.i)];
  $('#lbImg').src = p.url; $('#lbCap').textContent = p.caption;
  $('#lightbox').showModal();
});
$('#lightbox').addEventListener('click', () => $('#lightbox').close());

$('#likeBtn').addEventListener('click', async () => {
  const like = !cook.likedByMe;
  try {
    const r = await api(`/api/cooks/${cook.id}/like`, { method: 'POST', body: { viewerId: vid, like } });
    cook.likes = r.likes; cook.likedByMe = r.likedByMe;
    $('#likeCount').textContent = t('cookPage.likes', { n: cook.likes });
    $('#likeBtn').setAttribute('aria-pressed', String(cook.likedByMe));
  } catch { /* ignore */ }
});

$('#shareBtn').addEventListener('click', async () => {
  const url = location.origin + location.pathname;
  try {
    if (navigator.share) await navigator.share({ title: cook.name, url });
    else { await navigator.clipboard.writeText(url); $('#shareBtn').textContent = t('cookPage.copied'); }
  } catch { /* cancelled */ }
});

/* ---------- order from her ---------- */
$('#orderBtn').addEventListener('click', () => {
  $('#orderError').hidden = true;
  if (cook.kind === 'restaurant') {
    const s = orderSummary();
    $('#orderLinesBox').hidden = false;
    $('#orderLines').textContent = s.count ? [...s.lines, s.total ? t('cookPage.total', { total: s.total }) : ''].filter(Boolean).join('\n') : t('cookPage.contactNoItems');
    $('#orderText').placeholder = t('cookPage.notePlaceholder');
  }
  $('#orderSheet').showModal();
});
$('#orderGps').addEventListener('click', async () => {
  const st = $('#orderGpsStatus');
  st.classList.remove('bad');
  st.textContent = t('location.locating');
  try {
    orderPos = await getPosition({ precise: true, maxWaitMs: 8000, goodEnough: 50 });
    const { area } = await api(`/api/areas/nearest?lat=${orderPos.lat}&lng=${orderPos.lng}`);
    st.textContent = t('location.gpsDone', { area: area?.name || '' });
    $('#orderGps').textContent = t('join.gpsAgain');
  } catch { orderPos = null; st.classList.add('bad'); st.textContent = t('location.gpsDenied'); }
});
$('#orderForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('#orderError');
  err.hidden = true;
  const text = $('#orderText').value.trim();
  const isRest = cook.kind === 'restaurant';
  if (!isRest && text.length < 5) { err.textContent = t(text ? 'errors.too_short' : 'errors.required'); err.hidden = false; return; }
  if (!orderPos) { err.textContent = t('errors.location_required'); err.hidden = false; return; }
  const btn = $('#orderSend');
  btn.disabled = true;
  try {
    const items = isRest ? [...cart].map(([id, qty]) => ({ id, qty })) : undefined;
    const { requestId } = await api(`/api/cooks/${cook.id}/request`, { method: 'POST', body: { text, items, lat: orderPos.lat, lng: orderPos.lng, startedAt, website: '' } });
    const r = await api('/api/contact', { method: 'POST', body: { requestId, cookId: cook.id } });
    myCooks.remember({ id: cook.id, name: cook.name, reviewToken: r.reviewToken });
    window.location.href = r.whatsappUrl;
  } catch (ex) { err.textContent = errorText(ex); err.hidden = false; }
  finally { btn.disabled = false; }
});

/* ---------- restaurant menu: choose dishes & quantities (optional) ---------- */
const cart = new Map(); // item id → qty
const money = (v, cur) => fmtMoney(v, cur);
function renderMenu() {
  const items = cook.menu || [];
  $('#menuBlock').hidden = cook.kind !== 'restaurant' || !items.length;
  $('#menuList').innerHTML = items.map((it) => `
    <li class="menu-item">
      <span><b>${esc(it.name)}</b>${it.description ? `<small>${esc(it.description)}</small>` : ''}
        ${it.price != null ? `<span class="price">${esc(money(it.price, it.currency))}</span>` : ''}</span>
      <span class="qty"><button type="button" data-dec="${it.id}" aria-label="−">−</button><output>${cart.get(it.id) || 0}</output><button type="button" data-inc="${it.id}" aria-label="+">+</button></span>
    </li>`).join('');
  renderOrderBar();
}
function orderSummary() {
  const lines = []; const totals = new Map();
  for (const it of cook.menu || []) {
    const q = cart.get(it.id) || 0;
    if (!q) continue;
    lines.push(`${q} × ${it.name}${it.price != null ? ` — ${money(it.price * q, it.currency)}` : ''}`);
    if (it.price != null) totals.set(it.currency || 'USD', (totals.get(it.currency || 'USD') || 0) + it.price * q);
  }
  const total = [...totals].map(([c, v]) => money(Math.round(v * 100) / 100, c)).join(' + ');
  return { lines, total, count: [...cart.values()].reduce((a, b) => a + b, 0) };
}
function renderOrderBar() {
  const s = orderSummary();
  $('#orderBar').hidden = !s.count;
  $('#orderBar').textContent = s.count ? `${t('cookPage.selected', { n: s.count })}${s.total ? ' · ' + t('cookPage.total', { total: s.total }) : ''}` : '';
}
$('#menuList').addEventListener('click', (e) => {
  const inc = e.target.closest('[data-inc]'); const dec = e.target.closest('[data-dec]');
  if (!inc && !dec) return;
  const id = Number((inc || dec).dataset.inc || (inc || dec).dataset.dec);
  const q = Math.max(0, Math.min(99, (cart.get(id) || 0) + (inc ? 1 : -1)));
  if (q) cart.set(id, q); else cart.delete(id);
  (inc || dec).parentElement.querySelector('output').textContent = q;
  renderOrderBar();
});

/* ---------- complaint / note → admin only ---------- */
$('#feedbackBtn').addEventListener('click', () => { $('#fbError').hidden = true; $('#feedbackSheet').showModal(); });
$('#feedbackForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    await api('/api/feedback', {
      method: 'POST',
      body: { cookId: cook.id, kind: f.kind.value, message: f.message.value, name: f.name.value, phone: f.phone.value, website: f.website.value, startedAt },
    });
    f.innerHTML = `<div class="sheet-head"><h2 class="title">${esc(t('cookPage.feedbackTitle'))}</h2><button class="btn-text" type="button" data-close>${esc(t('common.close'))}</button></div>
      <div class="alert ok">${esc(t('cookPage.sent'))}</div>`;
  } catch (ex) {
    const fields = Object.values(ex.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    $('#fbError').textContent = fields || errorText(ex);
    $('#fbError').hidden = false;
  }
});

(async function boot() {
  await initI18n();
  initMenu();
  try {
    cook = await api(`/api/cooks/${cookId}?viewerId=${encodeURIComponent(vid)}`);
  } catch {
    $('#notAvailable').hidden = false;
    return;
  }
  $('#profile').hidden = false;
  render();
  api(`/api/cooks/${cook.id}/view`, { method: 'POST', body: { viewerId: vid } }).catch(() => {});
})();
