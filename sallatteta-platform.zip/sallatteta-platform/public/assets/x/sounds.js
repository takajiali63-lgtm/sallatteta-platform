// App sound effects (customer / store / driver). The owner manages them in the admin «مدير الأصوات»; this module
// fetches the per-role config, listens to akBus and plays short sounds — politely:
//  • never before the person touched the page (browser autoplay rules), never louder than the device / silent switch;
//  • one sound at a time, critical alerts interrupt minor ones, the same event at most once per 1.5 s;
//  • missing or broken files stay silent (console.debug only, no error toasts);
//  • the person can mute interface sounds, or everything (then even critical alerts are silent).
import { t, esc, akBus, toast } from './core.js';
import { canAutoplay, throttleOk, decide, allowedByUser, preloadNames, parseConfig, resolve, isCritical } from './sounds-core.js';

const LS_CFG = (role) => `ak_sounds_cfg_${role}`;
const LS_UI = 'ak_sounds_muted';        // '1' = interface sounds off, '0' = explicitly on (even with reduced motion)
const LS_ALL = 'ak_sounds_muted_all';   // '1' = every sound off, critical alerts included
const REFRESH_MS = 5 * 60_000;

const S = { role: null, cfg: null, gesture: false, last: {}, current: null, audios: new Map(), broken: new Set(), fetchedAt: 0, listening: false };
const dbg = (...a) => { try { console.debug('[sounds]', ...a); } catch { /* ignore */ } };
const ls = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch { /* private mode */ } },
};
const reducedMotion = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };
const prefs = () => ({ all: ls.get(LS_ALL), ui: ls.get(LS_UI), reducedMotion: reducedMotion() });

function audioFor(url, preload) {
  let a = S.audios.get(url);
  if (!a) {
    a = new Audio();
    a.preload = preload ? 'auto' : 'none';
    a.addEventListener('error', () => { S.broken.add(url); dbg('cannot load', url); });
    a.src = url;
    S.audios.set(url, a);
  }
  return a;
}

function preload() {
  if (!S.cfg?.enabled) return;
  for (const n of preloadNames(S.cfg.events)) audioFor(S.cfg.events[n].url, true);
}

async function fetchConfig() {
  S.fetchedAt = Date.now();
  try {
    // the server answers 304 when nothing changed (ETag); offline the saved copy below keeps working
    const r = await fetch(`/api/sounds/config?role=${encodeURIComponent(S.role)}`, { credentials: 'same-origin' });
    if (!r.ok) return dbg('config', r.status);
    const cfg = parseConfig(await r.json());
    if (!cfg) return dbg('config: bad shape');
    if (!S.cfg || S.cfg.version !== cfg.version) {
      S.cfg = cfg;
      ls.set(LS_CFG(S.role), JSON.stringify(cfg));
      preload();
    }
  } catch (e) { dbg('config offline', e?.message); }
}

/** Plays the sound mapped to an event name (as emitted on akBus). Safe to call anytime; returns true if it started. */
export function playSound(name) {
  const e = resolve(S.cfg, name);
  // the sound system "owns" this event (played, or silenced on purpose by the owner / the user): the screens then skip
  // their old built-in beep. Unmapped events (or no config yet) leave the old beep as the fallback.
  if (S.cfg && e.skip !== 'unmapped') window.akSoundHandled = Date.now();
  if (e.skip) { if (e.skip !== 'unmapped') dbg(name, e.skip); return false; }
  if (!allowedByUser(e.priority, prefs())) return false;
  const hasBeenActive = !!(typeof navigator !== 'undefined' && navigator.userActivation?.hasBeenActive);
  if (!canAutoplay({ hasBeenActive, gestureSeen: S.gesture })) { dbg(name, 'waiting for a first tap'); return false; }
  if (S.broken.has(e.url)) return false;
  const action = decide(S.current, e.priority);
  if (action === 'skip') return false;
  if (!throttleOk(S.last, name, Date.now())) return false;
  if (action === 'interrupt' && S.current?.audio) { try { S.current.audio.pause(); S.current.audio.currentTime = 0; } catch { /* ignore */ } }
  const audio = audioFor(e.url, isCritical(e.priority));
  const cur = { audio, priority: e.priority, playing: true, name };
  S.current = cur;
  const done = () => { if (S.current === cur) cur.playing = false; };
  audio.onended = done; audio.onpause = done;
  try {
    audio.volume = e.volume;      // relative to the device volume; the OS / silent switch always has the last word
    audio.currentTime = 0;
    const p = audio.play();
    if (p?.catch) p.catch((err) => { done(); dbg(name, 'play refused', err?.name); });
  } catch (err) { done(); dbg(name, 'play failed', err?.message); return false; }
  return true;
}

/** Call once per page with 'customer' | 'store' | 'driver'. Uses the saved config at once, then refreshes it. */
export async function initSounds(role) {
  if (!['customer', 'store', 'driver'].includes(role)) return;
  S.role = role;
  S.cfg = parseConfig(ls.get(LS_CFG(role)));
  // iOS 17+/Safari: "ambient" mixes with music and obeys the silent switch (never bypass the device mute).
  try { if (navigator.audioSession) navigator.audioSession.type = 'ambient'; } catch { /* unsupported */ }
  if (!S.listening) {
    S.listening = true;
    const mark = () => { S.gesture = true; };
    addEventListener('pointerdown', mark, { capture: true, once: true, passive: true });
    addEventListener('keydown', mark, { capture: true, once: true, passive: true });
    akBus.addEventListener('ak:event', (ev) => { const n = ev?.detail?.name; if (typeof n === 'string') playSound(n); });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && Date.now() - S.fetchedAt > REFRESH_MS) fetchConfig();
    });
  }
  preload();
  await fetchConfig();
}

// Texts fall back to Arabic if the translation patch is not loaded yet.
const FALLBACK = {
  'sounds.title': 'الأصوات', 'sounds.ui': 'أصوات الواجهة', 'sounds.uiHint': 'نقرات خفيفة عند الإضافة إلى السلة والتأكيد والرسائل.',
  'sounds.all': 'كل الأصوات', 'sounds.allHint': 'عند الإيقاف تصمت حتى التنبيهات المهمة مثل الطلبات الجديدة.',
  'sounds.test': 'تجربة الصوت', 'sounds.device': 'يتبع صوت الهاتف ووضع الصامت دائماً.',
  'sounds.reduced': 'هاتفك يطلب تقليل الحركة، لذلك أصوات الواجهة مطفأة إلى أن تشغّلها.',
  'sounds.off': 'أوقفت الإدارة المؤثرات الصوتية حالياً.',
};
const tx = (k) => { const v = t(k); return v && v !== k ? v : FALLBACK[k] || k; };

/** Draws the person's sound preferences (two switches + a test button) into `el`. */
export function renderSoundSettings(el, role = S.role) {
  if (!el) return;
  if (role && role !== S.role) initSounds(role);
  const draw = () => {
    const p = prefs();
    const allOn = p.all !== '1';
    const uiOn = allOn && allowedByUser('normal', p);
    el.innerHTML = `<div class="snd-set"><h3>🔊 ${esc(tx('sounds.title'))}</h3>
      <div class="toggle"><div><b>${esc(tx('sounds.all'))}</b><div class="mute small">${esc(tx('sounds.allHint'))}</div></div>
        <button class="sw${allOn ? ' on' : ''}" data-snd="all" role="switch" aria-checked="${allOn}" aria-label="${esc(tx('sounds.all'))}"></button></div>
      <div class="toggle${allOn ? '' : ' snd-dim'}"><div><b>${esc(tx('sounds.ui'))}</b><div class="mute small">${esc(tx('sounds.uiHint'))}</div></div>
        <button class="sw${uiOn ? ' on' : ''}" data-snd="ui" role="switch" aria-checked="${uiOn}" aria-label="${esc(tx('sounds.ui'))}"${allOn ? '' : ' disabled'}></button></div>
      ${p.reducedMotion && p.ui === null && allOn ? `<div class="note">${esc(tx('sounds.reduced'))}</div>` : ''}
      ${S.cfg && !S.cfg.enabled ? `<div class="note">${esc(tx('sounds.off'))}</div>` : ''}
      <div class="snd-row"><button class="btn sm alt" data-snd="test">▶ ${esc(tx('sounds.test'))}</button><span class="mute small">${esc(tx('sounds.device'))}</span></div></div>`;
    el.querySelector('[data-snd="all"]').onclick = () => { ls.set(LS_ALL, allOn ? '1' : null); draw(); };
    el.querySelector('[data-snd="ui"]').onclick = () => { ls.set(LS_UI, uiOn ? '1' : '0'); draw(); };
    el.querySelector('[data-snd="test"]').onclick = () => {
      S.gesture = true;   // this click is the gesture
      // test the most relevant sound the person will hear: a UI sound if allowed, else the role's critical alert
      const order = ['success', 'cart_add', 'store_new_order', 'driver_new_request', 'new_message'];
      const n = order.find((x) => S.cfg?.events[x] && allowedByUser(S.cfg.events[x].priority, prefs()));
      if (n) delete S.last[n];   // a test tap is never throttled
      if (!n || !playSound(n)) toast(tx('sounds.noneToPlay'));   // say so, instead of a silent button
    };
  };
  draw();
}

/** For tests / logout: stops whatever plays. */
export function stopSounds() { try { S.current?.audio?.pause(); } catch { /* ignore */ } if (S.current) S.current.playing = false; }
