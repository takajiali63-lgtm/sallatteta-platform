// v8 money between drivers and stores (shared by the store and driver screens).
// The platform never holds the money: each order the driver collected cash for becomes an INVOICE (goods only — his
// delivery fee is shown apart and stays his). A payment is confirmed only when the driver says «I paid X» AND the store
// says «I received X» (the same amount). Everything is computed by the server; the screens only show it.
import { t, esc, $, $$, api, errText, toast, sheet, money, fmtTime, emit } from './core.js';

const T = (k, v) => t(`fin.${k}`, v);
const chip = (st) => `<span class="chip ${st === 'settled' ? 'g' : st === 'partial' ? 'a' : st === 'reversed' ? '' : 'w'}">${esc(T(`st_${st}`))}</span>`;
const newKey = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

/** One invoice card (goods and delivery fee kept apart). */
function invoiceRow(i, role) {
  const who = role === 'store' ? `🛵 ${esc(i.driver)}` : `🏪 ${esc(i.store)}`;
  return `<div class="card inv-card"><div class="row"><b>${esc(i.ref)} · ${esc(i.orderRef)}</b>${chip(i.status)}</div>
    <p class="small">${who} · ${esc(fmtTime(i.date))}${i.exception ? ` · <span class="chip a">${esc(T('exception'))}</span>` : ''}</p>
    <div class="inv-lines">
      <div class="row"><span>${esc(T('goods'))}</span><b>${esc(money(i.goods))}</b></div>
      <div class="row mute"><span>${esc(T('fee'))}</span><span>${esc(money(i.deliveryFee))}</span></div>
      <div class="row mute"><span>${esc(T('collected'))}</span><span>${esc(money(i.collected))}</span></div>
      ${i.paid ? `<div class="row"><span>${esc(T('paid'))}</span><span>${esc(money(i.paid))}</span></div>` : ''}
      ${i.status !== 'settled' && i.status !== 'reversed' ? `<div class="row"><span>${esc(T('remaining'))}</span><b>${esc(money(i.remaining))}</b></div>` : ''}
    </div>
    ${role === 'store' && i.status !== 'settled' && i.status !== 'reversed' ? `<button class="btn sm alt" data-fcomp="${i.id}">⚖️ ${esc(T('complain'))}</button>` : ''}</div>`;
}

/** Pending / under-review payments between the two sides. */
function paymentsHtml(list, role) {
  if (!list?.length) return '';
  return `<h3>⏳ ${esc(T('waiting'))}</h3>${list.map((p) => `<div class="card ${p.status === 'review' ? 'warnc' : 'hl'}">
    <div class="row"><b>${esc(p.ref)}</b><span class="chip ${p.status === 'review' ? 'b' : 'w'}">${esc(T(`p_${p.status}`))}</span></div>
    <p class="small">${role === 'store' ? `🛵 ${esc(p.driver)}` : `🏪 ${esc(p.store)}`}${p.kind === 'admin' ? ` · ${esc(T('byAdmin'))}` : ''}</p>
    ${p.driverSays != null ? `<p class="small">🛵 ${esc(T('driverSays', { t: money(p.driverSays) }))}</p>` : ''}
    ${p.storeSays != null ? `<p class="small">🏪 ${esc(T('storeSays', { t: money(p.storeSays) }))}</p>` : ''}
    ${p.status === 'review' ? `<p class="note small">${esc(T('reviewNote'))}</p>` : ''}</div>`).join('')}`;
}

/** The invoices sheet: open (to pay) / archive (paid), with the pending payments on top. */
export async function invoicesSheet(role, { driverId = null, title = '' } = {}) {
  const base = role === 'store' ? '/api/store/invoices' : '/api/driver/invoices';
  const sh = sheet(`<h2>🧾 ${esc(title || T('title'))}</h2><div class="tabs"><button data-st="open" class="on">${esc(T('open'))}</button><button data-st="archive">${esc(T('archive'))}</button></div><div id="invBox"><div class="skel cover"></div></div><button class="btn alt" data-close>${esc(t('common.close'))}</button>`);
  const load = async (state) => {
    $$('[data-st]', sh.el).forEach((b) => b.classList.toggle('on', b.dataset.st === state));
    const box = $('#invBox', sh.el);
    try {
      const r = await api('GET', `${base}?state=${state}${driverId ? `&driverId=${driverId}` : ''}`);
      const total = r.invoices.reduce((a, i) => a + (state === 'open' ? i.remaining : i.goods), 0);
      box.innerHTML = `${state === 'open' ? paymentsHtml(r.payments, role) : ''}
        <div class="stat"><b>${esc(money(Math.round(total * 100) / 100))}</b><span>${esc(state === 'open' ? T('totalOpen') : T('totalArchive'))}</span></div>
        ${r.invoices.map((i) => invoiceRow(i, role)).join('') || `<div class="empty">${esc(T(state === 'open' ? 'noneOpen' : 'noneArchive'))}</div>`}`;
      $$('[data-fcomp]', box).forEach((b) => { b.onclick = () => complaintSheet(Number(b.dataset.fcomp), () => load(state)); });
    } catch (e) { box.innerHTML = `<div class="empty">${esc(errText(e))}</div>`; }
  };
  $$('[data-st]', sh.el).forEach((b) => { b.onclick = () => load(b.dataset.st); });
  load('open');
  return sh;
}

/** A store complains about a driver for an unpaid invoice (the owner reviews it; it never blocks the driver by itself). */
export function complaintSheet(invoiceId, done) {
  const sh = sheet(`<h2>⚖️ ${esc(T('complain'))}</h2><p class="small mute">${esc(T('complainHint'))}</p><form id="fcf"><textarea class="in" name="body" required minlength="5" maxlength="1000"></textarea><button class="btn">${esc(t('common.send'))}</button></form>`);
  $('#fcf', sh.el).addEventListener('submit', async (e) => {
    e.preventDefault();
    try { const r = await api('POST', `/api/store/invoices/${invoiceId}/complaint`, { body: e.target.body.value }); sh.close(); toast(T('complaintSent', { ref: r.ref })); done?.(); } catch (x) { toast(errText(x)); }
  });
}

/** Ask the amount (default = all that is owed). Returns a number or null. */
export function askAmount(owed, label) {
  return new Promise((resolve) => {
    const sh = sheet(`<h2>💵 ${esc(label)}</h2><form id="amf"><label class="f">${esc(T('amount'))}<input class="in" name="a" type="number" inputmode="decimal" min="0.01" step="0.01" max="${owed}" value="${owed}" required></label>
      <p class="mute small">${esc(T('partialHint', { t: money(owed) }))}</p><button class="btn">${esc(t('common.confirm'))}</button></form>`, { onClose: () => resolve(null) });
    $('#amf', sh.el).addEventListener('submit', (e) => {
      e.preventDefault();
      const v = Math.round(Number(e.target.a.value) * 100) / 100;
      if (!(v > 0) || v > owed + 0.001) return toast(T('amountInvalid'));
      resolve(v); sh.close();
    });
  });
}

/** Show the result of «I paid» / «I received» in words. */
export function paymentResult(r) {
  if (r.status === 'confirmed') { toast(T('r_confirmed', { t: money(r.amount) })); emit('payment_success', { source: 'dues' }); }
  else if (r.status === 'review') { toast(T('r_review')); emit('warning', { source: 'dues' }); }
  else toast(T('r_pending', { t: money(r.amount) }));
}

/** Pay / receive with an idempotency key, so a double tap or a retry after a bad connection counts once. */
export async function sendPayment(url, body) {
  const idem = newKey();
  for (let i = 0; i < 3; i += 1) {
    try { return await api('POST', url, { ...body, idem }); } catch (e) {
      if (e.status || i === 2) throw e;   // a real answer from the server: stop; a network error: try again with the same key
      await new Promise((r) => setTimeout(r, 800 * (i + 1)));
    }
  }
  return null;
}
