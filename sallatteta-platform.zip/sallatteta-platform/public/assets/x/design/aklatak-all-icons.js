// Aklatak icon system — the emoji used as interface icons become one consistent set of line icons (24px grid,
// 1.8 stroke, currentColor, so they follow every design and both directions). Presentation only: texts, translations
// and click handlers are untouched. Works on anything drawn later too (new stores, sections, buttons): a light
// observer upgrades new nodes. People's own words (chat, notes, names typed in fields) are left as they are.
(() => {
  'use strict';
  const P = {
    home: '<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    heart: '<path d="M20.8 8.5c0 4.5-8.8 10.5-8.8 10.5S3.2 13 3.2 8.5a4.6 4.6 0 0 1 8.8-1.7 4.6 4.6 0 0 1 8.8 1.7z"/>',
    receipt: '<path d="M5 3h14v18l-3-2-4 2-4-2-3 2zM9 8h6M9 12h6M9 16h4"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-8 16-8 16 0"/>',
    location: '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/>',
    palette: '<path d="M12 3a9 9 0 0 0 0 18h2a2 2 0 0 0 2-2c0-2-2-2-2-4a2 2 0 0 1 2-2h2a4 4 0 0 0 4-4c0-4-5-6-10-6z"/><circle cx="7.5" cy="10" r="1"/><circle cx="11" cy="6.8" r="1"/><circle cx="16" cy="8" r="1"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18M12 3c5 5 5 13 0 18"/>',
    shop: '<path d="M4 10 6 3h12l2 7M4 10v11h16V10M9 21v-8h6v8"/><path d="M3 10c0 4 4 4 5 1 1 3 5 3 6 0 1 3 5 3 7-1"/>',
    food: '<path d="M5 3v7m3-7v7M2 3v5c0 3 3 4 4 4v9M18 3c-6 0-6 10 0 10h2V3h-2zm0 10v8"/>',
    cart: '<path d="M2 4h3l3 12h11l3-9H6"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
    coffee: '<path d="M4 7h14v8c0 7-14 7-14 0zM18 9h2c4 0 3 6-2 6M3 22h17"/>',
    medicine: '<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M12 8v9M7.5 12.5h9"/>',
    bike: '<circle cx="5" cy="18" r="3"/><circle cx="19" cy="18" r="3"/><path d="m5 18 5-9 4 9h5l-5-9h-4M8 6h4"/>',
    truck: '<path d="M2 6h12v12H2zM14 10h4l4 5v3h-8"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/>',
    gift: '<rect x="3" y="10" width="18" height="12" rx="1"/><path d="M2 10h20M12 10v12M12 10c-10 0-9-7-5-7 3 0 5 7 5 7zm0 0c10 0 9-7 5-7-3 0-5 7-5 7z"/>',
    star: '<path d="m12 2 3 7 7 .5-5.5 5 1.8 7.5L12 18l-6.3 4 1.8-7.5L2 9.5 9 9z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M19 5l-2 2M7 17l-2 2"/>',
    chart: '<path d="M4 21V3M4 21h18M8 17v-6M13 17V7M18 17V4"/>',
    wallet: '<rect x="2" y="5" width="20" height="16" rx="3"/><path d="M15 11h7v5h-7a2.5 2.5 0 0 1 0-5z"/>',
    phone: '<path d="M7 3 4 6c-2 5 9 16 14 14l3-3-6-5-3 3-4-4 3-3z"/>',
    note: '<path d="M5 2h14v20H5zM8 8h8M8 12h8M8 16h5"/>',
    lock: '<rect x="4" y="10" width="16" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 10v7M12 6h.01"/>',
    spark: '<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/>',
    back: '<path d="m15 5-7 7 7 7"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
    package: '<path d="m3 7 9-4 9 4v11l-9 4-9-4zM3 7l9 5 9-5M12 12v10"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    hospital: '<rect x="4" y="3" width="16" height="19" rx="2"/><path d="M12 7v8M8 11h8M9 22v-4h6v4"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    hourglass: '<path d="M5 22h14M5 2h14M17 22v-4.2a2 2 0 0 0-.6-1.4L12 12l-4.4 4.4a2 2 0 0 0-.6 1.4V22M7 2v4.2a2 2 0 0 0 .6 1.4L12 12l4.4-4.4a2 2 0 0 0 .6-1.4V2"/>',
    hash: '<path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>',
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    pin: '<path d="M12 17v5M9 10.8V4h6v6.8l2 2.2v2H7v-2z"/>',
    compass: '<circle cx="12" cy="12" r="10"/><path d="m16.2 7.8-2.1 6.3-6.3 2.1 2.1-6.3z"/>',
    zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-4"/>',
    refresh: '<path d="M21 12a9 9 0 0 1-15 6.7L3 16M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M3 21v-5h5"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    dot: '<circle cx="12" cy="12" r="6" fill="currentColor"/>',
    tag: '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
    leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.4 5.1-6"/>',
    megaphone: '<path d="m3 11 18-5v12L3 14v-3zM11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
    up: '<path d="m18 15-6-6-6 6"/>',
    flag: '<path d="M4 22V4M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1"/>',
    scale: '<path d="M12 3v18M7 21h10M3 7h18M6 7l-3 7a3 3 0 0 0 6 0zM18 7l-3 7a3 3 0 0 0 6 0z"/>',
    folder: '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9l-2-3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    eyeoff: '<path d="M9.9 4.2A10 10 0 0 1 12 4c6.5 0 10 8 10 8a17 17 0 0 1-2.2 3.2M6.6 6.6C3.7 8.4 2 12 2 12s3.5 7 10 7a9.7 9.7 0 0 0 5.4-1.6M2 2l20 20M14.1 14.1A3 3 0 0 1 9.9 9.9"/>',
    ban: '<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
    ruler: '<path d="M21.3 15.3 8.7 2.7a1 1 0 0 0-1.4 0L2.7 7.3a1 1 0 0 0 0 1.4l12.6 12.6a1 1 0 0 0 1.4 0l4.6-4.6a1 1 0 0 0 0-1.4zM7.5 10.5l2-2M10.5 13.5l2-2M13.5 16.5l2-2"/>',
    bank: '<path d="M3 22h18M6 18v-7M10 18v-7M14 18v-7M18 18v-7M12 2l8 5H4z"/>',
    camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
    printer: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
    target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    signal: '<path d="M4.9 19.1a10 10 0 0 1 0-14.2M7.8 16.2a6 6 0 0 1 0-8.4M16.2 7.8a6 6 0 0 1 0 8.4M19.1 4.9a10 10 0 0 1 0 14.2"/><circle cx="12" cy="12" r="2"/>',
    pen: '<path d="M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    thanks: '<path d="M7 11v8a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1zM7 11l4-8a3 3 0 0 1 3 3v4h5.6a2 2 0 0 1 2 2.3l-1.4 7a2 2 0 0 1-2 1.7H7"/>',
    cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>',
    card: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
    tools: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2M2 13h20M10 13v2h4v-2"/>',
    play: '<path d="M7 4v16l13-8z"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    volume: '<path d="M11 5 6 9H2v6h4l5 4zM15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
    mute: '<path d="M11 5 6 9H2v6h4l5 4zM22 9l-6 6M16 9l6 6"/>',
    mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8"/>',
    send: '<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
    bot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4M8 13h.01M16 13h.01M9 17h6M2 13v3M22 13v3"/><circle cx="12" cy="3" r="1"/>',
    snow: '<path d="M12 2v20M4.9 6l14.2 12M4.9 18 19.1 6M9 4l3 3 3-3M9 20l3-3 3 3"/>',
    save: '<path d="M5 3h11l4 4v14H4V3z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>',
    tv: '<rect x="2" y="6" width="20" height="13" rx="2"/><path d="m8 2 4 4 4-4M7 22h10"/>',
    broom: '<path d="M14 3 9 13M5 13h9l2 8H3z"/><path d="M8 17v4M11 17v4"/>',
    gym: '<path d="M6 7v10M3 9v6M18 7v10M21 9v6M6 12h12"/>',
    car: '<path d="M5 17h14M5 17a2 2 0 1 0 4 0M15 17a2 2 0 1 0 4 0M3 17v-5l2-5h14l2 5v5M3 12h18"/>',
  };
  const MAP = [
    ['home', '🏠🏡🏘'], ['search', '🔍🔎'], ['heart', '❤️♥️🤍💗💖💝💕💓'], ['receipt', '🧾📋📄📃'], ['user', '👤👥🙍👩👨🧑'], ['location', '📍🗺️'],
    ['globe', '🌐🌍🌎🌏'], ['palette', '🎨'], ['shop', '🏪🏬🏢'], ['food', '🍔🍕🍟🍽️🍴🥗🍲🥘🥙🌮🍛🍱🍝🍰🧁🍞🥖🍎🥩🍳🍖🍗🧀🥛'], ['cart', '🛒🛍️🧺'], ['coffee', '☕🍵🧃🥤'],
    ['medicine', '💊💉🩺'], ['bike', '🛵🚲🏍️'], ['truck', '🚚🚛'], ['car', '🚗🚕'], ['gift', '🎁💐🌹'], ['star', '⭐🌟✨'], ['settings', '⚙️🔧🛠️🎛️🎛🔩'], ['tools', '🧰🪚🔨🪛'],
    ['chart', '📊📈📉'], ['cash', '💵💸💰💲'], ['card', '💳'], ['wallet', '👛'], ['phone', '📞☎️📱📲'], ['note', '📝'], ['pen', '✏️✍️'], ['lock', '🔒🔐🔑'],
    ['info', 'ℹ️❓'], ['alert', '⚠️❗'], ['back', '⬅️🔙'], ['check', '✅☑️✔️'], ['package', '📦'], ['hospital', '🏥'], ['calendar', '📅📆🗓️'],
    ['bell', '🔔'], ['plus', '➕'], ['hourglass', '⏳⌛'], ['hash', '🔢'], ['trash', '🗑️🗑'], ['message', '💬🗨️'], ['x', '❌✖️❎'], ['pin', '📌'],
    ['compass', '🧭'], ['zap', '⚡'], ['undo', '↩️'], ['refresh', '🔁🔄'], ['clock', '⏰🕐🕒⏱️'], ['dot', '🟢'], ['tag', '🏷️'], ['link', '🔗'], ['leaf', '🌿'],
    ['megaphone', '📣📢'], ['up', '⬆️'], ['thanks', '🙏👍'], ['flag', '🏁🚩'], ['scale', '⚖️'], ['folder', '🗂️🗂📁📂'], ['eye', '👁️👁👀'], ['ban', '🚫⛔'],
    ['ruler', '📏'], ['bank', '🏛️'], ['eyeoff', '🙈'], ['camera', '📷📸'], ['image', '🖼️🖼'], ['printer', '🖨️🖨'], ['target', '🎯'], ['signal', '📡'],
    ['shield', '🦺🛡️'], ['bot', '🤖'], ['play', '▶️▶'], ['download', '⬇️⬇'], ['volume', '🔊🔉🔈'], ['mute', '🔇'], ['mic', '🎤🎙️'], ['phone', '📞'], ['mail', '✉️📧'], ['menu', '☰'], ['snow', '❄️❄'], ['save', '💾'], ['tv', '📺'], ['broom', '🧹'], ['gym', '🏋️🏋'],
  ];
  const seg = new Intl.Segmenter('en', { granularity: 'grapheme' });
  const ICON = new Map();
  for (const [k, chars] of MAP) for (const s of seg.segment(chars)) { ICON.set(s.segment, k); ICON.set(s.segment.replace(/️/g, ''), k); }
  // ⬇︎ (text style), 👩‍🍳 (joined emoji): try without the style marks, then the last and the first piece of a joined one
  const kindOf = (g) => {
    if (ICON.has(g)) return ICON.get(g);
    const bare = g.replace(/[\uFE0E\uFE0F]/g, '');
    if (ICON.has(bare)) return ICON.get(bare);
    const bits = bare.split('\u200D').filter(Boolean);
    return bits.length > 1 ? (ICON.get(bits[bits.length - 1]) || ICON.get(bits[0]) || null) : null;
  };
  const EMOJI = /[\p{Extended_Pictographic}☰▶⬇]/u;
  // Never touched: what people typed or wrote (inputs, chat, notes, reviews) and what is already an icon.
  const SKIP = 'script,style,textarea,option,select,svg,code,pre,[contenteditable],.ak-svg-icon,.ak-real-icon,.ugc,.msgs,.chat,.bubble,[data-raw]';
  function glyph(kind) {
    const s = document.createElement('span');
    s.className = `ak-svg-icon ak-i-${kind}`;
    s.setAttribute('aria-hidden', 'true');
    s.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${P[kind]}</svg>`;
    return s;
  }
  function upgrade(root) {
    if (!root || !root.isConnected) return;
    if (root.nodeType === 3) root = root.parentElement;
    if (!root || root.closest?.(SKIP)) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!EMOJI.test(n.nodeValue || '')) return NodeFilter.FILTER_REJECT;
        const p = n.parentElement;
        return !p || p.closest(SKIP) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
      },
    });
    const nodes = [];
    while (w.nextNode()) nodes.push(w.currentNode);
    for (const node of nodes) {
      const parts = [...seg.segment(node.nodeValue)].map((x) => x.segment);
      if (!parts.some((x) => kindOf(x))) continue;
      const frag = document.createDocumentFragment();
      for (const part of parts) frag.append(kindOf(part) ? glyph(kindOf(part)) : document.createTextNode(part));
      node.replaceWith(frag);
    }
  }
  window.aklatakIcon = (kind) => (P[kind] ? glyph(kind).outerHTML : '');
  const pending = new Set();
  let queued = false;
  function flush() { queued = false; const list = [...pending]; pending.clear(); for (const n of list) upgrade(n); }
  function init() {
    upgrade(document.body);
    new MutationObserver((muts) => {
      for (const m of muts) { if (m.type === 'characterData') pending.add(m.target); else m.addedNodes.forEach((n) => pending.add(n)); }
      if (!queued && pending.size) { queued = true; queueMicrotask(flush); }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true }); else init();
})();
