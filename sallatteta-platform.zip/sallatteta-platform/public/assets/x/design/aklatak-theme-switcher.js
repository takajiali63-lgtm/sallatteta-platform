// Aklatak signature design — the two looks (modern / luxury).
// The owner chooses the look everybody gets first and whether people may switch (admin → Designs); both arrive as CSS
// variables in /design.css. A person's own choice is kept on this phone only (and only when switching is allowed).
// With a classic design (/design.css empty) this script does nothing.
(() => {
  'use strict';
  const TXT = {
    ar: { title: 'اختر المظهر', desc: 'غيّر الألوان فوراً. يُحفظ اختيارك على هذا الجهاز.', modern: 'العصري', modernD: 'برتقالي وأبيض وأسود', luxury: 'الفاخر', luxuryD: 'خمري داكن وذهبي', close: 'إغلاق', button: 'اختيار المظهر' },
    en: { title: 'Choose appearance', desc: 'Change colors instantly. Your choice is saved on this device.', modern: 'Modern', modernD: 'Orange, white and black', luxury: 'Luxury', luxuryD: 'Dark burgundy and gold', close: 'Close', button: 'Choose appearance' },
    fr: { title: 'Choisir le thème', desc: 'Changez les couleurs immédiatement. Votre choix est enregistré sur cet appareil.', modern: 'Moderne', modernD: 'Orange, blanc et noir', luxury: 'Prestige', luxuryD: 'Bordeaux foncé et or', close: 'Fermer', button: 'Choisir le thème' },
    es: { title: 'Elegir apariencia', desc: 'Cambia los colores al instante. Tu elección se guarda en este dispositivo.', modern: 'Moderno', modernD: 'Naranja, blanco y negro', luxury: 'Lujo', luxuryD: 'Burdeos oscuro y dorado', close: 'Cerrar', button: 'Elegir apariencia' },
  };
  const get = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
  const set = (k, v) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } };
  const tr = (k) => { const l = String(get('st_lang') || document.documentElement.lang || 'ar').slice(0, 2); return (TXT[l] || TXT.ar)[k] || TXT.ar[k]; };
  const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  const root = document.documentElement;
  if (cssVar('--ak-signature') !== '1') { root.removeAttribute('data-ak-theme'); return; }   // classic design chosen by the owner

  const OPTIONS = ['modern', 'luxury'];
  const role = location.pathname.startsWith('/driver') ? 'driver' : location.pathname.startsWith('/store') || location.pathname.startsWith('/account') ? 'merchant' : 'customer';
  const KEY = `aklatak-appearance-v2-${role}`;
  const fallback = OPTIONS.includes(cssVar('--ak-default-variant')) ? cssVar('--ak-default-variant') : 'modern';
  const allowSwitch = cssVar('--ak-allow-switch') !== '0';
  const mine = get(KEY);
  const apply = (v) => {
    if (!OPTIONS.includes(v)) return;
    root.setAttribute('data-ak-theme', v);
    document.querySelectorAll('.ak-theme-choice').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.theme === v)));
  };
  apply(allowSwitch && OPTIONS.includes(mine) ? mine : fallback);
  if (!allowSwitch) return;

  function dialog() {
    let d = document.getElementById('ak-theme-dialog');
    if (d) return d;
    d = document.createElement('div');
    d.id = 'ak-theme-dialog'; d.className = 'ak-theme-dialog'; d.hidden = true;
    d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true');
    const panel = document.createElement('div'); panel.className = 'ak-theme-panel';
    const h = document.createElement('h2'); h.className = 'ak-theme-title';
    const p = document.createElement('p'); p.className = 'ak-theme-desc';
    panel.append(h, p);
    for (const v of OPTIONS) {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'ak-theme-choice'; b.dataset.theme = v;
      const sw = document.createElement('span'); sw.className = `ak-theme-swatch ak-swatch-${v}`;
      const txt = document.createElement('span'); const bb = document.createElement('b'); const sm = document.createElement('small');
      txt.append(bb, sm); b.append(sw, txt);
      b.addEventListener('click', () => { set(KEY, v); apply(v); close(); });
      panel.append(b);
    }
    const c = document.createElement('button'); c.type = 'button'; c.className = 'ak-theme-close';
    c.addEventListener('click', () => close());
    panel.append(c); d.append(panel); document.body.append(d);
    d.addEventListener('click', (e) => { if (e.target === d) close(); });
    return d;
  }
  const esc = (e) => { if (e.key === 'Escape') close(); };
  function close() { const d = document.getElementById('ak-theme-dialog'); if (d) d.hidden = true; document.removeEventListener('keydown', esc); }
  function open() {
    const d = dialog();
    d.setAttribute('aria-label', tr('button'));
    d.querySelector('.ak-theme-title').textContent = tr('title');
    d.querySelector('.ak-theme-desc').textContent = tr('desc');
    for (const v of OPTIONS) {
      const b = d.querySelector(`[data-theme="${v}"]`);
      b.querySelector('b').textContent = tr(v); b.querySelector('small').textContent = tr(`${v}D`);
    }
    d.querySelector('.ak-theme-close').textContent = tr('close');
    apply(root.dataset.akTheme || fallback);
    d.hidden = false;
    document.addEventListener('keydown', esc);
    d.querySelector('.ak-theme-choice').focus();
  }
  window.aklatakOpenTheme = open;

  // The 🎨 button lives in the header photo (top corner), the same place on every screen.
  function mount() {
    const all = [...document.querySelectorAll('.ak-theme-button')];
    all.slice(1).forEach((b) => b.remove());
    if (all[0]) return;
    const host = document.querySelector('.brandbar');
    if (!host) return;
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'ak-theme-button'; b.textContent = '🎨';
    b.title = tr('button'); b.setAttribute('aria-label', tr('button'));
    b.addEventListener('click', open);
    host.append(b);
  }
  let queued = false;
  const later = () => { if (queued) return; queued = true; requestAnimationFrame(() => { queued = false; mount(); }); };
  const start = () => { mount(); new MutationObserver(later).observe(document.querySelector('.brandbar') || document.body, { childList: true }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
