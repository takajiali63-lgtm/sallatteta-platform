// v8.3 AI Operations Manager — client screens (store dashboard, driver app, customer store page).
// Mount functions (the screens call them; nothing runs by itself):
//   renderAiSettings(el, role)     "إعدادات المدير الذكي" — master switch + 4-level control per permission (or the upgrade offer)
//   openAiChat(role, { storeId })  chat sheet with a microphone (voice two-way with the Web Speech API, on the phone only)
//   renderApprovals(el, role)      actions waiting for approval + tasks for a human
//   renderAiReports(el, role)      saved daily/weekly reports, usage and the actions log
// role: 'store' | 'driver' (customers use openAiChat('customer', { storeId })).
// Speech is recognised and spoken by the phone's browser: no audio is sent to the server, only the text.
import { t, esc, $, $$, api, toast, sheet, getLang, emit, errText, fmtTime } from './core.js';

const roleOf = (role) => (role === 'driver' || role === 'store' ? role : location.pathname.startsWith('/driver') ? 'driver' : 'store');
const asQ = (role, sep = '?') => `${sep}as=${roleOf(role)}`;
const LEVELS = ['OFF', 'READ_ONLY', 'ASK_APPROVAL', 'AUTO_EXECUTE'];
const SPEECH_LANG = { ar: ['ar-LB', 'ar'], en: ['en-US'], fr: ['fr-FR'], es: ['es-ES'] };
const tt = (key, fallback) => { const s = t(key); return s === key ? (fallback ?? key) : s; };

function upsell(el, reason) {
  const items = ['orders', 'customers', 'products', 'bookings', 'reports', 'voice'];
  el.innerHTML = `<div class="card ak-ai-upsell">
    <h2>🤖 ${esc(t('ai.title'))}</h2>
    ${reason === 'ai_disabled' ? `<p class="mute">${esc(t('ai.disabledByOwner'))}</p>` : `<p>${esc(t('ai.upsellIntro'))}</p>
    <ul class="ak-ai-list">${items.map((k) => `<li>${esc(t(`ai.includes.${k}`))}</li>`).join('')}</ul>
    <p class="small mute">${esc(t('ai.upsellNote'))}</p>
    <button class="btn" data-up>${esc(t('ai.upgrade'))}</button>`}
  </div>`;
  $('[data-up]', el)?.addEventListener('click', () => { if (window.akUpgradeAi) window.akUpgradeAi(); else toast(t('ai.upgradeSoon')); });
}

/** The "AI manager settings" page. */
export async function renderAiSettings(el, role) {
  role = roleOf(role);
  el.innerHTML = '<div class="skel cover"></div>';
  let s, u;
  try {
    s = await api('GET', `/api/ai/settings${asQ(role)}`);
    u = (await api('GET', `/api/ai/usage${asQ(role)}`)).usage;
  } catch (e) {
    if (e.status === 403) return upsell(el, e.code);
    el.innerHTML = `<div class="empty">${esc(errText(e))}</div>`;
    return;
  }
  const levelBtns = (p) => `<div class="ak-ai-seg" role="group" aria-label="${esc(tt(`ai.perm.${p.key}`, p.desc))}">${LEVELS.filter((l) => p.allowed.includes(l)).map((l) =>
    `<button type="button" data-perm="${esc(p.key)}" data-level="${l}" aria-pressed="${p.level === l}" class="${p.level === l ? 'on' : ''}">${esc(t(`ai.level.${l}`))}</button>`).join('')}</div>`;
  el.innerHTML = `<div class="ak-ai">
    <h1>🤖 ${esc(t('ai.settingsTitle'))}</h1>
    <label class="toggle ak-ai-master"><span><b>${esc(t('ai.master'))}</b><br><small class="mute">${esc(t('ai.masterHint'))}</small></span>
      <input type="checkbox" id="akAiMaster" ${s.enabled ? 'checked' : ''}></label>
    <div class="card ak-ai-usage"><div class="row"><span>${esc(t('ai.usageMessages'))}</span><b>${u.messages} / ${u.messagesLimit}</b></div>
      <div class="ak-ai-meter"><i class="w${Math.min(10, Math.round((u.messages / Math.max(1, u.messagesLimit)) * 10))}"></i></div>
      <div class="row small"><span>${esc(t('ai.usageVoice'))}</span><b>${Math.floor(u.voiceSeconds / 60)} / ${Math.floor(u.voiceLimitSeconds / 60)} ${esc(t('ai.minutes'))}</b></div></div>
    <div class="ak-ai-actions"><button class="btn sm" data-open="chat">💬 ${esc(t('ai.openChat'))}</button>
      <button class="btn sm alt" data-open="approvals">✅ ${esc(t('ai.approvals'))}</button><button class="btn sm alt" data-open="reports">📊 ${esc(t('ai.reports'))}</button></div>
    <p class="small mute">${esc(t('ai.levelsHelp'))}</p>
    ${s.groups.map((g) => `<section class="card ak-ai-group"><h3>${esc(t(`ai.group.${g.key}`))}</h3>
      ${g.perms.map((p) => `<div class="ak-ai-perm"><div class="row"><b>${esc(tt(`ai.perm.${p.key}`, p.desc))}</b>
        <span class="chip ${p.risk === 'high' ? 'b' : p.risk === 'medium' ? 'w' : 'g'}">${esc(t(`ai.risk.${p.risk}`))}</span></div>
        ${p.risk === 'high' ? `<p class="tiny mute">${esc(t('ai.highRiskNote'))}</p>` : ''}${levelBtns(p)}</div>`).join('')}</section>`).join('')}
    <p class="tiny mute">${esc(t('ai.priceNote'))}</p>
  </div>`;
  $('#akAiMaster', el).addEventListener('change', async (e) => {
    try { await api('PUT', `/api/ai/settings${asQ(role)}`, { enabled: e.target.checked }); toast(t('ai.saved')); } catch (x) { e.target.checked = !e.target.checked; toast(errText(x)); }
  });
  $$('[data-perm]', el).forEach((b) => b.addEventListener('click', async () => {
    const group = b.parentElement;
    try {
      await api('PUT', `/api/ai/settings${asQ(role)}`, { perms: { [b.dataset.perm]: b.dataset.level } });
      $$('button', group).forEach((x) => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-pressed', String(on)); });
      toast(t('ai.saved'));
    } catch (x) { toast(errText(x)); }
  }));
  $('[data-open="chat"]', el).addEventListener('click', () => openAiChat(role));
  $('[data-open="approvals"]', el).addEventListener('click', () => { const s2 = sheet(`<h2>✅ ${esc(t('ai.approvals'))}</h2><div class="ak-ai-sheetbody"></div><button class="btn alt" data-close>${esc(t('ai.close'))}</button>`); renderApprovals($('.ak-ai-sheetbody', s2.el), role); });
  $('[data-open="reports"]', el).addEventListener('click', () => { const s2 = sheet(`<h2>📊 ${esc(t('ai.reports'))}</h2><div class="ak-ai-sheetbody"></div><button class="btn alt" data-close>${esc(t('ai.close'))}</button>`); renderAiReports($('.ak-ai-sheetbody', s2.el), role); });
}

/** Chat with the AI manager (role store/driver) or with a store's assistant (role 'customer' + storeId). */
export function openAiChat(role, { storeId } = {}) {
  const customer = role === 'customer';
  if (!customer) role = roleOf(role);
  const path = customer ? `/api/ai/store/${Number(storeId)}/chat` : `/api/ai/manager/chat${asQ(role)}`;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const canSpeak = 'speechSynthesis' in window;
  const voiceOk = !customer && !!SR;
  const s = sheet(`<div class="ak-ai-chat">
    <div class="row"><h2>🤖 ${esc(customer ? t('ai.assistantTitle') : t('ai.title'))}</h2><button class="btn sm alt" data-close aria-label="${esc(t('ai.close'))}">✕</button></div>
    <div class="ak-ai-log" aria-live="polite"><p class="ak-ai-msg bot">${esc(customer ? t('ai.assistantHello') : t('ai.hello'))}</p></div>
    <p class="tiny mute ak-ai-status" hidden></p>
    <form class="ak-ai-form"><input class="in" name="m" maxlength="${customer ? 500 : 1000}" autocomplete="off" placeholder="${esc(t('ai.placeholder'))}" aria-label="${esc(t('ai.placeholder'))}">
      ${customer ? '' : `<button type="button" class="ak-ai-mic" aria-pressed="false" aria-label="${esc(t('ai.mic'))}" ${voiceOk ? '' : 'disabled'}>🎤</button>`}
      <button class="ak-ai-send" aria-label="${esc(t('ai.send'))}">➤</button></form>
    ${!customer && !voiceOk ? `<p class="tiny mute">${esc(t('ai.voiceUnsupported'))}</p>` : ''}
    ${!customer ? `<p class="tiny mute">${esc(t('ai.voicePrivacy'))}</p>` : ''}
  </div>`, { onClose: () => { stopVoice(); emit('ai_session_ended', { role }); } });
  const log = $('.ak-ai-log', s.el), form = $('.ak-ai-form', s.el), input = form.m, status = $('.ak-ai-status', s.el), mic = $('.ak-ai-mic', s.el);
  emit('ai_session_started', { role, storeId: storeId || null });
  const add = (text, who) => { const p = document.createElement('p'); p.className = `ak-ai-msg ${who}`; p.textContent = text; log.appendChild(p); log.scrollTop = log.scrollHeight; return p; };
  const setStatus = (txt) => { status.hidden = !txt; status.textContent = txt || ''; };
  let busy = false;

  async function send(text, { voice = false } = {}) {
    if (!text || busy) return;
    busy = true;
    add(text, 'me');
    const wait = add('…', 'bot wait');
    emit('ai_processing', { role });
    try {
      const r = await api('POST', path, { message: text, ...(voice ? { voice: true } : {}) });
      wait.remove();
      add(r.reply || t('ai.noAnswer'), 'bot');
      emit('ai_response_ready', { role, voice });
      if (r.requiresApproval) { emit('ai_requires_approval', { role, actions: r.actions }); add(t('ai.needsApproval'), 'bot note'); }
      if (voice) await speak(r.reply || '', r.lang);
    } catch (e) {
      wait.remove();
      add(e.code === 'ai_quota_exceeded' ? t('ai.quota') : errText(e), 'bot err');
      emit('ai_failed', { role, error: e.code });
      if (voice) stopVoice();
    } finally { busy = false; }
  }
  form.addEventListener('submit', (e) => { e.preventDefault(); const v = input.value.trim(); input.value = ''; send(v); });
  setTimeout(() => input.focus(), 50);

  // ---------- voice: listen → send the text → speak the answer → listen again ----------
  let rec = null, voiceOn = false, sessionId = null, beat = null, retries = 0, langIdx = 0;
  const speechLangs = () => SPEECH_LANG[getLang()] || SPEECH_LANG.ar;
  function speak(text, lang) {
    if (!canSpeak || !text || !voiceOn) return Promise.resolve();
    return new Promise((resolve) => {
      try {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text.slice(0, 600));
        u.lang = (SPEECH_LANG[lang] || speechLangs())[0];
        u.onend = u.onerror = () => resolve();
        speechSynthesis.speak(u);
      } catch { resolve(); }
    });
  }
  function listen() {
    if (!voiceOn || busy) return;
    try {
      rec = new SR();
      rec.lang = speechLangs()[Math.min(langIdx, speechLangs().length - 1)];
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      rec.onresult = async (ev) => {
        const text = String(ev.results?.[0]?.[0]?.transcript || '').trim();
        retries = 0;
        if (text) { setStatus(t('ai.thinking')); await send(text, { voice: true }); }
      };
      rec.onerror = (ev) => {
        if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') { toast(t('ai.micDenied')); stopVoice(); return; }
        if (ev.error === 'language-not-supported' && langIdx < speechLangs().length - 1) { langIdx += 1; return; }   // e.g. ar-LB → ar
        retries += 1;
        if (retries > 3) { toast(t('ai.voiceError')); emit('ai_failed', { role, error: ev.error }); stopVoice(); }
      };
      // reconnect after each phrase / error while voice mode is on (with a small backoff)
      rec.onend = () => { if (voiceOn) setTimeout(() => { if (voiceOn && !busy) listen(); else if (voiceOn) waitIdle(); }, 300 * (retries + 1)); };
      rec.start();
      setStatus(t('ai.listening'));
      emit('ai_listening', { role });
    } catch { retries += 1; if (retries <= 3) setTimeout(listen, 600); else stopVoice(); }
  }
  function waitIdle() { const iv = setInterval(() => { if (!voiceOn) return clearInterval(iv); if (!busy) { clearInterval(iv); listen(); } }, 300); }
  async function startVoice() {
    try {
      const r = await api('POST', `/api/ai/voice/session${asQ(role)}`, {});
      sessionId = r.sessionId;
      voiceOn = true; retries = 0; langIdx = 0;
      mic.classList.add('on'); mic.setAttribute('aria-pressed', 'true');
      // count the minutes used (the server also checks its own clock); stops by itself at the monthly limit
      beat = setInterval(async () => {
        try { const h = await api('POST', `/api/ai/voice/session/${sessionId}/heartbeat${asQ(role)}`, { seconds: 15 }); if (h.stopped) { toast(t('ai.quota')); stopVoice(); } } catch { /* next beat */ }
      }, 15_000);
      listen();
    } catch (e) { toast(e.code === 'ai_quota_exceeded' ? t('ai.quota') : errText(e)); emit('ai_failed', { role, error: e.code }); }
  }
  function stopVoice() {
    if (!voiceOn) return;
    voiceOn = false;
    clearInterval(beat); beat = null;
    try { rec?.abort(); } catch { /* ignore */ }
    try { speechSynthesis?.cancel(); } catch { /* ignore */ }
    mic?.classList.remove('on'); mic?.setAttribute('aria-pressed', 'false');
    setStatus('');
    if (sessionId) api('POST', `/api/ai/voice/session/${sessionId}/end${asQ(role)}`, {}).catch(() => {});
    sessionId = null;
  }
  mic?.addEventListener('click', () => { if (!voiceOk) return toast(t('ai.voiceUnsupported')); voiceOn ? stopVoice() : startVoice(); });
  // the app in the background can't listen: voice stops when the screen is hidden (no claim of listening while closed)
  const onHide = () => { if (document.hidden) stopVoice(); };
  document.addEventListener('visibilitychange', onHide);
  const obs = new MutationObserver(() => { if (!document.body.contains(s.el)) { stopVoice(); document.removeEventListener('visibilitychange', onHide); obs.disconnect(); } });
  obs.observe(document.body, { childList: true });
  return { close: s.close, send };
}

const TOOL_KEYS = ['read_orders', 'list_new_orders', 'order_status_update', 'notify_customer', 'read_catalog', 'suggest_description', 'prepare_product_update', 'suggest_price',
  'prepare_promotion', 'read_bookings', 'read_visit_requests', 'create_booking_within_rules', 'send_reminder', 'propose_reschedule', 'read_errands', 'earnings_report', 'sales_report',
  'detect_problems', 'draft_marketing_text', 'escalate_to_human'];
const toolName = (n) => (TOOL_KEYS.includes(n) ? tt(`ai.tool.${n}`, n) : n);
const argsText = (a) => (a && typeof a === 'object' ? Object.entries(a).map(([k, v]) => `${k}: ${v}`).join(' · ') : '');

/** Actions waiting for the subscriber's approval, and tasks the AI handed to a human. */
export async function renderApprovals(el, role) {
  role = roleOf(role);
  el.innerHTML = '<div class="skel cover"></div>';
  let d;
  try { d = await api('GET', `/api/ai/approvals${asQ(role)}`); } catch (e) { if (e.status === 403) return upsell(el, e.code); el.innerHTML = `<div class="empty">${esc(errText(e))}</div>`; return; }
  const pending = d.approvals.filter((a) => a.status === 'pending');
  const done = d.approvals.filter((a) => a.status !== 'pending').slice(0, 20);
  el.innerHTML = `<div class="ak-ai">
    ${pending.length ? pending.map((a) => `<div class="card ak-ai-appr"><div class="row"><b>${esc(toolName(a.tool))}</b><span class="tiny mute">${esc(fmtTime(a.created_at))}</span></div>
      <p class="small">${esc(argsText(a.args))}</p>
      <div class="row"><button class="btn sm" data-ok="${a.id}">${esc(t('ai.approve'))}</button><button class="btn sm bad" data-no="${a.id}">${esc(t('ai.reject'))}</button></div></div>`).join('')
      : `<div class="empty">${esc(t('ai.noApprovals'))}</div>`}
    ${d.tasks.length ? `<h2>🙋 ${esc(t('ai.tasks'))}</h2>${d.tasks.map((x) => `<div class="card"><p>${esc(x.reason || '')}</p><button class="btn sm alt" data-close-task="${x.id}">${esc(t('ai.done'))}</button></div>`).join('')}` : ''}
    ${done.length ? `<h2>${esc(t('ai.history'))}</h2>${done.map((a) => `<div class="row small ak-ai-hist"><span>${esc(toolName(a.tool))}</span><span class="chip ${a.status === 'executed' ? 'g' : a.status === 'rejected' ? '' : 'b'}">${esc(t(`ai.status.${a.status}`))}</span></div>`).join('')}` : ''}
  </div>`;
  const act = async (url, okMsg) => { try { const r = await api('POST', url, {}); toast(r.status === 'failed' ? t('ai.failed') : okMsg); } catch (e) { toast(errText(e)); } renderApprovals(el, role); };
  $$('[data-ok]', el).forEach((b) => b.addEventListener('click', () => { b.disabled = true; act(`/api/ai/approvals/${b.dataset.ok}/approve${asQ(role)}`, t('ai.approved')); }));
  $$('[data-no]', el).forEach((b) => b.addEventListener('click', () => { b.disabled = true; act(`/api/ai/approvals/${b.dataset.no}/reject${asQ(role)}`, t('ai.rejected')); }));
  $$('[data-close-task]', el).forEach((b) => b.addEventListener('click', () => act(`/api/ai/tasks/${b.dataset.closeTask}/close${asQ(role)}`, t('ai.saved'))));
}

/** Saved daily / weekly reports, this month's usage and the AI actions log. */
export async function renderAiReports(el, role) {
  role = roleOf(role);
  el.innerHTML = '<div class="skel cover"></div>';
  let reps, acts;
  try {
    reps = (await api('GET', `/api/ai/reports${asQ(role)}`)).reports;
    acts = (await api('GET', `/api/ai/actions${asQ(role)}&limit=50`)).actions;
  } catch (e) { if (e.status === 403) return upsell(el, e.code); el.innerHTML = `<div class="empty">${esc(errText(e))}</div>`; return; }
  const line = (r) => {
    const d = r.data || {};
    if (d.totalEarnings !== undefined) return `${t('ai.earnings')}: <b>${d.totalEarnings}$</b> · ${t('ai.storeDeliveries')}: ${d.storeDeliveries} · ${t('ai.customerRequests')}: ${d.customerRequests}`;
    return `${t('ai.ordersCount')}: <b>${d.orders ?? 0}</b> · ${t('ai.delivered')}: ${d.delivered ?? 0} · ${t('ai.rejectedCount')}: ${d.rejected ?? 0} · ${t('ai.revenue')}: <b>${d.revenue ?? 0} ${esc(d.currency || '')}</b>`;
  };
  el.innerHTML = `<div class="ak-ai">
    ${reps.length ? reps.map((r) => `<div class="card ak-ai-rep"><div class="row"><b>${esc(t(`ai.period.${r.period}`))}</b><span class="tiny mute">${esc(r.period_key)}</span></div><p class="small">${line(r)}</p></div>`).join('')
      : `<div class="empty">${esc(t('ai.noReports'))}</div>`}
    <h2>${esc(t('ai.log'))}</h2>
    ${acts.length ? `<div class="ak-ai-logtbl">${acts.map((a) => `<div class="row small"><span>${esc(a.tool === 'chat' ? t('ai.chatTurn') : toolName(a.tool))}</span><span class="chip ${['executed', 'approved', 'answered'].includes(a.decision) ? 'g' : a.decision === 'queued' ? 'w' : 'b'}">${esc(t(`ai.decision.${a.decision}`))}</span><span class="tiny mute">${esc(fmtTime(a.created_at))}</span></div>`).join('')}</div>`
      : `<div class="empty">${esc(t('ai.noLog'))}</div>`}
  </div>`;
}
