// v8.2 subscriptions bought inside the Google Play app (Trusted Web Activity) — Digital Goods API + Payment Request.
// The phone only starts the purchase; the server asks Google and activates (POST /api/billing/google/verify).
// Outside the Play app every function answers "not available" quietly, and the usual payment screens stay as they are.
import { api, t, esc, toast, emit, getLang } from './core.js';

const PLAY = 'https://play.google.com/billing';
let svc = null;

/** True when this page runs inside our Play app with Google Play Billing available. */
export function canUsePlayBilling() {
  return typeof window !== 'undefined' && 'getDigitalGoodsService' in window && 'PaymentRequest' in window;
}
async function service() {
  if (!canUsePlayBilling()) return null;
  if (!svc) svc = window.getDigitalGoodsService(PLAY).catch(() => null);
  const s = await svc;
  if (!s) svc = null;   // try again next time (the Play app may not be ready yet)
  return s;
}
const fmtPrice = (p) => {
  try { return new Intl.NumberFormat(getLang(), { style: 'currency', currency: p.currency }).format(Number(p.value)); }
  catch { return `${p.value} ${p.currency}`; }
};

/** Localized prices from Google Play: [{ productId, title, description, price, priceValue, currency }] (empty outside the Play app). */
export async function listPlayProducts(ids) {
  const s = await service();
  if (!s || !ids?.length) return [];
  try {
    const items = await s.getDetails(ids);
    return items.map((i) => ({ productId: i.itemId, title: i.title, description: i.description, price: i.price ? fmtPrice(i.price) : '', priceValue: i.price?.value, currency: i.price?.currency }));
  } catch { return []; }
}

/** The plans this account can buy (from the server — no product id is written in the app) and its current state. */
export async function billingStatus() {
  const [p, me] = await Promise.all([api('GET', '/api/billing/products'), api('GET', '/api/billing/me')]);
  return { ...p, ...me };
}

const ERR = { purchase_belongs_to_another_account: 'billing.otherAccount', billing_not_configured: 'billing.notConfigured', product_not_for_account: 'billing.failed' };

/**
 * Buy (or switch to) a plan: prepare → Google Play payment sheet → the server verifies with Google → refresh.
 * Returns { ok, granted, state } or { ok:false, reason: 'unavailable'|'cancelled'|<error code> }.
 * upgradeFrom: { productId, purchaseToken } of the current Play subscription when switching plans.
 */
export async function playSubscribe(productId, { upgradeFrom = null, onDone = null } = {}) {
  if (!(await service())) { toast(t('billing.unavailable')); return { ok: false, reason: 'unavailable' }; }
  let prep;
  try { prep = await api('GET', `/api/billing/google/prepare?productId=${encodeURIComponent(productId)}`); }
  catch (e) { toast(t(ERR[e.code] || 'billing.failed')); return { ok: false, reason: e.code }; }
  const data = { sku: productId, obfuscatedAccountId: prep.accountId };   // the account id is ignored by older Play apps; harmless
  if (upgradeFrom?.purchaseToken && upgradeFrom.productId !== productId) Object.assign(data, { oldSku: upgradeFrom.productId, purchaseToken: upgradeFrom.purchaseToken });
  let resp;
  try {
    const req = new PaymentRequest([{ supportedMethods: PLAY, data }], { total: { label: 'Total', amount: { currency: 'USD', value: '0' } } });
    resp = await req.show();
  } catch (e) {
    if (e?.name === 'AbortError') { toast(t('billing.cancelled')); return { ok: false, reason: 'cancelled' }; }
    toast(t('billing.failed')); emit('payment_failure', { source: 'play' }); return { ok: false, reason: 'play_error' };
  }
  const purchaseToken = resp.details?.purchaseToken || resp.details?.token;
  toast(t('billing.verifying'));
  try {
    const r = await api('POST', '/api/billing/google/verify', { productId, purchaseToken });
    await resp.complete('success').catch(() => {});
    if (r.granted) { toast(t('billing.success')); emit('payment_success', { source: 'play', productId }); }
    else toast(t('billing.pending'));
    emit('billing_updated', { productId, state: r.entitlement?.state });
    onDone?.(r);
    return { ok: true, granted: !!r.granted, state: r.entitlement?.state || null };
  } catch (e) {
    await resp.complete('fail').catch(() => {});
    toast(t(ERR[e.code] || 'billing.failed'));
    emit('payment_failure', { source: 'play', code: e.code });
    return { ok: false, reason: e.code };
  }
}

/** On app start: send purchases Google Play already has (renewals, purchases interrupted before verify) to the server. Quiet. */
export async function syncPlayPurchases() {
  const s = await service();
  if (!s?.listPurchases) return 0;
  let n = 0;
  try {
    for (const p of await s.listPurchases()) {
      try { await api('POST', '/api/billing/google/verify', { productId: p.itemId, purchaseToken: p.purchaseToken }); n++; } catch { /* another account / not ours */ }
    }
  } catch { /* Play not ready */ }
  if (n) emit('billing_updated', {});
  return n;
}

const fmtDate = (s) => { try { return new Date(s).toLocaleDateString(getLang(), { dateStyle: 'medium' }); } catch { return s; } };

/**
 * Plan cards with Google Play prices and a subscribe button, inside `el`. Returns false (and draws nothing) when the page
 * is not in the Play app or the owner has not set Google Play up — the caller then keeps its usual payment screen.
 */
export async function mountPlayPlans(el, { onDone = null } = {}) {
  if (!el || !canUsePlayBilling()) return false;
  let st;
  try { st = await billingStatus(); } catch { return false; }
  if (!st.google || !st.products.length) return false;
  const prices = new Map((await listPlayProducts(st.products.map((p) => p.productId))).map((p) => [p.productId, p]));
  if (!prices.size) return false;
  const now = new Date().toISOString();
  const current = st.entitlements.find((e) => e.platform === 'google' && ['active', 'grace', 'cancelled'].includes(e.state) && e.expiresAt > now);
  const period = (m) => (Number(m) === 1 ? t('billing.perMonth') : t('billing.perMonths', { n: m }));
  el.classList.add('akb');
  el.innerHTML = `<h3 class="akb-title">${esc(t('billing.title'))}</h3>
    ${st.products.filter((p) => prices.has(p.productId)).map((p) => {
      const mine = current?.productId === p.productId;
      return `<div class="akb-plan${p.tier === 'ai' ? ' akb-ai' : ''}${mine ? ' akb-mine' : ''}">
        <div class="akb-head"><b>${esc(t(p.tier === 'ai' ? 'billing.tierAi' : 'billing.tierBasic'))}</b><span class="akb-price">${esc(prices.get(p.productId).price)} <small>${esc(period(p.months))}</small></span></div>
        ${mine ? `<p class="akb-state">${esc(t('billing.current'))} · ${esc(t('billing.until', { date: fmtDate(current.expiresAt) }))}</p>`
    : `<button class="btn akb-buy" data-sku="${esc(p.productId)}">${esc(t('billing.subscribe'))}</button>`}
      </div>`;
    }).join('')}
    ${current ? `<a class="akb-manage" href="https://play.google.com/store/account/subscriptions" target="_blank" rel="noopener">${esc(t('billing.manage'))}</a>` : ''}`;
  for (const b of el.querySelectorAll('.akb-buy')) {
    b.addEventListener('click', async () => {
      for (const x of el.querySelectorAll('.akb-buy')) x.disabled = true;
      const r = await playSubscribe(b.dataset.sku, { upgradeFrom: current ? { productId: current.productId, purchaseToken: current.purchaseToken } : null });
      if (r.ok) { onDone?.(r); await mountPlayPlans(el, { onDone }); } else for (const x of el.querySelectorAll('.akb-buy')) x.disabled = false;
    });
  }
  return true;
}
