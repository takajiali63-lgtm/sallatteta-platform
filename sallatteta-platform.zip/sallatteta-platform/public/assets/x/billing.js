// v8.2 subscriptions bought inside the Google Play app (Trusted Web Activity) — Digital Goods API + Payment Request.
// v8.3 the SAME screens on iPhone: inside our App Store app, purchases go through Apple (StoreKit) via a small native
// bridge (window.webkit.messageHandlers.aklatakIAP — contract in docs/MOBILE.md); the server checks Apple's signature.
// Google Play does not work on iPhone and Apple does not work on Android: each phone uses its own store, same products.
// The phone only starts the purchase; the server verifies and activates. Elsewhere every function answers "not available".
import { api, t, esc, toast, emit, getLang } from './core.js';

const PLAY = 'https://play.google.com/billing';
let svc = null;

const googleOk = () => typeof window !== 'undefined' && 'getDigitalGoodsService' in window && 'PaymentRequest' in window;
const appleBridge = () => { try { return window.webkit?.messageHandlers?.aklatakIAP || null; } catch { return null; } };
/** Which store this app can pay with: 'google' (Android Play app), 'apple' (iPhone App Store app) or null (browser). */
export function storeKind() { return googleOk() ? 'google' : appleBridge() ? 'apple' : null; }
/** True inside our Play app (Google Play Billing) or our iPhone app (Apple in-app purchase). */
export function canUsePlayBilling() { return !!storeKind(); }

// the iPhone bridge: postMessage({ id, action, ... }) → the app answers window.aklatakIAPResult(id, { ok, ... })
const waiting = new Map();
let seq = 0;
if (typeof window !== 'undefined') window.aklatakIAPResult = (id, res) => { const w = waiting.get(id); if (w) { waiting.delete(id); w(res || { ok: false }); } };
function apple(action, payload = {}, ms = 180_000) {
  const b = appleBridge();
  if (!b) return Promise.resolve({ ok: false, error: 'unavailable' });
  const id = `iap${++seq}`;
  return new Promise((resolve) => {
    waiting.set(id, resolve);
    setTimeout(() => { if (waiting.has(id)) { waiting.delete(id); resolve({ ok: false, error: 'timeout' }); } }, ms);
    try { b.postMessage({ id, action, ...payload }); } catch { waiting.delete(id); resolve({ ok: false, error: 'unavailable' }); }
  });
}
const tk = (key) => (storeKind() === 'apple' && ['billing.title', 'billing.manage', 'billing.unavailable'].includes(key) ? `${key}Apple` : key);
const MANAGE = { google: 'https://play.google.com/store/account/subscriptions', apple: 'https://apps.apple.com/account/subscriptions' };

async function service() {
  if (!googleOk()) return null;
  if (!svc) svc = window.getDigitalGoodsService(PLAY).catch(() => null);
  const s = await svc;
  if (!s) svc = null;   // try again next time (the Play app may not be ready yet)
  return s;
}
const fmtPrice = (p) => {
  try { return new Intl.NumberFormat(getLang(), { style: 'currency', currency: p.currency }).format(Number(p.value)); }
  catch { return `${p.value} ${p.currency}`; }
};

/** Localized prices from Google Play: [{ productId, title, description, price, priceValue, currency }] (empty outside the Play app). */
export async function listPlayProducts(ids) {
  if (storeKind() === 'apple') {
    if (!ids?.length) return [];
    const r = await apple('products', { productIds: ids }, 30_000);
    return r.ok && Array.isArray(r.products) ? r.products.map((i) => ({ productId: i.productId, title: i.title || '', description: i.description || '', price: i.price || '', priceValue: i.priceValue, currency: i.currency })) : [];
  }
  const s = await service();
  if (!s || !ids?.length) return [];
  try {
    const items = await s.getDetails(ids);
    return items.map((i) => ({ productId: i.itemId, title: i.title, description: i.description, price: i.price ? fmtPrice(i.price) : '', priceValue: i.price?.value, currency: i.price?.currency }));
  } catch { return []; }
}

/** The plans this account can buy (from the server — no product id is written in the app) and its current state. */
export async function billingStatus() {
  const [p, me] = await Promise.all([api('GET', '/api/billing/products'), api('GET', '/api/billing/me')]);
  return { ...p, ...me };
}

const ERR = { purchase_belongs_to_another_account: 'billing.otherAccount', billing_not_configured: 'billing.notConfigured', product_not_for_account: 'billing.failed' };

/**
 * Buy (or switch to) a plan: prepare → Google Play payment sheet → the server verifies with Google → refresh.
 * Returns { ok, granted, state } or { ok:false, reason: 'unavailable'|'cancelled'|<error code> }.
 * upgradeFrom: { productId, purchaseToken } of the current Play subscription when switching plans.
 */
export async function playSubscribe(productId, { upgradeFrom = null, onDone = null } = {}) {
  if (storeKind() === 'apple') return appleBuy(productId, { onDone });
  if (!(await service())) { toast(t(tk('billing.unavailable'))); return { ok: false, reason: 'unavailable' }; }
  let prep;
  try { prep = await api('GET', `/api/billing/google/prepare?productId=${encodeURIComponent(productId)}`); }
  catch (e) { toast(t(ERR[e.code] || 'billing.failed')); return { ok: false, reason: e.code }; }
  const data = { sku: productId, obfuscatedAccountId: prep.accountId };   // the account id is ignored by older Play apps; harmless
  if (upgradeFrom?.purchaseToken && upgradeFrom.productId !== productId) Object.assign(data, { oldSku: upgradeFrom.productId, purchaseToken: upgradeFrom.purchaseToken });
  let resp;
  try {
    const req = new PaymentRequest([{ supportedMethods: PLAY, data }], { total: { label: 'Total', amount: { currency: 'USD', value: '0' } } });
    resp = await req.show();
  } catch (e) {
    if (e?.name === 'AbortError') { toast(t('billing.cancelled')); return { ok: false, reason: 'cancelled' }; }
    toast(t('billing.failed')); emit('payment_failure', { source: 'play' }); return { ok: false, reason: 'play_error' };
  }
  const purchaseToken = resp.details?.purchaseToken || resp.details?.token;
  toast(t('billing.verifying'));
  try {
    const r = await api('POST', '/api/billing/google/verify', { productId, purchaseToken });
    await resp.complete('success').catch(() => {});
    if (r.granted) { toast(t('billing.success')); emit('payment_success', { source: 'play', productId }); }
    else toast(t('billing.pending'));
    emit('billing_updated', { productId, state: r.entitlement?.state });
    onDone?.(r);
    return { ok: true, granted: !!r.granted, state: r.entitlement?.state || null };
  } catch (e) {
    await resp.complete('fail').catch(() => {});
    toast(t(ERR[e.code] || 'billing.failed'));
    emit('payment_failure', { source: 'play', code: e.code });
    return { ok: false, reason: e.code };
  }
}

/** iPhone: prepare → Apple's payment sheet (StoreKit, with our opaque account id) → the server checks Apple's signature. */
async function appleBuy(productId, { onDone = null } = {}) {
  let prep;
  try { prep = await api('GET', `/api/billing/apple/prepare?productId=${encodeURIComponent(productId)}`); }
  catch (e) { toast(t(ERR[e.code] || 'billing.failed')); return { ok: false, reason: e.code }; }
  const r = await apple('buy', { productId, appAccountToken: prep.accountId });
  if (!r.ok || !r.signedTransaction) {
    if (r.error === 'cancelled') { toast(t('billing.cancelled')); return { ok: false, reason: 'cancelled' }; }
    if (r.error === 'pending') { toast(t('billing.pending')); return { ok: false, reason: 'pending' }; }
    toast(t('billing.failed')); emit('payment_failure', { source: 'apple' }); return { ok: false, reason: r.error || 'apple_error' };
  }
  toast(t('billing.verifying'));
  try {
    const v = await api('POST', '/api/billing/apple/verify', { signedTransaction: r.signedTransaction });
    await apple('finish', { transactionId: r.transactionId }, 15_000);   // tell StoreKit it was delivered (consumables too)
    if (v.granted || v.entitlement?.productId) { toast(t('billing.success')); emit('payment_success', { source: 'apple', productId }); } else toast(t('billing.pending'));
    emit('billing_updated', { productId, state: v.entitlement?.state });
    onDone?.(v);
    return { ok: true, granted: !!v.granted, state: v.entitlement?.state || null };
  } catch (e) {
    toast(t(ERR[e.code] || 'billing.failed'));
    emit('payment_failure', { source: 'apple', code: e.code });
    return { ok: false, reason: e.code };
  }
}

/** On app start: send purchases Google Play already has (renewals, purchases interrupted before verify) to the server. Quiet. */
export async function syncPlayPurchases() {
  if (storeKind() === 'apple') {   // iPhone: the store's current purchases (also the «restore purchases» button)
    const r = await apple('restore', {}, 60_000);
    let n = 0;
    for (const jws of (r.ok && Array.isArray(r.transactions) ? r.transactions : []).slice(0, 50)) {
      try { await api('POST', '/api/billing/apple/verify', { signedTransaction: jws }); n++; } catch { /* another account / not ours */ }
    }
    if (n) emit('billing_updated', {});
    return n;
  }
  const s = await service();
  if (!s?.listPurchases) return 0;
  let n = 0;
  try {
    for (const p of await s.listPurchases()) {
      try { await api('POST', '/api/billing/google/verify', { productId: p.itemId, purchaseToken: p.purchaseToken }); n++; } catch { /* another account / not ours */ }
    }
  } catch { /* Play not ready */ }
  if (n) emit('billing_updated', {});
  return n;
}

const fmtDate = (s) => { try { return new Date(s).toLocaleDateString(getLang(), { dateStyle: 'medium' }); } catch { return s; } };

/**
 * Plan cards with Google Play prices and a subscribe button, inside `el`. Returns false (and draws nothing) when the page
 * is not in the Play app or the owner has not set Google Play up — the caller then keeps its usual payment screen.
 */
export async function mountPlayPlans(el, { onDone = null } = {}) {
  if (!el || !canUsePlayBilling()) return false;
  let st;
  try { st = await billingStatus(); } catch { return false; }
  const kind = storeKind();
  if (!st[kind] || !st.products.length) return false;
  const prices = new Map((await listPlayProducts(st.products.map((p) => p.productId))).map((p) => [p.productId, p]));
  if (!prices.size) return false;
  const now = new Date().toISOString();
  const current = st.entitlements.find((e) => e.platform === kind && ['active', 'grace', 'cancelled'].includes(e.state) && e.expiresAt > now);
  const period = (m) => (Number(m) === 1 ? t('billing.perMonth') : t('billing.perMonths', { n: m }));
  el.classList.add('akb');
  el.innerHTML = `<h3 class="akb-title">${esc(t(tk('billing.title')))}</h3>
    ${st.products.filter((p) => p.tier !== 'pack' && prices.has(p.productId)).map((p) => {
      const mine = current?.productId === p.productId;
      return `<div class="akb-plan${p.tier === 'ai' || p.tier === 'branch_ai' ? ' akb-ai' : ''}${mine ? ' akb-mine' : ''}">
        <div class="akb-head"><b>${esc(t({ ai: 'billing.tierAi', branch: 'billing.tierBranch', branch_ai: 'billing.tierBranchAi' }[p.tier] || 'billing.tierBasic'))}</b><span class="akb-price">${esc(prices.get(p.productId).price)} <small>${esc(period(p.months))}</small></span></div>
        ${mine ? `<p class="akb-state">${esc(t('billing.current'))} · ${esc(t('billing.until', { date: fmtDate(current.expiresAt) }))}</p>`
    : `<button class="btn akb-buy" data-sku="${esc(p.productId)}">${esc(t('billing.subscribe'))}</button>`}
      </div>`;
    }).join('')}
    ${current ? `<a class="akb-manage" href="${MANAGE[kind]}" target="_blank" rel="noopener">${esc(t(tk('billing.manage')))}</a>` : ''}
    ${kind === 'apple' ? `<button class="btn alt sm akb-restore">${esc(t('billing.restore'))}</button>` : ''}`;
  el.querySelector('.akb-restore')?.addEventListener('click', async () => { const n = await syncPlayPurchases(); toast(t(n ? 'billing.restored' : 'billing.nothingToRestore')); if (n) await mountPlayPlans(el, { onDone }); });
  for (const b of el.querySelectorAll('.akb-buy')) {
    b.addEventListener('click', async () => {
      for (const x of el.querySelectorAll('.akb-buy')) x.disabled = true;
      const r = await playSubscribe(b.dataset.sku, { upgradeFrom: current && kind === 'google' ? { productId: current.productId, purchaseToken: current.purchaseToken } : null });
      if (r.ok) { onDone?.(r); await mountPlayPlans(el, { onDone }); } else for (const x of el.querySelectorAll('.akb-buy')) x.disabled = false;
    });
  }
  return true;
}

/** v8.2 the AI pack (Google one-time product): buy it in the Play app → the server adds the budget. */
export async function playBuyPack({ onDone = null } = {}) {
  if (!canUsePlayBilling()) return { ok: false, reason: 'unavailable' };
  let st;
  try { st = await billingStatus(); } catch { return { ok: false, reason: 'unavailable' }; }
  const pack = st.products.find((p) => p.tier === 'pack');
  if (!st[storeKind()] || !pack) { toast(t('billing.notConfigured')); return { ok: false, reason: 'not_configured' }; }
  return playSubscribe(pack.productId, { onDone });
}
