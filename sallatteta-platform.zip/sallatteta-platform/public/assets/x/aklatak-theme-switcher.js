(() => {
  'use strict';
  const role = location.pathname.includes('driver') ? 'driver' : location.pathname.includes('store') ? 'merchant' : 'customer';
  const key = 'aklatak-appearance-v1-' + role;
  const options = ['modern','luxury'];
  let current;
  try { current = localStorage.getItem(key); } catch (_) {}
  if (!options.includes(current)) current='modern';
  function apply(value) {
    if (!options.includes(value)) return;
    document.documentElement.setAttribute('data-ak-theme',value);
    document.querySelectorAll('.ak-theme-choice').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.theme===value)));
    try {localStorage.setItem(key,value);} catch (_) {}
  }
  apply(current);
  function createDialog() {
    if(document.getElementById('ak-theme-dialog')) return;
    const dialog=document.createElement('div'); dialog.id='ak-theme-dialog';dialog.className='ak-theme-dialog';dialog.hidden=true;
    dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-label','اختيار المظهر');
    dialog.innerHTML=`<div class="ak-theme-panel"><h2 class="ak-theme-title">🎨 اختر المظهر</h2><p class="ak-theme-desc">غيّر الألوان فوراً. اختيارك بينحفظ على هالجهاز.</p>
      <button type="button" class="ak-theme-choice" data-theme="modern"><span class="ak-theme-swatch" style="background:#ff602e"></span><span><b>العصري</b><small>برتقالي، أبيض وأسود</small></span></button>
      <button type="button" class="ak-theme-choice" data-theme="luxury"><span class="ak-theme-swatch" style="background:#a92342"></span><span><b>الفاخر</b><small>أحمر داكن وأبيض</small></span></button>
      <button type="button" class="ak-theme-close">إغلاق</button></div>`;
    document.body.append(dialog);
    const close=()=>{dialog.hidden=true;document.removeEventListener('keydown',escape);};
    const escape=e=>{if(e.key==='Escape')close();};
    dialog.querySelector('.ak-theme-close').addEventListener('click',close);
    dialog.addEventListener('click',e=>{if(e.target===dialog)close();});
    dialog.querySelectorAll('.ak-theme-choice').forEach(b=>b.addEventListener('click',()=>{apply(b.dataset.theme);close();}));
    window.aklatakOpenTheme=()=>{dialog.hidden=false;apply(document.documentElement.dataset.akTheme||'modern');document.addEventListener('keydown',escape);dialog.querySelector('.ak-theme-choice').focus();};
  }
  function mount() {
    createDialog();
    const buttons=[...document.querySelectorAll('.ak-theme-button')];
    buttons.slice(1).forEach(button=>button.remove());
    if(buttons.length) return;
    const lang=document.querySelector('#langbtn, #lang');
    const header=document.querySelector('.brandbar');
    if(!lang && !header) return;
    const button=document.createElement('button');
    button.type='button';button.className='ak-theme-button';button.textContent='🎨';
    button.title='اختيار المظهر';button.setAttribute('aria-label','اختيار المظهر');
    button.addEventListener('click',()=>window.aklatakOpenTheme());
    if(lang)lang.insertAdjacentElement('afterend',button);else header.append(button);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
  const observer=new MutationObserver(()=>{if(!document.body)return;mount();});
  observer.observe(document.documentElement,{subtree:true,childList:true});
})();
