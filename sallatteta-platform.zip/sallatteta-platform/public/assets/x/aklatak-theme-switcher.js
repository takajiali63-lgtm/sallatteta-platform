(() => {
  'use strict';
  const uiText = {"ar":{"theme_title": "اختر المظهر", "theme_desc": "غيّر الألوان فوراً. اختيارك محفوظ على هذا الجهاز.", "theme_modern": "العصري", "theme_modern_desc": "برتقالي وأبيض وأسود", "theme_luxury": "الفاخر", "theme_luxury_desc": "خمري داكن وذهبي", "theme_close": "إغلاق", "theme_button": "اختيار المظهر"},"en":{"theme_title": "Choose appearance", "theme_desc": "Change colors instantly. Your choice is saved on this device.", "theme_modern": "Modern", "theme_modern_desc": "Orange, white and black", "theme_luxury": "Luxury", "theme_luxury_desc": "Dark burgundy and gold", "theme_close": "Close", "theme_button": "Choose appearance"},"fr":{"theme_title": "Choisir le thème", "theme_desc": "Changez les couleurs immédiatement. Votre choix est enregistré sur cet appareil.", "theme_modern": "Moderne", "theme_modern_desc": "Orange, blanc et noir", "theme_luxury": "Prestige", "theme_luxury_desc": "Bordeaux foncé et or", "theme_close": "Fermer", "theme_button": "Choisir le thème"},"es":{"theme_title": "Elegir apariencia", "theme_desc": "Cambia los colores al instante. Tu elección se guarda en este dispositivo.", "theme_modern": "Moderno", "theme_modern_desc": "Naranja, blanco y negro", "theme_luxury": "Lujo", "theme_luxury_desc": "Burdeos oscuro y dorado", "theme_close": "Cerrar", "theme_button": "Elegir apariencia"}};
  const tr=(k)=>{const l=document.documentElement.lang?.slice(0,2)||'ar';return (uiText[l]||uiText.ar)[k]||uiText.ar[k]||k;};
  const role = location.pathname.includes('driver') ? 'driver' : location.pathname.includes('store') ? 'merchant' : 'customer';
  const key = 'aklatak-appearance-v1-' + role;
  const options = ['modern','luxury'];
  let current;
  try { current = localStorage.getItem(key); } catch (_) {}
  if (!options.includes(current)) current='modern';
  function apply(value) {
    if (!options.includes(value)) return;
    document.documentElement.setAttribute('data-ak-theme',value);
    document.querySelectorAll('.ak-theme-choice').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.theme===value)));
    try {localStorage.setItem(key,value);} catch (_) {}
  }
  apply(current);
  function createDialog() {
    if(document.getElementById('ak-theme-dialog')) return;
    const dialog=document.createElement('div'); dialog.id='ak-theme-dialog';dialog.className='ak-theme-dialog';dialog.hidden=true;
    dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-label',tr('theme_button'));
    dialog.innerHTML=`<div class="ak-theme-panel"><h2 class="ak-theme-title">${tr('theme_title')}</h2><p class="ak-theme-desc">${tr('theme_desc')}</p>
      <button type="button" class="ak-theme-choice" data-theme="modern"><span class="ak-theme-swatch" style="background:#ff602e"></span><span><b>${tr('theme_modern')}</b><small>${tr('theme_modern_desc')}</small></span></button>
      <button type="button" class="ak-theme-choice" data-theme="luxury"><span class="ak-theme-swatch" style="background:#a92342"></span><span><b>${tr('theme_luxury')}</b><small>${tr('theme_luxury_desc')}</small></span></button>
      <button type="button" class="ak-theme-close">${tr('theme_close')}</button></div>`;
    document.body.append(dialog);
    const close=()=>{dialog.hidden=true;document.removeEventListener('keydown',escape);};
    const escape=e=>{if(e.key==='Escape')close();};
    dialog.querySelector('.ak-theme-close').addEventListener('click',close);
    dialog.addEventListener('click',e=>{if(e.target===dialog)close();});
    dialog.querySelectorAll('.ak-theme-choice').forEach(b=>b.addEventListener('click',()=>{apply(b.dataset.theme);close();}));
    window.aklatakOpenTheme=()=>{dialog.hidden=false;apply(document.documentElement.dataset.akTheme||'modern');document.addEventListener('keydown',escape);dialog.querySelector('.ak-theme-choice').focus();};
  }
  function mount() {
    createDialog();
    const buttons=[...document.querySelectorAll('.ak-theme-button')];
    buttons.slice(1).forEach(button=>button.remove());
    if(buttons.length) return;
    const lang=document.querySelector('#langbtn, #lang');
    const header=document.querySelector('.brandbar');
    if(!lang && !header) return;
    const button=document.createElement('button');
    button.type='button';button.className='ak-theme-button';button.textContent='🎨';
    button.title=tr('theme_button');button.setAttribute('aria-label',tr('theme_button'));
    button.addEventListener('click',()=>window.aklatakOpenTheme());
    if(lang)lang.insertAdjacentElement('afterend',button);else header.append(button);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
  const observer=new MutationObserver(()=>{if(!document.body)return;mount();});
  observer.observe(document.documentElement,{subtree:true,childList:true});
})();
