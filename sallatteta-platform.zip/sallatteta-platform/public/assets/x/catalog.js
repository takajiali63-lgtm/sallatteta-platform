// v8.4 catalog screens, shared by the customer app, the store dashboard and the driver app:
// product options sheet, «Offers» row, business-page details, preparation status, craftspeople's quotes,
// independent drivers (list, profile, booking, their services screen) and drivers' quotes on customers' requests.
// Prices shown here are previews only — the server always recomputes them from the database.
import { t, esc, $, $$, api, errText, toast, sheet, fmtDist, money, fmtTime, getLang, getCountry, shrinkImage, pickOnMap, locate, emit } from './core.js';

// the stylesheet comes with the module (no change needed in the pages)
if (!document.querySelector('link[data-catalog-css]')) {
  const l = document.createElement('link');
  l.rel = 'stylesheet'; l.href = '/assets/x/catalog.css?v=840'; l.dataset.catalogCss = '1';
  document.head.appendChild(l);
}

const T = (k, v) => t(`catalog.${k}`, v);
const cents = (n) => Math.round(Number(n || 0) * 100);
/** Error text: this module's own messages first (item gone, option missing…), then the app's. */
export function cerr(e) {
  const k = `catalog.err_${e?.code}`;
  const s = t(k);
  return s === k ? errText(e) : s;
}
const stars = (r) => (r?.avg ? `⭐ ${r.avg} <span class="mute tiny">(${r.count})</span>` : `<span class="mute tiny">${esc(T('noRating'))}</span>`);
const VEH = { moto: '🛵', car: '🚗' };
const dayNames = () => { try { const f = new Intl.DateTimeFormat(getLang(), { weekday: 'long' }); return [0, 1, 2, 3, 4, 5, 6].map((d) => f.format(new Date(Date.UTC(2023, 0, 1 + d, 12)))); } catch { return ['0', '1', '2', '3', '4', '5', '6']; } };
/** Opening hours as text: "every day 09:00–22:00 · closed: Friday". */
export function hoursText(h) {
  if (!h) return '';
  const days = dayNames();
  const closed = (h.closed || []).length ? ` · ${T('closedOn')}: ${(h.closed || []).map((d) => days[d]).join('، ')}` : '';
  return (h.allDay ? T('allDay') : `${h.open}–${h.close}`) + closed;
}

/* ====================================================================================================
   CUSTOMER — product sheet (options & extras), menu helpers, cart price check
   ==================================================================================================== */
/** Price preview of one unit: base + chosen options − the running offer (the server has the last word). */
export function unitPreview(item, chosenIds = []) {
  const all = (item.options || []).flatMap((g) => g.options);
  let c = cents(item.price) + chosenIds.reduce((a, id) => a + Number(all.find((o) => o.id === id)?.priceCents || 0), 0);
  if (item.promo) c -= item.promo.kind === 'percent' ? Math.round((c * item.promo.value) / 100) : Math.min(c, cents(item.promo.value));
  return Math.max(0, c) / 100;
}
/** Menu card extras: offer badge + crossed old price, "unavailable" label, "choose options" hint. */
export function menuBadges(m) {
  if (m.available === false) return `<span class="chip b ak-unavail-chip">${esc(T('unavailable'))}${m.availFrom ? ` · ${esc(m.availFrom)}–${esc(m.availTo)}` : ''}</span>`;
  return `${m.promo ? `<span class="chip g ak-promo-chip">🏷 ${esc(m.promo.label)}</span>` : ''}${m.options?.length ? `<span class="chip ak-opt-chip">${esc(T('hasOptions'))}</span>` : ''}`;
}
export function menuPrice(m) {
  if (m.price == null) return '';
  return m.promo ? `<div class="ak-product-price"><s class="mute">${esc(money(m.price, m.currency))}</s> ${esc(money(m.promo.price, m.currency))}</div>` : `<div class="ak-product-price">${esc(money(m.price, m.currency))}</div>`;
}

/**
 * The product sheet: photo, description, option groups ("choose 1, required" / "up to N"), quantity and a live price.
 * onAdd({ id, name, price, currency, options: [ids], optNames: [names], qty }) is called with a valid choice.
 */
export function productSheet(item, { canOrder = true, onAdd } = {}) {
  const groups = item.options || [];
  let qty = 1;
  const sh = sheet(`<div class="ak-psheet">
    ${item.photo ? `<img class="ak-psheet-photo" src="${esc(item.photo)}" alt="">` : `<div class="ak-psheet-photo ph" aria-hidden="true">🛍️</div>`}
    <h2>${esc(item.name)}</h2>${item.description ? `<p class="mute small">${esc(item.description)}</p>` : ''}
    <div class="chips">${menuBadges(item)}</div>
    <form id="psf">${groups.map((g) => `<fieldset class="ak-ogroup" data-g="${g.id}" data-min="${g.min}" data-max="${g.max}">
        <legend><b>${esc(g.name)}</b> <span class="chip ${g.min ? 'w' : ''}">${esc(g.min ? (g.max === 1 ? T('chooseOneReq') : T('chooseReq', { min: g.min, max: g.max })) : T('upTo', { n: g.max }))}</span></legend>
        ${g.options.map((o) => `<label class="check ak-opt ${o.available ? '' : 'off'}"><input type="${g.max === 1 ? 'radio' : 'checkbox'}" name="g${g.id}" value="${o.id}" ${o.available ? '' : 'disabled'}>
          <span>${esc(o.name)}${o.available ? '' : ` <small class="mute">(${esc(T('unavailable'))})</small>`}</span><b class="ak-opt-price">${o.priceCents ? `+${esc(money(o.priceCents / 100, item.currency))}` : ''}</b></label>`).join('')}
      </fieldset>`).join('')}
      ${canOrder && item.available !== false && item.price != null ? `<div class="row ak-psheet-foot"><div class="qty"><button type="button" data-pq="-1" aria-label="-">−</button><b id="pqn">1</b><button type="button" data-pq="1" aria-label="+">+</button></div>
        <button class="btn" id="padd">${esc(T('addToCart'))} · <span id="ptot"></span></button></div>` : `<p class="note">${esc(item.available === false ? T('unavailableLong') : T('viewOnly'))}</p>`}
    </form><button class="btn alt" type="button" data-close>${esc(t('common.close'))}</button></div>`);
  const f = $('#psf', sh.el);
  const chosen = () => $$('input:checked', f).map((x) => Number(x.value));
  const paint = () => {
    for (const fs of $$('fieldset[data-max]', f)) {   // "up to N": the others are disabled once N are ticked
      const max = Number(fs.dataset.max), boxes = $$('input[type=checkbox]', fs);
      const n = boxes.filter((b) => b.checked).length;
      boxes.forEach((b) => { if (!b.checked) b.disabled = n >= max || b.closest('.ak-opt').classList.contains('off'); });
    }
    const p = $('#ptot', sh.el);
    if (p) p.textContent = money(unitPreview(item, chosen()) * qty, item.currency);
  };
  f.addEventListener('change', paint);
  sh.el.addEventListener('click', (e) => { const b = e.target.closest('[data-pq]'); if (!b) return; qty = Math.max(1, Math.min(50, qty + Number(b.dataset.pq))); $('#pqn', sh.el).textContent = qty; paint(); });
  f.addEventListener('submit', (e) => {
    e.preventDefault();
    const ids = chosen();
    for (const g of groups) {
      const n = g.options.filter((o) => ids.includes(o.id)).length;
      if (n < g.min) return toast(T('pickRequired', { g: g.name }));
      if (n > g.max) return toast(T('tooMany', { g: g.name, n: g.max }));
    }
    const names = groups.flatMap((g) => g.options.filter((o) => ids.includes(o.id)).map((o) => o.name));
    onAdd?.({ id: item.id, name: item.name, price: unitPreview(item, ids), currency: item.currency, options: ids, optNames: names, qty });   // the cart plays «cart_add»
    sh.close();
  });
  paint();
  return sh;
}

/**
 * Ask the server for today's prices of the cart. Returns { lines, total } or, when something is no longer available,
 * { gone: { itemId, optionId }, message } so the cart can remove that line and say why.
 */
export async function checkCart(storeId, lines) {
  try {
    return await api('POST', '/api/delivery/cart/price', { storeId, items: lines.map((l) => ({ id: Number(l.id), qty: l.qty, options: l.options || [] })) });
  } catch (e) {
    if (e.data?.itemId && ['item_unavailable', 'option_required', 'too_many_options', 'option_invalid'].includes(e.code)) {
      return { gone: { itemId: e.data.itemId, optionId: e.data.optionId || null, code: e.code }, message: T(e.code === 'item_unavailable' ? 'removedUnavailable' : 'removedChanged', { name: e.data.name || '' }) };
    }
    throw e;
  }
}
/** Same answer from "send order": which line to remove (or null). */
export function goneFromError(e) {
  if (!e?.data?.itemId || !['item_unavailable', 'option_required', 'too_many_options', 'option_invalid'].includes(e.code)) return null;
  return { gone: { itemId: e.data.itemId, optionId: e.data.optionId || null, code: e.code }, message: T(e.code === 'item_unavailable' ? 'removedUnavailable' : 'removedChanged', { name: e.data.name || '' }) };
}

/* ====================================================================================================
   CUSTOMER — «Offers» (home row + page)
   ==================================================================================================== */
const locQ = (loc) => (loc?.lat != null ? `lat=${loc.lat}&lng=${loc.lng}&` : '');
function offerCard(o) {
  const img = o.item?.photo || o.store.photoUrl;
  return `<div class="ak-nearby-item ak-offer-item">
    <a class="ak-nearby-card" href="#/s/${o.store.id}"><div class="ak-nearby-cover">${img ? `<img src="${esc(img)}" alt="" loading="lazy">` : '<span aria-hidden="true">🏷</span>'}<span class="badge ak-offer-badge">${esc(o.label)}</span></div></a>
    <div class="ak-nearby-name">${esc(o.item ? o.item.name : o.section || o.store.name)}</div>
    <div class="ak-nearby-distance">${o.item ? `<s>${esc(money(o.item.price, o.item.currency))}</s> <b>${esc(money(o.item.newPrice, o.item.currency))}</b>` : esc(o.store.name)}${o.distanceM != null ? ` · ${esc(fmtDist(o.distanceM))}` : ''}</div>
  </div>`;
}
/** The «Offers» row for the home page (empty string when there is none). Put it FIRST in loadHomeExtra. */
export async function loadOffersRow({ country = getCountry(), loc = null } = {}) {
  try {
    const r = await api('GET', `/api/delivery/offers?${locQ(loc)}country=${country}&limit=12`);
    if (!r.offers.length) return '';
    return `<section class="hrow ak-offers-row"><div class="row"><h2>🏷 ${esc(T('offers'))}</h2><a class="small" href="#/offers">${esc(t('home.all'))}</a></div>
      <div class="ak-store-grid hscroll">${r.offers.map(offerCard).join('')}</div></section>`;
  } catch { return ''; }
}
/** #/offers — every running offer, paged (location optional, never called "nearest" without one). */
export async function viewOffers(root, { country = getCountry(), loc = null } = {}) {
  root.innerHTML = `<button class="iconbtn" data-back>${getLang() === 'ar' ? '→' : '←'}</button><h1>🏷 ${esc(T('offers'))}</h1><div id="offl"><div class="skel cover"></div></div>`;
  $('[data-back]', root).onclick = () => (history.length > 1 ? history.back() : (location.hash = '#/'));
  let page = 0;
  const box = $('#offl', root);
  const load = async () => {
    const r = await api('GET', `/api/delivery/offers?${locQ(loc)}country=${country}&limit=24&page=${page}`);
    if (!page) box.innerHTML = r.offers.length ? `<p class="mute small">${esc(r.sorted === 'distance' ? T('offersNear') : T('offersAll'))}</p><div class="ak-store-grid" id="offg"></div>` : `<div class="empty">${esc(T('noOffers'))}</div>`;
    $('#offg', root)?.insertAdjacentHTML('beforeend', r.offers.map(offerCard).join(''));
    $('#offMore', root)?.remove();
    if (r.hasMore) { box.insertAdjacentHTML('beforeend', `<button class="btn alt" id="offMore">${esc(t('common.more'))} ▾</button>`); $('#offMore', root).onclick = () => { page++; load().catch((e) => toast(cerr(e))); }; }
  };
  try { await load(); } catch (e) { box.innerHTML = `<div class="empty">${esc(cerr(e))}</div>`; }
}

/* ====================================================================================================
   CUSTOMER — business page details (hours, towns served, contacts, share, gallery with captions)
   ==================================================================================================== */
export function businessInfoHtml(s) {
  const lang = getLang();
  const areas = (s.areas || []).map((a) => (lang === 'ar' ? a.ar : a.en)).filter(Boolean);
  const gallery = s.gallery || [];
  return `<div class="card ak-bizinfo">
      <div class="row"><h3>ℹ️ ${esc(T('aboutBiz'))}</h3><button class="btn sm alt" id="akShare">🔗 ${esc(T('share'))}</button></div>
      ${s.hours ? `<p class="small">🕐 ${esc(hoursText(s.hours))}</p>` : `<p class="small mute">🕐 ${esc(T('noHours'))}</p>`}
      ${areas.length ? `<p class="small">📍 ${esc(T('serves'))}: ${esc(areas.slice(0, 12).join('، '))}${areas.length > 12 ? '…' : ''}</p>` : ''}
      ${s.deliveryRadiusKm ? `<p class="small">🛵 ${esc(T('radius', { km: s.deliveryRadiusKm }))}</p>` : ''}
      <div class="ctabs">${s.whatsapp ? `<a class="btn sm alt" href="https://wa.me/${esc(s.whatsapp)}" target="_blank" rel="noopener">🟢 ${esc(t('common.whatsapp'))}</a>` : ''}
        ${s.callPhone ? `<a class="btn sm alt" href="tel:${esc(s.callPhone)}">📞 ${esc(t('common.call'))}</a>` : ''}</div>
    </div>
    <h2>🖼 ${esc(T('gallery'))}</h2>
    ${gallery.length ? `<div class="ak-gallery">${gallery.map((g) => `<figure><img src="${esc(g.url)}" alt="${esc(g.caption)}" loading="lazy">${g.caption ? `<figcaption>${esc(g.caption)}</figcaption>` : ''}</figure>`).join('')}</div>`
      : `<div class="ak-gallery-empty" role="img" aria-label="${esc(T('noPhotos'))}"><span aria-hidden="true">🖼</span><b>${esc(T('noPhotos'))}</b><small class="mute">${esc(T('noPhotosHint'))}</small></div>`}`;
}
/** Share button: the phone's share menu, or copy the canonical address (/c/<id>). */
export function bindShare(root, s) {
  const btn = $('#akShare', root);
  if (!btn) return;
  btn.onclick = async () => {
    const url = `${location.origin}${s.shareUrl || `/c/${s.id}`}`;
    try { if (navigator.share) { await navigator.share({ title: s.name, url }); return; } } catch { return; }
    try { await navigator.clipboard.writeText(url); toast(T('linkCopied')); } catch { prompt(T('share'), url); }
  };
}

/* ---------------- tracking: preparation ---------------- */
export function prepHtml(o) {
  if (o.readyAt && ['preparing', 'searching', 'assigned'].includes(o.status)) return `<div class="note g">✅ ${esc(T('readyForPickup'))}</div>`;
  if (o.prepMinutes && ['preparing', 'searching', 'assigned'].includes(o.status)) {
    const by = o.readyBy ? new Intl.DateTimeFormat(getLang(), { timeStyle: 'short' }).format(new Date(o.readyBy)) : '';
    return `<div class="note">⏱ ${esc(T('prepLine', { m: o.prepMinutes, at: by }))}</div>`;
  }
  return '';
}

/* ====================================================================================================
   CUSTOMER — craftspeople's quotes on "come to me" requests (orders → visits)
   ==================================================================================================== */
export function visitExtraHtml(v) {
  const q = v.quote;
  let out = '';
  if (v.jobStatus) out += `<p class="small"><span class="chip g">${esc(T(`job_${v.jobStatus}`))}</span>${v.price != null ? ` <b>${esc(money(v.price))}</b>` : ''}${v.jobAt ? ` · 📅 ${esc(fmtTime(v.jobAt))}` : ''}</p>`;
  if (q && q.status === 'sent' && !v.jobStatus) {
    out += q.expired ? `<p class="note small">${esc(T('quoteExpired'))}</p>`
      : `<div class="card hl ak-quote"><div class="row"><b>💬 ${esc(T('quoteFromCraft'))}</b><b class="big">${esc(money(q.price))}</b></div>
        ${q.note ? `<p class="small">${esc(q.note)}</p>` : ''}<p class="mute tiny">${esc(T('validUntil', { d: fmtTime(q.validUntil) }))}</p>
        <div class="grid2"><button class="btn" data-vq="${q.id}" data-vid="${v.id}" data-x="accept">✅ ${esc(T('acceptQuote'))}</button><button class="btn alt" data-vq="${q.id}" data-vid="${v.id}" data-x="reject">${esc(T('rejectQuote'))}</button></div></div>`;
  } else if (q && q.status === 'rejected' && !v.jobStatus) out += `<p class="mute tiny">${esc(T('quoteRejected'))}</p>`;
  if (v.jobStatus === 'completed') out += `<button class="btn acc" data-vconfirm="${v.id}">✔️ ${esc(T('confirmJob'))}</button>`;
  return out;
}
export function bindVisitActions(root, redraw) {
  $$('[data-vq]', root).forEach((b) => { b.onclick = async () => {
    if (b.dataset.x === 'accept' && !confirm(T('acceptQuoteQ'))) return;
    b.disabled = true;
    try { await api('POST', `/api/customer/visits/${b.dataset.vid}/quotes/${b.dataset.vq}/${b.dataset.x}`, {}); toast(t('common.done')); redraw(); } catch (e) { toast(cerr(e)); b.disabled = false; }
  }; });
  $$('[data-vconfirm]', root).forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/customer/visits/${b.dataset.vconfirm}/confirm`, {}); toast(t('common.done')); redraw(); } catch (e) { toast(cerr(e)); } }; });
}

/* ====================================================================================================
   CUSTOMER — independent drivers: list (#/drivers), profile (#/d/<id>), booking; quotes on a request (#/e/<id>)
   ==================================================================================================== */
const face = (d, cls = 'ak-dface') => (d.photo ? `<img class="${cls}" src="${esc(d.photo)}" alt="" loading="lazy">` : `<span class="${cls} ph" aria-hidden="true">${VEH[d.vehicle] || '🛵'}</span>`);
const priceTxt = (s) => (s.priceMode === 'fixed' && s.price != null ? money(s.price) : T('onQuote'));
function driverCard(d) {
  return `<a class="card ak-drv" href="#/d/${d.id}">${face(d)}<div class="ak-drv-body">
    <div class="row"><b>${esc(d.name)}</b><span class="small">${stars(d.rating)}</span></div>
    <div class="chips">${d.services.slice(0, 3).map((s) => `<span class="chip">${esc(s.typeName)} · ${esc(priceTxt(s))}</span>`).join('')}</div>
    <div class="chips">${d.distanceM != null ? `<span class="chip">📍 ${esc(T('about', { d: fmtDist(d.distanceM) }))}</span>` : ''}<span class="chip ${d.openNow ? 'g' : ''}">${esc(d.openNow ? T('availableNow') : T('notNow'))}</span></div>
  </div></a>`;
}
/** The home tile «Independent drivers» (a .cat button like the categories). */
export function driversTileHtml() {
  return `<a class="cat ak-drivers-tile" href="#/drivers"><span class="ak-real-icon" aria-hidden="true"><svg viewBox="0 0 64 64"><use href="#ak-delivery"></use></svg></span>${esc(T('independentDrivers'))}</a>`;
}
export async function viewDrivers(root, { country = getCountry(), loc = null, type = '' } = {}) {
  root.innerHTML = `<button class="iconbtn" data-back>${getLang() === 'ar' ? '→' : '←'}</button><h1>🛵 ${esc(T('independentDrivers'))}</h1>
    <p class="mute small">${esc(T('driversIntro'))}</p><div class="tabs ak-dtypes" id="dtypes"></div><div id="drl"><div class="skel cover"></div></div>
    <a class="card hl errand-cta" href="#/errand"><b>${esc(T('openRequest'))}</b><span class="mute small">${esc(T('openRequestSub'))}</span></a>`;
  $('[data-back]', root).onclick = () => (history.length > 1 ? history.back() : (location.hash = '#/'));
  let page = 0;
  const load = async (reset) => {
    if (reset) { page = 0; $('#drl', root).innerHTML = '<div class="skel cover"></div>'; }
    const r = await api('GET', `/api/delivery/drivers?${locQ(loc)}country=${country}&lang=${getLang()}${type ? `&type=${encodeURIComponent(type)}` : ''}&page=${page}`);
    if (reset || !page) {
      $('#dtypes', root).innerHTML = [{ key: '', names: { [getLang()]: t('home.all') } }, ...r.types].map((x) => `<button data-ty="${esc(x.key)}" class="${x.key === type ? 'on' : ''}">${esc(x.names[getLang()] || x.names.ar || x.key)}</button>`).join('');
      $$('[data-ty]', root).forEach((b) => { b.onclick = () => { type = b.dataset.ty; load(true).catch((e) => toast(cerr(e))); }; });
      $('#drl', root).innerHTML = r.drivers.length ? `<p class="mute tiny">${esc(r.sorted === 'distance' ? T('driversNear') : T('driversAll'))}</p><div id="drg"></div>` : `<div class="empty">${esc(T('noDrivers'))}</div>`;
    }
    $('#drg', root)?.insertAdjacentHTML('beforeend', r.drivers.map(driverCard).join(''));
    $('#drMore', root)?.remove();
    if (r.hasMore) { $('#drl', root).insertAdjacentHTML('beforeend', `<button class="btn alt" id="drMore">${esc(t('common.more'))} ▾</button>`); $('#drMore', root).onclick = () => { page++; load().catch((e) => toast(cerr(e))); }; }
  };
  try { await load(true); } catch (e) { $('#drl', root).innerHTML = `<div class="empty">${esc(cerr(e))}</div>`; }
}
/**
 * #/d/<id>: a driver's public profile and services; "request this service" books it.
 * ctx = { ensureLogin, pickPlace, loc, maxPurchase } from the app (sign-in sheet and place picker).
 */
export async function viewDriver(root, id, ctx = {}) {
  root.innerHTML = '<div class="skel hero"></div>';
  let d, types = [];
  try {
    d = (await api('GET', `/api/delivery/drivers/${id}?${locQ(ctx.loc)}country=${getCountry()}&lang=${getLang()}`)).driver;
    types = (await api('GET', '/api/delivery/service-types')).types;
  } catch (e) { root.innerHTML = `<div class="empty">${esc(cerr(e))}</div>`; return; }
  const lang = getLang();
  root.innerHTML = `<button class="iconbtn" data-back>${lang === 'ar' ? '→' : '←'}</button>
    <div class="ak-dprof">${face(d, 'ak-dface big')}<div><h1>${esc(d.name)}</h1><div class="small">${stars(d.rating)} · ${VEH[d.vehicle] || ''}</div></div></div>
    <p class="note small">🔒 ${esc(T('privacyNote'))}</p>
    ${d.services.map((s) => `<div class="card ak-svc">
      <div class="row"><b>${esc(s.typeName)}</b><b class="big">${esc(priceTxt(s))}</b></div>
      <p>${esc(s.description)}</p>
      <div class="chips"><span class="chip">📍 ${esc(s.areaMode === 'radius' ? T('withinKm', { km: s.radiusKm }) : s.areas.map((a) => a.name).join('، '))}</span>
        <span class="chip ${s.openNow ? 'g' : ''}">🕐 ${esc(s.hours ? hoursText(s.hours) : T('anyTime'))}</span>
        ${s.minNoticeMin ? `<span class="chip">⏳ ${esc(T('notice', { m: s.minNoticeMin }))}</span>` : ''}${s.servesYou === false ? `<span class="chip b">${esc(T('notYourArea'))}</span>` : ''}</div>
      ${s.bookingNote ? `<p class="mute small">📝 ${esc(s.bookingNote)}</p>` : ''}
      <button class="btn" data-book="${s.id}" ${s.openNow ? '' : 'disabled'}>${esc(s.openNow ? T('requestService') : T('notNow'))}</button></div>`).join('') || `<div class="empty">${esc(T('noServices'))}</div>`}`;
  $('[data-back]', root).onclick = () => (history.length > 1 ? history.back() : (location.hash = '#/drivers'));
  $$('[data-book]', root).forEach((b) => { b.onclick = () => bookSheet(d, d.services.find((s) => String(s.id) === b.dataset.book), types.find((x) => x.key === d.services.find((s) => String(s.id) === b.dataset.book)?.type), ctx); });
}
async function bookSheet(d, svc, type, ctx) {
  await ctx.ensureLogin?.();
  const st = { from: ctx.loc ? { ...ctx.loc, label: T('here') } : null, to: null };
  const sh = sheet(`<h2>${esc(svc.typeName)} — ${esc(d.name)}</h2><p class="mute small">${esc(svc.priceMode === 'fixed' ? T('bookFixed', { p: money(svc.price) }) : T('bookQuote'))}</p>
    <form id="bkf"><label class="f">${esc(T('what'))}<textarea class="in" name="desc" required minlength="3" maxlength="500" placeholder="${esc(svc.bookingNote || T('whatPh'))}"></textarea></label>
    <div class="row"><b>${esc(t('errand.from'))}</b><button class="btn sm alt" type="button" id="bkFrom">${esc(st.from?.label || t('errand.pick'))}</button></div>
    <input class="in" name="fd" maxlength="300" placeholder="${esc(t('errand.details'))}">
    <div class="row"><b>${esc(t('errand.to'))}</b><button class="btn sm alt" type="button" id="bkTo">${esc(t('errand.pick'))}</button></div>
    <input class="in" name="td" maxlength="300" placeholder="${esc(t('errand.details'))}">
    ${type?.errand === 'buy' ? `<label class="f">${esc(t('errand.purchase'))}<input class="in" name="pv" type="number" min="0" max="${ctx.maxPurchase || 50}" step="0.5" inputmode="decimal"></label>` : ''}
    <div class="note small">${esc(t('errand.notice'))}</div>
    <button class="btn">${esc(T('sendRequest'))}</button></form>`);
  const pick = async (k, btn) => { const p = await ctx.pickPlace?.(); if (p) { st[k] = p; btn.textContent = p.label || '📍'; } };
  $('#bkFrom', sh.el).onclick = (e) => pick('from', e.currentTarget);
  $('#bkTo', sh.el).onclick = (e) => pick('to', e.currentTarget);
  $('#bkf', sh.el).addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    if (!st.from || !st.to) return toast(t('errand.pick'));
    const btn = $('button:not([type])', f) || $('button[type=submit]', f);
    btn && (btn.disabled = true);
    try {
      const r = await api('POST', `/api/delivery/drivers/${d.id}/book`, { serviceId: svc.id, description: f.desc.value,
        from: { lat: st.from.lat, lng: st.from.lng, details: f.fd.value }, to: { lat: st.to.lat, lng: st.to.lng, details: f.td.value },
        purchaseValue: f.pv && f.pv.value !== '' ? Number(f.pv.value) : undefined });
      sh.close(); toast(T('requestSent')); location.hash = `#/e/${r.id}`;
    } catch (x) { toast(cerr(x)); btn && (btn.disabled = false); }
  });
}

/** Drivers' quotes on a request (shown while it is searching). Accepting one gives him the request at that price. */
export async function renderErrandQuotes(box, errandId, onAccepted) {
  if (!box) return;
  let quotes = [];
  try { quotes = (await api('GET', `/api/customer/errands/${errandId}/quotes`)).quotes.filter((x) => x.status === 'sent'); } catch { return; }
  if (!box.isConnected) return;
  box.innerHTML = quotes.length ? `<h3>💬 ${esc(T('quotesTitle', { n: quotes.length }))}</h3>${quotes.map((x) => `<div class="card ak-quote">
      <div class="row"><span class="ak-drvline">${face(x.driver)}<b>${esc(x.driver.name)}</b> <span class="small">${stars(x.driver.rating)}</span></span><b class="big">${esc(money(x.price))}</b></div>
      ${x.note ? `<p class="small">${esc(x.note)}</p>` : ''}<button class="btn" data-qa="${x.id}">✅ ${esc(T('chooseQuote', { p: money(x.price) }))}</button></div>`).join('')}`
    : `<p class="note small">⏳ ${esc(T('waitingQuotes'))}</p>`;
  $$('[data-qa]', box).forEach((b) => { b.onclick = async () => {
    if (!confirm(T('chooseQuoteQ'))) return;
    $$('[data-qa]', box).forEach((x) => { x.disabled = true; });
    try { await api('POST', `/api/customer/errands/${errandId}/quotes/${b.dataset.qa}/accept`, {}); toast(T('quoteChosen')); onAccepted?.(); }
    catch (e) { toast(cerr(e)); onAccepted?.(); }
  }; });
}
/** Stars for a finished request with a driver. */
export function bindErrandRating(root, e) {
  const box = $('#erate', root);
  if (!box || e.status !== 'delivered' || !e.driver || e.rating) return;
  box.innerHTML = `<div class="card"><b>⭐ ${esc(T('rateDriver'))}</b><div class="stars">${[1, 2, 3, 4, 5].map((n) => `<button type="button" data-es="${n}" aria-label="${n}">★</button>`).join('')}</div></div>`;
  $$('[data-es]', box).forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/customer/errands/${e.id}/rate`, { stars: Number(b.dataset.es) }); box.innerHTML = `<p class="note g small">${esc(T('thanksRating'))}</p>`; } catch (x) { toast(cerr(x)); } }; });
}

/* ====================================================================================================
   STORE — options & availability editor, promotions, preparation, craftspeople's quotes, gallery captions
   ==================================================================================================== */
/** Sheet to edit a product's option groups and its daily availability window. onSaved() after saving. */
export async function extrasSheet(item, onSaved) {
  let data;
  try { data = await api('GET', `/api/store/menu/${item.id}/extras`); } catch (e) { toast(cerr(e)); return; }
  let groups = data.groups.map((g) => ({ name: g.name, min: g.min, max: g.max, options: g.options.map((o) => ({ ...o })) }));
  const sh = sheet(`<h2>⚙️ ${esc(T('extrasTitle'))}</h2><p class="mute small">${esc(item.name)}</p>
    <div class="card"><h3>🕐 ${esc(T('availWindow'))}</h3><p class="mute tiny">${esc(T('availHint'))}</p>
      <div class="grid2"><label class="f">${esc(T('from'))}<input class="in" type="time" id="avf" value="${esc(data.availFrom || '')}"></label><label class="f">${esc(T('to'))}<input class="in" type="time" id="avt" value="${esc(data.availTo || '')}"></label></div></div>
    <div id="egs"></div><button class="btn alt" type="button" id="addg">➕ ${esc(T('addGroup'))}</button>
    <button class="btn" id="esave">${esc(t('common.save'))}</button><button class="btn alt" data-close>${esc(t('common.close'))}</button>`);
  const keep = () => {
    $$('[data-gi]', sh.el).forEach((box) => {
      const g = groups[Number(box.dataset.gi)];
      g.name = $('[data-k=name]', box).value;
      g.min = $('[data-k=req]', box).checked ? Math.max(1, Number(g.min) || 1) : 0;
      g.max = Number($('[data-k=max]', box).value) || 1;
      $$('[data-oi]', box).forEach((row) => { const o = g.options[Number(row.dataset.oi)]; o.name = $('[data-k=oname]', row).value; o.price = Number($('[data-k=oprice]', row).value || 0); o.available = $('[data-k=oav]', row).checked; });
    });
  };
  const draw = () => {
    $('#egs', sh.el).innerHTML = groups.map((g, gi) => `<div class="card ak-egroup" data-gi="${gi}">
      <div class="row"><input class="in" data-k="name" maxlength="40" placeholder="${esc(T('groupPh'))}" value="${esc(g.name)}"><button class="btn sm bad" type="button" data-rg="${gi}" aria-label="${esc(t('merchant.delete'))}">✕</button></div>
      <div class="grid2"><label class="check"><input type="checkbox" data-k="req" ${g.min ? 'checked' : ''}><span>${esc(T('required'))}</span></label>
        <label class="f small">${esc(T('maxChoices'))}<input class="in" type="number" min="1" max="20" data-k="max" value="${g.max}"></label></div>
      ${g.options.map((o, oi) => `<div class="ak-eopt" data-oi="${oi}"><input class="in" data-k="oname" maxlength="40" placeholder="${esc(T('optionPh'))}" value="${esc(o.name)}">
        <input class="in ak-eprice" data-k="oprice" type="number" min="0" step="0.25" inputmode="decimal" value="${o.price ?? 0}" aria-label="${esc(T('addsPrice'))}">
        <label class="check ak-eav" title="${esc(T('available'))}"><input type="checkbox" data-k="oav" ${o.available === false ? '' : 'checked'}><span>✓</span></label>
        <button class="btn sm alt" type="button" data-ro="${gi}:${oi}" aria-label="${esc(t('merchant.delete'))}">✕</button></div>`).join('')}
      <button class="btn sm alt" type="button" data-ao="${gi}">➕ ${esc(T('addOption'))}</button></div>`).join('') || `<p class="mute small">${esc(T('noGroups'))}</p>`;
  };
  draw();
  sh.el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-rg],[data-ro],[data-ao],#addg');
    if (!b) return;
    keep();
    if (b.id === 'addg') groups.push({ name: '', min: 0, max: 1, options: [{ name: '', price: 0, available: true }] });
    else if (b.dataset.rg) groups.splice(Number(b.dataset.rg), 1);
    else if (b.dataset.ao) groups[Number(b.dataset.ao)].options.push({ name: '', price: 0, available: true });
    else { const [gi, oi] = b.dataset.ro.split(':').map(Number); groups[gi].options.splice(oi, 1); }
    draw();
  });
  $('#esave', sh.el).onclick = async () => {
    keep();
    const f = $('#avf', sh.el).value, to = $('#avt', sh.el).value;
    if ((f && !to) || (!f && to)) return toast(T('windowBoth'));
    for (const g of groups) {
      if (!g.name.trim() || !g.options.length || g.options.some((o) => !o.name.trim())) return toast(T('fillNames'));
      if (g.max > g.options.length) g.max = g.options.length;
      if (g.min > g.max) g.min = g.max;
    }
    try {
      await api('PUT', `/api/store/menu/${item.id}/extras`, { groups: groups.map((g) => ({ name: g.name, min: g.min, max: g.max, options: g.options.map((o) => ({ name: o.name, price: o.price, available: o.available !== false })) })), availFrom: f || null, availTo: to || null });
      toast(t('common.saved')); sh.close(); onSaved?.();
    } catch (x) { toast(cerr(x)); }
  };
}

/** The store's «Offers» tab: create, switch off, delete. me = the store (menu, menuSections). */
export async function panePromotions(pane, me) {
  let list = [];
  try { list = (await api('GET', '/api/store/promotions')).promotions; } catch (e) { pane.innerHTML = `<div class="empty">${esc(cerr(e))}</div>`; return; }
  const menu = (me.menu || []).filter((m) => m.price != null);
  const sections = [...new Set([...(me.menuSections || []), ...menu.map((m) => m.section).filter(Boolean)])];
  pane.innerHTML = `<button class="btn" id="pnew">➕ ${esc(T('newOffer'))}</button>
    ${list.map((p) => `<div class="card ${p.live ? 'hl' : ''}"><div class="row"><b>🏷 ${esc(p.badge || (p.kind === 'percent' ? `-${p.value}%` : `-${money(p.value)}`))}</b><span class="chip ${p.live ? 'g' : ''}">${esc(p.live ? T('live') : p.active ? T('scheduledOrEnded') : T('off'))}</span></div>
      <p class="small">${esc(p.itemName || `${T('section')}: ${p.section}`)} · ${esc(p.kind === 'percent' ? `${p.value}%` : money(p.value))}</p>
      <p class="mute tiny">${esc(fmtTime(p.startsAt))} → ${esc(fmtTime(p.endsAt))}</p>
      <div class="grid2"><button class="btn sm alt" data-pt="${p.id}" data-on="${p.active ? 0 : 1}">${esc(p.active ? T('turnOff') : T('turnOn'))}</button><button class="btn sm bad" data-pd="${p.id}">🗑 ${esc(t('merchant.delete'))}</button></div></div>`).join('') || `<div class="empty">${esc(T('noOffersStore'))}</div>`}`;
  $$('[data-pt]', pane).forEach((b) => { b.onclick = async () => { try { await api('PATCH', `/api/store/promotions/${b.dataset.pt}`, { active: b.dataset.on === '1' }); panePromotions(pane, me); } catch (e) { toast(cerr(e)); } }; });
  $$('[data-pd]', pane).forEach((b) => { b.onclick = async () => { if (!confirm(t('merchant.deleteConfirm'))) return; try { await api('DELETE', `/api/store/promotions/${b.dataset.pd}`); panePromotions(pane, me); } catch (e) { toast(cerr(e)); } }; });
  $('#pnew', pane).onclick = () => {
    const day = (d) => new Date(Date.now() + d * 864e5).toISOString().slice(0, 10);
    const sh = sheet(`<h2>🏷 ${esc(T('newOffer'))}</h2><form id="pf">
      <label class="f">${esc(T('offerOn'))}<select class="in" name="target">${menu.map((m) => `<option value="i${m.id}">${esc(m.name)} — ${esc(money(m.price, m.currency))}</option>`).join('')}${sections.map((s) => `<option value="s${esc(s)}">🗂 ${esc(T('section'))}: ${esc(s)}</option>`).join('')}</select></label>
      <div class="grid2"><label class="f">${esc(T('kind'))}<select class="in" name="kind"><option value="percent">${esc(T('percent'))}</option><option value="fixed">${esc(T('fixed'))}</option></select></label>
        <label class="f">${esc(T('value'))}<input class="in" name="value" type="number" min="0.01" step="0.01" inputmode="decimal" required></label></div>
      <label class="f">${esc(T('badge'))}<input class="in" name="badge" maxlength="24" placeholder="${esc(T('badgePh'))}"></label>
      <div class="grid2"><label class="f">${esc(T('starts'))}<input class="in" name="starts" type="date" value="${day(0)}"></label><label class="f">${esc(T('ends'))}<input class="in" name="ends" type="date" value="${day(7)}" required></label></div>
      <button class="btn">${esc(t('common.save'))}</button></form>`);
    $('#pf', sh.el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target, tg = f.target.value;
      if (!tg) return toast(T('noProducts'));
      const starts = f.starts.value === day(0) ? new Date().toISOString() : new Date(`${f.starts.value}T00:00:00`).toISOString();
      try {
        await api('POST', '/api/store/promotions', { ...(tg[0] === 'i' ? { itemId: Number(tg.slice(1)) } : { section: tg.slice(1) }), kind: f.kind.value, value: Number(f.value.value), badge: f.badge.value, startsAt: starts, endsAt: new Date(`${f.ends.value}T23:59:00`).toISOString() });
        sh.close(); panePromotions(pane, me);
      } catch (x) { toast(cerr(x)); }
    });
  };
}

/** Preparation controls in a store's order card: time to choose when accepting, "ready" button, countdown / late. */
export function prepAcceptHtml(o) {
  return `<label class="f small ak-prep">⏱ ${esc(T('prepTime'))}<select class="in" id="pm${o.id}"><option value="">—</option>${[5, 10, 15, 20, 30, 45, 60, 90].map((m) => `<option value="${m}" ${m === 20 ? 'selected' : ''}>${esc(T('minutes', { m }))}</option>`).join('')}</select></label>`;
}
export function prepStatusHtml(o) {
  if (!['preparing', 'searching', 'assigned'].includes(o.status)) return '';
  if (o.readyAt) return `<div class="note g small">✅ ${esc(T('markedReady'))}</div>`;
  const due = o.prepDueAt ? new Intl.DateTimeFormat(getLang(), { timeStyle: 'short' }).format(new Date(o.prepDueAt)) : '';
  return `${o.prepLate ? `<div class="note b small">⏰ ${esc(T('prepLate', { at: due }))}</div>` : due ? `<p class="small">⏱ ${esc(T('prepDue', { at: due }))}</p>` : ''}
    <button class="btn acc" data-a="ready" data-id="${o.id}">✅ ${esc(T('readyBtn'))}</button>`;
}
/** Body for "accept" with the chosen preparation time. */
export const acceptBody = (id) => { const v = document.getElementById(`pm${id}`)?.value; return v ? { prepMinutes: Number(v) } : {}; };
// app-wide sounds / AI alerts: each event once per order
const fired = { neu: new Set(), late: new Set(), remind: new Set() };
/** Call after each refresh of the store's orders. first = the very first load (no "new order" sound for old ones). */
export function storeOrderEvents(orders, { first = false } = {}) {
  for (const o of orders) {
    if (o.status === 'pending' && !fired.neu.has(o.id)) { fired.neu.add(o.id); if (!first) emit('store_new_order', { orderId: o.id }); }
    if (o.prepLate && !o.readyAt && !fired.late.has(o.id)) { fired.late.add(o.id); emit('order_delayed', { orderId: o.id }); }
    if (o.prepDueAt && !o.readyAt && !o.prepLate && !fired.remind.has(o.id) && Date.parse(o.prepDueAt) - Date.now() <= 2 * 60_000) { fired.remind.add(o.id); emit('prep_reminder', { orderId: o.id }); }
  }
}

/** A craftsperson's visit card: send a price, then the job steps. */
export function storeVisitExtraHtml(v) {
  const q = v.quote;
  let out = '';
  if (v.jobStatus) {
    out += `<p class="small"><span class="chip g">${esc(T(`job_${v.jobStatus}`))}</span> <b>${esc(money(v.price))}</b>${v.jobAt ? ` · 📅 ${esc(fmtTime(v.jobAt))}` : ''}</p>`;
    if (v.jobStatus === 'scheduled') out += `<button class="btn" data-vj="${v.id}" data-x="start">▶️ ${esc(T('startJob'))}</button>`;
    if (['scheduled', 'in_progress'].includes(v.jobStatus)) out += `<button class="btn acc" data-vj="${v.id}" data-x="complete">✔️ ${esc(T('completeJob'))}</button>`;
    if (v.jobStatus === 'completed') out += `<p class="note small">${esc(T('waitConfirm'))}</p>`;
  } else if (['pending', 'accepted'].includes(v.status)) {
    if (q) out += `<p class="small">💬 ${esc(T('yourQuote'))}: <b>${esc(money(q.price))}</b> · <span class="chip ${q.status === 'rejected' ? 'b' : ''}">${esc(q.expired ? T('expired') : T(`q_${q.status}`))}</span></p>`;
    out += `<button class="btn alt" data-vquote="${v.id}">💬 ${esc(q ? T('newQuote') : T('sendQuote'))}</button>`;
  }
  return out;
}
export function bindStoreVisits(root, redraw) {
  $$('[data-vj]', root).forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/store/visits/${b.dataset.vj}/job/${b.dataset.x}`, {}); redraw(); } catch (e) { toast(cerr(e)); } }; });
  $$('[data-vquote]', root).forEach((b) => { b.onclick = () => {
    const sh = sheet(`<h2>💬 ${esc(T('sendQuote'))}</h2><form id="vqf">
      <label class="f">${esc(T('price'))}<input class="in" name="price" type="number" min="1" step="0.5" inputmode="decimal" required></label>
      <label class="f">${esc(T('quoteNote'))}<textarea class="in" name="note" maxlength="300" placeholder="${esc(T('quoteNotePh'))}"></textarea></label>
      <div class="grid2"><label class="f">${esc(T('validFor'))}<select class="in" name="valid">${[6, 24, 48, 72, 168].map((h) => `<option value="${h}" ${h === 48 ? 'selected' : ''}>${esc(T('hours', { h }))}</option>`).join('')}</select></label>
        <label class="f">${esc(T('when'))}<input class="in" name="when" type="datetime-local"></label></div>
      <button class="btn">${esc(t('common.send'))}</button></form>`);
    $('#vqf', sh.el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      try { await api('POST', `/api/store/visits/${b.dataset.vquote}/quote`, { price: Number(f.price.value), note: f.note.value, validHours: Number(f.valid.value), when: f.when.value ? new Date(f.when.value).toISOString() : undefined }); sh.close(); toast(t('common.sent')); redraw(); } catch (x) { toast(cerr(x)); }
    });
  }; });
}
/** Gallery captions (portfolio): one field under each photo, saved when it changes. */
export function captionInput(p) { return `<input class="in ak-cap" data-cap="${p.id}" maxlength="80" placeholder="${esc(T('captionPh'))}" value="${esc(p.caption || '')}">`; }
export function bindCaptions(root) {
  $$('[data-cap]', root).forEach((inp) => { inp.onchange = async () => { try { await api('PATCH', `/api/store/photos/${inp.dataset.cap}`, { caption: inp.value }); toast(t('common.saved')); } catch (e) { toast(cerr(e)); } }; });
}

/* ====================================================================================================
   DRIVER — «My services» tab and quotes on requests
   ==================================================================================================== */
export async function tabServices(pane) {
  let r;
  try { r = await api('GET', `/api/driver/services?lang=${getLang()}`); } catch (e) { pane.innerHTML = `<div class="empty">${esc(cerr(e))}</div>`; return; }
  const lang = getLang();
  const tn = (k) => { const x = r.types.find((y) => y.key === k); return x?.names?.[lang] || x?.names?.ar || k; };
  pane.innerHTML = `<div class="toggle"><div><b>${esc(r.on ? T('listedOn') : T('listedOff'))}</b><div class="mute small">${esc(T('listedHint'))}</div></div><button class="sw${r.on ? ' on' : ''}" id="svon" aria-label="${esc(T('listedOn'))}"></button></div>
    ${r.jobsActive ? '' : `<div class="note b small">${esc(T('needJobs'))}</div>`}
    <div class="card"><div class="row"><b>📷 ${esc(T('publicPhoto'))}</b><label class="btn sm alt">${esc(r.hasPhoto ? T('changePhoto') : T('addPhoto'))}<input type="file" accept="image/*" class="hide" id="pph"></label></div>
      <p class="mute tiny">${esc(T('publicPhotoHint'))}</p></div>
    <button class="btn" id="svnew">➕ ${esc(T('addService'))}</button>
    ${r.services.map((s) => `<div class="card ${s.active ? '' : 'ak-off'}"><div class="row"><b>${esc(tn(s.type))}</b><b>${esc(priceTxt(s))}</b></div>
      <p class="small">${esc(s.description)}</p>
      <div class="chips"><span class="chip">📍 ${esc(s.areaMode === 'radius' ? T('withinKm', { km: s.radiusKm }) : s.areas.map((a) => a.name).join('، '))}</span><span class="chip">🕐 ${esc(s.hours ? hoursText(s.hours) : T('anyTime'))}</span>${s.active ? '' : `<span class="chip b">${esc(T('off'))}</span>`}</div>
      <div class="grid2"><button class="btn sm alt" data-sved="${s.id}">✏️ ${esc(T('edit'))}</button><button class="btn sm bad" data-svdel="${s.id}">🗑 ${esc(t('merchant.delete'))}</button></div></div>`).join('') || `<div class="empty">${esc(T('noServicesYet'))}</div>`}`;
  $('#svon', pane).onclick = async () => { try { await api('POST', '/api/driver/services-switch', { on: !r.on }); tabServices(pane); } catch (e) { toast(cerr(e)); } };
  $('#pph', pane).onchange = async (e) => { try { const photo = await shrinkImage(e.target.files[0], { max: 600, limit: 250_000 }); await api('POST', '/api/driver/profile-photo', { photo }); toast(t('common.saved')); tabServices(pane); } catch (x) { toast(x?.code ? cerr(x) : t('errors.validation_failed')); } };
  $('#svnew', pane).onclick = () => serviceSheet(r.types, null, () => tabServices(pane));
  $$('[data-sved]', pane).forEach((b) => { b.onclick = () => serviceSheet(r.types, r.services.find((s) => String(s.id) === b.dataset.sved), () => tabServices(pane)); });
  $$('[data-svdel]', pane).forEach((b) => { b.onclick = async () => { if (!confirm(t('merchant.deleteConfirm'))) return; try { await api('DELETE', `/api/driver/services/${b.dataset.svdel}`); tabServices(pane); } catch (e) { toast(cerr(e)); } }; });
}
function serviceSheet(types, s, done) {
  const lang = getLang();
  const st = { center: s?.center || null, areas: (s?.areas || []).map((a) => ({ id: a.id, name: a.name })) };
  const h = s?.hours || null, days = dayNames();
  const sh = sheet(`<h2>${esc(s ? T('editService') : T('addService'))}</h2><form id="svf">
    <label class="f">${esc(T('type'))}<select class="in" name="type">${types.map((x) => `<option value="${esc(x.key)}" ${s?.type === x.key ? 'selected' : ''}>${esc(x.names?.[lang] || x.names?.ar || x.key)}</option>`).join('')}</select></label>
    <p class="mute tiny">🚫 ${esc(T('rulesNote'))}</p>
    <label class="f">${esc(T('description'))}<textarea class="in" name="desc" required minlength="5" maxlength="300">${esc(s?.description || '')}</textarea></label>
    <div class="grid2"><label class="f">${esc(T('pricing'))}<select class="in" name="pm"><option value="quote" ${s?.priceMode !== 'fixed' ? 'selected' : ''}>${esc(T('onQuote'))}</option><option value="fixed" ${s?.priceMode === 'fixed' ? 'selected' : ''}>${esc(T('fixedPrice'))}</option></select></label>
      <label class="f">${esc(T('price'))}<input class="in" name="price" type="number" min="0.5" step="0.5" inputmode="decimal" value="${s?.price ?? ''}"></label></div>
    <label class="f">${esc(T('area'))}<select class="in" name="am"><option value="radius" ${s?.areaMode !== 'areas' ? 'selected' : ''}>${esc(T('areaRadius'))}</option><option value="areas" ${s?.areaMode === 'areas' ? 'selected' : ''}>${esc(T('areaTowns'))}</option></select></label>
    <div id="amRadius"><div class="row"><button class="btn sm alt" type="button" id="cGps">📍 ${esc(T('centerHere'))}</button><button class="btn sm alt" type="button" id="cMap">📌 ${esc(t('map.pick'))}</button></div>
      <p class="small mute" id="cTxt">${esc(st.center ? T('centerSet') : T('centerNone'))}</p>
      <label class="f">${esc(T('radiusKm'))}<input class="in" name="km" type="number" min="1" max="50" step="1" value="${s?.radiusKm ?? 5}"></label></div>
    <div id="amAreas"><input class="in" id="tq" placeholder="${esc(T('searchTown'))}"><div class="list" id="tr"></div><div class="chips" id="tchips"></div></div>
    <div class="card"><label class="check"><input type="checkbox" name="any" ${h ? '' : 'checked'}><span>${esc(T('anyTime'))}</span></label>
      <div id="hrs"><div class="grid2"><label class="f">${esc(T('from'))}<input class="in" type="time" name="ho" value="${esc(h?.open || '08:00')}"></label><label class="f">${esc(T('to'))}<input class="in" type="time" name="hc" value="${esc(h?.close || '20:00')}"></label></div>
        <p class="small">${esc(T('daysOff'))}</p><div class="chips">${days.map((d, i) => `<label class="check ak-day"><input type="checkbox" name="off" value="${i}" ${(h?.closed || []).includes(i) ? 'checked' : ''}><span>${esc(d)}</span></label>`).join('')}</div></div></div>
    <div class="grid2"><label class="f">${esc(T('minNotice'))}<input class="in" name="notice" type="number" min="0" max="1440" step="5" value="${s?.minNoticeMin ?? 0}"></label>
      <label class="check"><input type="checkbox" name="active" ${s?.active === false ? '' : 'checked'}><span>${esc(T('activeSvc'))}</span></label></div>
    <label class="f">${esc(T('bookingNote'))}<input class="in" name="bnote" maxlength="200" value="${esc(s?.bookingNote || '')}" placeholder="${esc(T('bookingNotePh'))}"></label>
    <button class="btn">${esc(t('common.save'))}</button></form>`);
  const f = $('#svf', sh.el);
  const paint = () => {
    $('#amRadius', sh.el).classList.toggle('hide', f.am.value !== 'radius');
    $('#amAreas', sh.el).classList.toggle('hide', f.am.value !== 'areas');
    $('#hrs', sh.el).classList.toggle('hide', f.any.checked);
    f.price.disabled = f.pm.value !== 'fixed';
    $('#tchips', sh.el).innerHTML = st.areas.map((a) => `<button type="button" class="chip" data-rmA="${a.id}">${esc(a.name)} ✕</button>`).join('');
    $('#cTxt', sh.el).textContent = st.center ? T('centerSet') : T('centerNone');
  };
  f.addEventListener('change', paint);
  $('#cGps', sh.el).onclick = async () => { try { const p = await locate(); st.center = { lat: p.lat, lng: p.lng }; paint(); } catch { toast(t('errors.location')); } };
  $('#cMap', sh.el).onclick = async () => { const p = await pickOnMap(st.center); if (p) { st.center = { lat: p.lat, lng: p.lng }; paint(); } };
  let deb;
  $('#tq', sh.el).oninput = (e) => { clearTimeout(deb); deb = setTimeout(async () => {
    const qv = e.target.value.trim();
    if (qv.length < 2) { $('#tr', sh.el).innerHTML = ''; return; }
    try { const { areas } = await api('GET', `/api/areas/search?q=${encodeURIComponent(qv)}`); $('#tr', sh.el).innerHTML = areas.slice(0, 8).map((a) => `<button type="button" class="li" data-addA="${a.id}" data-n="${esc(a.name)}">${esc(a.name)}<small>${esc(a.districtName || '')}</small></button>`).join(''); } catch { /* ignore */ }
  }, 300); };
  sh.el.addEventListener('click', (e) => {
    const add = e.target.closest('[data-addA]'), rm = e.target.closest('[data-rmA]');
    if (add && !st.areas.some((a) => String(a.id) === add.dataset.adda) && st.areas.length < 30) { st.areas.push({ id: Number(add.dataset.adda), name: add.dataset.n }); paint(); }
    if (rm) { st.areas = st.areas.filter((a) => String(a.id) !== rm.dataset.rma); paint(); }
  });
  paint();
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (f.am.value === 'radius' && !st.center) return toast(T('centerNone'));
    if (f.am.value === 'areas' && !st.areas.length) return toast(T('pickTowns'));
    if (f.pm.value === 'fixed' && !(Number(f.price.value) > 0)) return toast(T('priceNeeded'));
    const body = {
      type: f.type.value, description: f.desc.value, priceMode: f.pm.value, price: f.pm.value === 'fixed' ? Number(f.price.value) : undefined,
      areaMode: f.am.value, center: st.center, radiusKm: Number(f.km.value), areaIds: st.areas.map((a) => a.id),
      hours: f.any.checked ? null : { open: f.ho.value, close: f.hc.value, closed: $$('input[name=off]:checked', f).map((x) => Number(x.value)) },
      minNoticeMin: Number(f.notice.value || 0), bookingNote: f.bnote.value, active: f.active.checked,
    };
    try { await api(s ? 'PUT' : 'POST', s ? `/api/driver/services/${s.id}` : '/api/driver/services', body); sh.close(); toast(t('common.saved')); done?.(); } catch (x) { toast(cerr(x)); }
  });
}

/** Instead of "accept": a request priced by quotes gets "send your price" (and shows the price he already sent). */
export function quoteActionsHtml(o) {
  if (o.state === 'reserved') return `<div class="note b">🔒 ${esc(t('driver.reserved'))}</div>`;
  return `${o.direct ? `<span class="chip a">📩 ${esc(T('direct'))}</span>` : ''}${o.myQuote != null ? `<p class="note g small">💬 ${esc(T('yourPriceSent', { p: money(o.myQuote) }))}</p>` : ''}
    <div class="grid2"><button class="btn" data-eq="${o.errandId}" data-cur="${o.myQuote ?? ''}">💬 ${esc(o.myQuote != null ? T('changePrice') : T('sendPrice'))}</button><button class="btn alt" data-ef="decline" data-id="${o.id}">${esc(t('driver.decline'))}</button></div>`;
}
export const feeText = (o) => (o.quoteMode ? (o.myQuote != null ? money(o.myQuote) : T('yourPrice')) : money(o.fee));
// one listener for every screen of the driver app
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-eq]');
  if (!b) return;
  const sh = sheet(`<h2>💬 ${esc(T('sendPrice'))}</h2><p class="mute small">${esc(T('sendPriceHint'))}</p><form id="eqf">
    <label class="f">${esc(T('price'))}<input class="in" name="price" type="number" min="0.5" max="500" step="0.5" inputmode="decimal" required value="${esc(b.dataset.cur)}"></label>
    <label class="f">${esc(T('quoteNote'))}<input class="in" name="note" maxlength="200" placeholder="${esc(T('driverNotePh'))}"></label>
    <button class="btn">${esc(t('common.send'))}</button></form>`);
  $('#eqf', sh.el).addEventListener('submit', async (ev) => {
    ev.preventDefault();
    try { await api('POST', `/api/driver/errands/${b.dataset.eq}/quote`, { price: Number(ev.target.price.value), note: ev.target.note.value }); sh.close(); toast(T('priceSent')); } catch (x) { toast(cerr(x)); }
  });
});
