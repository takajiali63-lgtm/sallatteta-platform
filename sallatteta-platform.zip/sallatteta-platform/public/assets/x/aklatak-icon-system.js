(()=>{'use strict';
const emoji=/[\\p{Extended_Pictographic}]/u;
const match=(name)=>{name=String(name||'').toLowerCase();
if(/pharm|صيدل|farmac|medic/.test(name))return 'pharmacy';
if(/coffee|cafe|قهو|مقه|cafét/.test(name))return 'coffee';
if(/market|super|grocer|بقال|سوبر|épicer|mercado/.test(name))return 'market';
if(/driver|delivery|سائق|توصيل|repart|livraison/.test(name))return 'delivery';
if(/craft|خدم|service|صيان|repair/.test(name))return 'tools';
if(/shop|store|محل|متجر|tienda|boutique/.test(name))return 'bag';
if(/home|بيت|منزل/.test(name))return 'home';
if(/all|الكل|todos|tout/.test(name))return 'all';
return 'food'};
function replaceIcons(){
 document.querySelectorAll('.cat>span:first-child').forEach(el=>{
 if(el.querySelector('svg')||!emoji.test(el.textContent))return;
 const card=el.closest('.cat');
 const key=card?.dataset.cat||card?.textContent||'';
 const type=match(key);
 el.innerHTML='<span class="ak-real-icon" aria-hidden="true"><svg viewBox="0 0 64 64"><use href="#ak-'+type+'"></use></svg></span>';
 });
}
const observer=new MutationObserver(()=>replaceIcons());
const start=()=>{replaceIcons();observer.observe(document.body,{subtree:true,childList:true})};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();