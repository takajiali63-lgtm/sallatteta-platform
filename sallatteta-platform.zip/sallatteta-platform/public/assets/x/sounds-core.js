// Pure rules behind the app's sound effects (no DOM, no audio): unit-tested in test/v81-sounds.test.js.
// sounds.js wires them to the browser.

export const THROTTLE_MS = 1500;
export const RANK = { low: 0, normal: 1, high: 2 };
export const rank = (p) => RANK[p] ?? RANK.normal;
export const isCritical = (p) => p === 'high';

/** Browsers block audio until the person has touched the page; we never try before that. */
export function canAutoplay({ hasBeenActive = false, gestureSeen = false } = {}) {
  return !!(hasBeenActive || gestureSeen);
}

/** Same event at most once per `ms` (a burst of 5 "cart_add" taps = one sound). Mutates `last` only when allowed. */
export function throttleOk(last, name, now, ms = THROTTLE_MS) {
  const prev = last[name];
  if (prev !== undefined && now - prev < ms) return false;
  last[name] = now;
  return true;
}

/**
 * One sound at a time: nothing playing → 'play'; a more important sound → 'interrupt' the current one;
 * otherwise 'skip' (never queue or overlap — that only makes noise).
 */
export function decide(current, nextPriority) {
  if (!current || !current.playing) return 'play';
  return rank(nextPriority) > rank(current.priority) ? 'interrupt' : 'skip';
}

/**
 * The person's own choices. prefs: { all: '1' = mute everything, ui: '1' muted | '0' explicitly on | null not chosen }.
 * Critical operational alerts (high) still play unless ALL sounds are muted. Interface sounds also stay quiet when the
 * phone asks for reduced motion, unless the person explicitly turned them on.
 */
export function allowedByUser(priority, { all = null, ui = null, reducedMotion = false } = {}) {
  if (all === '1') return false;
  if (isCritical(priority)) return true;
  if (ui === '1') return false;
  if (ui === '0') return true;
  return !reducedMotion;
}

/** Only these are fetched up front (critical alerts + the most frequent tap); the rest load on first use. */
export function preloadNames(events = {}) {
  return Object.keys(events).filter((n) => isCritical(events[n]?.priority) || n === 'cart_add');
}

/** Accepts only a well-formed config (a corrupted saved copy is ignored rather than crashing the page). */
export function parseConfig(raw) {
  let c = raw;
  if (typeof raw === 'string') { try { c = JSON.parse(raw); } catch { return null; } }
  if (!c || typeof c !== 'object' || !Number.isFinite(Number(c.version)) || typeof c.events !== 'object' || !c.events) return null;
  const events = {};
  for (const [name, e] of Object.entries(c.events)) {
    if (!e || typeof e.url !== 'string' || !/^\/media\/sounds\//.test(e.url)) continue;   // same-origin sound URLs only
    const volume = Math.min(1, Math.max(0, Number(e.volume)));
    if (!Number.isFinite(volume)) continue;
    events[name] = { url: e.url, volume, priority: RANK[e.priority] !== undefined ? e.priority : 'normal' };
  }
  return { enabled: c.enabled ? 1 : 0, version: Number(c.version), role: c.role, events };
}

/** What to play for an event, or null (with the reason, for console.debug). */
export function resolve(cfg, name) {
  if (!cfg) return { skip: 'no_config' };
  if (!cfg.enabled) return { skip: 'disabled' };
  const e = cfg.events[name];
  return e ? { ...e } : { skip: 'unmapped' };
}
