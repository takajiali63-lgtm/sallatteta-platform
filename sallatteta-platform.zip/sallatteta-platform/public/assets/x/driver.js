// Aklatak v7 — driver app. While "available", the GPS position is sent every 15 s and the screen stays on.
// (A browser/PWA can't track in the background; the native driver app will — see docs/DRIVER-APP.md.)
import { initI18n, t, esc, $, $$, api, errText, toast, fmtDist, money, mapsLink, telLink, shrinkImage, beep, langPicker, registerSW, openWithdraw, detectCountry, enablePush, refreshPush, pushSupported, fmtTime, copyText } from './core.js';

const ICON = { deliver: '📦', buy: '🛍️', service: '🧾' };
const DOCS = ['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'];
const S = { me: null, watch: null, lastSent: 0, pos: null, poll: null, wake: null, seen: new Set() };
const main = () => $('#main');

function loginView() {
  stopWork();
  main().innerHTML = `<div class="row"><h1>${esc(t('driver.loginTitle'))}</h1><button class="iconbtn" id="lang">🌐</button></div>
    <form id="lf" class="card"><label class="f">${esc(t('driver.phone'))}<input class="in" name="phone" type="tel" inputmode="tel" required autocomplete="username"></label>
    <label class="f">${esc(t('merchant.password'))}<input class="in" name="pw" type="password" required autocomplete="current-password"></label>
    <button class="btn">${esc(t('common.login'))}</button></form><button class="btn alt" id="apply">🛵 ${esc(t('driver.apply'))}</button>`;
  $('#lang').onclick = langPicker;
  $('#apply').onclick = applyView;
  $('#lf').addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await api('POST', '/api/driver/login', { phone: e.target.phone.value, password: e.target.pw.value, country: await detectCountry() }); boot2(); } catch (x) { toast(errText(x)); }
  });
}

async function applyView() {
  const docs = {};
  let plans = {};
  try { plans = (await api('GET', '/api/plans')).driverJobs || {}; } catch { /* optional */ }
  main().innerHTML = `<h1>${esc(t('driver.apply'))}</h1><form id="af">
    <label class="f">${esc(t('driver.fullName'))}<input class="in" name="fullName" required minlength="3" maxlength="80"></label>
    <label class="f">${esc(t('driver.phone'))}<input class="in" name="phone" type="tel" inputmode="tel" required></label>
    <label class="f">${esc(t('driver.password'))}<input class="in" name="password" type="password" minlength="5" required autocomplete="new-password"></label>
    <label class="f">${esc(t('driver.vehicle'))}<select class="in" name="vehicle"><option value="moto">${esc(t('driver.moto'))}</option><option value="car">${esc(t('driver.car'))}</option></select></label>
    <label class="f">${esc(t('driver.plate'))}<input class="in" name="plate" required maxlength="20"></label>
    <label class="f">${esc(t('driver.walletProvider'))}<select class="in" name="walletProvider"><option value="whish">${esc(t('driver.whish'))}</option><option value="omt">${esc(t('driver.omt'))}</option></select></label>
    <label class="f">${esc(t('driver.walletNumber'))}<input class="in" name="walletNumber" type="tel" inputmode="tel" required></label>
    <label class="f">${esc(t('driver.birthDate'))}<input class="in" name="birthDate" type="date" required max="${new Date(Date.now() - 18 * 365.25 * 864e5).toISOString().slice(0, 10)}"></label>
    <h2>${esc(t('driver.docs'))}</h2>
    ${DOCS.map((k) => `<div class="row item"><span>${esc(t(`driver.doc_${k}`))}</span><label class="btn sm alt" id="lb_${k}">${esc(t('driver.pick'))}<input type="file" accept="image/*" class="hide" data-doc="${k}"></label></div>`).join('')}
    <h2>${esc(t('driver.safetyTitle'))}</h2><div class="card legal small">${esc(t('driver.safety'))}</div>
    <div class="card"><h3>📦 ${esc(t('driver.jobsTitle'))}</h3><p class="mute small">${esc(t('driver.jobsHint'))}</p>
      <label class="check"><input type="radio" name="jobs" value="" checked><span>${esc(t('driver.jobsNone'))}</span></label>
      ${Object.entries(plans).map(([m, price]) => `<label class="check"><input type="radio" name="jobs" value="${esc(m)}"><span>${esc(t('driver.months', { n: m }))} — <b>${esc(money(price))}</b></span></label>`).join('')}</div>
    <label class="check"><input type="checkbox" name="adult" required><span>${esc(t('driver.adult'))}</span></label>
    <label class="check"><input type="checkbox" name="terms" required><span>${esc(t('driver.acceptSafety'))} — <a href="/#/legal/terms" target="_blank">${esc(t('me.terms'))}</a> · <a href="/#/legal/privacy" target="_blank">${esc(t('me.privacy'))}</a></span></label>
    <button class="btn" id="sub">${esc(t('driver.submit'))}</button></form><button class="btn alt" id="have">${esc(t('driver.haveAccount'))}</button>`;
  $('#have').onclick = loginView;
  $$('[data-doc]').forEach((inp) => {
    inp.onchange = async () => {
      const k = inp.dataset.doc;
      try { docs[k] = await shrinkImage(inp.files[0]); $(`#lb_${k}`).firstChild.textContent = t('driver.docDone'); $(`#lb_${k}`).classList.remove('alt'); } catch { toast(t('errors.validation_failed')); }
    };
  });
  $('#af').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const missing = DOCS.filter((k) => !docs[k]);
    if (missing.length) return toast(`${t('driver.docs')}: ${missing.map((k) => t(`driver.doc_${k}`)).join('، ')}`);
    const btn = $('#sub');
    btn.disabled = true;
    try {
      await api('POST', '/api/driver/apply', {
        fullName: f.fullName.value, phone: f.phone.value, password: f.password.value, vehicle: f.vehicle.value, plate: f.plate.value,
        walletProvider: f.walletProvider.value, walletNumber: f.walletNumber.value, acceptTerms: f.terms.checked, adult: f.adult.checked, birthDate: f.birthDate.value,
        jobsMonths: f.jobs.value ? Number(f.jobs.value) : null, docs, country: await detectCountry(),
      });
      await api('POST', '/api/driver/login', { phone: f.phone.value, password: f.password.value, country: await detectCountry() });
      boot2();
    } catch (x) { toast(errText(x)); btn.disabled = false; }
  });
}

/* ---------- working: GPS + screen awake + polling ---------- */
async function keepAwake() { try { S.wake = await navigator.wakeLock?.request('screen'); } catch { /* not supported */ } }
document.addEventListener('visibilitychange', () => { if (!document.hidden && S.me?.available) keepAwake(); });
function startWork() {
  if (!navigator.geolocation) return toast(t('errors.location'));
  keepAwake();
  S.watch ??= navigator.geolocation.watchPosition(async (p) => {
    S.pos = { lat: p.coords.latitude, lng: p.coords.longitude };
    if (Date.now() - S.lastSent > 15_000) { S.lastSent = Date.now(); api('POST', '/api/driver/location', S.pos).catch(() => {}); }
  }, () => toast(t('errors.location')), { enableHighAccuracy: true, maximumAge: 10_000 });
}
function stopWork() {
  if (S.watch != null) navigator.geolocation.clearWatch(S.watch);
  S.watch = null;
  S.wake?.release?.().catch(() => {}); S.wake = null;
  clearInterval(S.poll); S.poll = null;
}

async function home() {
  let me;
  try { me = await api('GET', '/api/driver/me'); } catch (e) { return e.status === 401 ? loginView() : toast(errText(e)); }
  S.me = me;
  if (me.status !== 'active') {
    stopWork();
    main().innerHTML = `<h1>${esc(me.name)}</h1><div class="note ${me.status === 'suspended' ? 'b' : ''}">${esc(me.status === 'suspended' ? t('driver.suspendedMsg') : t('driver.pendingMsg'))}</div>
      ${me.warnings.count ? `<div class="card">${me.warnings.items.map((w) => `<p>⚠️ ${esc(w.reason)}</p>`).join('')}</div>` : ''}<button class="btn alt" id="out">${esc(t('common.logout'))}</button>`;
    $('#out').onclick = logout;
    return;
  }
  const left = Math.max(0, me.payoutThreshold - me.balance);
  main().innerHTML = `
    <div class="row"><div><h1>${esc(me.name)}</h1><span class="mute small">🛵 ${esc(t(`driver.${me.vehicle}`))} · ${esc(me.plate || '')}</span></div><button class="iconbtn" id="lang">🌐</button></div>
    <div class="toggle"><div><b>${esc(me.available ? t('driver.available') : t('driver.unavailable'))}</b><div class="mute small">${esc(t('driver.availableHint'))}</div></div><button class="sw${me.available ? ' on' : ''}" id="sw" aria-label="${esc(t('driver.available'))}"></button></div>
    ${me.available ? `<div class="note">📲 ${esc(t('driver.keepOpen'))}</div>` : ''}
    ${me.warnings.count ? `<div class="note b">${esc(t('common.warnings', { n: me.warnings.count, max: me.warnings.max }))}</div>` : ''}
    <div class="note ${me.jobs.active ? 'g' : ''}">${esc(me.jobs.active ? t('errand.jobsActive', { d: new Date(me.jobs.until).toLocaleDateString() }) : t('errand.jobsInactive', { p: money(me.jobs.price) }))}</div>
    <div id="bc"></div>
    ${pushSupported() && Notification.permission === 'default' ? `<button class="btn alt" id="pushOn">🔔 ${esc(t('me.notifOn'))}</button>` : ''}
    <div id="work"></div>
    <div class="grid2"><div class="stat"><b>${esc(money(me.balance))}</b><span>${esc(t('driver.balance'))}</span></div><button class="btn ${left ? 'alt' : 'acc'}" id="wd">💸 ${esc(t('wd.button'))}</button></div>
    <p class="mute tiny">${esc(t('driver.payoutNote', { t: money(me.payoutThreshold) }))}</p>
    <div class="list"><button class="li" id="hist">🧾 ${esc(t('driver.myDeliveries'))}</button><button class="li" id="rep">📊 ${esc(t('driver.report'))}</button><button class="li" id="out">↩ ${esc(t('common.logout'))}</button></div>`;
  $('#lang').onclick = langPicker;
  $('#out').onclick = logout;
  $('#rep').onclick = report;
  $('#hist').onclick = deliveriesView;
  $('#pushOn')?.addEventListener('click', async () => { const r = await enablePush('driver'); toast(r === 'on' ? t('me.notifDone') : r === 'denied' ? t('me.notifDenied') : t('me.notifNo')); home(); });
  refreshPush('driver');
  api('GET', '/api/driver/broadcasts').then(({ broadcasts }) => { const el = $('#bc'); if (el && broadcasts.length) el.innerHTML = `<div class="card warnc"><h3>📢 ${esc(t('driver.messages'))}</h3>${broadcasts.map((b) => `<p class="legal">${esc(b.body)}</p>`).join('<hr>')}</div>`; }).catch(() => {});
  $('#wd').onclick = () => openWithdraw('driver', home);
  $('#sw').onclick = async () => {
    try {
      if (!me.available) {
        const p = await new Promise((res, rej) => navigator.geolocation.getCurrentPosition((x) => res({ lat: x.coords.latitude, lng: x.coords.longitude }), rej, { enableHighAccuracy: true, timeout: 15000 }));
        await api('POST', '/api/driver/availability', { available: true, ...p });
        S.lastSent = Date.now();
      } else { await api('POST', '/api/driver/availability', { available: false }); stopWork(); }
      home();
    } catch (x) { toast(x?.code ? errText(x) : t('errors.location')); }
  };
  if (me.available) startWork();
  clearInterval(S.poll);
  await work();
  S.poll = setInterval(work, 5000);
}

async function work() {
  const box = $('#work');
  if (!box) return;
  try {
    const { orders, errand } = await api('GET', '/api/driver/current');
    if (errand) {
      if (document.activeElement?.id === 'dmsg' && errand.messages.length === S.msgCount) return;
      S.msgCount = errand.messages.length;
      const typed = $('#dmsg')?.value || '';
      const e = errand;
      box.innerHTML = `<div class="card hl errandc"><div class="row"><b>${ICON[e.kind]} ${esc(t('errand.offer'))}: ${esc(t(`errand.kind_${e.kind}`))} #${e.id}</b><span class="big">${esc(money(e.fee))}</span></div>
        <p>${esc(e.description)}</p>${e.purchaseValue != null ? `<p class="small">🛍️ ${esc(t('errand.purchaseD'))}: <b>${esc(money(e.purchaseValue))}</b></p>` : ''}
        <p class="small">📍 ${esc(t('errand.from'))}: ${esc(e.from.details || '')}<br>🏁 ${esc(t('errand.to'))}: ${esc(e.to.details || '')} · ${esc(fmtDist(e.totalM))}</p>
        <div class="grid2"><a class="btn alt" href="${esc(mapsLink(e.from.lat, e.from.lng))}" target="_blank" rel="noopener">🧭 ${esc(t('errand.openFrom'))}</a><a class="btn alt" href="${esc(mapsLink(e.to.lat, e.to.lng))}" target="_blank" rel="noopener">🏁 ${esc(t('errand.openTo'))}</a></div>
        <p>👤 ${esc(e.customer.name)}</p>
        <div class="grid2"><a class="btn alt" href="${esc(telLink(e.customer.phone))}">📞 ${esc(t('driver.callCustomer'))}</a><a class="btn alt" href="https://wa.me/${esc(e.customer.phone)}" target="_blank" rel="noopener">🟢 ${esc(t('common.whatsapp'))}</a></div>
        <h3>💬 ${esc(t('errand.chat'))}</h3><div class="chat">${e.messages.map((m) => `<p class="${m.from_type === 'driver' ? 'me' : ''}"><b>${esc(m.from_type === 'driver' ? t('errand.you') : t('errand.customerW'))}:</b> ${esc(m.body)}</p>`).join('')}</div>
        <div class="row"><input class="in" id="dmsg" maxlength="1000" placeholder="${esc(t('errand.chatPh'))}" value="${esc(typed)}"><button class="btn sm" id="dsend">${esc(t('errand.sendMsg'))}</button></div>
        <div class="note">${esc(t('errand.agree'))}</div>
        ${e.status === 'assigned' ? `<button class="btn" data-eo="picked" data-id="${e.id}">📦 ${esc(t('driver.picked'))}</button>` : ''}
        <button class="btn acc" data-eo="delivered" data-id="${e.id}">✅ ${esc(t('driver.delivered'))}</button></div>`;
      const send = async () => { const v = $('#dmsg').value.trim(); if (!v) return; try { await api('POST', `/api/errands/${e.id}/messages`, { body: v }); $('#dmsg').value = ''; $('#dmsg').blur(); S.msgCount = -1; work(); } catch (x) { toast(errText(x)); } };
      $('#dsend').onclick = send;
      $('#dmsg').onkeydown = (ev) => { if (ev.key === 'Enter') send(); };
      return;
    }
    if (orders && orders.length) {
      box.innerHTML = orders.map((order) => `<div class="card hl"><div class="row"><b>✅ ${esc(t('driver.yourOrder'))} ${esc(order.ref)}</b><span class="big">${esc(money(order.fee))}</span></div>
        <p>🏪 <b>${esc(order.store.name)}</b> ${order.store.area ? `<span class="mute small">— ${esc(order.store.area)}</span>` : ''}</p>
        <div class="grid2"><a class="btn alt" href="${esc(mapsLink(order.store.lat, order.store.lng))}" target="_blank" rel="noopener">🧭 ${esc(t('driver.openStore'))}</a>${order.store.phone ? `<a class="btn alt" href="${esc(telLink(order.store.phone))}">📞 ${esc(t('driver.callStore'))}</a>` : ''}</div>
        ${order.customer ? `<p>👤 ${esc(order.customer.name)}${order.customer.details ? ` — <span class="small">${esc(order.customer.details)}</span>` : ''}</p>
          <p class="mute tiny">📍 ${esc(t('driver.customerPlace'))}</p>
          <div class="grid2"><a class="btn" href="${esc(mapsLink(order.customer.lat, order.customer.lng))}" target="_blank" rel="noopener">🧭 ${esc(t('driver.openCustomer'))}</a><a class="btn alt" href="${esc(telLink(order.customer.phone))}">📞 ${esc(t('driver.callCustomer'))}</a></div>`
          : `<div class="note">⏳ ${esc(t('driver.waitingLocation'))}</div>`}
        <div class="note small">💵 ${esc(t('driver.payStore', { t: money(order.total, order.currency), n: '+' + order.store.payTo, ref: order.ref }))} <button class="btn sm alt" data-copy="${esc(order.ref)}">${esc(t('common.copy'))}</button></div>
        ${order.status === 'assigned' ? `<button class="btn" data-o="picked" data-id="${order.id}">📦 ${esc(t('driver.picked'))}</button>` : ''}
        <button class="btn acc" data-o="delivered" data-id="${order.id}">✅ ${esc(t('driver.delivered'))}</button>
        <p class="mute tiny">🔔 ${esc(t('driver.remindCustomer'))}</p></div>`).join('');
    } else if (S.me?.available) {
      const { offers } = await api('GET', '/api/driver/offers');
      if (offers.some((o) => o.state === 'open' && !S.seen.has(o.type + o.id))) beep();
      offers.forEach((o) => S.seen.add(o.type + o.id));
      box.innerHTML = offers.length ? offers.map((o) => o.type === 'errand' ? `<div class="card hl errandc"><div class="row"><b>${ICON[o.kind]} ${esc(t('errand.offer'))}: ${esc(t(`errand.kind_${o.kind}`))}</b></div>
        <p>${esc(o.description)}</p>
        <div class="row"><span>📍 ${esc(t('errand.fromStart'))}</span><b>${esc(fmtDist(o.toStartM))}</b></div>
        <div class="row"><span>📏 ${esc(t('errand.total'))}</span><b>${esc(fmtDist(o.totalM))}</b></div>
        ${o.purchaseValue != null ? `<div class="row"><span>🛍️ ${esc(t('errand.purchaseD'))}</span><b>${esc(money(o.purchaseValue))}</b></div>` : ''}
        <div class="row"><span>💵 ${esc(t('errand.yourFee'))}</span><span class="big">${esc(money(o.fee))}</span></div>
        <div class="note">${esc(t('errand.agree'))}</div>
        ${offerActions(o, 'ef')}</div>`
        : `<div class="card hl ${o.state === 'reserved' ? 'reserved' : ''}"><div class="row"><b>🏪 ${esc(t('errand.storeOrder'))} ${esc(o.ref || '')}</b></div>${o.addon ? `<p class="chip a">${esc(t('driver.addonTag'))}</p>` : ''}<p>🏪 ${esc(o.store)}</p>
        <div class="row"><span>📍 ${esc(t('driver.toStore'))}</span><b>${esc(fmtDist(o.toStoreM))}</b></div>
        <div class="row"><span>🏠 ${esc(t('driver.toCustomer'))}</span><b>${esc(fmtDist(o.storeToCustomerM))}</b></div>
        <div class="row"><span>💵 ${esc(t('driver.fee'))}</span><span class="big">${esc(money(o.fee))}</span></div>
        ${offerActions(o, 'f')}</div>`).join('')
        : `<div class="empty">${esc(t('driver.noOffers'))}</div>`;
    } else box.innerHTML = '';
  } catch (e) { if (e.status === 401) loginView(); else if (e.status === 403) home(); }
}
function offerActions(o, attr) {
  if (o.state === 'reserved') return `<div class="note b">🔒 ${esc(t('driver.reserved'))}</div>`;
  if (o.state === 'waiting') return `<div class="note g">⏳ ${esc(t('driver.waiting'))}</div>`;
  return `<div class="grid2"><button class="btn" data-${attr}="accept" data-id="${o.id}">${esc(t('driver.accept'))}</button><button class="btn alt" data-${attr}="decline" data-id="${o.id}">${esc(t('driver.decline'))}</button></div>`;
}
document.addEventListener('click', (e) => { const c = e.target.closest('[data-copy]'); if (c) copyText(c.dataset.copy); });

async function deliveriesView() {
  clearInterval(S.poll);
  main().innerHTML = `<button class="iconbtn" id="back">→</button><h1>${esc(t('driver.myDeliveries'))}</h1><div id="hl"><div class="skel cover"></div></div>`;
  $('#back').onclick = home;
  const draw = async () => {
    const { orders } = await api('GET', '/api/driver/history');
    $('#hl').innerHTML = orders.length ? orders.map((o) => `<div class="card"><div class="row"><b>${esc(o.ref)}</b><span class="mute small">${esc(fmtTime(o.deliveredAt))}</span></div>
      <p>🏪 ${esc(o.store.name)} · ${esc(money(o.total, o.currency))}</p>
      <div class="chips"><span class="chip ${o.storePaid ? 'g' : 'w'}">${esc(o.storePaid ? t('driver.paidStore') : t('driver.owes'))}</span>
        <span class="chip ${o.feeState === 'paid' ? 'g' : o.feeState === 'refunded' ? 'b' : ''}">${esc(o.feeState === 'paid' ? t('driver.feePaid') : o.feeState === 'refunded' ? t('driver.feeRefunded') : t('driver.feePending'))} · ${esc(money(o.fee))}</span></div>
      ${o.storePaid ? '' : `<p class="small">💵 ${esc(t('driver.payStore', { t: money(o.total, o.currency), n: '+' + o.store.payTo, ref: o.ref }))}</p>`}
      <div class="grid2"><a class="btn alt" href="${esc(mapsLink(o.store.lat, o.store.lng))}" target="_blank" rel="noopener">🧭 ${esc(t('driver.storePlace'))}</a><button class="btn bad" data-hide="${o.id}">${esc(t('driver.hide'))}</button></div></div>`).join('')
      : `<div class="empty">${esc(t('driver.noDeliveries'))}</div>`;
    $$('[data-hide]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/driver/history/${b.dataset.hide}/hide`, {}); draw(); } catch (x) { toast(errText(x)); } }; });
  };
  try { await draw(); } catch (x) { toast(errText(x)); }
}

document.addEventListener('click', async (e) => {
  const f = e.target.closest('[data-f]'), o = e.target.closest('[data-o]'), ef = e.target.closest('[data-ef]'), eo = e.target.closest('[data-eo]');
  if (!f && !o && !ef && !eo) return;
  const b = f || o || ef || eo;
  b.disabled = true;
  try {
    if (f) await api('POST', `/api/driver/offers/${f.dataset.id}/${f.dataset.f}`, {});
    else if (o) await api('POST', `/api/driver/orders/${o.dataset.id}/${o.dataset.o}`, {});
    else if (ef) await api('POST', `/api/driver/errand-offers/${ef.dataset.id}/${ef.dataset.ef}`, {});
    else await api('POST', `/api/driver/errands/${eo.dataset.id}/${eo.dataset.eo}`, {});
    if (o?.dataset.o === 'delivered' || eo?.dataset.eo === 'delivered') return home();
    work();
  } catch (x) { toast(errText(x)); work(); }
});

async function report(period = 'month') {
  clearInterval(S.poll);
  main().innerHTML = `<button class="iconbtn" id="back">→</button><h1>${esc(t('driver.report'))}</h1><div class="tabs">${['today', 'week', 'month'].map((p) => `<button data-p="${p}" class="${p === period ? 'on' : ''}">${esc(t(`merchant.${p}`))}</button>`).join('')}</div><div id="rep"></div>`;
  $('#back').onclick = home;
  $$('[data-p]').forEach((b) => { b.onclick = () => report(b.dataset.p); });
  try {
    const { report: r } = await api('GET', `/api/driver/report?period=${period}`);
    $('#rep').innerHTML = `<div class="grid2"><div class="stat"><b>${r.deliveries}</b><span>${esc(t('driver.rDeliveries'))}</span></div><div class="stat"><b>${r.km} ${esc(t('common.km'))}</b><span>${esc(t('driver.rKm'))}</span></div>
      <div class="stat"><b>${esc(money(r.earnings))}</b><span>${esc(t('driver.rEarnings'))}</span></div><div class="stat"><b>${esc(money(r.paid))}</b><span>${esc(t('driver.rPaid'))}</span></div></div>
      <div class="stat"><b>${r.errands}</b><span>${esc(t('errand.tab'))}</span></div>
      ${r.topStores.length ? `<h2>${esc(t('driver.rTop'))}</h2><div class="list">${r.topStores.map((s) => `<div class="row item"><span>${esc(s.name)}</span><b>${s.deliveries}</b></div>`).join('')}</div>` : ''}
      <button class="btn alt noprint" id="print">${esc(t('merchant.print'))}</button>`;
    $('#print').onclick = () => window.print();
  } catch (e) { toast(errText(e)); }
}

async function logout() { stopWork(); await api('POST', '/api/driver/logout', {}).catch(() => {}); loginView(); }
function boot2() { if (location.hash === '#apply') { window.history.replaceState(null, '', '/driver'); return applyView(); } home(); }
(async () => { registerSW(); await initI18n(); boot2(); })();
