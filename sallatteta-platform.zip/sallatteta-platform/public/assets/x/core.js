// Aklatak v7 front-end core, shared by the customer app, the store dashboard and the driver app.
// Texts come from /locales/<lang>.json → "dx" (editable from the admin "texts" editor), in 4 languages.
export const LANGS = ['ar', 'en', 'fr', 'es'];
const RTL = new Set(['ar']);
let dict = {}, fallback = {}, lang = 'ar';

const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch { /* private mode */ } },
};
export const session = {
  get(k) { try { return JSON.parse(sessionStorage.getItem(k)); } catch { return null; } },
  set(k, v) { try { v == null ? sessionStorage.removeItem(k) : sessionStorage.setItem(k, JSON.stringify(v)); } catch { /* ignore */ } },
};

function pickLang() {
  const q = new URLSearchParams(location.search).get('lang');
  if (LANGS.includes(q)) { store.set('st_lang', q); return q; }
  const saved = store.get('st_lang');
  if (LANGS.includes(saved)) return saved;
  const nav = (navigator.languages || [navigator.language || 'ar']).map((l) => String(l).slice(0, 2));
  return nav.find((l) => LANGS.includes(l)) || 'ar';
}

export async function initI18n() {
  lang = pickLang();
  const load = async (l) => { try { return (await (await fetch(`/locales/${l}.json`)).json()).dx || {}; } catch { return {}; } };
  [dict, fallback] = await Promise.all([load(lang), lang === 'ar' ? Promise.resolve({}) : load('ar')]);
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL.has(lang) ? 'rtl' : 'ltr';
  return lang;
}
export const getLang = () => lang;
export function setLang(l) { if (LANGS.includes(l)) { store.set('st_lang', l); location.reload(); } }

const dig = (o, key) => key.split('.').reduce((a, k) => (a && typeof a === 'object' ? a[k] : undefined), o);
export function t(key, vars) {
  let s = dig(dict, key) ?? dig(fallback, key) ?? key;
  if (vars) s = String(s).replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ''));
  return s;
}

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (s, root = document) => root.querySelector(s);
export const $$ = (s, root = document) => [...root.querySelectorAll(s)];

export class ApiError extends Error { constructor(status, code, data) { super(code); this.status = status; this.code = code; this.data = data; } }
export async function api(method, path, body) {
  let r;
  try {
    r = await fetch(path, {
      method, credentials: 'same-origin',
      headers: { 'X-Requested-With': 'fetch', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch { throw new ApiError(0, 'network'); }
  let data = null;
  try { data = await r.json(); } catch { data = null; }
  if (!r.ok) throw new ApiError(r.status, data?.error || 'generic', data);
  return data;
}
export function errText(e) {
  const code = e?.code || 'generic';
  const s = t(`errors.${code}`);
  return s === `errors.${code}` ? t('errors.generic') : s;
}

let toastTimer;
export function toast(msg) {
  let el = $('.toast');
  if (!el) { el = document.createElement('div'); el.className = 'toast'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
  el.textContent = msg;
  el.classList.remove('hide');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hide'), 3200);
}

/** Bottom sheet. Returns { el, close }. Clicking the dim background closes it. */
export function sheet(html, { onClose } = {}) {
  const bg = document.createElement('div');
  bg.className = 'sheet-bg';
  bg.innerHTML = `<div class="sheet" role="dialog" aria-modal="true">${html}</div>`;
  const close = () => { bg.remove(); onClose?.(); };
  bg.addEventListener('click', (e) => { if (e.target === bg || e.target.closest('[data-close]')) close(); });
  document.body.appendChild(bg);
  return { el: bg.querySelector('.sheet'), close };
}

export function fmtDist(m) {
  if (m == null || !Number.isFinite(Number(m))) return '';
  m = Number(m);
  return m < 1000 ? `${Math.max(10, Math.round(m / 10) * 10)} ${t('common.m')}` : `${(m / 1000).toFixed(m < 10000 ? 1 : 0)} ${t('common.km')}`;
}
const SYM = { USD: '$', EUR: '€', LBP: 'ل.ل' };
export function money(n, cur = 'USD') {
  const v = Math.round(Number(n || 0) * 100) / 100;
  const s = Number.isInteger(v) ? String(v) : v.toFixed(2);
  return SYM[cur] ? `${s}${SYM[cur]}` : `${s} ${cur}`;
}
export function fmtTime(iso) {
  try { return new Intl.DateTimeFormat(lang, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso)); } catch { return iso; }
}

/** One GPS reading (high accuracy, 15 s). */
export function locate() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('location'));
    navigator.geolocation.getCurrentPosition((p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }),
      () => reject(new Error('location')), { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
  });
}
export const mapsLink = (lat, lng) => `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
export const telLink = (phone) => `tel:+${String(phone).replace(/^\+/, '')}`;

/** Shrink a photo on the phone before sending (keeps the database small). Returns a JPEG data URL. */
export function shrinkImage(file, { max = 1280, quality = 0.72, limit = 330_000 } = {}) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      let { width: w, height: h } = img;
      const scale = Math.min(1, max / Math.max(w, h));
      w = Math.round(w * scale); h = Math.round(h * scale);
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      c.getContext('2d').drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      let q = quality, out = c.toDataURL('image/jpeg', q);
      while (out.length > limit && q > 0.35) { q -= 0.1; out = c.toDataURL('image/jpeg', q); }
      if (out.length > limit) { const c2 = document.createElement('canvas'); c2.width = Math.round(w * 0.7); c2.height = Math.round(h * 0.7); c2.getContext('2d').drawImage(c, 0, 0, c2.width, c2.height); out = c2.toDataURL('image/jpeg', 0.6); }
      resolve(out);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('image')); };
    img.src = url;
  });
}

/** Short beep for new orders (no audio file needed). */
let audioCtx;
export function beep() {
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.frequency.value = 880; g.gain.value = 0.15;
    o.start(); o.stop(audioCtx.currentTime + 0.35);
    navigator.vibrate?.([200, 100, 200]);
  } catch { /* no audio */ }
}

/** Time zone → country (from /api/config), so each country stays separate. */
export function countryFromConfig(cfg) {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const map = cfg.countryTimezones || {};   // { 'Asia/Beirut': 'LB', … }
    if (typeof map[tz] === 'string') return map[tz];
  } catch { /* ignore */ }
  return cfg.country?.code || 'LB';
}

export function langPicker() {
  const names = { ar: 'العربية', en: 'English', fr: 'Français', es: 'Español' };
  const s = sheet(`<h2>${esc(t('me.language'))}</h2><div class="list">${LANGS.map((l) => `<button class="li" data-l="${l}">${names[l]}${l === lang ? ' ✓' : ''}</button>`).join('')}</div>`);
  s.el.addEventListener('click', (e) => { const b = e.target.closest('[data-l]'); if (b) setLang(b.dataset.l); });
}

export function registerSW() { if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {}); }

/** Withdraw sheet for drivers and stores: any Whish/OMT number, confirmed with the account password; history + money log. */
export async function openWithdraw(type, onDone) {
  let info;
  try { info = await api('GET', `/api/${type}/withdrawals`); } catch (e) { toast(errText(e)); return; }
  const kinds = { topup: 'merchant.k_topup', hold: 'merchant.k_hold', release: 'merchant.k_release', adjust: 'merchant.k_adjust', earning: 'merchant.k_earning', payout: 'merchant.k_payout' };
  const can = info.balance >= info.minimum;
  const s = sheet(`<h2>${esc(t('wd.title'))}</h2>
    <div class="stat"><b>${esc(money(info.balance))}</b><span>${esc(t('wd.available'))}</span></div>
    <p class="mute small">${esc(t('wd.minimum', { m: money(info.minimum) }))} · ${esc(t('wd.daily', { m: money(info.dailyMax) }))}</p>
    ${can ? `<form id="wf">
      <label class="f">${esc(t('wd.amount'))}<input class="in" name="amount" type="number" step="0.01" min="${info.minimum}" max="${info.balance}" value="${info.balance}" inputmode="decimal" required></label>
      <label class="f">${esc(t('wd.via'))}<select class="in" name="provider"><option value="whish">Whish Money</option><option value="omt">OMT</option></select></label>
      <label class="f">${esc(t('wd.number'))}<input class="in" name="number" type="tel" inputmode="tel" required></label>
      <label class="f">${esc(t('wd.password'))}<input class="in" name="password" type="password" required autocomplete="current-password"></label>
      <div class="note">${esc(t('wd.warn'))}</div>
      <button class="btn">${esc(t('wd.send'))}</button></form>` : ''}
    <h2>${esc(t('wd.history'))}</h2>
    <div class="list">${info.withdrawals.map((w) => `<div class="row item"><span>${esc(money(w.amount))} — ${esc(w.provider.toUpperCase())} +${esc(w.number)}<br><small>${esc(fmtTime(w.created_at))}</small></span><span class="chip ${w.status === 'paid' ? 'g' : w.status === 'rejected' ? 'b' : 'w'}">${esc(t(`wd.${w.status}`))}</span></div>`).join('') || `<div class="empty">${esc(t('orders.none'))}</div>`}</div>
    <h2>${esc(t('wd.log'))}</h2>
    <div class="list">${info.ledger.map((l) => `<div class="row item"><span>${esc(t(kinds[l.kind] || l.kind))}${l.order_id ? ` #${l.order_id}` : ''}<br><small>${esc(fmtTime(l.created_at))}</small></span><b>${esc(money(l.amount))}</b></div>`).join('')}</div>
    <button class="btn alt" data-close>${esc(t('common.close'))}</button>`);
  $('#wf', s.el)?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target, btn = $('button', f);
    btn.disabled = true;
    try {
      await api('POST', `/api/${type}/withdrawals`, { amount: Number(f.amount.value), provider: f.provider.value, number: f.number.value, password: f.password.value, country: await detectCountry() });
      s.close(); toast(t('wd.sent')); onDone?.();
    } catch (x) { toast(errText(x)); btn.disabled = false; }
  });
}

/** The visitor's country (from the time zone), asked once. Every country is separate. */
let countryP;
export function detectCountry() {
  countryP ||= api('GET', '/api/config').then((c) => countryFromConfig(c)).catch(() => 'LB');
  return countryP;
}
