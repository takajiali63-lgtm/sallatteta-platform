// Aklatak v7 — store dashboard (restaurants, cafés, shops, clinics, craftspeople).
import { initI18n, t, esc, $, $$, api, errText, toast, sheet, fmtDist, money, fmtTime, beep, shrinkImage, mapsLink, telLink, langPicker, registerSW, getLang, openWithdraw } from './core.js';

const S = { me: null, wallet: null, tab: 'orders', timer: null, seen: new Set(), cats: [] };
const main = () => $('#main');
const err = (e) => toast(e?.code === 'invalid_cook_credentials' ? t('errors.invalid_credentials') : errText(e));
const isCraft = () => S.cats.find((c) => c.key === S.me?.kind)?.group === 'crafts';

function loginView() {
  main().innerHTML = `<div class="row"><h1>${esc(t('merchant.loginTitle'))}</h1><button class="iconbtn" id="lang">🌐</button></div>
    <form id="lf" class="card"><label class="f">${esc(t('merchant.phone'))}<input class="in" name="phone" type="tel" inputmode="tel" required autocomplete="username"></label>
    <label class="f">${esc(t('merchant.password'))}<input class="in" name="pw" type="password" required autocomplete="current-password"></label>
    <button class="btn">${esc(t('common.login'))}</button></form>
    <a class="btn alt" href="/join">${esc(t('me.forStores'))}</a>`;
  $('#lang').onclick = langPicker;
  $('#lf').addEventListener('submit', async (e) => {
    e.preventDefault();
    try { await api('POST', '/api/cook/login', { whatsapp: e.target.phone.value, password: e.target.pw.value }); boot2(); } catch (x) { err(x); }
  });
}

function tabs() {
  const list = ['orders', 'products'];
  if (S.me.booking) list.push('appointments');
  if (isCraft()) list.push('visits');
  list.push('wallet', 'report', 'settings');
  return list;
}

function frame() {
  const on = S.accepting;
  main().innerHTML = `
    <div class="row"><div><h1>${esc(S.me.name)}</h1><span class="mute small">${esc(t('merchant.title'))}</span></div><button class="iconbtn" id="lang">🌐</button></div>
    <div class="toggle"><b>${esc(on ? t('merchant.accepting') : t('merchant.notAccepting'))}</b><button class="sw${on ? ' on' : ''}" id="acc" aria-label="${esc(t('merchant.accepting'))}"></button></div>
    ${S.wallet?.warnings?.count ? `<div class="note">${esc(t('common.warnings', { n: S.wallet.warnings.count, max: S.wallet.warnings.max }))}</div>` : ''}
    <div class="tabs">${tabs().map((k) => `<button data-t="${k}" class="${k === S.tab ? 'on' : ''}">${esc(t(`merchant.tab${k[0].toUpperCase() + k.slice(1)}`))}</button>`).join('')}</div>
    <div id="pane"></div>`;
  $('#lang').onclick = langPicker;
  $('#acc').onclick = async () => { try { await api('POST', '/api/store/accepting', { on: !S.accepting }); S.accepting = !S.accepting; frame(); } catch (e) { err(e); } };
  $$('[data-t]').forEach((b) => { b.onclick = () => { S.tab = b.dataset.t; frame(); }; });
  clearInterval(S.timer); S.timer = null;
  ({ orders: paneOrders, products: paneProducts, appointments: paneAppts, visits: paneVisits, wallet: paneWallet, report: paneReport, settings: paneSettings }[S.tab] || paneOrders)();
}
const pane = () => $('#pane');

/* ---------- orders ---------- */
function orderCard(o) {
  const items = o.items.map((i) => `${i.qty} × ${esc(i.name)}`).join('، ');
  const mode = S.wallet?.deliveryMode;
  let actions = '';
  if (o.status === 'pending') actions = `<div class="grid2"><button class="btn" data-a="accept" data-id="${o.id}">${esc(t('merchant.accept'))}</button><button class="btn alt" data-a="reject" data-id="${o.id}">${esc(t('merchant.reject'))}</button></div>`;
  else if (o.status === 'preparing') {
    actions = mode === 'delivery'
      ? `<label class="f">${esc(t('merchant.fee'))}<input class="in" type="number" min="0.5" step="0.5" inputmode="decimal" value="2" id="fee${o.id}"></label><p class="mute tiny">${esc(t('merchant.feeHint'))}</p>
         <button class="btn" data-a="search" data-id="${o.id}">🛵 ${esc(t('merchant.findDriver'))}</button><button class="btn alt" data-a="self" data-id="${o.id}">${esc(t('merchant.selfDispatch'))}</button>`
      : `<button class="btn" data-a="self" data-id="${o.id}">🛵 ${esc(t('merchant.onTheWay'))}</button>`;
    actions += `<button class="btn bad" data-a="cancel" data-id="${o.id}">${esc(t('merchant.cancelOrder'))}</button>`;
  } else if (o.status === 'searching') {
    actions = `<div class="note">${esc(o.driversNotified ? t('merchant.searching', { n: o.driversNotified }) : t('merchant.noDrivers'))}</div>
      ${o.canRaise || !o.driversNotified ? `<p class="small">${esc(t('merchant.raiseHint'))}</p><div class="row"><input class="in" type="number" min="1" step="0.5" value="${Number(o.deliveryFee) + 1}" id="fee${o.id}"><button class="btn sm acc" data-a="raise" data-id="${o.id}">${esc(t('merchant.raise'))}</button></div>` : ''}
      <button class="btn bad" data-a="cancel" data-id="${o.id}">${esc(t('merchant.cancelOrder'))}</button>`;
  } else if (o.status === 'assigned' || (o.status === 'picked_up' && !o.selfDelivery)) {
    actions = `<div class="note g">✅ ${esc(t('merchant.driverAccepted', { name: o.driver?.name || '' }))} — ${esc(t(`driver.${o.driver?.vehicle || 'moto'}`))}</div>
      ${o.driver ? `<a class="btn sm alt" href="${esc(telLink(o.driver.phone))}">📞 ${esc(t('common.call'))}</a>` : ''}
      ${o.locationSent ? `<div class="note g">📍 ${esc(t('merchant.locationSent'))}</div>` : `<button class="btn acc" data-a="loc" data-id="${o.id}">📍 ${esc(t('merchant.sendLocation'))}</button>`}`;
  } else if (o.status === 'picked_up' && o.selfDelivery) {
    actions = `<button class="btn" data-a="selfdone" data-id="${o.id}">✅ ${esc(t('merchant.selfDelivered'))}</button>`;
  }
  return `<div class="card ${o.status === 'pending' ? 'hl' : ''}">
    <div class="row"><b>${esc(t('merchant.newOrder', { id: o.id }))}</b><span class="chip">${esc(t(`status.${o.status === 'picked_up' && o.selfDelivery ? 'picked_up_self' : o.status}`))}</span></div>
    <p>${items}</p>${o.note ? `<p class="mute small">📝 ${esc(o.note)}</p>` : ''}${o.scheduledAt ? `<p class="small">🕐 ${esc(fmtTime(o.scheduledAt))}</p>` : ''}
    <div class="row small"><span>👤 ${esc(o.customer.name)} <a href="${esc(telLink(o.customer.phone))}">📞</a></span><span class="mute">${esc(t('merchant.customerAway', { d: fmtDist(o.distanceM) }))}</span></div>
    <div class="row"><span class="mute small">${esc(fmtTime(o.createdAt))}</span><b>${esc(money(o.total, o.currency))}</b></div>${actions}</div>`;
}
async function paneOrders() {
  const draw = async () => {
    let r;
    try { r = await api('GET', '/api/store/orders'); } catch (e) { if (e.status === 401) return loginView(); return; }
    if (S.tab !== 'orders' || !pane()) return;
    const fresh = r.orders.filter((o) => o.status === 'pending' && !S.seen.has(o.id));
    if (fresh.length && S.seen.size) beep();
    r.orders.forEach((o) => S.seen.add(o.id));
    S.wallet = { ...(S.wallet || {}), balance: r.balance };
    pane().innerHTML = `<div class="stat"><b>${esc(money(r.balance))}</b><span>${esc(t('merchant.balance'))}</span></div><h2></h2>
      ${r.orders.length ? r.orders.map(orderCard).join('') : `<div class="empty">${esc(t('merchant.noOrders'))}</div>`}`;
  };
  pane().onclick = async (e) => {
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const id = b.dataset.id, a = b.dataset.a;
    const path = { accept: 'accept', reject: 'reject', search: 'search', raise: 'raise', loc: 'send-location', cancel: 'cancel', self: 'self-dispatch', selfdone: 'self-delivered' }[a];
    const body = ['search', 'raise'].includes(a) ? { fee: Number($(`#fee${id}`).value) } : {};
    b.disabled = true;
    try { await api('POST', `/api/store/orders/${id}/${path}`, body); await draw(); } catch (x) { err(x); b.disabled = false; }
  };
  await draw();
  S.timer = setInterval(draw, 8000);
}

/* ---------- products ---------- */
function paneProducts() {
  const menu = S.me.menu || [];
  pane().innerHTML = `<button class="btn" id="add">➕ ${esc(t('merchant.addProduct'))}</button>
    ${menu.map((m) => `<div class="item"><div class="txt"><b>${esc(m.name)}</b>${m.description ? `<p>${esc(m.description)}</p>` : ''}<span class="price">${m.price != null ? esc(money(m.price, m.currency || 'USD')) : ''}</span></div>
      <div><button class="btn sm ${m.available ? 'alt' : 'bad'}" data-av="${m.id}">${esc(m.available ? t('merchant.available') : t('merchant.unavailable'))}</button>
      <button class="btn sm alt" data-ed="${m.id}">✏️</button></div></div>`).join('')}`;
  const form = (m = {}) => {
    const sh = sheet(`<h2>${esc(m.id ? m.name : t('merchant.addProduct'))}</h2><form id="pf">
      <label class="f">${esc(t('merchant.pName'))}<input class="in" name="name" required maxlength="80" value="${esc(m.name || '')}"></label>
      <label class="f">${esc(t('merchant.pPrice'))}<input class="in" name="price" type="number" step="0.01" min="0" inputmode="decimal" value="${m.price ?? ''}"></label>
      <label class="f">${esc(t('merchant.pDesc'))}<input class="in" name="desc" maxlength="200" value="${esc(m.description || '')}"></label>
      <button class="btn">${esc(t('common.save'))}</button>${m.id ? `<button class="btn bad" type="button" id="del">${esc(t('merchant.delete'))}</button>` : ''}</form>`);
    $('#pf', sh.el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      const body = { name: f.name.value, price: f.price.value === '' ? null : Number(f.price.value), description: f.desc.value };
      try { S.me = await api(m.id ? 'PATCH' : 'POST', m.id ? `/api/cook/menu/${m.id}` : '/api/cook/menu', body); sh.close(); paneProducts(); } catch (x) { err(x); }
    });
    $('#del', sh.el)?.addEventListener('click', async () => { if (!confirm(t('merchant.deleteConfirm'))) return; try { S.me = await api('DELETE', `/api/cook/menu/${m.id}`); sh.close(); paneProducts(); } catch (x) { err(x); } });
  };
  $('#add').onclick = () => form();
  $$('[data-ed]').forEach((b) => { b.onclick = () => form(menu.find((x) => String(x.id) === b.dataset.ed)); });
  $$('[data-av]').forEach((b) => { b.onclick = async () => { const m = menu.find((x) => String(x.id) === b.dataset.av); try { S.me = await api('PATCH', `/api/cook/menu/${m.id}`, { available: !m.available }); paneProducts(); } catch (x) { err(x); } }; });
}

/* ---------- appointments & visits ---------- */
async function paneAppts() {
  try {
    const { appointments } = await api('GET', '/api/store/appointments');
    pane().innerHTML = appointments.length ? appointments.map((a) => `<div class="card"><div class="row"><b>${esc(fmtTime(a.starts_at))}</b><span class="chip ${a.status === 'confirmed' ? 'g' : ''}">${esc(t(`appt.${a.status}`))}</span></div>
      <p>${esc(a.service)}</p><p class="small">👤 ${esc(a.customer_name)} <a href="${esc(telLink(a.customer_phone))}">📞</a></p>${a.note ? `<p class="mute small">${esc(a.note)}</p>` : ''}
      ${a.status === 'pending' ? `<div class="grid2"><button class="btn" data-ap="${a.id}" data-x="confirm">${esc(t('merchant.aConfirm'))}</button><button class="btn alt" data-ap="${a.id}" data-x="decline">${esc(t('merchant.aDecline'))}</button></div>` : ''}
      ${a.status === 'confirmed' ? `<button class="btn alt" data-ap="${a.id}" data-x="done">${esc(t('merchant.aDone'))}</button>` : ''}</div>`).join('') : `<div class="empty">${esc(t('orders.none'))}</div>`;
    $$('[data-ap]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/store/appointments/${b.dataset.ap}/${b.dataset.x}`, {}); paneAppts(); } catch (x) { err(x); } }; });
  } catch (e) { err(e); }
}
async function paneVisits() {
  const draw = async () => {
    try {
      const { visits } = await api('GET', '/api/store/visits');
      if (S.tab !== 'visits') return;
      pane().innerHTML = visits.length ? visits.map((v) => `<div class="card ${v.status === 'pending' ? 'hl' : ''}"><div class="row"><b>👤 ${esc(v.customerName)}</b><span class="chip">${esc(t(`visit.${v.status}`))}</span></div>
        <p>${esc(v.description)}</p><p class="mute small">📍 ${esc(t('merchant.vAway', { d: fmtDist(v.distanceM) }))}</p>
        ${v.customer ? `<div class="grid2"><a class="btn" href="${esc(mapsLink(v.customer.lat, v.customer.lng))}" target="_blank" rel="noopener">🧭 ${esc(t('common.map'))}</a><a class="btn alt" href="${esc(telLink(v.customer.phone))}">📞 ${esc(t('common.call'))}</a></div>${v.customer.details ? `<p class="small">${esc(v.customer.details)}</p>` : ''}` : ''}
        ${v.status === 'pending' ? `<div class="grid2"><button class="btn" data-v="${v.id}" data-x="accept">${esc(t('merchant.vAccept'))}</button><button class="btn alt" data-v="${v.id}" data-x="decline">${esc(t('merchant.vDecline'))}</button></div>` : ''}
        ${v.status === 'accepted' ? `<button class="btn alt" data-v="${v.id}" data-x="done">${esc(t('merchant.vDone'))}</button>` : ''}</div>`).join('') : `<div class="empty">${esc(t('orders.none'))}</div>`;
      $$('[data-v]').forEach((b) => { b.onclick = async () => { try { await api('POST', `/api/store/visits/${b.dataset.v}/${b.dataset.x}`, {}); draw(); } catch (x) { err(x); } }; });
    } catch (e) { err(e); }
  };
  await draw();
  S.timer = setInterval(draw, 15000);
}

/* ---------- wallet ---------- */
async function paneWallet() {
  try { S.wallet = await api('GET', '/api/store/wallet'); } catch (e) { return err(e); }
  const w = S.wallet;
  pane().innerHTML = `<div class="stat"><b>${esc(money(w.balance))}</b><span>${esc(t('merchant.balance'))}</span></div>
    <p class="mute small">${esc(t('merchant.deliveryMode'))}: ${esc(t(`merchant.mode_${w.deliveryMode}`))} — ${esc(t('merchant.modeHint'))}</p>
    <div class="grid2"><button class="btn" id="top">💳 ${esc(t('merchant.topup'))}</button><button class="btn alt" id="wd">💸 ${esc(t('wd.button'))}</button></div>
    <h2>${esc(t('merchant.ledger'))}</h2>
    <div class="list">${w.topups.filter((x) => x.status === 'pending').map((x) => `<div class="row item"><span>⏳ ${esc(t('merchant.k_topup'))} (${esc(x.method)})</span><b>${esc(money(x.amount))}</b></div>`).join('')}
    ${w.ledger.map((l) => `<div class="row item"><span>${esc(t(`merchant.k_${l.kind}`))}${l.order_id ? ` #${l.order_id}` : ''}<br><small>${esc(fmtTime(l.created_at))}</small></span><b class="${l.amount < 0 ? '' : 'big'}">${esc(money(l.amount))}</b></div>`).join('')}</div>`;
  $('#wd').onclick = () => openWithdraw('store', paneWallet);
  $('#top').onclick = () => {
    let receipt = null;
    const sh = sheet(`<h2>${esc(t('merchant.topup'))}</h2><form id="tf">
      <label class="f">${esc(t('merchant.amount'))}<input class="in" name="amount" type="number" min="1" step="1" inputmode="decimal" required></label>
      <label class="f">${esc(t('merchant.method'))}<select class="in" name="method"><option value="whish">Whish Money</option><option value="omt">OMT</option><option value="other">—</option></select></label>
      <label class="f">${esc(t('merchant.reference'))}<input class="in" name="ref" maxlength="80"></label>
      <label class="f">${esc(t('merchant.receipt'))}<input class="in" name="file" type="file" accept="image/*" required></label>
      <button class="btn">${esc(t('common.confirm'))}</button></form>`);
    $('input[name=file]', sh.el).onchange = async (e) => { try { receipt = await shrinkImage(e.target.files[0]); } catch { receipt = null; } };
    $('#tf', sh.el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      if (!receipt) return toast(t('errors.validation_failed'));
      try { await api('POST', '/api/store/topups', { amount: Number(f.amount.value), method: f.method.value, reference: f.ref.value, receipt }); sh.close(); toast(t('merchant.topupSent')); paneWallet(); } catch (x) { err(x); }
    });
  };
}

/* ---------- report ---------- */
async function paneReport(period = 'month') {
  pane().innerHTML = `<div class="tabs">${['today', 'week', 'month'].map((p) => `<button data-p="${p}" class="${p === period ? 'on' : ''}">${esc(t(`merchant.${p}`))}</button>`).join('')}</div><div id="rep"><div class="skel cover"></div></div>`;
  $$('[data-p]').forEach((b) => { b.onclick = () => paneReport(b.dataset.p); });
  try {
    const { report: r } = await api('GET', `/api/store/report?period=${period}`);
    const text = [
      `📊 ${S.me.name} — ${t(`merchant.${period}`)}`,
      `${t('merchant.rOrders')}: ${r.orders} (${t('merchant.rDelivered')} ${r.delivered} · ${t('merchant.rRejected')} ${r.rejected})`,
      `${t('merchant.rSales')}: ${money(r.sales)}`, `${t('merchant.rFees')}: ${money(r.deliveryFeesPaid)}`,
      `${t('merchant.rViews')}: ${r.pageViews}`,
      ...(r.topItems.length ? [`${t('merchant.rTop')}: ${r.topItems.map((i) => `${i.name} (${i.qty})`).join('، ')}`] : []),
    ].join('\n');
    $('#rep').innerHTML = `<div class="grid2">
      <div class="stat"><b>${r.orders}</b><span>${esc(t('merchant.rOrders'))}</span></div><div class="stat"><b>${r.delivered}</b><span>${esc(t('merchant.rDelivered'))}</span></div>
      <div class="stat"><b>${esc(money(r.sales))}</b><span>${esc(t('merchant.rSales'))}</span></div><div class="stat"><b>${esc(money(r.deliveryFeesPaid))}</b><span>${esc(t('merchant.rFees'))}</span></div>
      <div class="stat"><b>${r.rejected}</b><span>${esc(t('merchant.rRejected'))}</span></div><div class="stat"><b>${r.pageViews}</b><span>${esc(t('merchant.rViews'))}</span></div></div>
      ${r.topItems.length ? `<h2>${esc(t('merchant.rTop'))}</h2><div class="list">${r.topItems.map((i) => `<div class="row item"><span>${esc(i.name)}</span><b>${i.qty}</b></div>`).join('')}</div>` : ''}
      <div class="grid2 noprint"><button class="btn" id="share">${esc(t('merchant.share'))}</button><button class="btn alt" id="print">${esc(t('merchant.print'))}</button></div>`;
    $('#share').onclick = async () => { try { if (navigator.share) await navigator.share({ text }); else { await navigator.clipboard.writeText(text); toast(t('common.done')); } } catch { /* cancelled */ } };
    $('#print').onclick = () => window.print();
  } catch (e) { err(e); }
}

/* ---------- settings ---------- */
function paneSettings() {
  pane().innerHTML = `<div class="card"><h3>${esc(t('merchant.photo'))}</h3>${S.me.photoUrl ? `<img src="${esc(S.me.photoUrl)}" alt="" class="cover">` : ''}
    <label class="btn alt">${esc(t('merchant.changePhoto'))}<input type="file" accept="image/*" id="ph" class="hide"></label></div>
    <div class="list"><a href="/#/s/${S.me.id}">👁 ${esc(S.me.name)}</a><a href="/#/legal/terms">📄 ${esc(t('me.terms'))}</a><a href="/#/legal/privacy">🔒 ${esc(t('me.privacy'))}</a>
    <button class="li" id="out">↩ ${esc(t('common.logout'))}</button></div>`;
  $('#ph').onchange = async (e) => {
    try { const photo = await shrinkImage(e.target.files[0], { max: 800, limit: 190_000 }); S.me = await api('PATCH', '/api/cook/me', { photo }); toast(t('common.saved')); paneSettings(); } catch (x) { err(x); }
  };
  $('#out').onclick = async () => { await api('POST', '/api/cook/logout', {}).catch(() => {}); clearInterval(S.timer); loginView(); };
}

async function boot2() {
  try { S.me = await api('GET', '/api/cook/me'); } catch { return loginView(); }
  try { S.wallet = await api('GET', '/api/store/wallet'); } catch { S.wallet = { deliveryMode: 'none', balance: 0 }; }
  try { const cfg = await api('GET', '/api/config'); S.cats = cfg.site?.categories || []; } catch { /* ignore */ }
  S.accepting = S.wallet.accepting !== false;
  frame();
}
(async () => { registerSW(); await initI18n(); document.documentElement.lang = getLang(); boot2(); })();
