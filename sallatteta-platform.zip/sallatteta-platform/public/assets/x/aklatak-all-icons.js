(()=>{
'use strict';
// Presentation only: icon glyphs are upgraded; localized text and click handlers stay intact.
const paths={
home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',
search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
heart:'<path d="M20.8 8.5c0 4.5-8.8 10.5-8.8 10.5S3.2 13 3.2 8.5a4.6 4.6 0 0 1 8.8-1.7 4.6 4.6 0 0 1 8.8 1.7z"/>',
receipt:'<path d="M5 3h14v18l-3-2-4 2-4-2-3 2zM9 8h6M9 12h6M9 16h4"/>',
user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-8 16-8 16 0"/>',
location:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/>',
palette:'<path d="M12 3a9 9 0 0 0 0 18h2a2 2 0 0 0 2-2c0-2-2-2-2-4a2 2 0 0 1 2-2h2a4 4 0 0 0 4-4c0-4-5-6-10-6z"/><circle cx="7.5" cy="10" r="1"/><circle cx="11" cy="6.8" r="1"/><circle cx="16" cy="8" r="1"/>',
globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18M12 3c5 5 5 13 0 18"/>',
shop:'<path d="M4 10 6 3h12l2 7M4 10v11h16V10M9 21v-8h6v8"/><path d="M3 10c0 4 4 4 5 1 1 3 5 3 6 0 1 3 5 3 7-1"/>',
food:'<path d="M5 3v7m3-7v7M2 3v5c0 3 3 4 4 4v9M18 3c-6 0-6 10 0 10h2V3h-2zm0 10v8"/>',
cart:'<path d="M2 4h3l3 12h11l3-9H6"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
coffee:'<path d="M4 7h14v8c0 7-14 7-14 0zM18 9h2c4 0 3 6-2 6M3 22h17"/>',
medicine:'<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M12 8v9M7.5 12.5h9"/>',
bike:'<circle cx="5" cy="18" r="3"/><circle cx="19" cy="18" r="3"/><path d="m5 18 5-9 4 9h5l-5-9h-4M8 6h4"/>',
truck:'<path d="M2 6h12v12H2zM14 10h4l4 5v3h-8"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/>',
gift:'<rect x="3" y="10" width="18" height="12" rx="1"/><path d="M2 10h20M12 10v12M12 10c-10 0-9-7-5-7 3 0 5 7 5 7zm0 0c10 0 9-7 5-7-3 0-5 7-5 7z"/>',
star:'<path d="m12 2 3 7 7 .5-5.5 5 1.8 7.5L12 18l-6.3 4 1.8-7.5L2 9.5 9 9z"/>',
settings:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M19 5l-2 2M7 17l-2 2"/>',
chart:'<path d="M4 21V3M4 21h18M8 17v-6M13 17V7M18 17V4"/>',
wallet:'<rect x="2" y="5" width="20" height="16" rx="3"/><path d="M15 11h7v5h-7a2.5 2.5 0 0 1 0-5z"/>',
phone:'<path d="M7 3 4 6c-2 5 9 16 14 14l3-3-6-5-3 3-4-4 3-3z"/>',
note:'<path d="M5 2h14v20H5zM8 8h8M8 12h8M8 16h5"/>',
lock:'<rect x="4" y="10" width="16" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
info:'<circle cx="12" cy="12" r="10"/><path d="M12 10v7M12 6h.01"/>',
spark:'<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/>',
back:'<path d="m15 5-7 7 7 7"/>',
check:'<path d="m4 12 5 5L20 6"/>',
package:'<path d="m3 7 9-4 9 4v11l-9 4-9-4zM3 7l9 5 9-5M12 12v10"/>',
menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',
hospital:'<rect x="4" y="3" width="16" height="19" rx="2"/><path d="M12 7v8M8 11h8M9 22v-4h6v4"/>'
};
const mapping=[
['home','🏠🏡🏘'],['search','🔍🔎'],['heart','❤️♥️🤍💗💖💝💕💓'],['receipt','🧾📋📄📃'],['user','👤👥🙍'],['location','📍🗺️🌐🌍🌎🌏'],['palette','🎨'],['shop','🏪🏬🏢'],['food','🍔🍕🍟🍽️🍴🥗🍲🥘🥙🌮🍛🍱🍝🍰🧁🍞🥖'],['cart','🛒🛍️🧺'],['coffee','☕🍵'],['medicine','💊💉🩺'],['bike','🛵🚲🏍️'],['truck','🚚🚛🚗'],['gift','🎁💐🌹'],['star','⭐🌟✨'],['settings','⚙️🔧🛠️'],['chart','📊📈📉'],['wallet','💵💰💳💸'],['phone','📞☎️📱📲'],['note','📝✏️'],['lock','🔒🔐🔑'],['info','ℹ️❗❓'],['back','⬅️🔙'],['check','✅☑️✔️'],['package','📦'],['hospital','🏥'],['menu','☰']
];
const iconMap=new Map();
for(const [kind,chars] of mapping)for(const c of [...new Intl.Segmenter('en',{granularity:'grapheme'}).segment(chars)].map(x=>x.segment))iconMap.set(c,kind);
const emojiRe=/\p{Extended_Pictographic}/u;
function glyph(kind){
 const span=document.createElement('span');span.className='ak-svg-icon';span.setAttribute('aria-hidden','true');
 span.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(paths[kind]||paths.spark)+'</svg>';
 return span;
}
const segmenter=new Intl.Segmenter('en',{granularity:'grapheme'});
function upgrade(root){
 if(!root||!root.isConnected)return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(n){
  if(!emojiRe.test(n.nodeValue||''))return NodeFilter.FILTER_REJECT;
  const p=n.parentElement;
  if(!p||p.closest('script,style,textarea,option,svg,.ak-svg-icon,[contenteditable],.ak-real-icon'))return NodeFilter.FILTER_REJECT;
  return NodeFilter.FILTER_ACCEPT;
 }});
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 for(const node of nodes){
  const parts=[...segmenter.segment(node.nodeValue)].map(x=>x.segment);
  if(!parts.some(x=>iconMap.has(x)))continue;
  const frag=document.createDocumentFragment();
  for(const part of parts){if(iconMap.has(part))frag.append(glyph(iconMap.get(part)));else frag.append(document.createTextNode(part));}
  node.replaceWith(frag);
 }
}
let pending=false;
function schedule(){if(pending)return;pending=true;queueMicrotask(()=>{pending=false;upgrade(document.body)})}
function init(){
 upgrade(document.body);
 new MutationObserver(schedule).observe(document.body,{childList:true,subtree:true,characterData:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();