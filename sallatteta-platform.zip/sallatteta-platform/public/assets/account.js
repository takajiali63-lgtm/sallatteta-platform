import { initI18n, t, api, errorText, esc, fmtNumber, fmtDate, setRegion, getConfig, fmtMoney } from './i18n.js?v=602';
import { $, avatarHtml, resizeImage, servedAreasEditor, getPosition, locatedText, accuracyHtml, initMenu, explainGpsError } from './ui.js?v=602';

let me = null, config = null, editor = null, newAvatar;
const msg = (el, text, ok = true) => { el.textContent = text; el.className = `alert ${ok ? 'ok' : ''}`; el.hidden = !text; };

async function call(path, opts) {
  try { return await api(path, opts); }
  catch (err) { if (err.status === 401) showLogin(); throw err; }
}

function showLogin() { $('#loginView').hidden = false; $('#dashView').hidden = true; $('#logoutBtn').hidden = true; }

// Phone keypad by default; "Aa" switches to letters (the owner can sign in with his admin username here too).
$('#kbdToggle')?.addEventListener('click', () => {
  const i = $('#lw');
  i.inputMode = i.inputMode === 'tel' ? 'text' : 'tel';
  $('#kbdToggle').textContent = i.inputMode === 'tel' ? 'Aa' : '123';
  i.blur(); i.focus();
});

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginError').hidden = true;
  try {
    const r = await api('/api/cook/login', { method: 'POST', body: { whatsapp: e.target.whatsapp.value, password: e.target.password.value } });
    if (r.admin) { location.href = r.redirect || '/admin/'; return; }   // the owner signed in with his admin username
    e.target.reset();
    await loadMe();
  } catch (err) { $('#loginError').textContent = errorText(err); $('#loginError').hidden = false; }
});
$('#logoutBtn').addEventListener('click', async () => { await api('/api/cook/logout', { method: 'POST', body: {} }).catch(() => {}); showLogin(); });

async function loadMe() {
  me = await call('/api/cook/me');
  $('#loginView').hidden = true; $('#dashView').hidden = false; $('#logoutBtn').hidden = false;
  render();
}

function stat(label, total, last30) {
  return `<div class="stat-card"><b>${fmtNumber(total)}</b><span>${esc(label)}</span>${last30 != null ? `<small>${esc(t('account.last30', { n: fmtNumber(last30) }))}</small>` : ''}</div>`;
}

function render() {
  $('#hello').textContent = t('account.hello', { name: me.name });
  $('#viewPage').href = me.profileUrl;
  const s = me.stats;
  $('#stats').innerHTML = [
    stat(t('account.views'), s.views_total, s.views_30d),
    stat(t('account.likes'), s.likes),
    stat(t('account.impressions'), s.impressions_total, s.impressions_30d),
    stat(t('account.clicks'), s.whatsapp_total, s.whatsapp_30d),
  ].join('') + `<div class="stat-card"><b>${s.rating.count ? `★ ${s.rating.avg}` : '—'}</b><span>${esc(t('account.rating'))}</span><small>${s.rating.count ? esc(t('cookPage.ratingCount', { n: s.rating.count })) : esc(t('account.noRating'))}</small></div>`;

  const sub = me.subscription;
  const active = sub && sub.status === 'active';
  $('#subText').innerHTML = sub
    ? `<span class="pill ${esc(sub.status)}">${esc(t(`status.${sub.status}`))}</span> ${sub.expiryDate ? esc(t('account.expires', { date: fmtDate(sub.expiryDate) })) : ''}`
    : esc(t('status.no_subscription'));
  msg($('#subAlert'), me.hidden ? t('account.accountHidden') : active ? '' : t('account.subInactive'), false);

  $('#photoCount').textContent = t('account.photosCount', { n: me.photos.length, max: me.maxPhotos });
  $('#photos').innerHTML = me.photos.map((p) => `
    <figure><img src="${esc(p.url)}" alt="${esc(p.caption)}" loading="lazy">
      <button type="button" class="del" data-del="${p.id}">${esc(t('account.deletePhoto'))}</button>
      ${p.hidden ? `<span class="tag">${esc(t('account.hiddenByAdmin'))}</span>` : ''}
      <figcaption>${esc(p.caption)}</figcaption></figure>`).join('');
  $('#addPhotoBox').hidden = me.photos.length >= me.maxPhotos;

  $('#avatarPrev').innerHTML = avatarHtml({ name: me.name, photoUrl: newAvatar || me.photoUrl });
  $('#bio').value = me.bio;
  $('#hOpen').value = me.hours?.open || ''; $('#hClose').value = me.hours?.close || ''; $('#hAllDay').checked = !!me.hours?.allDay; $('#accBooking').checked = !!me.booking;
  document.querySelectorAll('[data-closed]').forEach((x) => { x.checked = (me.hours?.closed || []).includes(Number(x.dataset.closed)); });
  $('#deleteZone').hidden = false;
  const isRest = true;   // every category: description + menu (no service types, no separate specialty)
  $('#specialtyField').hidden = true;
  $('#servicesField').hidden = true;
  $('#specialty').value = me.specialty || '';
  $('#menuPanel').hidden = !isRest;
  if (isRest) renderMenuItems();
  $('#supportAlert').hidden = !me.unreadSupport;
  loadThread();
  $('#services').innerHTML = config.serviceTypes.map((k) =>
    `<label class="chip"><input type="checkbox" name="services" value="${k}" ${me.services.includes(k) ? 'checked' : ''}><span>${esc(t(`services.${k}`))}</span></label>`).join('');
  editor = servedAreasEditor($('#areasEditor'), { initial: me.servedAreas, point: me.location, districts: config.districts });
  $('#areaLabel').value = me.area?.name || '';
}

$('#photos').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-del]');
  if (!b || !confirm(t('account.confirmDelete'))) return;
  me = await call(`/api/cook/photos/${b.dataset.del}`, { method: 'DELETE' });
  render();
});

$('#photoFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const btn = $('#addPhotoBtn');
  btn.textContent = t('account.uploading');
  $('#photoError').hidden = true;
  try {
    const data = await resizeImage(file, 1000, 0.8);
    const thumb = await resizeImage(file, 400, 0.72);
    me = await call('/api/cook/photos', { method: 'POST', body: { data, thumb, caption: $('#caption').value } });
    $('#caption').value = '';
    render();
  } catch (err) { $('#photoError').textContent = errorText(err); $('#photoError').hidden = false; }
  finally { btn.textContent = t('account.addPhoto'); e.target.value = ''; }
});

// The profile photo is saved as soon as it is chosen (no need to press "Save" — people expected that).
$('#avatarFile').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const status = (text, ok = true) => { const el = $('#avatarStatus'); el.textContent = text; el.className = `avatar-status ${ok ? 'ok' : 'bad'}`; el.hidden = !text; };
  status(t('account.uploading'));
  let data;
  try {
    data = await resizeImage(f, 400, 0.82);
  } catch {
    // The phone gave a format the browser can't read (often HEIC/HEIF from Samsung or iPhone cameras).
    status(t(/heic|heif/i.test(f.type + f.name) ? 'account.photoHeic' : 'account.photoUnreadable'), false);
    e.target.value = '';
    return;
  }
  try {
    $('#avatarPrev').innerHTML = avatarHtml({ name: me.name, photoUrl: data });
    me = await call('/api/cook/me', { method: 'PATCH', body: { photo: data } });
    newAvatar = undefined;
    render();
    status(t('account.photoSaved'));
  } catch (err) {
    status(err.code === 'validation_failed' ? t('errors.too_large') : errorText(err), false);
    render();
  } finally { e.target.value = ''; }
});

$('#saveProfile').addEventListener('click', async () => {
  const body = {
    bio: $('#bio').value,
    booking: $('#accBooking').checked,
    hours: $('#hAllDay').checked ? { allDay: true, closed: [...document.querySelectorAll('[data-closed]:checked')].map((x) => Number(x.dataset.closed)) } : $('#hOpen').value && $('#hClose').value ? { open: $('#hOpen').value, close: $('#hClose').value, closed: [...document.querySelectorAll('[data-closed]:checked')].map((x) => Number(x.dataset.closed)) } : null,
    ...((!!me.kind && me.kind !== 'cook') ? { specialty: $('#specialty').value } : {}),
    services: [...document.querySelectorAll('#services input:checked')].map((i) => i.value),
    servedAreaIds: editor.ids(),
    areaLabel: $('#areaLabel').value,
  };
  if (newAvatar) body.photo = newAvatar;
  try {
    me = await call('/api/cook/me', { method: 'PATCH', body });
    newAvatar = undefined;
    render();
    msg($('#profileMsg'), t('account.saved'));
  } catch (err) {
    const f = Object.values(err.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    msg($('#profileMsg'), f || errorText(err), false);
  }
});

$('#locBtn').addEventListener('click', async () => {
  const st = $('#locStatus');
  st.classList.remove('bad');
  st.textContent = t('location.locating');
  try {
    const pos = await getPosition({ precise: true, onProgress: (m) => { st.textContent = t('join.locatingPrecise', { m }); } });
    await call('/api/cook/me', { method: 'PATCH', body: { lat: pos.lat, lng: pos.lng, accuracy: pos.accuracy, locationAt: pos.at } });
    me.location = pos;
    const r = await editor.setPoint(pos.lat, pos.lng);
    st.textContent = `${t('account.locationUpdated')} — ${locatedText(r)}`;
    $('#locAccuracy').innerHTML = accuracyHtml(pos);
    $('#locAccuracy').hidden = false;
  } catch (gpsErr) { if (typeof gpsErr?.code === 'string') { st.classList.add('bad'); st.textContent = errorText(gpsErr); } else explainGpsError(st, gpsErr, () => $('#locBtn').click()); }
});

$('#pwForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await call('/api/cook/password', { method: 'POST', body: { current: $('#pc').value, next: $('#pn').value } });
    e.target.reset();
    msg($('#pwMsg'), t('account.passwordChanged'));
  } catch (err) {
    const f = Object.values(err.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    msg($('#pwMsg'), f || errorText(err), false);
  }
});

/* ---------- restaurant menu ---------- */
const money = (v, cur) => fmtMoney(v, cur);
function renderMenuItems() {
  const cur = config?.country?.currency || me.menu[0]?.currency || 'USD';
  $('#mPriceLabel').textContent = t('account.itemPrice', { cur });
  $('#menuItems').innerHTML = me.menu.map((it) => `
    <li class="menu-item">
      <span><b>${esc(it.name)}</b>${it.description ? `<small>${esc(it.description)}</small>` : ''}
        ${it.price != null ? `<span class="price">${esc(money(it.price, it.currency))}</span>` : ''}</span>
      <span>
        <button class="btn-text" type="button" data-avail="${it.id}" data-to="${it.available ? 0 : 1}">${esc(t(it.available ? 'account.available' : 'account.unavailable'))}</button>
        <button class="btn-text" type="button" data-delitem="${it.id}">${esc(t('account.deletePhoto'))}</button>
      </span>
    </li>`).join('');
}
$('#menuForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    me = await call('/api/cook/menu', { method: 'POST', body: { name: $('#mName').value, price: $('#mPrice').value, description: $('#mDesc').value } });
    e.target.reset();
    renderMenuItems();
    msg($('#menuMsg'), t('account.saved'));
  } catch (err) {
    const f = Object.values(err.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    msg($('#menuMsg'), f || errorText(err), false);
  }
});
$('#menuItems').addEventListener('click', async (e) => {
  const a = e.target.closest('[data-avail]'); const d = e.target.closest('[data-delitem]');
  if (a) me = await call(`/api/cook/menu/${a.dataset.avail}`, { method: 'PATCH', body: { available: a.dataset.to === '1' } });
  else if (d) { if (!confirm(t('account.confirmDelete'))) return; me = await call(`/api/cook/menu/${d.dataset.delitem}`, { method: 'DELETE' }); }
  else return;
  renderMenuItems();
});

/* ---------- contact the admin ---------- */
async function loadThread() {
  try {
    const { messages } = await call('/api/cook/support');
    $('#thread').innerHTML = messages.map((m) => `<div class="bubble ${m.fromAdmin ? 'team' : 'me'}"><small>${esc(t(m.fromAdmin ? 'account.supportTeam' : 'account.supportYou'))} · ${esc(fmtDate(m.createdAt))}</small>${esc(m.body)}</div>`).join('');
    $('#thread').scrollTop = $('#thread').scrollHeight;
  } catch { /* ignore */ }
}
$('#supportForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = $('#supportText').value.trim();
  if (body.length < 2) return;
  try {
    await call('/api/cook/support', { method: 'POST', body: { body } });
    $('#supportText').value = '';
    msg($('#supportMsg'), '');
    loadThread();
  } catch (err) { msg($('#supportMsg'), errorText(err), false); }
});

(async function boot() {
  await initI18n();
  initMenu();
  config = await getConfig();
  try { await loadMe(); } catch { showLogin(); }
})();

// Google Play requirement: delete my account (permanent, password required)
document.getElementById('deleteMe')?.addEventListener('click', async () => {
  if (!confirm(t('del.confirm'))) return;
  const pw = prompt(t('del.password')); if (!pw) return;
  try { await api('/api/cook/me/delete', { method: 'POST', body: { password: pw } }); alert(t('del.done')); location.href = '/'; }
  catch (err) { alert(errorText(err)); }
});
