import { initI18n, t, api, errorText, esc, fmtNumber } from './i18n.js?v=240';
import { $, avatarHtml, resizeImage, servedAreasEditor, getPosition, locatedText, accuracyHtml } from './ui.js?v=240';

let me = null, config = null, editor = null, newAvatar;
const fmtDate = (v) => (v ? new Date(v).toLocaleDateString('ar-LB-u-nu-latn', { year: 'numeric', month: 'long', day: 'numeric' }) : '—');
const msg = (el, text, ok = true) => { el.textContent = text; el.className = `alert ${ok ? 'ok' : ''}`; el.hidden = !text; };

async function call(path, opts) {
  try { return await api(path, opts); }
  catch (err) { if (err.status === 401) showLogin(); throw err; }
}

function showLogin() { $('#loginView').hidden = false; $('#dashView').hidden = true; $('#logoutBtn').hidden = true; }

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#loginError').hidden = true;
  try {
    await api('/api/cook/login', { method: 'POST', body: { whatsapp: e.target.whatsapp.value, password: e.target.password.value } });
    e.target.reset();
    await loadMe();
  } catch (err) { $('#loginError').textContent = errorText(err); $('#loginError').hidden = false; }
});
$('#logoutBtn').addEventListener('click', async () => { await api('/api/cook/logout', { method: 'POST', body: {} }).catch(() => {}); showLogin(); });

async function loadMe() {
  me = await call('/api/cook/me');
  $('#loginView').hidden = true; $('#dashView').hidden = false; $('#logoutBtn').hidden = false;
  render();
}

function stat(label, total, last30) {
  return `<div class="stat-card"><b>${fmtNumber(total)}</b><span>${esc(label)}</span>${last30 != null ? `<small>${esc(t('account.last30', { n: fmtNumber(last30) }))}</small>` : ''}</div>`;
}

function render() {
  $('#hello').textContent = t('account.hello', { name: me.name });
  $('#viewPage').href = me.profileUrl;
  const s = me.stats;
  $('#stats').innerHTML = [
    stat(t('account.views'), s.views_total, s.views_30d),
    stat(t('account.likes'), s.likes),
    stat(t('account.impressions'), s.impressions_total, s.impressions_30d),
    stat(t('account.clicks'), s.whatsapp_total, s.whatsapp_30d),
  ].join('') + `<div class="stat-card"><b>${s.rating.count ? `★ ${s.rating.avg}` : '—'}</b><span>${esc(t('account.rating'))}</span><small>${s.rating.count ? esc(t('cookPage.ratingCount', { n: s.rating.count })) : esc(t('account.noRating'))}</small></div>`;

  const sub = me.subscription;
  const active = sub && sub.status === 'active';
  $('#subText').innerHTML = sub
    ? `<span class="pill ${esc(sub.status)}">${esc(t(`status.${sub.status}`))}</span> ${sub.expiryDate ? esc(t('account.expires', { date: fmtDate(sub.expiryDate) })) : ''}`
    : esc(t('status.no_subscription'));
  msg($('#subAlert'), active ? '' : t('account.subInactive'), false);

  $('#photoCount').textContent = t('account.photosCount', { n: me.photos.length, max: me.maxPhotos });
  $('#photos').innerHTML = me.photos.map((p) => `
    <figure><img src="${esc(p.url)}" alt="${esc(p.caption)}" loading="lazy">
      <button type="button" class="del" data-del="${p.id}">${esc(t('account.deletePhoto'))}</button>
      ${p.hidden ? `<span class="tag">${esc(t('account.hiddenByAdmin'))}</span>` : ''}
      <figcaption>${esc(p.caption)}</figcaption></figure>`).join('');
  $('#addPhotoBox').hidden = me.photos.length >= me.maxPhotos;

  $('#avatarPrev').innerHTML = avatarHtml({ name: me.name, photoUrl: newAvatar || me.photoUrl });
  $('#bio').value = me.bio;
  $('#services').innerHTML = config.serviceTypes.map((k) =>
    `<label class="chip"><input type="checkbox" name="services" value="${k}" ${me.services.includes(k) ? 'checked' : ''}><span>${esc(t(`services.${k}`))}</span></label>`).join('');
  editor = servedAreasEditor($('#areasEditor'), { initial: me.servedAreas, point: me.location, districts: config.districts });
  $('#areaLabel').value = me.area?.name || '';
}

$('#photos').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-del]');
  if (!b || !confirm(t('account.confirmDelete'))) return;
  me = await call(`/api/cook/photos/${b.dataset.del}`, { method: 'DELETE' });
  render();
});

$('#photoFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const btn = $('#addPhotoBtn');
  btn.textContent = t('account.uploading');
  $('#photoError').hidden = true;
  try {
    const data = await resizeImage(file, 1000, 0.8);
    me = await call('/api/cook/photos', { method: 'POST', body: { data, caption: $('#caption').value } });
    $('#caption').value = '';
    render();
  } catch (err) { $('#photoError').textContent = errorText(err); $('#photoError').hidden = false; }
  finally { btn.textContent = t('account.addPhoto'); e.target.value = ''; }
});

$('#avatarFile').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  newAvatar = await resizeImage(f, 320, 0.82);
  $('#avatarPrev').innerHTML = avatarHtml({ name: me.name, photoUrl: newAvatar });
});

$('#saveProfile').addEventListener('click', async () => {
  const body = {
    bio: $('#bio').value,
    services: [...document.querySelectorAll('#services input:checked')].map((i) => i.value),
    servedAreaIds: editor.ids(),
    areaLabel: $('#areaLabel').value,
  };
  if (newAvatar) body.photo = newAvatar;
  try {
    me = await call('/api/cook/me', { method: 'PATCH', body });
    newAvatar = undefined;
    render();
    msg($('#profileMsg'), t('account.saved'));
  } catch (err) {
    const f = Object.values(err.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    msg($('#profileMsg'), f || errorText(err), false);
  }
});

$('#locBtn').addEventListener('click', async () => {
  const st = $('#locStatus');
  st.classList.remove('bad');
  st.textContent = t('location.locating');
  try {
    const pos = await getPosition({ precise: true, onProgress: (m) => { st.textContent = t('join.locatingPrecise', { m }); } });
    await call('/api/cook/me', { method: 'PATCH', body: { lat: pos.lat, lng: pos.lng } });
    me.location = pos;
    const r = await editor.setPoint(pos.lat, pos.lng);
    st.textContent = `${t('account.locationUpdated')} — ${locatedText(r)}`;
    $('#locAccuracy').innerHTML = accuracyHtml(pos);
    $('#locAccuracy').hidden = false;
  } catch { st.classList.add('bad'); st.textContent = t('join.gpsDenied'); }
});

$('#pwForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await call('/api/cook/password', { method: 'POST', body: { current: $('#pc').value, next: $('#pn').value } });
    e.target.reset();
    msg($('#pwMsg'), t('account.passwordChanged'));
  } catch (err) {
    const f = Object.values(err.fields || {}).map((c) => t(`errors.${c}`)).join(' — ');
    msg($('#pwMsg'), f || errorText(err), false);
  }
});

(async function boot() {
  await initI18n();
  config = await api('/api/config');
  try { await loadMe(); } catch { showLogin(); }
})();
