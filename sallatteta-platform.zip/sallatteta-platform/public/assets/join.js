import { initI18n, t, api, errorText, esc, setRegion, getConfig, rememberCountry, fmtMoney } from './i18n.js?v=451';
import { servedAreasEditor, getPosition, locatedText, accuracyHtml, initMenu, explainGpsError } from './ui.js?v=451';

const $ = (s) => document.querySelector(s);
const startedAt = Date.now();
let photo = null;
let coords = null;
let editor = null;
let cfg = null;
let kind = new URLSearchParams(location.search).get('type') === 'restaurant' ? 'restaurant' : null;

/** Cook or restaurant: same form, different fields, prices and texts. */
function showForm(k) {
  kind = k;
  $('#chooseView').hidden = true;
  $('#formView').hidden = false;
  $('#formTitle').textContent = t(k === 'restaurant' ? 'join.titleRestaurant' : 'join.titleCook');
  $('#formLead').textContent = t(k === 'restaurant' ? 'join.leadRestaurant' : 'join.lead');
  $('#fullNameLabel').textContent = t(k === 'restaurant' ? 'join.restaurantName' : 'join.fullName');
  $('#specialtyField').hidden = k !== 'restaurant';
  $('#servicesLabel').hidden = k === 'restaurant';
  $('#serviceChips').hidden = k === 'restaurant';
  const err = document.querySelector('[data-err="services"]'); if (err && k === 'restaurant') err.hidden = true;
  renderCountryParts();
  window.scrollTo({ top: 0 });
}

/** Plan prices (USD or EUR by the cook's country) and the phone example follow the country. */
function priceText(plan) {
  const cur = cfg.billing?.currency || 'USD';
  const v = cfg.site?.prices?.[kind || 'cook']?.[plan]?.[cur.toLowerCase()];
  if (v === '' || v == null) return '';
  return ` — ${fmtMoney(Number(v), cur)}`;
}
function renderTrialNotes() {
  document.querySelectorAll('[data-trial]').forEach((el) => {
    const tr = cfg.site?.trial?.[el.dataset.trial];
    el.textContent = tr?.enabled ? ` · ${t('join.trialNote', { days: tr.days })}` : '';
  });
}
function renderCountryParts() {
  renderTrialNotes();
  const current = document.querySelector('input[name="plan"]:checked')?.value || 'monthly';
  chips('#planChips', 'plan', cfg.plans.map((k) => [k, t(`plans.${k}`) + priceText(k)]), { checked: [current] });
  $('#whatsappHint').textContent = t('join.whatsappHintIntl', { dial: cfg.country?.dialCode || '' });
}

function chips(container, name, items, { type = 'radio', checked = [] } = {}) {
  $(container).innerHTML = items.map(([value, label]) =>
    `<label class="chip"><input type="${type}" name="${name}" value="${esc(value)}" ${checked.includes(value) ? 'checked' : ''}><span>${esc(label)}</span></label>`).join('');
}

function showFieldErrors(fields = {}) {
  document.querySelectorAll('[data-err]').forEach((el) => {
    const code = fields[el.dataset.err];
    el.hidden = !code;
    el.textContent = code ? t(`errors.${code}`) : '';
    const input = document.getElementById(el.dataset.err);
    if (input) input.setAttribute('aria-invalid', code ? 'true' : 'false');
  });
  const first = document.querySelector('[data-err]:not([hidden])');
  if (first) first.closest('.field')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

// Resize to max 320px JPEG in the browser so uploads stay small (~20–40 KB).
function resizeImage(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const max = 320;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.82));
    };
    img.onerror = reject;
    img.src = url;
  });
}

function setPreview() {
  const box = $('#photoPreview');
  box.innerHTML = photo ? `<img class="avatar" src="${photo}" alt="">` : '+';
  $('#photoRemove').hidden = !photo;
}

(async function boot() {
  await initI18n(); initMenu();
  try { cfg = await getConfig(); } catch (err) { $('#formError').textContent = errorText(err); $('#formError').hidden = false; return; }
  editor = servedAreasEditor($('#servedEditor'), { districts: cfg.districts });
  chips('#serviceChips', 'services', cfg.serviceTypes.map((k) => [k, t(`services.${k}`)]), { type: 'checkbox' });
  renderTrialNotes();
  // Placeholders become links (markers survive escaping, then are swapped for safe <a> tags).
  $('#consentText').innerHTML = esc(t('legal.acceptTerms', { terms: '\u0001T\u0001', privacy: '\u0001P\u0001' }))
    .replace('\u0001T\u0001', `<a href="/terms" target="_blank" rel="noopener">${esc(t('legal.termsLink'))}</a>`)
    .replace('\u0001P\u0001', `<a href="/privacy" target="_blank" rel="noopener">${esc(t('legal.privacyLink'))}</a>`);
  document.querySelectorAll('[data-kind]').forEach((b) => b.addEventListener('click', () => showForm(b.dataset.kind)));
  $('#changeType').addEventListener('click', () => { $('#formView').hidden = true; $('#chooseView').hidden = false; window.scrollTo({ top: 0 }); });
  if (kind) showForm(kind);
})();

$('#gpsBtn').addEventListener('click', async () => {
  const s = $('#gpsStatus');
  const btn = $('#gpsBtn');
  s.classList.remove('bad');
  s.textContent = t('location.locating');
  btn.disabled = true;
  $('#gpsAccuracy').hidden = true;
  try {
    coords = await getPosition({ precise: true, maxWaitMs: 15000, goodEnough: 25, onProgress: (m) => { s.textContent = t('join.locatingPrecise', { m }); } });
  } catch (gpsErr) {
    coords = null; explainGpsError(s, gpsErr); btn.disabled = false;
    return;
  }
  s.textContent = t('join.loadingAreas');
  try {
    const r = await editor.setPoint(coords.lat, coords.lng);
    // The cook's real country (from GPS) decides the price currency and phone format.
    if (r.country && r.country !== cfg.country?.code) {
      rememberCountry(r.country);
      try { cfg = await (await fetch(`/api/config?country=${r.country}`)).json(); renderCountryParts(); } catch { /* keep current */ }
    }
    s.textContent = locatedText(r);
    s.classList.toggle('bad', r.source === 'fallback');
    $('#gpsAccuracy').innerHTML = accuracyHtml(coords);
    $('#gpsAccuracy').hidden = false;
    if (!$('#homeArea').value && r.nearest) $('#homeArea').placeholder = r.nearest.name;
    btn.textContent = t('join.gpsAgain');
    btn.classList.replace('btn-gold', 'btn-ghost');
    document.querySelector('[data-err="location"]').hidden = true;
  } catch (err) {
    s.classList.add('bad'); s.textContent = errorText(err);
  } finally { btn.disabled = false; }
});

$('#photoInput').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try { photo = await resizeImage(f); } catch { photo = null; }
  setPreview();
});
$('#photoRemove').addEventListener('click', () => { photo = null; $('#photoInput').value = ''; setPreview(); });

$('#showPw').addEventListener('click', () => {
  const i = $('#password');
  i.type = i.type === 'password' ? 'text' : 'password';
});

$('#joinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const btn = $('#submitBtn');
  $('#formError').hidden = true;
  if (!coords) { showFieldErrors({ location: 'location_required' }); return; }
  if ($('#password').value.length < 5) { showFieldErrors({ password: 'password_too_short' }); $('#password').focus(); return; }
  if (!$('#acceptTerms').checked) { showFieldErrors({ acceptTerms: 'required' }); $('#acceptTerms').focus(); return; }
  const body = {
    fullName: form.fullName.value,
    whatsapp: form.whatsapp.value,
    areaLabel: $('#homeArea').value || undefined,
    servedAreaIds: editor.ids(),
    lat: coords?.lat, lng: coords?.lng, accuracy: coords?.accuracy, locationAt: coords?.at,
    kind: kind || 'cook',
    acceptTerms: $('#acceptTerms').checked,
    password: $('#password').value,
    specialty: kind === 'restaurant' ? $('#specialty').value : undefined,
    services: kind === 'restaurant' ? [] : [...form.querySelectorAll('input[name="services"]:checked')].map((i) => i.value),
    bio: form.bio.value,
    plan: form.querySelector('input[name="plan"]:checked')?.value,
    photo: photo || undefined,
    website: form.website.value,
    startedAt,
  };
  btn.disabled = true;
  btn.textContent = t('join.submitting');
  try {
    const res = await api('/api/cook-applications', { method: 'POST', body });
    $('#formView').hidden = true;
    $('#doneView').hidden = false;
    window.scrollTo({ top: 0 });
    if (res.whatsappUrl) {
      $('#doneText').textContent = t('join.doneText');
      const a = $('#adminWa');
      a.href = res.whatsappUrl;
      a.hidden = false;
      window.location.href = res.whatsappUrl; // opens WhatsApp with the application ready
    } else {
      $('#doneText').textContent = t('join.noAdmin');
    }
  } catch (err) {
    showFieldErrors(err.fields);
    $('#formError').textContent = errorText(err);
    $('#formError').hidden = false;
    if (!Object.keys(err.fields || {}).length) $('#formError').scrollIntoView({ block: 'center' });
  } finally {
    btn.disabled = false;
    btn.textContent = t('join.submit');
  }
});
