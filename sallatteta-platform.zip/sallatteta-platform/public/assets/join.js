import { initI18n, t, api, errorText, esc, getApproxPosition } from './i18n.js';
import { areaSearch, servedAreasEditor, radiusChips } from './ui.js';

const $ = (s) => document.querySelector(s);
const startedAt = Date.now();
let photo = null;
let coords = null;
let homeAreaId = null;
let editor = null;
let getRadius = () => undefined;

function chips(container, name, items, { type = 'radio', checked = [] } = {}) {
  $(container).innerHTML = items.map(([value, label]) =>
    `<label class="chip"><input type="${type}" name="${name}" value="${esc(value)}" ${checked.includes(value) ? 'checked' : ''}><span>${esc(label)}</span></label>`).join('');
}

function showFieldErrors(fields = {}) {
  document.querySelectorAll('[data-err]').forEach((el) => {
    const code = fields[el.dataset.err] || (el.dataset.err === 'areaId' && fields.location);
    el.hidden = !code;
    el.textContent = code ? t(`errors.${code}`) : '';
    const input = document.getElementById(el.dataset.err);
    if (input) input.setAttribute('aria-invalid', code ? 'true' : 'false');
  });
  const first = document.querySelector('[data-err]:not([hidden])');
  if (first) first.closest('.field')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

// Resize to max 320px JPEG in the browser so uploads stay small (~20–40 KB).
function resizeImage(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const max = 320;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', 0.82));
    };
    img.onerror = reject;
    img.src = url;
  });
}

function setPreview() {
  const box = $('#photoPreview');
  box.innerHTML = photo ? `<img class="avatar" src="${photo}" alt="">` : '+';
  $('#photoRemove').hidden = !photo;
}

(async function boot() {
  await initI18n();
  let cfg;
  try { cfg = await api('/api/config'); } catch (err) { $('#formError').textContent = errorText(err); $('#formError').hidden = false; return; }
  editor = servedAreasEditor($('#servedEditor'), { districts: cfg.districts });
  getRadius = radiusChips($('#radiusChips'), cfg.radiusOptionsKm, 5);
  areaSearch($('#homeArea'), {
    onPick: (a) => {
      homeAreaId = a.id;
      const p = $('#homePicked'); p.textContent = t('location.picked', { area: `${a.name}${a.districtName ? ' — ' + a.districtName : ''}` }); p.hidden = false;
      editor.setHome(a.id);
    },
  });
  chips('#serviceChips', 'services', cfg.serviceTypes.map((k) => [k, t(`services.${k}`)]), { type: 'checkbox' });
  chips('#planChips', 'plan', cfg.plans.map((k) => [k, t(`plans.${k}`)]), { checked: ['monthly'] });
})();

$('#missingBtn').addEventListener('click', () => { $('#missingBox').hidden = false; $('#missingVillage').focus(); });

$('#gpsBtn').addEventListener('click', async () => {
  const s = $('#gpsStatus');
  s.classList.remove('bad');
  s.textContent = t('location.locating');
  try {
    coords = await getApproxPosition();
    s.textContent = t('join.gpsDone');
    if (!homeAreaId) {
      const { area } = await api(`/api/areas/nearest?lat=${coords.lat}&lng=${coords.lng}`);
      if (area) { homeAreaId = area.id; $('#homeArea').value = area.name; editor.setHome(area.id); }
    }
  }
  catch { coords = null; s.classList.add('bad'); s.textContent = t('errors.gps_unavailable'); }
});

$('#photoInput').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try { photo = await resizeImage(f); } catch { photo = null; }
  setPreview();
});
$('#photoRemove').addEventListener('click', () => { photo = null; $('#photoInput').value = ''; setPreview(); });

$('#joinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const btn = $('#submitBtn');
  $('#formError').hidden = true;
  const body = {
    fullName: form.fullName.value,
    whatsapp: form.whatsapp.value,
    areaId: homeAreaId,
    servedAreaIds: editor.ids(),
    radiusKm: getRadius(),
    missingVillage: $('#missingVillage').value || undefined,
    lat: coords?.lat, lng: coords?.lng,
    services: [...form.querySelectorAll('input[name="services"]:checked')].map((i) => i.value),
    bio: form.bio.value,
    plan: form.querySelector('input[name="plan"]:checked')?.value,
    photo: photo || undefined,
    website: form.website.value,
    startedAt,
  };
  btn.disabled = true;
  btn.textContent = t('join.submitting');
  try {
    const res = await api('/api/cook-applications', { method: 'POST', body });
    $('#formView').hidden = true;
    $('#doneView').hidden = false;
    window.scrollTo({ top: 0 });
    if (res.whatsappUrl) {
      $('#doneText').textContent = t('join.doneText');
      const a = $('#adminWa');
      a.href = res.whatsappUrl;
      a.hidden = false;
      window.location.href = res.whatsappUrl; // opens WhatsApp with the application ready
    } else {
      $('#doneText').textContent = t('join.noAdmin');
    }
  } catch (err) {
    showFieldErrors(err.fields);
    $('#formError').textContent = errorText(err);
    $('#formError').hidden = false;
    if (!Object.keys(err.fields || {}).length) $('#formError').scrollIntoView({ block: 'center' });
  } finally {
    btn.disabled = false;
    btn.textContent = t('join.submit');
  }
});
