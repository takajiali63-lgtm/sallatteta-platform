import { initI18n, t, raw, api, errorText, esc, getApproxPosition } from './i18n.js';
import { $, areaSearch, avatarHtml, starsHtml, starInput, myCooks } from './ui.js';

const STEPS = ['home', 'location', 'results', 'summary'];
const PROGRESS = { home: 1, location: 2, results: 3, summary: 3 };
const DRAFT_KEY = 'st_draft';

const state = {
  config: null, text: '', serviceType: '', location: null, areaName: '',
  requestId: null, areaLabel: '', cooks: [], cook: null, startedAt: Date.now(),
};

/* ---------- navigation ---------- */
function show(step, { push = true } = {}) {
  if (step !== 'home' && !state.text) step = 'home';
  if ((step === 'results' || step === 'summary') && !state.requestId) step = 'location';
  if (step === 'summary' && !state.cook) step = 'results';
  for (const s of STEPS) {
    const el = $(`#step-${s}`);
    el.hidden = s !== step;
    el.classList.toggle('enter', s === step);
  }
  $('#progress').hidden = step === 'home';
  document.querySelectorAll('#progress i').forEach((i, idx) => i.classList.toggle('on', idx < PROGRESS[step]));
  $('#stepLabel').textContent = t('common.step', { n: PROGRESS[step] });
  hideError();
  if (push) history.pushState({ step }, '', step === 'home' ? location.pathname : `#${step}`);
  window.scrollTo({ top: 0 });
  const h = $(`#step-${step} h2`);
  if (h && step !== 'home') { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
}
window.addEventListener('popstate', (e) => show(e.state?.step || 'home', { push: false }));
document.addEventListener('click', (e) => { const go = e.target.closest('[data-go]'); if (go) show(go.dataset.go); });
function showError(msg) { const el = $('#globalError'); el.textContent = msg; el.hidden = false; el.scrollIntoView({ block: 'nearest' }); }
function hideError() { $('#globalError').hidden = true; }

/* ---------- step 1: the request ---------- */
function renderTypeChips() {
  const opts = [['', t('home.anyType')], ...state.config.serviceTypes.map((k) => [k, t(`services.${k}`)])];
  $('#typeChips').innerHTML = opts.map(([k, label]) =>
    `<label class="chip"><input type="radio" name="serviceType" value="${esc(k)}" ${k === state.serviceType ? 'checked' : ''}><span>${esc(label)}</span></label>`).join('');
}
function renderIdeas() {
  const ideas = raw('home.ideas') || [];
  $('#ideas').setAttribute('aria-label', t('home.ideasLabel'));
  $('#ideas').innerHTML = ideas.map((i) => `<button type="button" class="idea">${esc(i)}</button>`).join('');
}
$('#ideas').addEventListener('click', (e) => {
  const b = e.target.closest('.idea');
  if (!b) return;
  const ta = $('#requestText');
  ta.value = ta.value.trim() ? `${ta.value.trim()}، ${b.textContent}` : `بدي ${b.textContent}`;
  ta.dispatchEvent(new Event('input'));
  ta.focus();
});
const saveDraft = () => { try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ text: state.text, serviceType: state.serviceType })); } catch { /* ignore */ } };
$('#requestText').addEventListener('input', (e) => { $('#charCount').textContent = e.target.value.length; $('#textErr').hidden = true; });
$('#homeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = $('#requestText').value.trim();
  if (text.length < 5) {
    $('#textErr').textContent = t(text ? 'errors.too_short' : 'errors.required');
    $('#textErr').hidden = false;
    $('#requestText').focus();
    return;
  }
  state.text = text;
  state.serviceType = document.querySelector('input[name="serviceType"]:checked')?.value || '';
  saveDraft();
  show('location');
  if (!state.location) setTimeout(() => $('#areaInput').focus(), 50);
});

/* ---------- step 2: where ---------- */
function setPicked(text) { const p = $('#pickedArea'); p.textContent = text; p.hidden = !text; }
areaSearch($('#areaInput'), {
  onPick: (a) => {
    state.location = { type: 'area', areaId: a.id };
    state.areaName = a.name;
    setPicked(t('location.picked', { area: `${a.name}${a.districtName ? ' — ' + a.districtName : ''}` }));
    $('#gpsStatus').textContent = '';
  },
});
$('#gpsBtn').addEventListener('click', async () => {
  const status = $('#gpsStatus');
  status.classList.remove('bad');
  status.textContent = t('location.locating');
  try {
    const pos = await getApproxPosition();
    state.location = { type: 'gps', ...pos };
    const { area } = await api(`/api/areas/nearest?lat=${pos.lat}&lng=${pos.lng}`);
    status.textContent = t('location.gpsDone', { area: area?.name || '' });
    $('#areaInput').value = ''; setPicked('');
    await runSearch();
  } catch {
    status.classList.add('bad');
    status.textContent = t('location.gpsDenied');
    $('#areaInput').focus();
  }
});
$('#searchBtn').addEventListener('click', () => {
  if (!state.location) {
    $('#gpsStatus').classList.add('bad');
    $('#gpsStatus').textContent = t('errors.required');
    $('#areaInput').focus();
    return;
  }
  runSearch();
});

async function runSearch() {
  const btn = $('#searchBtn');
  btn.disabled = true;
  try {
    const data = await api('/api/search', {
      method: 'POST',
      body: { text: state.text, serviceType: state.serviceType || undefined, location: state.location, startedAt: state.startedAt, website: '' },
    });
    state.requestId = data.requestId;
    state.areaLabel = data.areaLabel || '';
    state.cooks = data.cooks;
    renderResults();
    show('results');
  } catch (err) {
    showError(err.fields?.text ? t(`errors.${err.fields.text}`) : errorText(err));
  } finally {
    btn.disabled = false;
  }
}

/* ---------- step 3: results ---------- */
const servicesText = (keys) => keys.map((k) => t(`services.${k}`)).join(' + ');
function renderResults() {
  $('#echoText').textContent = state.text;
  const n = state.cooks.length;
  $('#resultsMeta').textContent = [state.areaLabel && t('results.near', { area: state.areaLabel }), n ? t('results.count', { n }) : ''].filter(Boolean).join(' — ');
  $('#emptyState').hidden = n > 0;
  $('#cookList').innerHTML = state.cooks.map((c, i) => `
    <li class="cook-row">
      <button class="cook" type="button" data-idx="${i}" aria-label="${esc(t('results.choose', { name: c.name }))}">
        ${avatarHtml(c)}
        <span>
          <span class="cook-name">${esc(c.name)}</span>
          <span class="cook-meta">${esc(c.area || '')} · ${starsHtml(c.rating)}</span>
          <span class="cook-meta">${esc(servicesText(c.services))}</span>
        </span>
        <span class="cook-dist">${esc(t('common.km', { d: c.distanceKm }))}</span>
      </button>
      <a class="profile-link" href="${esc(c.profileUrl)}">${esc(t('results.viewProfile'))}</a>
    </li>`).join('');
}
$('#cookList').addEventListener('click', (e) => {
  const b = e.target.closest('.cook');
  if (!b) return;
  state.cook = state.cooks[Number(b.dataset.idx)];
  renderSummary();
  show('summary');
});

/* ---------- step 4: summary → WhatsApp ---------- */
function renderSummary() {
  const c = state.cook;
  $('#sumRequest').textContent = state.text;
  $('#sumCook').innerHTML = `${avatarHtml(c)}<span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')} — ${starsHtml(c.rating)}</span></span>`;
  $('#sumDistance').textContent = t('common.km', { d: c.distanceKm });
  $('#sumProfile').href = c.profileUrl;
  $('#waFallback').hidden = true;
}
$('#waBtn').addEventListener('click', async () => {
  const btn = $('#waBtn');
  btn.disabled = true;
  $('#waLabel').textContent = t('summary.sending');
  try {
    const r = await api('/api/contact', { method: 'POST', body: { requestId: state.requestId, cookId: state.cook.id } });
    myCooks.remember({ id: r.cook.id, name: r.cook.name, reviewToken: r.reviewToken });
    $('#waFallback').href = r.whatsappUrl;
    $('#waFallback').hidden = false;
    window.location.href = r.whatsappUrl;
  } catch (err) {
    showError(errorText(err));
    if (err.code === 'request_expired' || err.code === 'request_not_found') state.requestId = null;
  } finally {
    btn.disabled = false;
    $('#waLabel').textContent = t('summary.send');
  }
});

/* ---------- home extras: sliders, my cooks, rating prompt, name search ---------- */
const DISH_ICONS = [
  // tray (kibbeh bil saniyeh)
  '<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="8" y="20" width="48" height="28" rx="4"/><path d="M8 28h48M20 20l24 28M44 20 20 48M32 20v28"/></svg>',
  // rolled grape leaves
  '<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><ellipse cx="32" cy="40" rx="24" ry="10"/><rect x="16" y="24" width="10" height="16" rx="5"/><rect x="27" y="22" width="10" height="18" rx="5"/><rect x="38" y="24" width="10" height="16" rx="5"/></svg>',
  // pot
  '<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 28h40v14a10 10 0 0 1-10 10H22a10 10 0 0 1-10-10z"/><path d="M8 28h48M26 20c0-4 4-4 4-8M36 20c0-4 4-4 4-8"/></svg>',
  // pastries
  '<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M10 44 22 22l12 22z"/><path d="M30 44 42 22l12 22z"/><path d="M8 48h48"/></svg>',
];

function autoSlide(slider, dots) {
  const items = [...slider.children];
  if (items.length < 2) return;
  dots.innerHTML = items.map(() => '<i></i>').join('');
  const mark = () => {
    const idx = Math.round(Math.abs(slider.scrollLeft) / (items[0].offsetWidth + 12));
    [...dots.children].forEach((d, i) => d.classList.toggle('on', i === Math.min(idx, items.length - 1)));
  };
  slider.addEventListener('scroll', () => requestAnimationFrame(mark), { passive: true });
  mark();
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  let paused = false;
  ['pointerdown', 'touchstart', 'focusin'].forEach((ev) => slider.addEventListener(ev, () => { paused = true; }, { passive: true }));
  setInterval(() => {
    if (paused || document.hidden || $('#step-home').hidden) return;
    const w = items[0].offsetWidth + 12;
    const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
    const atEnd = Math.abs(slider.scrollLeft) + slider.clientWidth >= slider.scrollWidth - 4;
    slider.scrollTo({ left: atEnd ? 0 : slider.scrollLeft + dir * w, behavior: 'smooth' });
  }, 4500);
}

async function loadFeed() {
  let feed = { dishes: [], cooks: [] };
  try { feed = await api('/api/feed'); } catch { /* keep placeholders */ }
  const slider = $('#dishSlider');
  if (feed.dishes.length) {
    slider.innerHTML = feed.dishes.map((d) => `
      <a class="dish" href="${esc(d.profileUrl)}">
        <img class="dish-img" src="${esc(d.photoUrl)}" alt="${esc(d.caption)}" loading="lazy">
        ${d.caption ? `<span class="dish-cap">${esc(d.caption)}</span>` : ''}
        <span class="dish-by">${esc(t('feed.by', { name: d.cookName }))} · ${esc(d.area || '')}</span>
      </a>`).join('');
  } else {
    // Before cooks upload photos: warm illustrated cards that also work as ideas.
    const ideas = raw('home.ideas') || [];
    slider.innerHTML = ideas.slice(0, 4).map((idea, i) => `
      <button type="button" class="dish-ph idea-card" data-idea="${esc(idea)}">${DISH_ICONS[i % DISH_ICONS.length]}<b>${esc(idea.split(' ').slice(0, 2).join(' '))}</b></button>`).join('');
    slider.querySelectorAll('.idea-card').forEach((b) => b.addEventListener('click', () => {
      const ta = $('#requestText'); ta.value = `بدي ${b.dataset.idea}`; ta.dispatchEvent(new Event('input')); ta.focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }));
  }
  autoSlide(slider, $('#dishDots'));
  if (feed.cooks.length) {
    $('#cooksBlock').hidden = false;
    $('#cookSlider').innerHTML = feed.cooks.map((c) => `
      <a class="cook-card" href="${esc(c.profileUrl)}">${avatarHtml(c)}<b>${esc(c.name)}</b><span>${esc(c.area || '')}</span>${starsHtml(c.rating)}</a>`).join('');
  }
}

function renderMine() {
  const list = myCooks.list();
  $('#mineBlock').hidden = !list.length;
  $('#mineList').innerHTML = list.slice(0, 8).map((c) => `<a class="chip-sel" href="/c/${c.id}">${esc(c.name)}</a>`).join('');
  // Ask to rate the most recent cook that wasn't rated yet.
  const pending = list.find((c) => c.reviewToken && !c.rating && !c.dismissed && Date.now() - c.at < 60 * 86400_000);
  const slot = $('#rateSlot');
  if (!pending) { slot.innerHTML = ''; return; }
  slot.innerHTML = `<div class="rate-card"><p>${esc(t('mine.rateTitle', { name: pending.name }))}</p><div id="rateStars"></div>
    <button class="btn-text" type="button" id="rateLater">${esc(t('mine.later'))}</button></div>`;
  starInput($('#rateStars'), {
    onPick: async (n) => {
      try {
        await api('/api/reviews', { method: 'POST', body: { token: pending.reviewToken, rating: n } });
        myCooks.update(pending.id, { rating: n });
        slot.innerHTML = `<div class="rate-card"><p>${esc(t('mine.rateThanks'))}</p></div>`;
      } catch (err) { showError(errorText(err)); }
    },
  });
  $('#rateLater').addEventListener('click', () => { myCooks.update(pending.id, { dismissed: true }); slot.innerHTML = ''; });
}

let nameTimer;
$('#nameQ').addEventListener('input', (e) => {
  clearTimeout(nameTimer);
  const q = e.target.value.trim();
  if (q.length < 2) { $('#nameResults').hidden = true; $('#nameEmpty').hidden = true; return; }
  nameTimer = setTimeout(async () => {
    try {
      const { cooks } = await api(`/api/cooks/search?q=${encodeURIComponent(q)}`);
      $('#nameEmpty').hidden = cooks.length > 0;
      $('#nameResults').hidden = !cooks.length;
      $('#nameResults').innerHTML = cooks.map((c) => `
        <li><a class="cook" href="${esc(c.profileUrl)}">${avatarHtml(c)}
          <span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')} · ${starsHtml(c.rating)}</span></span>
          <span class="cook-dist" aria-hidden="true">‹</span></a></li>`).join('');
    } catch { /* ignore */ }
  }, 250);
});

/* ---------- boot ---------- */
(async function boot() {
  await initI18n();
  try { state.config = await api('/api/config'); } catch (err) { showError(errorText(err)); return; }
  try {
    const d = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
    if (d?.text) { $('#requestText').value = d.text; $('#charCount').textContent = d.text.length; state.serviceType = d.serviceType || ''; }
  } catch { /* ignore */ }
  renderTypeChips();
  renderIdeas();
  renderMine();
  history.replaceState({ step: 'home' }, '', location.pathname + location.search);
  show('home', { push: false });
  loadFeed();
})();
