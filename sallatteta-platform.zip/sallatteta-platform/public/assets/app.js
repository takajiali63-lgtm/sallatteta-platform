import { initI18n, t, api, errorText, esc, setRegion, fmtDistance, getConfig, rememberCountry, fmtDistanceM, visitorRegion } from './i18n.js?v=602';
import { $, avatarHtml, starsHtml, starInput, myCooks, getPosition, initMenu, initLangButton, explainGpsError, catLabel, showOnHome } from './ui.js?v=602';

const STEPS = ['home', 'location', 'results', 'summary'];
const PROGRESS = { home: 1, location: 2, results: 3, summary: 3 };
const DRAFT_KEY = 'st_draft';

const state = {
  config: null, text: '', serviceType: '', location: null, areaName: '',
  requestId: null, areaLabel: '', cooks: [], cook: null, startedAt: Date.now(),
};

/* ---------- navigation ---------- */
function show(step, { push = true } = {}) {
  if (step !== 'home' && !state.text) step = 'home';
  if ((step === 'results' || step === 'summary') && !state.requestId) step = 'location';
  if (step === 'summary' && !state.cook) step = 'results';
  for (const s of STEPS) {
    const el = $(`#step-${s}`);
    el.hidden = s !== step;
    el.classList.toggle('enter', s === step);
  }
  $('#progress').hidden = step === 'home';
  $('#headerBack').hidden = step === 'home';
  document.querySelectorAll('#progress i').forEach((i, idx) => i.classList.toggle('on', idx < PROGRESS[step]));
  $('#stepLabel').textContent = t('common.step', { n: PROGRESS[step] });
  hideError();
  if (push) history.pushState({ step }, '', step === 'home' ? location.pathname : `#${step}`);
  window.scrollTo({ top: 0 });
  const h = $(`#step-${step} h2`);
  if (h && step !== 'home') { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
}
window.addEventListener('popstate', (e) => show(e.state?.step || 'home', { push: false }));
document.addEventListener('click', (e) => { const go = e.target.closest('[data-go]'); if (go) show(go.dataset.go); });
$('#headerBack').addEventListener('click', () => history.back());
function showError(msg) { const el = $('#globalError'); el.textContent = msg; el.hidden = false; el.scrollIntoView({ block: 'nearest' }); }
function hideError() { $('#globalError').hidden = true; }

/* ---------- step 1: the request ---------- */
const saveDraft = () => { try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ text: state.text, serviceType: state.serviceType })); } catch { /* ignore */ } };
$('#requestText').addEventListener('input', (e) => { $('#charCount').textContent = e.target.value.length; $('#textErr').hidden = true; });
$('#homeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = $('#requestText').value.trim();
  if (text.length < 5) {
    $('#textErr').textContent = t(text ? 'errors.too_short' : 'errors.required');
    $('#textErr').hidden = false;
    $('#requestText').focus();
    return;
  }
  state.text = text;
  saveDraft();
  show('location');
  setTimeout(() => $('#gpsBtn').focus(), 50);
});

/* ---------- step 2: where (the customer's location is required) ---------- */
$('#gpsBtn').addEventListener('click', async () => {
  const status = $('#gpsStatus');
  const btn = $('#gpsBtn');
  status.classList.remove('bad');
  status.textContent = t('location.locating');
  btn.disabled = true;
  try {
    const pos = await getPosition({ precise: true, maxWaitMs: 8000, goodEnough: 50 });
    state.location = { type: 'gps', ...pos };
  } catch (gpsErr) {
    explainGpsError(status, gpsErr, () => $('#gpsBtn').click());
    btn.disabled = false;
    return;
  }
  status.textContent = t('location.searching');
  await runSearch();
  status.textContent = '';
  btn.disabled = false;
});

async function runSearch() {
  try {
    const data = await api('/api/search', {
      method: 'POST',
      body: { text: state.text, serviceType: state.serviceType || undefined, location: state.location, startedAt: state.startedAt, website: '' },
    });
    state.requestId = data.requestId;
    state.areaLabel = data.areaLabel || '';
    state.areaDist = data.area?.distanceKm ?? 0;
    state.cooks = data.cooks;
    if (data.country) rememberCountry(data.country);
    renderResults();
    show('results');
  } catch (err) {
    showError(err.fields?.text ? t(`errors.${err.fields.text}`) : errorText(err));
  }
}

/* ---------- step 3: results ---------- */
const kmText = (d) => fmtDistance(d);
const distText = (c) => (c.distanceM != null ? fmtDistanceM(c.distanceM) : fmtDistance(c.distanceKm));
const servicesText = (keys) => keys.map((k) => t(`services.${k}`)).join(' + ');
function renderResults() {
  $('#echoText').textContent = state.text;
  const n = state.cooks.length;
  $('#resultsMeta').textContent = [state.areaLabel && (state.areaDist > 1.5 ? t('results.nearFar', { area: state.areaLabel, d: state.areaDist }) : t('results.near', { area: state.areaLabel })), n ? t('results.count', { n }) : ''].filter(Boolean).join(' — ');
  $('#emptyState').hidden = n > 0;
  $('#cookList').innerHTML = state.cooks.map((c, i) => `
    <li class="cook-row">
      <button class="cook" type="button" data-idx="${i}" aria-label="${esc(t('results.choose', { name: c.name }))}">
        ${avatarHtml(c)}
        <span>
          <span class="cook-name">${esc(c.name)}</span>
          <span class="cook-meta">${esc(c.area || '')}</span>
          <span class="cook-meta">${esc(servicesText(c.services))}</span>
        </span>
        <span class="cook-dist">${esc(distText(c))}</span>
      </button>
      <a class="profile-link" href="${esc(c.profileUrl)}">${esc(t('results.viewProfile'))}</a>
    </li>`).join('');
}
$('#cookList').addEventListener('click', (e) => {
  const b = e.target.closest('.cook');
  if (!b) return;
  state.cook = state.cooks[Number(b.dataset.idx)];
  renderSummary();
  show('summary');
});

/* ---------- step 4: summary → WhatsApp ---------- */
function renderSummary() {
  const c = state.cook;
  $('#sumRequest').textContent = state.text;
  $('#sumCook').innerHTML = `${avatarHtml(c)}<span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')} — </span></span>`;
  $('#sumDistance').textContent = distText(c);
  $('#sumProfile').href = c.profileUrl;
  $('#waFallback').hidden = true;
}
$('#waBtn').addEventListener('click', async () => {
  const btn = $('#waBtn');
  btn.disabled = true;
  $('#waLabel').textContent = t('summary.sending');
  try {
    const r = await api('/api/contact', { method: 'POST', body: { requestId: state.requestId, cookId: state.cook.id } });
    myCooks.remember({ id: r.cook.id, name: r.cook.name, reviewToken: r.reviewToken });
    $('#waFallback').href = r.whatsappUrl;
    $('#waFallback').hidden = false;
    window.location.href = r.whatsappUrl;
  } catch (err) {
    showError(errorText(err));
    if (err.code === 'request_expired' || err.code === 'request_not_found') state.requestId = null;
  } finally {
    btn.disabled = false;
    $('#waLabel').textContent = t('summary.send');
  }
});

/* ---------- home extras: sliders, my cooks, rating prompt, name search ---------- */
// Two tabs on the home page: 🏪 shops / 🛠️ craftspeople (remembered for the visit)
const currentTab = () => { try { return sessionStorage.getItem('st_tab') === 'crafts' ? 'crafts' : 'shops'; } catch { return 'shops'; } };
let lastFeed = null;
async function loadFeed() {
  let feed = { dishes: [], cooks: [] };
  try { feed = await api(`/api/feed?country=${visitorRegion(state.config) || ''}`); } catch { /* keep placeholders */ }   // a country not on the platform shows no shops
  lastFeed = feed;
  renderCats(feed);
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-tab]'); if (!b) return;
  try { sessionStorage.setItem('st_tab', b.dataset.tab); } catch { /* ignore */ }
  if (lastFeed) renderCats(lastFeed);
});
function renderCats(feed) {
  const hiddenG = state.config.site?.groupsHidden || [];
  const tab = hiddenG.includes(currentTab()) ? (currentTab() === 'shops' ? 'crafts' : 'shops') : currentTab();   // a hidden group: only the other one
  // One row per category shown on the home page: a button + a strip of small photos of its subscribers.
  const liveHere = Object.entries(feed?.byKind || {}).filter(([, list]) => list?.length).map(([k]) => k);   // this country's categories with shops
  const cats = (state.config.site?.categories || []).filter((c) => showOnHome(c, feed ? liveHere : (state.config.liveKinds || [])) && (c.group === 'crafts' ? 'crafts' : 'shops') === tab);
  const tabs = hiddenG.length ? '' : `<div class="home-tabs" role="tablist">${['shops', 'crafts'].map((k) => `<button type="button" role="tab" data-tab="${k}" aria-selected="${k === tab}">${k === 'shops' ? '🏪' : '🛠️'} ${esc(t(`home.tab_${k}`))}</button>`).join('')}</div>`;
  $('#catsBlock').innerHTML = tabs + `<a class="btn all-near" href="/nearby?type=all${tab === 'crafts' ? '&group=crafts' : ''}"><span aria-hidden="true">📍</span> ${esc(t(tab === 'crafts' ? 'home.allNearCrafts' : 'home.allNear'))}</a>`
    + `<p class="dist-note">ⓘ ${esc(t('home.distanceNote'))}</p>` + cats.map((c) => {
    const items = feed.byKind?.[c.key] || [];
    const strip = items.length
      ? items.map((i) => `<a class="cat-thumb" href="${esc(i.profileUrl)}" title="${esc(i.name)}">
          ${i.img ? `<img src="${esc(i.img)}" alt="${esc(i.name)}" loading="lazy">` : `<span class="cat-initial" aria-hidden="true">${esc(i.name.slice(0, 1))}</span>`}
          <small>${esc(i.name)}</small></a>`).join('')
      : `<a class="cat-thumb cat-join" href="/join?type=${encodeURIComponent(c.key)}"><span class="cat-initial" aria-hidden="true">${esc(c.icon)}</span><small>${esc(t('home.yourShopHere'))}</small></a>`;
    return `<section class="cat-row">
      <a class="btn btn-gold cat-btn" href="/nearby?type=${encodeURIComponent(c.key)}"><span aria-hidden="true">${esc(c.icon)}</span> ${esc(t('home.findNear', { name: catLabel(c, 'one') }))}</a>
      <div class="cat-strip">${strip}</div></section>`;
  }).join('');
  document.querySelectorAll('#catsBlock .cat-strip').forEach((el) => autoSlide(el));   // every strip moves by itself
  state.hideCooksSlider = true;   // the home page shows categories now (no separate cooks slider)
  if (feed.cooks.length && !state.hideCooksSlider) {
    $('#cooksBlock').hidden = false;
    $('#cookSlider').innerHTML = feed.cooks.map((c) => `
      <a class="cook-card" href="${esc(c.profileUrl)}">${avatarHtml(c)}<b>${esc(c.name)}</b><span>${esc(c.area || '')}</span></a>`).join('');
  }
}

function renderMine() {
  const list = myCooks.list();
  // Ask to rate the most recent cook that wasn't rated yet.
  const pending = list.find((c) => c.reviewToken && !c.rating && !c.dismissed && Date.now() - c.at < 60 * 86400_000);
  const slot = $('#rateSlot');
  if (!pending) { slot.innerHTML = ''; return; }
  slot.innerHTML = `<div class="rate-card"><p>${esc(t('mine.rateTitle', { name: pending.name }))}</p><div id="rateStars"></div>
    <button class="btn-text" type="button" id="rateLater">${esc(t('mine.later'))}</button></div>`;
  starInput($('#rateStars'), {
    onPick: async (n) => {
      try {
        await api('/api/reviews', { method: 'POST', body: { token: pending.reviewToken, rating: n } });
        myCooks.update(pending.id, { rating: n });
        slot.innerHTML = `<div class="rate-card"><p>${esc(t('mine.rateThanks'))}</p></div>`;
      } catch (err) { showError(errorText(err)); }
    },
  });
  $('#rateLater').addEventListener('click', () => { myCooks.update(pending.id, { dismissed: true }); slot.innerHTML = ''; });
}

let nameTimer;
$('#nameQ').addEventListener('input', (e) => {
  clearTimeout(nameTimer);
  const q = e.target.value.trim();
  if (q.length < 2) { $('#nameResults').hidden = true; $('#nameEmpty').hidden = true; return; }
  nameTimer = setTimeout(async () => {
    try {
      const { cooks } = await api(`/api/cooks/search?q=${encodeURIComponent(q)}&country=${state.config?.country?.code || ''}`);
      $('#nameEmpty').hidden = cooks.length > 0;
      $('#nameResults').hidden = !cooks.length;
      $('#nameResults').innerHTML = cooks.map((c) => `
        <li><a class="cook" href="${esc(c.profileUrl)}">${avatarHtml(c)}
          <span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')}</span></span>
          <span class="cook-dist" aria-hidden="true">‹</span></a></li>`).join('');
    } catch { /* ignore */ }
  }, 250);
});

/** Gentle auto-scroll for a horizontal slider; pauses when touched; respects reduced motion. */
function autoSlide(el) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || el.children.length < 2 || el.dataset.auto) return;
  el.dataset.auto = '1';
  // moves by itself; a touch pauses it for a few seconds, then it moves again
  let pausedUntil = 0;
  ['pointerdown', 'touchstart', 'wheel', 'focusin'].forEach((ev) => el.addEventListener(ev, () => { pausedUntil = Date.now() + 6000; }, { passive: true }));
  setInterval(() => {
    if (Date.now() < pausedUntil || document.hidden || $('#step-home')?.hidden) return;
    if (el.scrollWidth <= el.clientWidth + 2) return;            // everything already visible
    const w = (el.children[0]?.offsetWidth || 60) + 8;
    const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
    const atEnd = Math.abs(el.scrollLeft) + el.clientWidth >= el.scrollWidth - 4;
    el.scrollTo({ left: atEnd ? 0 : el.scrollLeft + dir * w, behavior: 'smooth' });
  }, 3000);
}

/** Worldwide counters (only if the admin turned them on). */
/* ---------- today's visitors & orders, with a countdown to midnight (Beirut) ---------- */
let todayTick;
async function loadToday() {
  // count this device once per day (anonymous random id, kept on the phone)
  try {
    let vid = localStorage.getItem('st_vid');
    if (!vid) { vid = Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, '0')).join(''); localStorage.setItem('st_vid', vid); }
    const today = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem('st_vday') !== today) { await api('/api/visit', { method: 'POST', body: { vid } }); localStorage.setItem('st_vday', today); }
  } catch { /* counting is best-effort */ }
  let r;
  try { r = await api('/api/stats/today'); } catch { return; }
  if (!r.enabled) { $('#todayBlock').hidden = true; return; }
  const nf = new Intl.NumberFormat('en-US');
  $('#todayVisitors').textContent = nf.format(r.visitors);
  $('#todayOrders').textContent = nf.format(r.orders);
  $('#todayBlock').hidden = false;
  const end = new Date(r.resetsAt).getTime();
  clearInterval(todayTick);
  const draw = () => {
    const left = Math.max(0, end - Date.now());
    const h = Math.floor(left / 3_600_000), m = Math.floor((left % 3_600_000) / 60_000), sec = Math.floor((left % 60_000) / 1000);
    $('#todayTimer').textContent = [h, m, sec].map((x) => String(x).padStart(2, '0')).join(':');
    if (left === 0) { clearInterval(todayTick); setTimeout(loadToday, 3000); }   // midnight: counters start again
  };
  draw();
  todayTick = setInterval(draw, 1000);
}

async function loadCounters() {
  try {
    const s = await api('/api/stats/public');
    if (!s.enabled) return;
    const n = (x) => new Intl.NumberFormat(document.documentElement.lang + '-u-nu-latn').format(x || 0);
    // only countries and their number of subscribers (no other words)
    const flag = (c) => String.fromCodePoint(...[...c].map((ch) => 0x1f1e6 + ch.charCodeAt(0) - 65));
    const cname = (c) => { try { return new Intl.DisplayNames([document.documentElement.lang || 'ar'], { type: 'region' }).of(c); } catch { return c; } };
    $('#counters').innerHTML = (s.byCountry || []).map((x) => `<div><b>${flag(x.country)} ${n(x.n)}</b><span>${esc(cname(x.country))}</span></div>`).join('');
    if (!(s.byCountry || []).length) return;
    $('#countersBlock').hidden = false;
  } catch { /* optional */ }
}

/* ---------- boot ---------- */
(async function boot() {
  await initI18n();
  initMenu();
  initLangButton();
  try { state.config = await getConfig(); } catch (err) { showError(errorText(err)); return; }
  try {
    const d = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
    if (d?.text) { $('#requestText').value = d.text; $('#charCount').textContent = d.text.length;  }
  } catch { /* ignore */ }
  renderMine();
  const site = state.config.site || {};
  if (site.announcement) { $('#announce').textContent = site.announcement; $('#announce').hidden = false; }
  if (site.sections?.nameSearch === false) $('#nameSearchBlock').hidden = true;
  state.hideCooksSlider = site.sections?.cooksSlider === false;
  history.replaceState({ step: 'home' }, '', location.pathname + location.search);
  show('home', { push: false });
  loadFeed();
  loadCounters();
  loadToday();
})();

