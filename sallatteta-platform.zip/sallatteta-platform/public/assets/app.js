import { initI18n, t, api, errorText, esc, setRegion, fmtDistance, getConfig, rememberCountry, fmtDistanceM } from './i18n.js?v=440';
import { $, avatarHtml, starsHtml, starInput, myCooks, getPosition, initMenu, initLangButton } from './ui.js?v=440';

const STEPS = ['home', 'location', 'results', 'summary'];
const PROGRESS = { home: 1, location: 2, results: 3, summary: 3 };
const DRAFT_KEY = 'st_draft';

const state = {
  config: null, text: '', serviceType: '', location: null, areaName: '',
  requestId: null, areaLabel: '', cooks: [], cook: null, startedAt: Date.now(),
};

/* ---------- navigation ---------- */
function show(step, { push = true } = {}) {
  if (step !== 'home' && !state.text) step = 'home';
  if ((step === 'results' || step === 'summary') && !state.requestId) step = 'location';
  if (step === 'summary' && !state.cook) step = 'results';
  for (const s of STEPS) {
    const el = $(`#step-${s}`);
    el.hidden = s !== step;
    el.classList.toggle('enter', s === step);
  }
  $('#progress').hidden = step === 'home';
  $('#headerBack').hidden = step === 'home';
  document.querySelectorAll('#progress i').forEach((i, idx) => i.classList.toggle('on', idx < PROGRESS[step]));
  $('#stepLabel').textContent = t('common.step', { n: PROGRESS[step] });
  hideError();
  if (push) history.pushState({ step }, '', step === 'home' ? location.pathname : `#${step}`);
  window.scrollTo({ top: 0 });
  const h = $(`#step-${step} h2`);
  if (h && step !== 'home') { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
}
window.addEventListener('popstate', (e) => show(e.state?.step || 'home', { push: false }));
document.addEventListener('click', (e) => { const go = e.target.closest('[data-go]'); if (go) show(go.dataset.go); });
$('#headerBack').addEventListener('click', () => history.back());
function showError(msg) { const el = $('#globalError'); el.textContent = msg; el.hidden = false; el.scrollIntoView({ block: 'nearest' }); }
function hideError() { $('#globalError').hidden = true; }

/* ---------- step 1: the request ---------- */
const saveDraft = () => { try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ text: state.text, serviceType: state.serviceType })); } catch { /* ignore */ } };
$('#requestText').addEventListener('input', (e) => { $('#charCount').textContent = e.target.value.length; $('#textErr').hidden = true; });
$('#homeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = $('#requestText').value.trim();
  if (text.length < 5) {
    $('#textErr').textContent = t(text ? 'errors.too_short' : 'errors.required');
    $('#textErr').hidden = false;
    $('#requestText').focus();
    return;
  }
  state.text = text;
  saveDraft();
  show('location');
  setTimeout(() => $('#gpsBtn').focus(), 50);
});

/* ---------- step 2: where (the customer's location is required) ---------- */
$('#gpsBtn').addEventListener('click', async () => {
  const status = $('#gpsStatus');
  const btn = $('#gpsBtn');
  status.classList.remove('bad');
  status.textContent = t('location.locating');
  btn.disabled = true;
  try {
    const pos = await getPosition({ precise: true, maxWaitMs: 8000, goodEnough: 50 });
    state.location = { type: 'gps', ...pos };
  } catch {
    status.classList.add('bad');
    status.textContent = t('location.gpsDenied');
    btn.disabled = false;
    return;
  }
  status.textContent = t('location.searching');
  await runSearch();
  status.textContent = '';
  btn.disabled = false;
});

async function runSearch() {
  try {
    const data = await api('/api/search', {
      method: 'POST',
      body: { text: state.text, serviceType: state.serviceType || undefined, location: state.location, startedAt: state.startedAt, website: '' },
    });
    state.requestId = data.requestId;
    state.areaLabel = data.areaLabel || '';
    state.areaDist = data.area?.distanceKm ?? 0;
    state.cooks = data.cooks;
    if (data.country) rememberCountry(data.country);
    renderResults();
    show('results');
  } catch (err) {
    showError(err.fields?.text ? t(`errors.${err.fields.text}`) : errorText(err));
  }
}

/* ---------- step 3: results ---------- */
const kmText = (d) => fmtDistance(d);
const distText = (c) => (c.distanceM != null ? fmtDistanceM(c.distanceM) : fmtDistance(c.distanceKm));
const servicesText = (keys) => keys.map((k) => t(`services.${k}`)).join(' + ');
function renderResults() {
  $('#echoText').textContent = state.text;
  const n = state.cooks.length;
  $('#resultsMeta').textContent = [state.areaLabel && (state.areaDist > 1.5 ? t('results.nearFar', { area: state.areaLabel, d: state.areaDist }) : t('results.near', { area: state.areaLabel })), n ? t('results.count', { n }) : ''].filter(Boolean).join(' — ');
  $('#emptyState').hidden = n > 0;
  $('#cookList').innerHTML = state.cooks.map((c, i) => `
    <li class="cook-row">
      <button class="cook" type="button" data-idx="${i}" aria-label="${esc(t('results.choose', { name: c.name }))}">
        ${avatarHtml(c)}
        <span>
          <span class="cook-name">${esc(c.name)}</span>
          <span class="cook-meta">${esc(c.area || '')} · ${starsHtml(c.rating)}</span>
          <span class="cook-meta">${esc(servicesText(c.services))}</span>
        </span>
        <span class="cook-dist">${esc(distText(c))}</span>
      </button>
      <a class="profile-link" href="${esc(c.profileUrl)}">${esc(t('results.viewProfile'))}</a>
    </li>`).join('');
}
$('#cookList').addEventListener('click', (e) => {
  const b = e.target.closest('.cook');
  if (!b) return;
  state.cook = state.cooks[Number(b.dataset.idx)];
  renderSummary();
  show('summary');
});

/* ---------- step 4: summary → WhatsApp ---------- */
function renderSummary() {
  const c = state.cook;
  $('#sumRequest').textContent = state.text;
  $('#sumCook').innerHTML = `${avatarHtml(c)}<span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')} — ${starsHtml(c.rating)}</span></span>`;
  $('#sumDistance').textContent = distText(c);
  $('#sumProfile').href = c.profileUrl;
  $('#waFallback').hidden = true;
}
$('#waBtn').addEventListener('click', async () => {
  const btn = $('#waBtn');
  btn.disabled = true;
  $('#waLabel').textContent = t('summary.sending');
  try {
    const r = await api('/api/contact', { method: 'POST', body: { requestId: state.requestId, cookId: state.cook.id } });
    myCooks.remember({ id: r.cook.id, name: r.cook.name, reviewToken: r.reviewToken });
    $('#waFallback').href = r.whatsappUrl;
    $('#waFallback').hidden = false;
    window.location.href = r.whatsappUrl;
  } catch (err) {
    showError(errorText(err));
    if (err.code === 'request_expired' || err.code === 'request_not_found') state.requestId = null;
  } finally {
    btn.disabled = false;
    $('#waLabel').textContent = t('summary.send');
  }
});

/* ---------- home extras: sliders, my cooks, rating prompt, name search ---------- */
async function loadFeed() {
  let feed = { dishes: [], cooks: [] };
  try { feed = await api(`/api/feed?country=${state.config?.country?.code || ''}`); } catch { /* keep placeholders */ }
  // Restaurants: "find a restaurant near you" + a moving slider right under it (always visible).
  if (state.config.site?.sections?.restaurants !== false) {
    $('#restBlock').hidden = false;
    // One card per restaurant subscriber: its latest dish photo, else its profile photo, else its initial.
    const rests = feed.restaurants || [];
    let cardsHtml;
    if (rests.length) {
      cardsHtml = rests.map((r) => `
        <a class="rest-card" href="${esc(r.profileUrl)}">
          ${r.cover ? `<img src="${esc(r.cover)}" alt="${esc(r.name)}" loading="lazy">` : `<div class="rest-empty-art" aria-hidden="true">${esc(r.name.slice(0, 1))}</div>`}
          <span><b>${esc(r.name)}</b>${esc(r.specialty || r.area || '')}</span>
        </a>`).join('');
    } else {
      // no restaurant yet in this country: invite restaurants (the slider is always visible)
      cardsHtml = [1, 2, 3].map((i) => `
        <a class="rest-card rest-card-empty" href="/join?type=restaurant">
          <div class="rest-empty-art" aria-hidden="true">${['🍽️', '🥙', '🍲'][i - 1]}</div>
          <span><b>${esc(t('home.restHereTitle'))}</b>${esc(t('home.restHereText'))}</span>
        </a>`).join('');
    }
    $('#restSliderWrap').hidden = false;
    $('#restSlider').innerHTML = cardsHtml;
    autoSlide($('#restSlider'));
  }
  if (feed.cooks.length && !state.hideCooksSlider) {
    $('#cooksBlock').hidden = false;
    $('#cookSlider').innerHTML = feed.cooks.map((c) => `
      <a class="cook-card" href="${esc(c.profileUrl)}">${avatarHtml(c)}<b>${esc(c.name)}</b><span>${esc(c.area || '')}</span>${starsHtml(c.rating)}</a>`).join('');
  }
}

function renderMine() {
  const list = myCooks.list();
  // Ask to rate the most recent cook that wasn't rated yet.
  const pending = list.find((c) => c.reviewToken && !c.rating && !c.dismissed && Date.now() - c.at < 60 * 86400_000);
  const slot = $('#rateSlot');
  if (!pending) { slot.innerHTML = ''; return; }
  slot.innerHTML = `<div class="rate-card"><p>${esc(t('mine.rateTitle', { name: pending.name }))}</p><div id="rateStars"></div>
    <button class="btn-text" type="button" id="rateLater">${esc(t('mine.later'))}</button></div>`;
  starInput($('#rateStars'), {
    onPick: async (n) => {
      try {
        await api('/api/reviews', { method: 'POST', body: { token: pending.reviewToken, rating: n } });
        myCooks.update(pending.id, { rating: n });
        slot.innerHTML = `<div class="rate-card"><p>${esc(t('mine.rateThanks'))}</p></div>`;
      } catch (err) { showError(errorText(err)); }
    },
  });
  $('#rateLater').addEventListener('click', () => { myCooks.update(pending.id, { dismissed: true }); slot.innerHTML = ''; });
}

let nameTimer;
$('#nameQ').addEventListener('input', (e) => {
  clearTimeout(nameTimer);
  const q = e.target.value.trim();
  if (q.length < 2) { $('#nameResults').hidden = true; $('#nameEmpty').hidden = true; return; }
  nameTimer = setTimeout(async () => {
    try {
      const { cooks } = await api(`/api/cooks/search?q=${encodeURIComponent(q)}&country=${state.config?.country?.code || ''}`);
      $('#nameEmpty').hidden = cooks.length > 0;
      $('#nameResults').hidden = !cooks.length;
      $('#nameResults').innerHTML = cooks.map((c) => `
        <li><a class="cook" href="${esc(c.profileUrl)}">${avatarHtml(c)}
          <span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')} · ${starsHtml(c.rating)}</span></span>
          <span class="cook-dist" aria-hidden="true">‹</span></a></li>`).join('');
    } catch { /* ignore */ }
  }, 250);
});

/** Gentle auto-scroll for a horizontal slider; pauses when touched; respects reduced motion. */
function autoSlide(el) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || el.children.length < 2) return;
  let paused = false;
  ['pointerdown', 'touchstart', 'focusin'].forEach((ev) => el.addEventListener(ev, () => { paused = true; }, { passive: true }));
  setInterval(() => {
    if (paused || document.hidden || $('#step-home').hidden) return;
    const w = el.children[0].offsetWidth + 11;
    const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
    const atEnd = Math.abs(el.scrollLeft) + el.clientWidth >= el.scrollWidth - 4;
    el.scrollTo({ left: atEnd ? 0 : el.scrollLeft + dir * w, behavior: 'smooth' });
  }, 4500);
}

/** Worldwide counters (only if the admin turned them on). */
async function loadCounters() {
  try {
    const s = await api('/api/stats/public');
    if (!s.enabled) return;
    const n = (x) => new Intl.NumberFormat(document.documentElement.lang + '-u-nu-latn').format(x || 0);
    $('#counters').innerHTML = [['users', 'home.counterUsers'], ['cooks', 'home.counterCooks'], ['restaurants', 'home.counterRestaurants'], ['countries', 'home.counterCountries']]
      .map(([k, label]) => `<div><b>${n(s[k])}</b><span>${esc(t(label))}</span></div>`).join('');
    $('#countersBlock').hidden = false;
  } catch { /* optional */ }
}

/* ---------- boot ---------- */
(async function boot() {
  await initI18n();
  initMenu();
  initLangButton();
  try { state.config = await getConfig(); } catch (err) { showError(errorText(err)); return; }
  try {
    const d = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
    if (d?.text) { $('#requestText').value = d.text; $('#charCount').textContent = d.text.length;  }
  } catch { /* ignore */ }
  renderMine();
  const site = state.config.site || {};
  if (site.announcement) { $('#announce').textContent = site.announcement; $('#announce').hidden = false; }
  if (site.sections?.nameSearch === false) $('#nameSearchBlock').hidden = true;
  state.hideCooksSlider = site.sections?.cooksSlider === false;
  history.replaceState({ step: 'home' }, '', location.pathname + location.search);
  show('home', { push: false });
  loadFeed();
  loadCounters();
})();
