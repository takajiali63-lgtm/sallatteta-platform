import { initI18n, t, api, errorText, esc, getApproxPosition } from './i18n.js';

const $ = (s) => document.querySelector(s);
const STEPS = ['home', 'location', 'results', 'summary'];
const PROGRESS = { home: 1, location: 2, results: 3, summary: 3 };
const DRAFT_KEY = 'st_draft';

const state = {
  config: null,
  text: '',
  serviceType: '',
  location: null,      // { type: 'gps', lat, lng } | { type: 'area', areaId }
  requestId: null,
  areaLabel: '',
  cooks: [],
  cook: null,
  startedAt: Date.now(),
};

/* ---------- navigation ---------- */
function show(step, { push = true } = {}) {
  if (step !== 'home' && !state.text) step = 'home';
  if ((step === 'results' || step === 'summary') && !state.requestId) step = 'location';
  if (step === 'summary' && !state.cook) step = 'results';
  for (const s of STEPS) {
    const el = $(`#step-${s}`);
    el.hidden = s !== step;
    el.classList.toggle('enter', s === step);
  }
  document.querySelectorAll('#progress i').forEach((i, idx) => i.classList.toggle('on', idx < PROGRESS[step]));
  $('#stepLabel').textContent = t('common.step', { n: PROGRESS[step] });
  hideError();
  if (push) history.pushState({ step }, '', step === 'home' ? location.pathname : `#${step}`);
  window.scrollTo({ top: 0 });
  const focusable = $(`#step-${step} h1, #step-${step} h2`);
  if (focusable && step !== 'home') { focusable.setAttribute('tabindex', '-1'); focusable.focus({ preventScroll: true }); }
}
window.addEventListener('popstate', (e) => show(e.state?.step || 'home', { push: false }));
document.addEventListener('click', (e) => {
  const go = e.target.closest('[data-go]');
  if (go) show(go.dataset.go);
});

function showError(msg) { const el = $('#globalError'); el.textContent = msg; el.hidden = false; el.scrollIntoView({ block: 'nearest' }); }
function hideError() { $('#globalError').hidden = true; }

function busy(btn, on, label) {
  btn.disabled = on;
  if (on) { btn.dataset.label = btn.textContent; btn.textContent = label || t('common.loading'); }
  else if (btn.dataset.label) btn.textContent = btn.dataset.label;
}

/* ---------- step 1: request ---------- */
function renderTypeChips() {
  const opts = [['', t('home.anyType')], ...state.config.serviceTypes.map((k) => [k, t(`services.${k}`)])];
  $('#typeChips').innerHTML = opts.map(([k, label]) =>
    `<label class="chip"><input type="radio" name="serviceType" value="${esc(k)}" ${k === state.serviceType ? 'checked' : ''}><span>${esc(label)}</span></label>`).join('');
}

function saveDraft() {
  try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ text: state.text, serviceType: state.serviceType })); } catch { /* ignore */ }
}

$('#requestText').addEventListener('input', (e) => {
  $('#charCount').textContent = e.target.value.length;
  $('#textErr').hidden = true;
});
$('#homeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = $('#requestText').value.trim();
  if (text.length < 5) {
    $('#textErr').textContent = t(text ? 'errors.too_short' : 'errors.required');
    $('#textErr').hidden = false;
    $('#requestText').focus();
    return;
  }
  state.text = text;
  state.serviceType = document.querySelector('input[name="serviceType"]:checked')?.value || '';
  saveDraft();
  show('location');
});

/* ---------- step 2: location ---------- */
function renderAreas() {
  const sel = $('#areaSelect');
  sel.insertAdjacentHTML('beforeend', state.config.areas.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join(''));
}

$('#gpsBtn').addEventListener('click', async () => {
  const status = $('#gpsStatus');
  status.classList.remove('bad');
  status.textContent = t('location.locating');
  try {
    const pos = await getApproxPosition();
    state.location = { type: 'gps', ...pos };
    $('#areaSelect').value = '';
    status.textContent = t('location.gpsDone');
    await runSearch();
  } catch {
    status.classList.add('bad');
    status.textContent = t('location.gpsDenied');
    $('#areaSelect').focus();
  }
});
$('#areaSelect').addEventListener('change', (e) => {
  if (e.target.value) {
    state.location = { type: 'area', areaId: Number(e.target.value) };
    $('#gpsStatus').textContent = '';
  }
});
$('#searchBtn').addEventListener('click', () => {
  if (!state.location) {
    $('#gpsStatus').classList.add('bad');
    $('#gpsStatus').textContent = t('location.gpsDenied');
    $('#areaSelect').focus();
    return;
  }
  runSearch();
});

async function runSearch() {
  const btn = $('#searchBtn');
  busy(btn, true);
  try {
    const data = await api('/api/search', {
      method: 'POST',
      body: {
        text: state.text,
        serviceType: state.serviceType || undefined,
        location: state.location,
        startedAt: state.startedAt,
        website: '',
      },
    });
    state.requestId = data.requestId;
    state.areaLabel = data.areaLabel || '';
    state.cooks = data.cooks;
    renderResults();
    show('results');
  } catch (err) {
    showError(err.fields?.text ? t(`errors.${err.fields.text}`) : errorText(err));
  } finally {
    busy(btn, false);
  }
}

/* ---------- step 3: results ---------- */
function avatar(c) {
  return c.photoUrl
    ? `<img class="avatar" src="${esc(c.photoUrl)}" alt="" loading="lazy">`
    : `<span class="avatar" aria-hidden="true">${esc([...c.name.trim()][0] || '')}</span>`;
}
const servicesText = (keys) => keys.map((k) => t(`services.${k}`)).join(' + ');

function renderResults() {
  $('#echoText').textContent = state.text;
  const n = state.cooks.length;
  $('#resultsMeta').textContent = [state.areaLabel && t('results.near', { area: state.areaLabel }), n ? t('results.count', { n }) : '']
    .filter(Boolean).join(' — ');
  $('#emptyState').hidden = n > 0;
  $('#cookList').innerHTML = state.cooks.map((c, i) => `
    <li><button class="cook" type="button" data-idx="${i}" aria-label="${esc(t('results.choose', { name: c.name }))}">
      ${avatar(c)}
      <span>
        <span class="cook-name">${esc(c.name)}</span>
        <span class="cook-meta">${esc(c.area || '')}</span>
        <span class="cook-meta">${esc(servicesText(c.services))}</span>
        <span class="badge-active">${esc(t('results.active'))}</span>
      </span>
      <span class="cook-dist">${esc(t('common.km', { d: c.distanceKm }))}</span>
    </button></li>`).join('');
}
$('#cookList').addEventListener('click', (e) => {
  const b = e.target.closest('.cook');
  if (!b) return;
  state.cook = state.cooks[Number(b.dataset.idx)];
  renderSummary();
  show('summary');
});

/* ---------- step 4: summary → WhatsApp ---------- */
function renderSummary() {
  const c = state.cook;
  $('#sumRequest').textContent = state.text;
  $('#sumCook').innerHTML = `${avatar(c)}<span><span class="cook-name">${esc(c.name)}</span><span class="cook-meta">${esc(c.area || '')} — ${esc(servicesText(c.services))}</span></span>`;
  $('#sumDistance').textContent = t('common.km', { d: c.distanceKm });
  $('#waFallback').hidden = true;
}

$('#waBtn').addEventListener('click', async () => {
  const btn = $('#waBtn');
  const label = $('#waLabel');
  btn.disabled = true;
  label.textContent = t('summary.sending');
  try {
    const { whatsappUrl } = await api('/api/contact', { method: 'POST', body: { requestId: state.requestId, cookId: state.cook.id } });
    const fb = $('#waFallback');
    fb.href = whatsappUrl;
    fb.hidden = false;
    window.location.href = whatsappUrl;
  } catch (err) {
    showError(errorText(err));
    if (err.code === 'request_expired' || err.code === 'request_not_found') { state.requestId = null; }
  } finally {
    btn.disabled = false;
    label.textContent = t('summary.send');
  }
});

/* ---------- boot ---------- */
(async function boot() {
  await initI18n();
  try {
    state.config = await api('/api/config');
  } catch (err) {
    showError(errorText(err));
    return;
  }
  try {
    const d = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
    if (d?.text) { state.text = ''; $('#requestText').value = d.text; $('#charCount').textContent = d.text.length; state.serviceType = d.serviceType || ''; }
  } catch { /* ignore */ }
  renderTypeChips();
  renderAreas();
  history.replaceState({ step: 'home' }, '', location.pathname + location.search);
  show('home', { push: false });
})();
