// The list of background jobs. All of them are idempotent and safe with any number of instances (leases in job_runs).
import { expireSubscriptions } from './services/cooks.js';
import { PgStore } from './lib/ratelimit.js';
import { migratePhotos } from './services/photoMigration.js';

const DAY = 86_400_000;
const days = (name, def) => { const n = Number(process.env[name]); return Number.isFinite(n) && n > 0 ? n : def; };

export function defineJobs({ db, storage = null, log = console }) {
  return [
    {
      // Hide cooks whose subscription ended (search also checks dates live, so this is bookkeeping).
      name: 'expire-subscriptions', everyMs: 5 * 60_000,
      run: async () => ({ expired: await expireSubscriptions(db) }),
    },
    {
      name: 'cleanup', everyMs: 60 * 60_000,
      run: async () => {
        const now = new Date().toISOString();
        const a = (await db.query('DELETE FROM admin_sessions WHERE expires_at <= $1 RETURNING id', [now])).length;
        const c = (await db.query('DELETE FROM cook_sessions WHERE expires_at <= $1 RETURNING id', [now])).length;
        const r = await new PgStore(db).cleanup();
        return { adminSessions: a, cookSessions: c, rateLimits: r };
      },
    },
    {
      // Retention for high-volume event data, in small batches (never one huge DELETE).
      // Search impressions (up to 30 rows per search) are the biggest table; subscribers' stats use the last 30 days.
      name: 'retention', everyMs: 6 * 60 * 60_000,
      run: async () => {
        const out = { impressions: 0, visits: 0, pageViews: 0, adminLogins: 0 };
        const cutoff = new Date(Date.now() - days('RETENTION_IMPRESSIONS_DAYS', 180) * DAY).toISOString();
        const max = Number((await db.one('SELECT MAX(id) AS m FROM requests WHERE created_at < $1', [cutoff]))?.m) || 0;
        for (let from = 0; from < max; from += 2000) {
          out.impressions += (await db.query('DELETE FROM request_impressions WHERE request_id > $1 AND request_id <= $2 RETURNING request_id',
            [from, Math.min(from + 2000, max)])).length;
        }
        const dayCut = new Date(Date.now() - days('RETENTION_VISITS_DAYS', 120) * DAY).toISOString().slice(0, 10);
        out.visits = (await db.query('DELETE FROM daily_visits WHERE day < $1 RETURNING day', [dayCut])).length;
        const viewsCut = new Date(Date.now() - days('RETENTION_PAGEVIEWS_DAYS', 400) * DAY).toISOString();
        out.pageViews = (await db.query('DELETE FROM cook_page_views WHERE created_at < $1 RETURNING cook_id', [viewsCut]).catch(() => [])).length;
        const loginCut = new Date(Date.now() - days('RETENTION_ADMIN_LOGINS_DAYS', 365) * DAY).toISOString();
        out.adminLogins = (await db.query('DELETE FROM admin_logins WHERE created_at < $1 RETURNING id', [loginCut]).catch(() => [])).length;
        return out;
      },
    },
    {
      // Photos still inside the database are moved to object storage (R2/S3) automatically once it is configured.
      // Verified one by one; a photo stays in the database if storage can't serve it. STORAGE_AUTO_MIGRATE=false turns it off.
      name: 'photo-storage', everyMs: 6 * 60 * 60_000, retryMs: 30 * 60_000,
      run: async () => {
        if (!storage?.enabled || process.env.STORAGE_AUTO_MIGRATE === 'false') return { skipped: 1 };
        return migratePhotos({ db, storage });
      },
    },
  ];
}
