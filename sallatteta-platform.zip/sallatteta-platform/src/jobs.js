// The list of background jobs. All of them are idempotent.
import { expireSubscriptions } from './services/cooks.js';
import { PgStore } from './lib/ratelimit.js';

export function defineJobs({ db }) {
  return [
    {
      // Hide cooks whose subscription ended (search also checks dates live, so this is bookkeeping).
      name: 'expire-subscriptions', everyMs: 5 * 60_000,
      run: async () => ({ expired: await expireSubscriptions(db) }),
    },
    {
      name: 'cleanup', everyMs: 60 * 60_000,
      run: async () => {
        const now = new Date().toISOString();
        const a = (await db.query('DELETE FROM admin_sessions WHERE expires_at <= $1 RETURNING id', [now])).length;
        const c = (await db.query('DELETE FROM cook_sessions WHERE expires_at <= $1 RETURNING id', [now])).length;
        const r = await new PgStore(db).cleanup();
        return { adminSessions: a, cookSessions: c, rateLimits: r };
      },
    },
  ];
}
