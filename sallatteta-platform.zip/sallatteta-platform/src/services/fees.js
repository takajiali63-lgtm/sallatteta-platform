// v8 — delivery fee from the ROAD distance between the store and the customer (never from the driver's position).
// Owner's prices (admin → delivery settings): base + per km, minimum, maximum, rounding up, optional distance bands.
// If the map service can't give a road distance, no fee is invented: the order can't use Aklatak drivers until it can,
// unless the owner turned on the straight-line estimate (marked as an estimate).
import { HttpError } from '../lib/http.js';

const cents = (n) => Math.round(Number(n || 0) * 100);

/** Price for a road distance in km, with the owner's rules. Pure function (tested on its own). */
export function feeForKm(km, s) {
  const tiers = Array.isArray(s.feeTiers) ? [...s.feeTiers].sort((a, b) => a.km - b.km) : [];
  let price;
  const band = tiers.find((x) => km <= Number(x.km));
  if (band) price = Number(band.price);
  else price = Number(s.feeBase || 0) + Number(s.feePerKm || 0) * km;
  price = Math.max(price, Number(s.feeMin || 0));
  if (Number(s.feeMax) > 0) price = Math.min(price, Number(s.feeMax));
  const step = Number(s.feeRound) > 0 ? cents(s.feeRound) : 1;
  return Math.ceil(cents(price) / step) * step / 100;   // rounded UP to the step, in exact cents
}

/** Road distance store → customer and the fee. Throws 503 route_unavailable when no trustworthy distance exists. */
export async function quoteFee(roads, s, store, to) {
  if (!roads?.distance) {
    if (!Number(s.roadFallback)) throw new HttpError(503, 'route_unavailable');
  }
  let d = roads?.distance ? await roads.distance(store, to) : null;
  if (!d || d.approx) {
    if (!Number(s.roadFallback)) throw new HttpError(503, 'route_unavailable');
    const R = 6371e3, rad = (x) => (x * Math.PI) / 180;
    const a = Math.sin(rad(to.lat - store.lat) / 2) ** 2 + Math.cos(rad(store.lat)) * Math.cos(rad(to.lat)) * Math.sin(rad(to.lng - store.lng) / 2) ** 2;
    d = { m: Math.round(2 * R * Math.asin(Math.sqrt(a)) * 1.3), approx: true };
  }
  const km = d.m / 1000;
  return { fee: feeForKm(km, s), distanceM: d.m, km: Math.round(km * 10) / 10, approx: !!d.approx };
}
