// v8.1 big catalogs: a store uploads ALL its products at once from a spreadsheet (CSV or Excel .xlsx) instead of adding
// them one by one. The same file updates them later (prices, quantities): a row is matched to an existing product by its
// barcode, else by its name. Nothing is deleted by an import. Rows with a problem are skipped and listed with their row
// number, so the store fixes only those.
import { readZip } from '../lib/zip.js';
import { hasProfanity } from '../lib/profanity.js';
import { normalizeName } from '../../public/assets/normalize.js';

export const MAX_ROWS = 20_000;
export const FIELDS = ['name', 'price', 'section', 'description', 'barcode', 'stock', 'available'];
// the column titles a store may use (any of the 4 app languages); the template uses the Arabic ones
const ALIASES = {
  name: ['الاسم', 'اسم المنتج', 'المنتج', 'اسم', 'name', 'product', 'product name', 'nom', 'produit', 'nombre', 'producto'],
  price: ['السعر', 'سعر', 'price', 'prix', 'precio'],
  section: ['القسم', 'الفئة', 'الصنف', 'section', 'category', 'categorie', 'catégorie', 'categoria', 'categoría'],
  description: ['الوصف', 'وصف', 'description', 'descripcion', 'descripción'],
  barcode: ['الباركود', 'باركود', 'الرمز', 'barcode', 'code', 'ean', 'sku', 'code-barres', 'code barre', 'codigo', 'código'],
  stock: ['الكمية', 'كمية', 'المخزون', 'stock', 'quantity', 'qty', 'quantite', 'quantité', 'cantidad'],
  available: ['متوفر', 'متاح', 'available', 'disponible'],
};
const keyOf = (s) => String(s ?? '').replace(/^\uFEFF/, '').trim().toLowerCase().replace(/\s+/g, ' ');
const HEAD = new Map(Object.entries(ALIASES).flatMap(([f, list]) => list.map((a) => [keyOf(a), f])));
const NO = new Set(['0', 'no', 'non', 'لا', 'false', 'غير متوفر', 'x', 'n']);
export const BARCODE = /^[0-9A-Za-z._-]{1,40}$/;

/* ---------- reading the file ---------- */

/** CSV text → rows (comma, semicolon or tab; quoted cells; Excel's UTF-8 BOM). */
export function parseCsv(text) {
  const src = String(text).replace(/^\uFEFF/, '');
  const first = src.slice(0, src.search(/\r?\n|$/));
  const delim = [',', ';', '\t'].map((d) => [d, first.split(d).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [], cell = '', q = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (q) {
      if (ch === '"') { if (src[i + 1] === '"') { cell += '"'; i++; } else q = false; }
      else cell += ch;
    } else if (ch === '"' && cell === '') q = true;
    else if (ch === delim) { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && src[i + 1] === '\n') i++;
      row.push(cell); rows.push(row); row = []; cell = '';
      if (rows.length > MAX_ROWS + 1) break;
    } else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

const unxml = (s) => s.replace(/&(lt|gt|quot|apos|amp|#\d+|#x[0-9a-f]+);/gi, (m, e) => (
  e === 'lt' ? '<' : e === 'gt' ? '>' : e === 'quot' ? '"' : e === 'apos' ? "'" : e === 'amp' ? '&'
    : String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : Number(e.slice(1)))));
const texts = (xml) => [...xml.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map((m) => unxml(m[1])).join('');
const colIndex = (ref) => { let n = 0; for (const ch of ref.replace(/\d+/g, '')) n = n * 26 + (ch.charCodeAt(0) - 64); return n - 1; };

/** Excel .xlsx → rows of its first sheet (shared strings, inline strings, numbers). */
export function parseXlsx(buf) {
  const files = readZip(buf, { maxFiles: 400, maxTotal: 80_000_000 });
  const shared = files.get('xl/sharedStrings.xml') ? [...files.get('xl/sharedStrings.xml').toString('utf8').matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => texts(m[1])) : [];
  // the first sheet in the workbook's order
  let sheetPath = 'xl/worksheets/sheet1.xml';
  const wb = files.get('xl/workbook.xml')?.toString('utf8');
  const rels = files.get('xl/_rels/workbook.xml.rels')?.toString('utf8');
  const rid = wb && /<sheet\b[^>]*\br:id="([^"]+)"/.exec(wb)?.[1];
  const target = rid && rels && new RegExp(`<Relationship\\b[^>]*Id="${rid}"[^>]*Target="([^"]+)"`).exec(rels)?.[1];
  const alt = rid && rels && new RegExp(`<Relationship\\b[^>]*Target="([^"]+)"[^>]*Id="${rid}"`).exec(rels)?.[1];
  const tg = target || alt;
  if (tg) sheetPath = tg.startsWith('/') ? tg.slice(1) : `xl/${tg.replace(/^\.\//, '')}`;
  const sheet = files.get(sheetPath) || [...files.entries()].find(([n]) => /^xl\/worksheets\/[^/]+\.xml$/.test(n))?.[1];
  if (!sheet) throw new Error('no sheet');
  const rows = [];
  for (const rm of sheet.toString('utf8').matchAll(/<row\b[^>]*?(?:\/>|>([\s\S]*?)<\/row>)/g)) {
    const row = [];
    for (const cm of (rm[1] || '').matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const attrs = cm[1], body = cm[2] || '';
      const ref = /\br="([A-Z]+)\d+"/.exec(attrs)?.[1];
      const type = /\bt="([^"]+)"/.exec(attrs)?.[1];
      const v = /<v>([\s\S]*?)<\/v>/.exec(body)?.[1];
      let val = '';
      if (type === 's') val = shared[Number(v)] ?? '';
      else if (type === 'inlineStr') val = texts(body);
      else if (v != null) val = unxml(v);
      const idx = ref ? colIndex(ref) : row.length;
      while (row.length < idx) row.push('');
      row[idx] = val;
    }
    rows.push(row);
    if (rows.length > MAX_ROWS + 1) break;
  }
  return rows;
}

/** The file the store chose (name + bytes) → rows. Throws 'unsupported_file' / 'bad_file'. */
export function readSheet(fileName, buf) {
  const ext = String(fileName || '').toLowerCase().split('.').pop();
  const isZip = buf.length > 4 && buf.readUInt32LE(0) === 0x04034b50;
  if (ext === 'xls' && !isZip) throw Object.assign(new Error('old excel'), { code: 'old_excel' });
  try {
    if (isZip) return parseXlsx(buf);
    if (['csv', 'txt', 'tsv'].includes(ext) || !ext) return parseCsv(buf.toString('utf8'));
  } catch { throw Object.assign(new Error('bad file'), { code: 'bad_file' }); }
  throw Object.assign(new Error('unsupported'), { code: 'unsupported_file' });
}

/* ---------- checking the rows ---------- */

const num = (s) => {
  let t = String(s ?? '').trim().replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660)).replace(/[$€£\s]|usd|lbp|ل\.ل/gi, '');
  if (/^\d+,\d{1,2}$/.test(t)) t = t.replace(',', '.');      // 1,5 → 1.5
  else t = t.replace(/,/g, '');                                 // 1,500,000 → 1500000
  return t === '' ? null : Number(t);
};

/**
 * Rows → { rows: [{ row, name, price, section, description, barcode, stock, available, has: {field: true} }], errors, columns }.
 * The first row holds the column titles.
 */
export function checkRows(table) {
  const head = (table[0] || []).map((h) => HEAD.get(keyOf(h)) || null);
  const columns = [...new Set(head.filter(Boolean))];
  if (!columns.includes('name')) return { rows: [], errors: [{ row: 1, msg: 'no_name_column' }], columns, tooMany: false };
  const out = [], errors = [];
  const body = table.slice(1);
  const tooMany = body.length > MAX_ROWS;
  body.slice(0, MAX_ROWS).forEach((cells, i) => {
    const rowNo = i + 2;
    const raw = {};
    head.forEach((f, c) => { if (f && raw[f] === undefined) raw[f] = String(cells[c] ?? '').trim(); });
    if (!Object.values(raw).some((v) => v !== '')) return;   // empty line
    const r = { row: rowNo, has: {} };
    const bad = (msg) => errors.push({ row: rowNo, msg, name: raw.name || '' });
    const name = raw.name?.replace(/\s+/g, ' ');
    if (!name) return bad('name_missing');
    if (name.length > 80) return bad('name_long');
    r.name = name;
    if (raw.price !== undefined && raw.price !== '') { const p = num(raw.price); if (p == null || !Number.isFinite(p) || p < 0 || p > 1_000_000) return bad('price_invalid'); r.price = Math.round(p * 100) / 100; r.has.price = true; }
    if (raw.section !== undefined && raw.section !== '') { if (raw.section.length > 40) return bad('section_long'); r.section = raw.section; r.has.section = true; }
    if (raw.description !== undefined && raw.description !== '') { if (raw.description.length > 200) return bad('description_long'); r.description = raw.description; r.has.description = true; }
    if (raw.barcode !== undefined && raw.barcode !== '') {
      const b = raw.barcode.replace(/\.0+$/, '').replace(/\s/g, '');   // Excel shows long numbers as 6.29E+12 or 629…0.0
      if (/e\+/i.test(b)) return bad('barcode_as_number');
      if (!BARCODE.test(b)) return bad('barcode_invalid');
      r.barcode = b; r.has.barcode = true;
    }
    if (raw.stock !== undefined && raw.stock !== '') { const s = num(raw.stock); if (s == null || !Number.isInteger(s) || s < 0 || s > 1_000_000) return bad('stock_invalid'); r.stock = s; r.has.stock = true; }
    if (raw.available !== undefined && raw.available !== '') { r.available = !NO.has(keyOf(raw.available)); r.has.available = true; }
    if ([r.name, r.description, r.section].some((x) => x && hasProfanity(x))) return bad('inappropriate_words');
    out.push(r);
  });
  return { rows: out, errors, columns, tooMany };
}

/* ---------- planning + saving ---------- */

const N = (s) => normalizeName(s);

/**
 * What the import would do for this store: which rows create a product, which update one (and which change nothing).
 * existing = the store's products [{ id, name, barcode, price, section, description, stock, is_available, auto_off }].
 */
export function planImport(existing, rows) {
  const byCode = new Map(), byName = new Map();
  for (const e of existing) { if (e.barcode) byCode.set(e.barcode, e); const k = N(e.name); if (k && !byName.has(k)) byName.set(k, e); }
  const seen = new Set();
  const create = [], update = [], same = [], errors = [];
  for (const r of rows) {
    const key = r.barcode ? `b:${r.barcode}` : `n:${N(r.name)}`;
    if (seen.has(key)) { errors.push({ row: r.row, msg: 'duplicate_row', name: r.name }); continue; }
    seen.add(key);
    const hit = (r.barcode && byCode.get(r.barcode)) || byName.get(N(r.name));
    if (!hit) { create.push(r); continue; }
    if (r.barcode && hit.barcode && hit.barcode !== r.barcode && !byCode.get(r.barcode)) {
      // same name, another barcode: a different product with the same name (sizes / brands) → new product
      create.push(r); continue;
    }
    if (seen.has(`id:${hit.id}`)) { errors.push({ row: r.row, msg: 'duplicate_row', name: r.name }); continue; }
    seen.add(`id:${hit.id}`);
    const next = {
      id: hit.id, name: r.name,
      price: r.has.price ? r.price : (hit.price == null ? null : Number(hit.price)),
      section: r.has.section ? r.section : hit.section || null,
      description: r.has.description ? r.description : hit.description || null,
      barcode: r.has.barcode ? r.barcode : hit.barcode || null,
      stock: r.has.stock ? r.stock : (hit.stock == null ? null : Number(hit.stock)),
      is_available: Number(hit.is_available), auto_off: Number(hit.auto_off || 0),
    };
    if (r.has.available) { next.is_available = r.available ? 1 : 0; next.auto_off = 0; }
    if (r.has.stock) {
      if (r.stock === 0) { next.is_available = 0; next.auto_off = 1; }
      else if (next.auto_off === 1) { next.is_available = 1; next.auto_off = 0; }   // restocked → back in the store
    }
    const changed = ['name', 'price', 'section', 'description', 'barcode', 'stock', 'is_available', 'auto_off']
      .some((k) => String(next[k] ?? '') !== String((k === 'auto_off' ? Number(hit.auto_off || 0) : k === 'is_available' ? Number(hit.is_available) : hit[k]) ?? ''));
    (changed ? update : same).push({ row: r.row, ...next });
  }
  return { create, update, same, errors };
}

/** Save a plan (inside one transaction, by batches: thousands of products in seconds, also on Postgres). */
export async function applyImport(t, cookId, plan, { currency, startOrder }) {
  const B = 150;
  for (let k = 0; k < plan.create.length; k += B) {
    const part = plan.create.slice(k, k + B);
    const params = [];
    const vals = part.map((r, i) => {
      const stock = r.has.stock ? r.stock : null;
      const avail = stock === 0 ? 0 : r.has.available ? (r.available ? 1 : 0) : 1;
      params.push(cookId, r.name, r.description || null, r.has.price ? r.price : null, currency, startOrder + k + i, r.section || null, r.barcode || null, stock, avail, stock === 0 ? 1 : 0);
      const b = i * 11;
      return `(${Array.from({ length: 11 }, (_, j) => `$${b + j + 1}`).join(',')})`;
    });
    await t.query(`INSERT INTO menu_items (cook_id, name, description, price, currency, sort_order, section, barcode, stock, is_available, auto_off) VALUES ${vals.join(',')}`, params);
  }
  for (let k = 0; k < plan.update.length; k += B) {
    const part = plan.update.slice(k, k + B);
    const params = [];
    const vals = part.map((r, i) => {
      params.push(r.id, r.name, r.price, r.section, r.description, r.barcode, r.stock, r.is_available, r.auto_off);
      const b = i * 9;
      return `(CAST($${b + 1} AS INTEGER), CAST($${b + 2} AS TEXT), CAST($${b + 3} AS DOUBLE PRECISION), CAST($${b + 4} AS TEXT), CAST($${b + 5} AS TEXT), CAST($${b + 6} AS TEXT), CAST($${b + 7} AS INTEGER), CAST($${b + 8} AS INTEGER), CAST($${b + 9} AS INTEGER))`;
    });
    params.push(cookId);
    await t.query(`UPDATE menu_items SET name = v.column2, price = v.column3, section = v.column4, description = v.column5, barcode = v.column6, stock = v.column7, is_available = v.column8, auto_off = v.column9
      FROM (VALUES ${vals.join(',')}) AS v WHERE menu_items.id = v.column1 AND menu_items.cook_id = $${params.length}`, params);
  }
}

/** The template a store downloads: the Arabic column titles + two example rows (Excel opens it with the right letters). */
export function templateCsv() {
  const rows = [
    ['الاسم', 'السعر', 'القسم', 'الوصف', 'الباركود', 'الكمية', 'متوفر'],
    ['حليب كامل الدسم 1 ليتر', '1.5', 'ألبان وأجبان', '', '6291003000017', '24', 'نعم'],
    ['خبز عربي كبير', '0.9', 'مخبوزات', 'ربطة 6 أرغفة', '', '', 'نعم'],
  ];
  return '\uFEFF' + rows.map((r) => r.map((c) => (/[",\n]/.test(c) ? `"${c.replace(/"/g, '""')}"` : c)).join(',')).join('\r\n') + '\r\n';
}

/** Which product a photo file belongs to: its name is the product's barcode, or the product's name. */
export function matchPhoto(existing, fileName) {
  const base = String(fileName || '').replace(/^.*[\\/]/, '').replace(/\.[a-z0-9]{2,5}$/i, '').trim();
  if (!base) return null;
  const code = base.replace(/\s/g, '');
  return existing.find((e) => e.barcode && e.barcode === code) || existing.find((e) => N(e.name) === N(base)) || null;
}
