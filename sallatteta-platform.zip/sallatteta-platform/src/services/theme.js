// Turns the owner's design choices (admin panel → Design) into a small CSS file served at /theme.css.
// Only validated values are used: colours must be #rgb / #rrggbb, sizes and layouts come from fixed lists.

export const LAYOUTS = { cooks: ['slider', 'grid', 'list'], restaurants: ['slider', 'grid', 'list'] };
export const FONT_SCALES = [0.9, 1, 1.1, 1.2];
export const COLOR_KEYS = { gold: '--gold', goldSoft: '--gold-soft', bg: '--bg', surface: '--surface', text: '--text', muted: '--muted' };
export const isColor = (c) => /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(String(c || ''));

export function themeCss(theme = {}) {
  const lines = ['/* Aklatak — design chosen in the admin panel */'];
  const vars = Object.entries(COLOR_KEYS)
    .filter(([k]) => isColor(theme.colors?.[k]))
    .map(([k, v]) => `${v}: ${theme.colors[k]};`);
  if (vars.length) lines.push(`:root { ${vars.join(' ')} }`, `body { background-color: var(--bg); }`);
  const scale = FONT_SCALES.includes(Number(theme.fontScale)) ? Number(theme.fontScale) : 1;
  if (scale !== 1) lines.push(`html { font-size: ${Math.round(scale * 100)}%; }`);
  const grid = (sel, cols) => `${sel} { display: grid; grid-template-columns: repeat(${cols}, minmax(0, 1fr)); overflow: visible; scroll-snap-type: none; margin-inline: 0; padding-inline: 0; }`;
  const cooks = theme.layouts?.cooks;
  if (cooks === 'grid') lines.push(grid('#cookSlider', 2), '#cookSlider > * { width: auto; }');
  if (cooks === 'list') lines.push(grid('#cookSlider', 1), '#cookSlider > * { width: auto; }');
  const rest = theme.layouts?.restaurants;
  if (rest === 'grid') lines.push(grid('#restSlider', 2), '#restSlider .rest-card { width: auto; max-width: none; }');
  if (rest === 'list') lines.push(grid('#restSlider', 1), '#restSlider .rest-card { width: auto; max-width: none; }');
  return lines.join('\n') + '\n';
}
