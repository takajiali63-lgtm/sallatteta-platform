// In-memory index of villages/towns (a few hundred rows) for fast, typo-tolerant search.
import { haversineKm } from '../lib/geo.js';
import { normalizeName } from '../../public/assets/normalize.js';
import { DISTRICTS } from '../db/seed-data.js';

export class AreaIndex {
  constructor(db) { this.db = db; this.list = []; this.byId = new Map(); }

  async load() {
    const rows = await this.db.query(
      'SELECT id, slug, name_ar, name_en, name_fr, district, lat, lng FROM service_areas WHERE is_active = 1 ORDER BY sort_order, id');
    this.list = rows.map((r) => ({
      ...r,
      names: [...new Set([
        normalizeName(r.name_ar), normalizeName(r.name_ar, { keepAl: true }), normalizeName(r.name_en || ''),
      ].filter(Boolean))],
    }));
    this.byId = new Map(this.list.map((a) => [a.id, a]));
    return this;
  }

  get(id) { return this.byId.get(Number(id)) || null; }

  view(a, locale = 'ar', extra = {}) {
    if (!a) return null;
    const d = DISTRICTS[a.district];
    return {
      id: a.id,
      name: (locale === 'en' || locale === 'fr' ? a.name_en : a.name_ar) || a.name_ar,
      district: a.district || null,
      districtName: d ? (locale === 'ar' ? d.ar : d.en) : null,
      lat: a.lat,
      lng: a.lng,
      ...extra,
    };
  }

  /** Prefix matches first, then "contains" matches. */
  search(q, { locale = 'ar', limit = 12 } = {}) {
    const qs = [...new Set([normalizeName(q), normalizeName(q, { keepAl: true })])].filter(Boolean);
    if (!qs.length) return [];
    const scored = [];
    for (const a of this.list) {
      let score = -1;
      for (const name of a.names) for (const n of qs) {
        if (name === n) score = Math.max(score, 3);
        else if (name.startsWith(n)) score = Math.max(score, 2);
        else if (name.split(' ').some((w) => w.startsWith(n))) score = Math.max(score, 1.5);
        else if (name.includes(n)) score = Math.max(score, 1);
      }
      if (score > 0) scored.push([score, a]);
    }
    scored.sort((x, y) => y[0] - x[0] || x[1].name_ar.localeCompare(y[1].name_ar, 'ar'));
    return scored.slice(0, limit).map(([, a]) => this.view(a, locale));
  }

  nearest(lat, lng) {
    let best = null;
    for (const a of this.list) {
      const d = haversineKm(lat, lng, a.lat, a.lng);
      if (!best || d < best.d) best = { d, a };
    }
    return best ? best.a : null;
  }

  /** Villages around a village, nearest first (for the cook's "where do you deliver" picker). */
  nearby(areaId, { km = 15, limit = 30, locale = 'ar' } = {}) {
    const c = this.get(areaId);
    if (!c) return [];
    return this.list
      .map((a) => [haversineKm(c.lat, c.lng, a.lat, a.lng), a])
      .filter(([d]) => d <= km)
      .sort((x, y) => x[0] - y[0])
      .slice(0, limit)
      .map(([d, a]) => this.view(a, locale, { distanceKm: Math.round(d * 10) / 10 }));
  }

  /** Villages & areas around a point (cook's GPS), nearest first. */
  around(lat, lng, { km = 15, limit = 120, locale = 'ar' } = {}) {
    return this.list
      .map((a) => [haversineKm(lat, lng, a.lat, a.lng), a])
      .filter(([d]) => d <= km)
      .sort((x, y) => x[0] - y[0])
      .slice(0, limit)
      .map(([d, a]) => this.view(a, locale, { distanceKm: Math.round(d * 10) / 10 }));
  }

  /** Area ids that count as "where the customer is": the nearest one + any within `km`. */
  idsNear(lat, lng, km = 2.5) {
    const ids = new Set();
    const n = this.nearest(lat, lng);
    if (n) ids.add(n.id);
    for (const a of this.list) if (haversineKm(lat, lng, a.lat, a.lng) <= km) ids.add(a.id);
    return [...ids];
  }

  inDistrict(district, locale = 'ar') {
    return this.list.filter((a) => a.district === district).map((a) => this.view(a, locale));
  }

  districts(locale = 'ar') {
    return Object.entries(DISTRICTS).map(([key, d]) => ({ key, name: locale === 'ar' ? d.ar : d.en }));
  }
}
