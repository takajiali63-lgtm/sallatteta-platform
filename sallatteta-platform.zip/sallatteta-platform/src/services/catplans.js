// v8.1 per-CATEGORY settings chosen by the owner (admin → «حدود وأسعار الأقسام»): how many products and photos a business
// of this category may have, and what its subscription costs (basic / with drivers / AI MANAGER × 1 / 3 / 12 months).
// They apply automatically to every subscriber of the category (sign-up, «my plan», renewals, limits). Anything left
// empty falls back to the general numbers, so a category without its own values behaves exactly as before.
import { isCraft } from './categories.js';

export const MONTHS = [1, 3, 12];
export const PRODUCTS_MAX = 50_000;
export const PHOTOS_MAX = 5_000;
const KEY = /^[a-z][a-z0-9_]{1,30}$/;
const intIn = (v, lo, hi) => { const n = Math.round(Number(v)); return Number.isFinite(n) && n >= lo && n <= hi ? n : null; };
const priceIn = (v) => { const n = Number(v); return Number.isFinite(n) && n > 0 && n <= 100_000 ? Math.round(n * 100) / 100 : null; };

/** Which AI price list a category uses. */
export const aiGroupOf = (kind) => (kind === 'online_store' ? 'online' : isCraft(kind) ? 'crafts' : 'shops');

/**
 * Clean what the admin panel sends: { kind: { products, photos, basic: {1,3,12}, delivery: {…}, ai: {…} } }.
 * Empty values are dropped (= general). Returns null when something is wrong (nothing is half-saved).
 */
export function cleanCatPlans(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  const out = {};
  for (const [kind, raw] of Object.entries(input)) {
    if (!KEY.test(kind) || !raw || typeof raw !== 'object') return null;
    const c = {};
    if (raw.products !== undefined && raw.products !== null && raw.products !== '') { const n = intIn(raw.products, 1, PRODUCTS_MAX); if (n == null) return null; c.products = n; }
    if (raw.photos !== undefined && raw.photos !== null && raw.photos !== '') { const n = intIn(raw.photos, 1, PHOTOS_MAX); if (n == null) return null; c.photos = n; }
    for (const tier of ['basic', 'delivery', 'ai']) {
      if (!raw[tier]) continue;
      if (typeof raw[tier] !== 'object') return null;
      const p = {};
      for (const m of MONTHS) {
        const v = raw[tier][m];
        if (v === undefined || v === null || v === '') continue;
        const n = priceIn(v); if (n == null) return null; p[m] = n;
      }
      if (Object.keys(p).length) c[tier] = p;
    }
    if (Object.keys(c).length) out[kind] = c;
  }
  return out;
}

/** The plans this category pays: the general plans with the category's own prices on top. */
export function plansFor(plans, settings, kind) {
  const cp = settings?.catPlans?.[kind];
  if (!cp || !plans) return plans;
  const out = structuredClone(plans);
  for (const m of MONTHS) {
    if (cp.basic?.[m] && out.store?.basic?.[m]) out.store.basic[m].price = cp.basic[m];
    if (cp.delivery?.[m] && out.store?.delivery?.[m]) out.store.delivery[m].price = cp.delivery[m];
    // the AI MANAGER has no discount: the category's monthly AI price × months
    const g = aiGroupOf(kind);
    if (cp.ai?.[1] && out.ai?.[g]?.[m]) out.ai[g][m].price = Math.round(cp.ai[1] * m * 100) / 100;
  }
  return out;
}

/** How many products / gallery photos this category may have (its own number, else the general one). */
export function limitsFor(settings, kind) {
  const l = settings?.limits || {};
  const cp = settings?.catPlans?.[kind] || {};
  const generalPhotos = kind && kind !== 'cook' ? (Number(l.restaurantPhotos) || 300) : (Number(l.cookPhotos) || 300);
  return { products: cp.products || Number(l.menuItems) || 300, photos: cp.photos || generalPhotos };
}
