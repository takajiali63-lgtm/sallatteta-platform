import { haversineKm, boundingBox, roundTo } from '../lib/geo.js';
import { PLANS } from '../db/seed-data.js';

export const SUBSCRIPTION_STATUSES = ['pending', 'active', 'expired', 'suspended'];
export const PAYMENT_STATUSES = ['unpaid', 'paid', 'waived'];
export const PLAN_KEYS = Object.keys(PLANS);

const nowIso = () => new Date().toISOString();
const iso = (d) => (d == null ? null : d instanceof Date ? d.toISOString() : new Date(d).toISOString());

export function addMonths(date, months) {
  const d = new Date(date);
  const day = d.getUTCDate();
  d.setUTCMonth(d.getUTCMonth() + months);
  if (d.getUTCDate() < day) d.setUTCDate(0); // e.g. Jan 31 + 1 month → Feb 28/29
  return d;
}

/** Condition shared by search + contact: cook is approved and has a subscription active *right now*. */
const VISIBLE_SQL = `c.status = 'approved' AND EXISTS (
  SELECT 1 FROM subscriptions s WHERE s.cook_id = c.id AND s.status = 'active'
  AND s.start_date <= $1 AND s.expiry_date > $1)`;

async function serviceKeysFor(db, cookIds) {
  const map = new Map(cookIds.map((id) => [id, []]));
  if (!cookIds.length) return map;
  const ph = cookIds.map((_, i) => `$${i + 1}`).join(',');
  const rows = await db.query(
    `SELECT cst.cook_id, st.key FROM cook_service_types cst
     JOIN service_types st ON st.id = cst.service_type_id
     WHERE cst.cook_id IN (${ph}) ORDER BY st.sort_order`, cookIds);
  for (const r of rows) map.get(r.cook_id)?.push(r.key);
  return map;
}

function areaNameCol(locale) {
  return { en: 'a.name_en', fr: 'a.name_fr' }[locale] || 'a.name_ar';
}

/**
 * Active cooks whose own service radius covers the customer location, nearest first.
 * SQL pre-filters with a bounding box (max radius), then exact Haversine in JS.
 */
export async function searchNearbyCooks(db, { lat, lng, serviceType = null, locale = 'ar', maxRadiusKm = 50, limit = 30, now = nowIso() }) {
  const box = boundingBox(lat, lng, maxRadiusKm);
  const params = [now, box.minLat, box.maxLat, box.minLng, box.maxLng];
  let sql = `SELECT c.id, c.full_name, c.lat, c.lng, c.service_radius_km, c.bio,
      COALESCE(${areaNameCol(locale)}, a.name_ar, c.area_label) AS area_name,
      CASE WHEN c.photo IS NULL THEN 0 ELSE 1 END AS has_photo
    FROM cooks c LEFT JOIN service_areas a ON a.id = c.area_id
    WHERE ${VISIBLE_SQL}
      AND c.lat BETWEEN $2 AND $3 AND c.lng BETWEEN $4 AND $5`;
  if (serviceType) {
    params.push(serviceType);
    sql += ` AND EXISTS (SELECT 1 FROM cook_service_types cst JOIN service_types st ON st.id = cst.service_type_id
             WHERE cst.cook_id = c.id AND st.key = $6)`;
  }
  const rows = await db.query(sql, params);
  const matches = rows
    .map((r) => ({ ...r, distance: haversineKm(lat, lng, r.lat, r.lng) }))
    .filter((r) => r.distance <= r.service_radius_km)
    .sort((a, b) => a.distance - b.distance || a.full_name.localeCompare(b.full_name, 'ar'))
    .slice(0, limit);
  const services = await serviceKeysFor(db, matches.map((m) => m.id));
  // NOTE: WhatsApp numbers and exact coordinates are never returned here.
  return matches.map((m) => ({
    id: m.id,
    name: m.full_name,
    area: m.area_name,
    distanceKm: roundTo(m.distance, 1),
    services: services.get(m.id) || [],
    bio: m.bio || '',
    photoUrl: m.has_photo ? `/media/cooks/${m.id}.jpg` : null,
    subscriptionStatus: 'active',
  }));
}

export async function isCookVisible(db, cookId, now = nowIso()) {
  return !!(await db.one(`SELECT c.id FROM cooks c WHERE c.id = $2 AND ${VISIBLE_SQL}`, [now, cookId]));
}

export async function nearestArea(db, lat, lng, locale = 'ar') {
  const areas = await db.query('SELECT id, name_ar, name_en, name_fr, lat, lng FROM service_areas WHERE is_active = 1');
  let best = null;
  for (const a of areas) {
    const d = haversineKm(lat, lng, a.lat, a.lng);
    if (!best || d < best.d) best = { d, a };
  }
  if (!best) return null;
  return { id: best.a.id, name: best.a[`name_${locale}`] || best.a.name_ar, distanceKm: best.d };
}

/* ---------------- status helpers ---------------- */

export function effectiveStatus(cook, sub, now = new Date()) {
  if (cook.status === 'rejected') return 'rejected';
  if (!sub) return cook.status === 'pending' ? 'pending' : 'no_subscription';
  if (sub.status === 'active') {
    if (!sub.expiry_date || new Date(sub.expiry_date) <= now) return 'expired';
    if (sub.start_date && new Date(sub.start_date) > now) return 'scheduled';
    return cook.status === 'approved' ? 'active' : 'pending';
  }
  return sub.status; // pending | expired | suspended
}

/** Marks subscriptions whose expiry date passed as expired. Data is kept. */
export async function expireSubscriptions(db, now = nowIso()) {
  const rows = await db.query(
    `UPDATE subscriptions SET status = 'expired', updated_at = $1
     WHERE status = 'active' AND expiry_date <= $1 RETURNING id, cook_id`, [now]);
  return rows.length;
}

export async function latestSubscription(db, cookId) {
  return db.one('SELECT * FROM subscriptions WHERE cook_id = $1 ORDER BY id DESC LIMIT 1', [cookId]);
}

export async function setCookServices(db, cookId, keys) {
  await db.query('DELETE FROM cook_service_types WHERE cook_id = $1', [cookId]);
  for (const key of keys) {
    await db.query(
      `INSERT INTO cook_service_types (cook_id, service_type_id)
       SELECT CAST($1 AS INTEGER), id FROM service_types WHERE key = $2 ON CONFLICT DO NOTHING`, [cookId, key]);
  }
}

export async function logAdminAction(db, adminId, cookId, action, details = null) {
  await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,$2,$3,$4)',
    [adminId, cookId, action, details ? JSON.stringify(details) : null]);
}

/* ---------------- subscription actions ---------------- */

export async function activateSubscription(db, cookId, { plan, startDate, expiryDate, paymentStatus }) {
  const start = startDate ? new Date(startDate) : new Date();
  const expiry = expiryDate ? new Date(expiryDate) : addMonths(start, PLANS[plan]);
  if (expiry <= start) throw Object.assign(new Error('expiry_before_start'), { code: 'expiry_before_start' });
  const now = nowIso();
  const latest = await latestSubscription(db, cookId);
  if (latest) {
    await db.query(
      `UPDATE subscriptions SET plan=$1, status='active', payment_status=$2, start_date=$3, expiry_date=$4, updated_at=$5 WHERE id=$6`,
      [plan, paymentStatus, iso(start), iso(expiry), now, latest.id]);
  } else {
    await db.query(
      `INSERT INTO subscriptions (cook_id, plan, status, payment_status, start_date, expiry_date)
       VALUES ($1,$2,'active',$3,$4,$5)`, [cookId, plan, paymentStatus, iso(start), iso(expiry)]);
  }
  await db.query(`UPDATE cooks SET status='approved', updated_at=$1 WHERE id=$2`, [now, cookId]);
  return latestSubscription(db, cookId);
}

/** Extends from the current expiry if still running, otherwise from today. */
export async function renewSubscription(db, cookId, { plan, months, paymentStatus }) {
  const latest = await latestSubscription(db, cookId);
  const add = months || PLANS[plan];
  const nowD = new Date();
  const running = latest && latest.status === 'active' && latest.expiry_date && new Date(latest.expiry_date) > nowD;
  const base = running ? new Date(latest.expiry_date) : nowD;
  const start = running ? new Date(latest.start_date) : nowD;
  return activateSubscription(db, cookId, {
    plan: plan || latest?.plan || 'monthly',
    startDate: start,
    expiryDate: addMonths(base, add),
    paymentStatus: paymentStatus || latest?.payment_status || 'paid',
  });
}

export async function setSubscriptionStatus(db, cookId, status) {
  const latest = await latestSubscription(db, cookId);
  if (!latest) return null;
  await db.query('UPDATE subscriptions SET status=$1, updated_at=$2 WHERE id=$3', [status, nowIso(), latest.id]);
  return latestSubscription(db, cookId);
}

export async function updateSubscriptionFields(db, cookId, fields) {
  const latest = await latestSubscription(db, cookId);
  if (!latest) return null;
  const next = {
    plan: fields.plan ?? latest.plan,
    payment_status: fields.paymentStatus ?? latest.payment_status,
    start_date: fields.startDate ? iso(fields.startDate) : latest.start_date,
    expiry_date: fields.expiryDate ? iso(fields.expiryDate) : latest.expiry_date,
    status: fields.status ?? latest.status,
    notes: fields.notes !== undefined ? fields.notes : latest.notes,
  };
  await db.query(
    `UPDATE subscriptions SET plan=$1, payment_status=$2, start_date=$3, expiry_date=$4, status=$5, notes=$6, updated_at=$7 WHERE id=$8`,
    [next.plan, next.payment_status, iso(next.start_date), iso(next.expiry_date), next.status, next.notes, nowIso(), latest.id]);
  return latestSubscription(db, cookId);
}
