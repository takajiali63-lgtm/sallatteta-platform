// Signature checks for store-app billing, with Node built-ins only (no npm packages):
//  - our own RS256 JWT to get a Google access token from a service account;
//  - Google's signed OIDC token on Pub/Sub pushes (RS256 against Google's published keys);
//  - Apple's JWS (ES256) with its x5c certificate chain, which must end at Apple Root CA - G3.
import { createPublicKey, createHash, sign, verify, X509Certificate } from 'node:crypto';

export const b64url = (buf) => Buffer.from(buf).toString('base64url');
const fromB64url = (s) => Buffer.from(String(s), 'base64url');

export class BillingAuthError extends Error {
  constructor(code) { super(code); this.code = code; }
}

/* ---------------- Google service account ---------------- */

/** GOOGLE_PLAY_SERVICE_ACCOUNT_JSON may be pasted as JSON or as base64 of the JSON (easier in Render). */
export function parseServiceAccount(raw) {
  if (!raw) return null;
  const tryJson = (s) => { try { const o = JSON.parse(s); return o && o.client_email && o.private_key ? o : null; } catch { return null; } };
  return tryJson(raw) || tryJson(Buffer.from(String(raw), 'base64').toString('utf8'));
}

/** Signed assertion (RS256) exchanged at Google's token endpoint for an access token. */
export function serviceAccountJwt(sa, { scope, now = Date.now() } = {}) {
  const iat = Math.floor(now / 1000);
  const head = b64url(JSON.stringify({ alg: 'RS256', typ: 'JWT', ...(sa.private_key_id ? { kid: sa.private_key_id } : {}) }));
  const body = b64url(JSON.stringify({ iss: sa.client_email, scope, aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 }));
  const sig = sign('RSA-SHA256', Buffer.from(`${head}.${body}`), sa.private_key);
  return `${head}.${body}.${b64url(sig)}`;
}

function splitJwt(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new BillingAuthError('malformed_token');
  let header, payload;
  try { header = JSON.parse(fromB64url(parts[0]).toString('utf8')); payload = JSON.parse(fromB64url(parts[1]).toString('utf8')); }
  catch { throw new BillingAuthError('malformed_token'); }
  return { header, payload, signed: Buffer.from(`${parts[0]}.${parts[1]}`), sig: fromB64url(parts[2]) };
}

/* ---------------- Google OIDC (Pub/Sub push) ---------------- */

export const GOOGLE_CERTS_URL = 'https://www.googleapis.com/oauth2/v3/certs';

/** Google's public keys, cached (an unknown key id refreshes them, at most once a minute). */
export function googleJwks(fetchImpl, { ttlMs = 3600_000 } = {}) {
  let keys = null, at = 0, lastTry = 0;
  async function load() {
    lastTry = Date.now();
    const r = await fetchImpl(GOOGLE_CERTS_URL);
    if (!r.ok) throw new BillingAuthError('jwks_unavailable');
    const j = await r.json();
    keys = new Map((j.keys || []).map((k) => [k.kid, k]));
    at = Date.now();
  }
  return {
    async key(kid) {
      if (!keys || Date.now() - at > ttlMs) await load();
      if (!keys.has(kid) && Date.now() - lastTry > 60_000) await load();
      const jwk = keys.get(kid);
      if (!jwk) throw new BillingAuthError('unknown_key');
      return createPublicKey({ key: jwk, format: 'jwk' });
    },
  };
}

export async function verifyGoogleOidc(token, { audience, jwks, now = Date.now() }) {
  const { header, payload, signed, sig } = splitJwt(token);
  if (header.alg !== 'RS256' || !header.kid) throw new BillingAuthError('bad_alg');
  const key = await jwks.key(header.kid);
  if (!verify('RSA-SHA256', signed, key, sig)) throw new BillingAuthError('bad_signature');
  if (!['accounts.google.com', 'https://accounts.google.com'].includes(payload.iss)) throw new BillingAuthError('bad_issuer');
  const aud = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
  if (!aud.includes(audience)) throw new BillingAuthError('bad_audience');
  const sec = Math.floor(now / 1000);
  if (!(Number(payload.exp) > sec - 30)) throw new BillingAuthError('expired');
  if (payload.iat && Number(payload.iat) > sec + 300) throw new BillingAuthError('not_yet_valid');
  return payload;
}

/* ---------------- Apple JWS (App Store Server Notifications V2, signed transactions) ---------------- */

// SHA-256 of the DER of "Apple Root CA - G3" (published by Apple: support.apple.com/121728). The x5c chain must end here.
export const APPLE_ROOT_G3_SHA256 = '63343ABFB89A6A03EBB57E9B3F5FA7BE7C4F5C756F3017B3A8C488C3653E9179';

/** DER of an OID value (used to find Apple's marker extensions in the certificates). */
export function oidDer(oid) {
  const parts = oid.split('.').map(Number);
  const bytes = [parts[0] * 40 + parts[1]];
  for (const p of parts.slice(2)) {
    const stack = [p & 0x7f];
    let v = Math.floor(p / 128);
    while (v > 0) { stack.unshift((v & 0x7f) | 0x80); v = Math.floor(v / 128); }
    bytes.push(...stack);
  }
  return Buffer.from([0x06, bytes.length, ...bytes]);
}
// Apple puts these extensions in the certificates that sign App Store data: leaf (receipt signing) and the WWDR intermediate.
export const APPLE_LEAF_OID = '1.2.840.113635.100.6.11.1';
export const APPLE_INTERMEDIATE_OID = '1.2.840.113635.100.6.2.1';

const fp = (cert) => createHash('sha256').update(cert.raw).digest('hex').toUpperCase();

/**
 * Verify an Apple JWS and return its payload. Throws BillingAuthError on any problem.
 * rootFingerprints: production always uses [APPLE_ROOT_G3_SHA256]; tests may pass their own local root.
 */
export function verifyAppleJws(jws, { rootFingerprints = [APPLE_ROOT_G3_SHA256], now = Date.now() } = {}) {
  const { header, payload, signed, sig } = splitJwt(jws);
  if (header.alg !== 'ES256') throw new BillingAuthError('bad_alg');
  if (!Array.isArray(header.x5c) || header.x5c.length < 2 || header.x5c.length > 4) throw new BillingAuthError('bad_chain');
  let certs;
  try { certs = header.x5c.map((c) => new X509Certificate(Buffer.from(String(c), 'base64'))); }
  catch { throw new BillingAuthError('bad_chain'); }
  const root = certs[certs.length - 1];
  const roots = rootFingerprints.map((f) => String(f).replace(/[^0-9a-f]/gi, '').toUpperCase());
  if (!roots.includes(fp(root))) throw new BillingAuthError('untrusted_root');
  // every certificate is signed by the next one, and the root by itself
  for (let i = 0; i < certs.length - 1; i++) {
    if (!certs[i].checkIssued(certs[i + 1]) || !certs[i].verify(certs[i + 1].publicKey)) throw new BillingAuthError('bad_chain');
    if (!certs[i + 1].ca) throw new BillingAuthError('bad_chain');
  }
  if (!root.verify(root.publicKey)) throw new BillingAuthError('bad_chain');
  for (const c of certs) {
    if (!(Date.parse(c.validFrom) <= now && now <= Date.parse(c.validTo))) throw new BillingAuthError('cert_expired');
  }
  // Apple's marker extensions: the leaf is an App Store signing certificate, the intermediate is Apple's WWDR CA
  if (!certs[0].raw.includes(oidDer(APPLE_LEAF_OID))) throw new BillingAuthError('bad_leaf');
  if (certs.length > 2 && !certs[1].raw.includes(oidDer(APPLE_INTERMEDIATE_OID))) throw new BillingAuthError('bad_intermediate');
  if (sig.length !== 64 || !verify('sha256', signed, { key: certs[0].publicKey, dsaEncoding: 'ieee-p1363' }, sig)) {
    throw new BillingAuthError('bad_signature');
  }
  return payload;
}
