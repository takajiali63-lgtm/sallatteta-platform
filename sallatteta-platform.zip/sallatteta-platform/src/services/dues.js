// v8 — money between drivers and stores, the platform never holds it.
//
//   INVOICE   = one driver_cash_entries row per order the driver delivered and collected cash for: what he owes the
//               store for the goods (due_cents), kept apart from his delivery fee (fee_cents). Partly paid → paid_cents.
//   PAYMENT   = the driver says "I paid the store X" and the store says "I received X". Only when BOTH said the same
//               amount is it confirmed and spread over the oldest invoices (partial payments allowed). Different amounts
//               → "review" for the owner. One open payment per driver/store at a time; every change in one transaction.
//   ADMIN     = the owner may pay a store for a driver (all or part). The driver then owes the PLATFORM that amount, and
//               any such debt (even 1 $) blocks him from every new order (cash and card) until the owner confirms he
//               paid it back.
//   CAP       = a driver may owe stores at most `cashLimit` (100 $): open invoices + orders he already accepted. A new cash
//               order that would pass the cap is refused (90 $ + a 20 $ order = 110 $ → refused).
//   EXCEPTION = one big order (above the cap, up to `exceptionCap`, 150 $) is allowed only to a driver who owes nothing,
//               after the store accepted the exception before the search and the driver accepted it explicitly. Until that
//               invoice is fully paid he gets no new orders at all.
// All amounts are integers in cents.
import { HttpError } from '../lib/http.js';
import { lockAccount } from './delivery.js';

const iso = () => new Date().toISOString();
export const toCents = (n) => Math.round(Number(n || 0) * 100);
export const fromCents = (c) => Math.round(Number(c || 0)) / 100;
const err = (status, code, extra) => new HttpError(status, code, extra);

/* ---------------- position: what a driver owes, holds and may take ---------------- */
export async function driverPosition(q, s, driverId) {
  const open = await q.one(`SELECT COALESCE(SUM(COALESCE(due_cents, CAST(ROUND(amount * 100) AS INTEGER)) - paid_cents), 0) AS c, CAST(COUNT(*) AS INTEGER) AS n
    FROM driver_cash_entries WHERE driver_id = $1 AND status IN ('open','in_settlement') AND direction = 'driver_to_store'`, [driverId]);
  // orders he took and has not handed the money over for yet (accepted, on the way, delivered but not confirmed)
  const reserved = await q.one(`SELECT COALESCE(SUM(total), 0) AS s FROM orders WHERE driver_id = $1 AND payment_method = 'cash' AND customer_total IS NOT NULL AND self_delivery = 0
    AND (status IN ('assigned','picked_up') OR (status = 'delivered' AND financial_status IN ('open','disputed')))`, [driverId]);
  const debt = await q.one('SELECT COALESCE(SUM(cents), 0) AS c FROM admin_debt_ledger WHERE driver_id = $1', [driverId]);
  const exc = await q.one(`SELECT o.id FROM orders o LEFT JOIN driver_cash_entries e ON e.order_id = o.id
    WHERE o.driver_id = $1 AND o.exception = 1 AND (o.status IN ('assigned','picked_up') OR (o.status = 'delivered' AND o.financial_status IN ('open','disputed')) OR e.status IN ('open','in_settlement'))`, [driverId]);
  const openC = Number(open.c), reservedC = toCents(reserved.s), debtC = Number(debt.c);
  const cap = toCents(s.cashLimit ?? 100);
  return {
    openCents: openC, reservedCents: reservedC, adminDebtCents: debtC, exposureCents: openC + reservedC, capCents: cap,
    exceptionCapCents: toCents(s.exceptionCap ?? 150), exceptionOn: Number(s.exceptionOn ?? 1) === 1, exceptionActive: !!exc,
    blocked: debtC > 0 ? 'admin_debt' : exc ? 'exception_open' : null,
  };
}

/** What this order would add to the driver's debt to the store (only cash orders the driver collects). */
export function orderObligationCents(o) {
  return o && o.customer_total != null && o.payment_method === 'cash' && !Number(o.self_delivery) ? toCents(o.total) : 0;
}

/**
 * May this driver take this order? Throws the reason (backend rule — the app only shows it).
 * Returns { exception: true } when the order is taken under the big-order exception.
 */
export function checkTake(pos, s, order, { consent = false } = {}) {
  if (pos.blocked === 'admin_debt') throw err(409, 'admin_debt_block', { amount: fromCents(pos.adminDebtCents) });
  if (pos.blocked === 'exception_open') throw err(409, 'exception_block');
  const add = orderObligationCents(order);
  if (!add) return { exception: false };   // card / store's own delivery: nothing owed by the driver (blocks above still apply)
  if (pos.exposureCents + add <= pos.capCents) return { exception: false };
  const exceptionFits = pos.exceptionOn && Number(order.exception_ok) === 1 && add > pos.capCents && add <= pos.exceptionCapCents
    && pos.exposureCents === 0 && pos.adminDebtCents === 0;
  if (!exceptionFits) throw err(409, 'cash_limit_reached', { owed: fromCents(pos.exposureCents), limit: fromCents(pos.capCents), order: fromCents(add) });
  if (!consent) throw err(409, 'exception_consent_required', { amount: fromCents(add), limit: fromCents(pos.capCents) });
  return { exception: true };
}

/** Can the driver even SEE this order offer (same rules, without throwing; exception offers shown to free drivers). */
export function canSee(pos, order) {
  try { checkTake(pos, {}, order, { consent: true }); return true; } catch { return false; }
}

/* ---------------- invoices ---------------- */
const INV_COLS = `e.id, e.order_id, e.driver_id, e.store_id, e.status, e.direction, e.created_at, e.settled_at, e.paid_cents, e.fee_cents, e.collected_cents,
  COALESCE(e.due_cents, CAST(ROUND(e.amount * 100) AS INTEGER)) AS due_cents, o.payment_method, o.delivered_at, o.exception, o.delivery_fee, o.total`;
function invoiceView(r, extra = {}) {
  const due = Number(r.due_cents), paid = Number(r.paid_cents || 0);
  return {
    id: r.id, ref: `INV-${r.id}`, orderId: r.order_id, orderRef: `AKL${r.order_id}`, driverId: r.driver_id, storeId: r.store_id,
    goods: fromCents(due), deliveryFee: fromCents(r.fee_cents || toCents(r.delivery_fee)), collected: fromCents(r.collected_cents ?? (due + (r.fee_cents || toCents(r.delivery_fee)))),
    paid: fromCents(paid), remaining: fromCents(Math.max(0, due - paid)), status: r.status === 'open' && paid > 0 ? 'partial' : r.status,
    method: r.payment_method, exception: !!Number(r.exception), date: r.delivered_at || r.created_at, settledAt: r.settled_at, ...extra,
  };
}
/** One side's invoices: 'open' (to pay), 'archive' (paid / reversed). Never another party's. */
export async function listInvoices(db, { driverId = null, storeId = null, state = 'open', limit = 100, before = null } = {}) {
  const where = [];
  const p = [];
  if (driverId) { p.push(driverId); where.push(`e.driver_id = $${p.length}`); }
  if (storeId) { p.push(storeId); where.push(`e.store_id = $${p.length}`); }
  where.push(state === 'open' ? `e.status IN ('open','in_settlement')` : `e.status IN ('settled','reversed')`);
  if (before) { p.push(Number(before)); where.push(`e.id < $${p.length}`); }
  const rows = await db.query(`SELECT ${INV_COLS}, c.full_name AS store, d.full_name AS driver FROM driver_cash_entries e LEFT JOIN orders o ON o.id = e.order_id
    JOIN cooks c ON c.id = e.store_id JOIN drivers d ON d.id = e.driver_id WHERE ${where.join(' AND ')} ORDER BY e.id ${state === 'open' ? 'ASC' : 'DESC'} LIMIT ${Math.min(500, Number(limit) || 100)}`, p);
  return rows.map((r) => invoiceView(r, { store: r.store, driver: r.driver }));
}
export async function invoiceDetail(db, entryId, { driverId = null, storeId = null } = {}) {
  const r = await db.one(`SELECT ${INV_COLS}, c.full_name AS store, d.full_name AS driver FROM driver_cash_entries e LEFT JOIN orders o ON o.id = e.order_id
    JOIN cooks c ON c.id = e.store_id JOIN drivers d ON d.id = e.driver_id WHERE e.id = $1`, [entryId]);
  if (!r || (driverId && r.driver_id !== driverId) || (storeId && r.store_id !== storeId)) throw err(404, 'not_found');
  const payments = await db.query(`SELECT p.id, p.kind, p.status, p.amount_cents, p.created_at, a.cents FROM due_allocations a JOIN due_payments p ON p.id = a.payment_id WHERE a.entry_id = $1 ORDER BY a.id`, [entryId]);
  return invoiceView(r, { store: r.store, driver: r.driver, payments: payments.map((x) => ({ id: x.id, kind: x.kind, amount: fromCents(x.cents), at: x.created_at })) });
}

async function owedPair(t, driverId, storeId) {
  const r = await t.one(`SELECT COALESCE(SUM(COALESCE(due_cents, CAST(ROUND(amount * 100) AS INTEGER)) - paid_cents), 0) AS c, CAST(COUNT(*) AS INTEGER) AS n
    FROM driver_cash_entries WHERE driver_id = $1 AND store_id = $2 AND status = 'open' AND direction = 'driver_to_store'`, [driverId, storeId]);
  return { cents: Number(r.c), invoices: r.n };
}

/** Spread a confirmed payment over the pair's open invoices (the ticked ones first, then oldest first). */
async function allocate(t, paymentId, driverId, storeId, cents, target = null) {
  const rows = await t.query(`SELECT id, COALESCE(due_cents, CAST(ROUND(amount * 100) AS INTEGER)) AS due, paid_cents FROM driver_cash_entries
    WHERE driver_id = $1 AND store_id = $2 AND status = 'open' AND direction = 'driver_to_store' ORDER BY id`, [driverId, storeId]);
  const first = Array.isArray(target) ? rows.filter((r) => target.includes(r.id)) : [];
  const order = [...first, ...rows.filter((r) => !first.includes(r))];
  let left = cents;
  const closed = [];
  for (const r of order) {
    if (left <= 0) break;
    const rem = Number(r.due) - Number(r.paid_cents);
    if (rem <= 0) continue;
    const take = Math.min(rem, left);
    const full = take === rem;
    // optimistic guard: the row must still be what we read (no double allocation, even across instances)
    const u = await t.query(`UPDATE driver_cash_entries SET paid_cents = paid_cents + $1, status = $2, settled_at = $3, updated_at = $3
      WHERE id = $4 AND status = 'open' AND paid_cents = $5 RETURNING id`, [take, full ? 'settled' : 'open', iso(), r.id, Number(r.paid_cents)]);
    if (!u.length) throw err(409, 'try_again');
    await t.query('INSERT INTO due_allocations (payment_id, entry_id, cents) VALUES ($1,$2,$3)', [paymentId, r.id, take]);
    if (full) closed.push(r.id);
    left -= take;
  }
  if (left > 0) throw err(409, 'amount_over_owed');
  const rest = await owedPair(t, driverId, storeId);
  if (!rest.invoices) await t.query(`UPDATE handovers SET status = 'confirmed', decided_at = $1 WHERE driver_id = $2 AND store_id = $3 AND status = 'claimed'`, [iso(), driverId, storeId]);
  return { closed, leftCents: rest.cents };
}

async function journal(t, e) {
  await t.query(`INSERT INTO financial_ledger (kind, driver_id, store_id, amount, currency, note) VALUES ($1,$2,$3,$4,'USD',$5)`,
    [e.kind, e.driverId ?? null, e.storeId ?? null, fromCents(e.cents), e.note ?? null]);
}

/** Both sides said an amount: same → confirmed and allocated; different (or more than owed) → review by the owner. */
async function resolve(t, p) {
  if (p.driver_cents == null || p.store_cents == null) return { status: 'pending', id: p.id };
  const owed = await owedPair(t, p.driver_id, p.store_id);
  if (Number(p.driver_cents) !== Number(p.store_cents) || Number(p.driver_cents) > owed.cents) {
    await t.query(`UPDATE due_payments SET status = 'review' WHERE id = $1 AND status = 'pending'`, [p.id]);
    await journal(t, { kind: 'due_payment_review', driverId: p.driver_id, storeId: p.store_id, cents: p.driver_cents, note: `driver ${fromCents(p.driver_cents)} / store ${fromCents(p.store_cents)} / owed ${fromCents(owed.cents)}` });
    return { status: 'review', id: p.id, driver: fromCents(p.driver_cents), store: fromCents(p.store_cents), owed: fromCents(owed.cents) };
  }
  const u = await t.query(`UPDATE due_payments SET status = 'confirmed', amount_cents = $1, decided_at = $2 WHERE id = $3 AND status = 'pending' RETURNING id`, [p.driver_cents, iso(), p.id]);
  if (!u.length) throw err(409, 'invalid_state');
  const a = await allocate(t, p.id, p.driver_id, p.store_id, Number(p.driver_cents), p.target ? JSON.parse(p.target) : null);
  await journal(t, { kind: 'due_payment_confirmed', driverId: p.driver_id, storeId: p.store_id, cents: p.driver_cents, note: `P-${p.id}` });
  return { status: 'confirmed', id: p.id, amount: fromCents(p.driver_cents), closed: a.closed.length, left: fromCents(a.leftCents) };
}

/**
 * One side says an amount. side = 'driver' ("I paid the store") | 'store' ("I received it").
 * cents = null → the whole amount still owed (or, for the store, what the driver already said).
 */
export async function sayPaid(db, side, { driverId, storeId, cents = null, target = null }) {
  return db.tx(async (t) => {
    await lockAccount(t, db.kind, 'driver', driverId);   // one money change per driver at a time (PostgreSQL row lock)
    const owed = await owedPair(t, driverId, storeId);
    if (!owed.invoices) throw err(409, 'nothing_to_settle');
    const p = await t.one(`SELECT * FROM due_payments WHERE driver_id = $1 AND store_id = $2 AND kind = 'driver' AND status IN ('pending','review') ORDER BY id DESC`, [driverId, storeId]);
    if (p?.status === 'review') throw err(409, 'payment_in_review');
    const mineCol = side === 'driver' ? 'driver_cents' : 'store_cents';
    const atCol = side === 'driver' ? 'driver_at' : 'store_at';
    const other = side === 'driver' ? 'store_cents' : 'driver_cents';
    let amount = cents;
    if (amount == null) amount = p?.[other] != null ? Number(p[other]) : owed.cents;
    if (!Number.isInteger(amount) || amount <= 0) throw err(422, 'validation_failed', { fields: { amount: 'invalid' } });
    if (p && p[mineCol] != null) {   // already said by this side
      if (Number(p[mineCol]) === amount) return { status: 'pending', id: p.id, again: true, amount: fromCents(amount) };   // same tap again
      throw err(409, 'already_claimed', { amount: fromCents(p[mineCol]) });
    }
    let row;
    if (p) {
      await t.query(`UPDATE due_payments SET ${mineCol} = $1, ${atCol} = $2 WHERE id = $3 AND status = 'pending' AND ${mineCol} IS NULL`, [amount, iso(), p.id]);
      row = await t.one('SELECT * FROM due_payments WHERE id = $1', [p.id]);
    } else {
      row = await t.one(`INSERT INTO due_payments (driver_id, store_id, kind, ${mineCol}, ${atCol}, target) VALUES ($1,$2,'driver',$3,$4,$5) RETURNING *`,
        [driverId, storeId, amount, iso(), Array.isArray(target) && target.length ? JSON.stringify(target.slice(0, 200)) : null]);
    }
    await journal(t, { kind: side === 'driver' ? 'due_driver_says_paid' : 'due_store_says_received', driverId, storeId, cents: amount, note: `P-${row.id}` });
    const out = await resolve(t, row);
    return { ...out, amount: fromCents(amount), owed: fromCents(owed.cents) };
  });
}

/** The store says it did NOT receive what the driver claims: the claim is dropped, the invoices stay open, the owner sees it. */
export async function rejectClaim(db, storeId, paymentId, note = null) {
  const r = await db.query(`UPDATE due_payments SET status = 'rejected', note = $1, decided_at = $2 WHERE id = $3 AND store_id = $4 AND status = 'pending' AND driver_cents IS NOT NULL AND store_cents IS NULL
    RETURNING id, driver_id, driver_cents`, [note, iso(), paymentId, storeId]);
  if (!r.length) throw err(409, 'invalid_state');
  return { id: r[0].id, driverId: r[0].driver_id, amount: fromCents(r[0].driver_cents) };
}

/** Owner settles a payment in review: confirm an amount (allocated) or reject it. */
export async function adminResolve(db, adminId, paymentId, { decision, cents = null, note = null }) {
  return db.tx(async (t) => {
    const p = await t.one(`SELECT * FROM due_payments WHERE id = $1 AND status IN ('review','pending')`, [paymentId]);
    if (!p) throw err(409, 'invalid_state');
    await lockAccount(t, db.kind, 'driver', p.driver_id);
    if (decision === 'reject') {
      await t.query(`UPDATE due_payments SET status = 'rejected', decided_by = $1, decided_at = $2, note = $3 WHERE id = $4`, [adminId, iso(), note, p.id]);
      await t.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,$2,$3,$4)', [adminId, p.store_id, 'due_payment_reject', JSON.stringify({ id: p.id, note })]);
      return { status: 'rejected' };
    }
    const owed = await owedPair(t, p.driver_id, p.store_id);
    if (!Number.isInteger(cents) || cents <= 0 || cents > owed.cents) throw err(422, 'validation_failed', { fields: { amount: 'invalid' }, owed: fromCents(owed.cents) });
    await t.query(`UPDATE due_payments SET status = 'confirmed', amount_cents = $1, decided_by = $2, decided_at = $3, note = $4 WHERE id = $5`, [cents, adminId, iso(), note, p.id]);
    const a = await allocate(t, p.id, p.driver_id, p.store_id, cents, p.target ? JSON.parse(p.target) : null);
    await t.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,$2,$3,$4)', [adminId, p.store_id, 'due_payment_confirm', JSON.stringify({ id: p.id, amount: fromCents(cents), note })]);
    await journal(t, { kind: 'due_payment_confirmed_by_admin', driverId: p.driver_id, storeId: p.store_id, cents, note: `P-${p.id}` });
    return { status: 'confirmed', amount: fromCents(cents), left: fromCents(a.leftCents) };
  });
}

/** The owner paid a store for a driver (all or part). The driver now owes the platform that amount — and is blocked. */
export async function adminPayForDriver(db, adminId, { driverId, storeId, cents, method = 'cash', proof = null, note = null }) {
  return db.tx(async (t) => {
    await lockAccount(t, db.kind, 'driver', driverId);
    const owed = await owedPair(t, driverId, storeId);
    if (!owed.invoices) throw err(409, 'nothing_to_settle');
    if (!Number.isInteger(cents) || cents <= 0) throw err(422, 'validation_failed', { fields: { amount: 'invalid' } });
    if (cents > owed.cents) throw err(409, 'amount_over_owed', { owed: fromCents(owed.cents) });
    const p = await t.one(`INSERT INTO due_payments (driver_id, store_id, kind, amount_cents, status, decided_by, decided_at, method, proof, note)
      VALUES ($1,$2,'admin',$3,'confirmed',$4,$5,$6,$7,$8) RETURNING id`, [driverId, storeId, cents, adminId, iso(), method, proof, note]);
    const a = await allocate(t, p.id, driverId, storeId, cents);
    await t.query('INSERT INTO admin_debt_ledger (driver_id, cents, payment_id, admin_id, method, proof, note) VALUES ($1,$2,$3,$4,$5,$6,$7)', [driverId, cents, p.id, adminId, method, proof, note]);
    await t.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,$2,$3,$4)', [adminId, storeId, 'due_admin_paid_store', JSON.stringify({ paymentId: p.id, driverId, amount: fromCents(cents), method, proof })]);
    await journal(t, { kind: 'due_admin_paid_store', driverId, storeId, cents, note: `P-${p.id}` });
    const debt = await t.one('SELECT COALESCE(SUM(cents), 0) AS c FROM admin_debt_ledger WHERE driver_id = $1', [driverId]);
    return { paymentId: p.id, paid: fromCents(cents), leftForStore: fromCents(a.leftCents), driverOwesPlatform: fromCents(debt.c) };
  });
}

/** "Settled between the platform and the driver": the driver paid the owner back (all or part, never more than owed). */
export async function adminSettleDebt(db, adminId, driverId, { cents, method = 'cash', proof = null, note = null }) {
  return db.tx(async (t) => {
    await lockAccount(t, db.kind, 'driver', driverId);
    const debt = Number((await t.one('SELECT COALESCE(SUM(cents), 0) AS c FROM admin_debt_ledger WHERE driver_id = $1', [driverId])).c);
    if (debt <= 0) throw err(409, 'nothing_to_settle');
    if (!Number.isInteger(cents) || cents <= 0) throw err(422, 'validation_failed', { fields: { amount: 'invalid' } });
    if (cents > debt) throw err(409, 'amount_over_owed', { owed: fromCents(debt) });
    await t.query('INSERT INTO admin_debt_ledger (driver_id, cents, admin_id, method, proof, note) VALUES ($1,$2,$3,$4,$5,$6)', [driverId, -cents, adminId, method, proof, note]);
    await t.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,$2,$3,$4)', [adminId, null, 'due_admin_debt_settled', JSON.stringify({ driverId, amount: fromCents(cents), method, proof })]);
    await journal(t, { kind: 'due_driver_repaid_admin', driverId, cents, note });
    return { left: fromCents(debt - cents), unblocked: debt - cents === 0 };
  });
}

/** Pending / review payments of one side (to show "waiting for your confirmation"). */
export async function pendingPayments(db, { driverId = null, storeId = null, status = ['pending', 'review'] } = {}) {
  const OK = ['pending', 'review', 'confirmed', 'rejected', 'cancelled'];
  const p = [];
  let where = `p.status IN (${status.filter((x) => OK.includes(x)).map((x) => `'${x}'`).join(',') || "'pending'"})`;
  if (driverId) { p.push(driverId); where += ` AND p.driver_id = $${p.length}`; }
  if (storeId) { p.push(storeId); where += ` AND p.store_id = $${p.length}`; }
  const rows = await db.query(`SELECT p.*, c.full_name AS store, d.full_name AS driver, d.phone AS driver_phone FROM due_payments p JOIN cooks c ON c.id = p.store_id JOIN drivers d ON d.id = p.driver_id
    WHERE ${where} ORDER BY p.id DESC LIMIT 200`, p);
  return rows.map((r) => ({ id: r.id, ref: `P-${r.id}`, kind: r.kind, status: r.status, driverId: r.driver_id, storeId: r.store_id, store: r.store, driver: r.driver, driverPhone: r.driver_phone,
    driverSays: r.driver_cents == null ? null : fromCents(r.driver_cents), storeSays: r.store_cents == null ? null : fromCents(r.store_cents),
    amount: r.amount_cents == null ? null : fromCents(r.amount_cents), driverAt: r.driver_at, storeAt: r.store_at, at: r.created_at, note: r.note, method: r.method, proof: r.proof }));
}

/** A stored answer for a repeated request (double tap / retry). */
export async function idempotent(db, key, scope, fn) {
  if (!key) return fn();
  const k = `${scope}:${String(key).slice(0, 80)}`;
  const prev = await db.one('SELECT result FROM idempotency_keys WHERE key = $1', [k]);
  if (prev) return { ...JSON.parse(prev.result || '{}'), replayed: true };
  const out = await fn();
  try { await db.query('INSERT INTO idempotency_keys (key, scope, result) VALUES ($1,$2,$3)', [k, scope, JSON.stringify(out ?? {})]); } catch { /* same key raced: first one kept */ }
  return out;
}
