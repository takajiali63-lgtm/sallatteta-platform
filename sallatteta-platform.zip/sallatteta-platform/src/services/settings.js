// Site settings editable from the admin panel (stored in app_meta, shared by all instances).
// Each instance re-reads them every 30 s, so a change reaches every server within half a minute.
import { setBrand } from '../lib/i18n.js';

export const DEFAULT_SETTINGS = {
  brandName: '',        // empty = use BRAND_NAME env / default
  brandNameEn: '',
  announcement: '',     // short notice shown at the top of the home page
  adminWhatsapp: '',    // empty = use ADMIN_WHATSAPP_NUMBER env
  sections: { nearby: true, regions: true, dishes: true, nameSearch: true, cooksSlider: true },
};

export function createSettings(db, cfg, { log = console } = {}) {
  const base = { brand: { ...cfg.brand }, adminWhatsapp: cfg.adminWhatsapp };
  let current = structuredClone(DEFAULT_SETTINGS);
  let timer = null;

  function apply(s) {
    current = { ...structuredClone(DEFAULT_SETTINGS), ...s, sections: { ...DEFAULT_SETTINGS.sections, ...(s.sections || {}) } };
    cfg.brand = {
      name: current.brandName || base.brand.name,
      nameEn: current.brandNameEn || current.brandName || base.brand.nameEn,
    };
    setBrand(cfg.brand);
    cfg.adminWhatsapp = current.adminWhatsapp || base.adminWhatsapp;
  }

  async function load() {
    try {
      const row = await db.one(`SELECT value FROM app_meta WHERE key = 'site_settings'`);
      apply(row ? JSON.parse(row.value) : {});
    } catch (err) { log.warn?.(`[settings] could not load: ${err.message}`); }
    return current;
  }

  return {
    load,
    get: () => current,
    /** Public part only (never the admin number). */
    publicView: () => ({ announcement: current.announcement, sections: current.sections, brand: cfg.brand }),
    async save(patch) {
      const next = { ...current, ...patch, sections: { ...current.sections, ...(patch.sections || {}) } };
      const value = JSON.stringify(next);
      const row = await db.one(`SELECT key FROM app_meta WHERE key = 'site_settings'`);
      if (row) await db.query(`UPDATE app_meta SET value = $1 WHERE key = 'site_settings'`, [value]);
      else await db.query(`INSERT INTO app_meta (key, value) VALUES ('site_settings', $1)`, [value]);
      apply(next);
      return current;
    },
    start() { timer = setInterval(() => { load(); }, 30_000); timer.unref?.(); },
    stop() { clearInterval(timer); },
  };
}
