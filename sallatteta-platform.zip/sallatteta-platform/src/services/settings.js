// Site settings editable from the admin panel (stored in app_meta, shared by all instances).
// Each instance re-reads them every 30 s, so a change reaches every server within half a minute.
import { setBrand, setTextOverrides } from '../lib/i18n.js';

export const DEFAULT_SETTINGS = {
  brandName: '',        // empty = use BRAND_NAME env / default
  brandNameEn: '',
  announcement: '',     // short notice shown at the top of the home page
  adminWhatsapp: '',    // empty = use ADMIN_WHATSAPP_NUMBER env
  sections: {
    nearby: true, regions: true, dishes: true, nameSearch: true, cooksSlider: true,
    restaurants: true,        // restaurant slider + "find a restaurant near me"
    globalCounters: false,    // worldwide counters at the bottom of the home page (off until the admin turns it on)
  },
  // Subscription prices per KIND and plan, in USD (most countries) and EUR (euro countries). Empty = not shown.
  prices: {
    cook: { monthly: { usd: '', eur: '' }, quarterly: { usd: '', eur: '' }, semiannual: { usd: '', eur: '' }, yearly: { usd: '', eur: '' } },
    restaurant: { monthly: { usd: '', eur: '' }, quarterly: { usd: '', eur: '' }, semiannual: { usd: '', eur: '' }, yearly: { usd: '', eur: '' } },
  },
  // Free trial per kind (applied by the admin with one click, and announced on the join page when enabled).
  trial: { cook: { enabled: false, days: 14 }, restaurant: { enabled: false, days: 14 } },
  // Limits per kind.
  limits: { cookPhotos: 12, restaurantPhotos: 30, menuItems: 150 },
  // Any site text edited by the admin, per language: { ar: { 'home.title': '…' }, en: {…} }
  textOverrides: {},
};

const KIND_KEYS = ['cook', 'restaurant'];
/** Deep-merge a saved/patch object into defaults (only known keys). Old flat prices {monthly:{…}} count as cook prices. */
function mergeSettings(base, s = {}) {
  const out = structuredClone(base);
  for (const k of ['brandName', 'brandNameEn', 'announcement', 'adminWhatsapp']) if (s[k] !== undefined) out[k] = s[k];
  Object.assign(out.sections, s.sections || {});
  const prices = s.prices || {};
  const legacy = prices.monthly || prices.quarterly || prices.semiannual || prices.yearly ? { cook: prices } : prices;
  for (const kind of KIND_KEYS) {
    for (const [plan, v] of Object.entries(legacy[kind] || {})) if (out.prices[kind][plan]) Object.assign(out.prices[kind][plan], v);
    Object.assign(out.trial[kind], (s.trial || {})[kind] || {});
  }
  Object.assign(out.limits, s.limits || {});
  // text edits: per language; a null value removes an edit (back to the original text)
  for (const [lang, kv] of Object.entries(s.textOverrides || {})) {
    if (!/^[a-z]{2}$/.test(lang) || typeof kv !== 'object' || !kv) continue;
    const cur = (out.textOverrides[lang] ||= {});
    for (const [k, v] of Object.entries(kv)) { if (v === null) delete cur[k]; else if (typeof v === 'string') cur[k] = v; }
  }
  return out;
}

export function createSettings(db, cfg, { log = console } = {}) {
  const base = { brand: { ...cfg.brand }, adminWhatsapp: cfg.adminWhatsapp };
  let current = structuredClone(DEFAULT_SETTINGS);
  let timer = null;

  function apply(s) {
    current = mergeSettings(DEFAULT_SETTINGS, s);
    cfg.brand = {
      name: current.brandName || base.brand.name,
      nameEn: current.brandNameEn || current.brandName || base.brand.nameEn,
    };
    setBrand(cfg.brand);
    setTextOverrides(current.textOverrides);
    cfg.adminWhatsapp = current.adminWhatsapp || base.adminWhatsapp;
  }

  async function load() {
    try {
      const row = await db.one(`SELECT value FROM app_meta WHERE key = 'site_settings'`);
      apply(row ? JSON.parse(row.value) : {});
    } catch (err) { log.warn?.(`[settings] could not load: ${err.message}`); }
    return current;
  }

  return {
    load,
    get: () => current,
    /** Public part only (never the admin number). */
    publicView: () => ({ announcement: current.announcement, sections: current.sections, brand: cfg.brand, prices: current.prices, trial: current.trial, limits: current.limits }),
    async save(patch) {
      const next = mergeSettings(current, patch);
      const value = JSON.stringify(next);
      const row = await db.one(`SELECT key FROM app_meta WHERE key = 'site_settings'`);
      if (row) await db.query(`UPDATE app_meta SET value = $1 WHERE key = 'site_settings'`, [value]);
      else await db.query(`INSERT INTO app_meta (key, value) VALUES ('site_settings', $1)`, [value]);
      apply(next);
      return current;
    },
    start() { timer = setInterval(() => { load(); }, 30_000); timer.unref?.(); },
    stop() { clearInterval(timer); },
  };
}
