// Import shops from the map (Geoapify Places, OpenStreetMap data) into categories — admin panel "Import from the map".
// Every shop is offered, whatever its phone: mobile → WhatsApp orders · landline → call · none → directions only.
import { geoapifyGet } from './geoapify.js';
import { normalizePhone } from '../lib/whatsapp.js';
import { normalizeName } from '../../public/assets/normalize.js';
import { haversineKm } from '../lib/geo.js';

// Map types per default category (Geoapify / OpenStreetMap categories). A category's own `map` field overrides this.
export const DEFAULT_MAP_TYPES = {
  restaurant: ['catering.restaurant', 'catering.fast_food', 'catering.cafe', 'catering.food_court'],
  bakery: ['commercial.food_and_drink.bakery'],
  butcher: ['commercial.food_and_drink.butcher'],
  supermarket: ['commercial.supermarket'],
  minimarket: ['commercial.convenience'],
  produce: ['commercial.food_and_drink.fruit_and_vegetable'],
  juice: ['commercial.food_and_drink.confectionery', 'catering.ice_cream', 'commercial.food_and_drink.drinks'],
  pharmacy: ['healthcare.pharmacy', 'commercial.chemist'],
  gym: ['sport.fitness.fitness_centre', 'sport.sports_centre'],
};
export const MAP_TYPE_RE = /^[a-z_]+(\.[a-z_]+)*$/;

export const mapTypesOf = (cat) => {
  const own = String(cat?.map || '').split(',').map((x) => x.trim()).filter((x) => MAP_TYPE_RE.test(x));
  return own.length ? own : DEFAULT_MAP_TYPES[cat?.key] || [];
};

/** Is this number a mobile (WhatsApp) number? 'mobile' | 'landline' | 'unknown' (country without rules). */
export function phoneKind(raw) {
  const e164 = `+${String(raw || '').replace(/^\+/, '')}`;   // stored numbers have no '+'
  if (/^\+961/.test(e164)) return /^\+961(3\d{6}|7[0-9]\d{6}|81\d{6})$/.test(e164) ? 'mobile' : 'landline';
  if (/^\+33/.test(e164)) return /^\+33[67]\d{8}$/.test(e164) ? 'mobile' : 'landline';
  if (/^\+34/.test(e164)) return /^\+34[67]\d{8}$/.test(e164) ? 'mobile' : 'landline';
  if (/^\+971/.test(e164)) return /^\+9715\d{8}$/.test(e164) ? 'mobile' : 'landline';
  if (/^\+966/.test(e164)) return /^\+9665\d{8}$/.test(e164) ? 'mobile' : 'landline';
  if (/^\+44/.test(e164)) return /^\+447\d{9}$/.test(e164) ? 'mobile' : 'landline';
  return 'unknown';
}

export async function findPlaceAndShops({ q, radiusKm, categories, key, fetchImpl, db }) {
  const geo = await geoapifyGet('/v1/geocode/search', { text: q, limit: '1', format: 'json' }, { key, fetchImpl });
  const at = geo?.results?.[0];
  if (!at) return { place: null, groups: [] };
  const center = { name: at.formatted || q, lat: at.lat, lng: at.lon, country: String(at.country_code || '').toUpperCase() };
  const cats = categories.filter((c) => !c.deleted && mapTypesOf(c).length);
  const types = [...new Set(cats.flatMap(mapTypesOf))];
  if (!types.length) return { place: center, groups: [] };
  const r = await geoapifyGet('/v2/places', {
    categories: types.join(','), filter: `circle:${center.lng},${center.lat},${Math.round(radiusKm * 1000)}`,
    bias: `proximity:${center.lng},${center.lat}`, limit: '500',
  }, { key, fetchImpl });
  const existing = await db.query(`SELECT ext_ref, name_norm, lat, lng FROM cooks WHERE lat BETWEEN $1 AND $2 AND lng BETWEEN $3 AND $4`,
    [center.lat - 0.2, center.lat + 0.2, center.lng - 0.25, center.lng + 0.25]);
  const refs = new Set(existing.map((e) => e.ext_ref).filter(Boolean));
  const groups = new Map(cats.map((c) => [c.key, []]));
  for (const f of r?.features || []) {
    const p = f.properties || {};
    if (!p.name || p.lat == null || p.lon == null) continue;
    const kind = cats.find((c) => mapTypesOf(c).some((t) => (p.categories || []).some((pc) => pc === t || pc.startsWith(`${t}.`))))?.key;
    if (!kind) continue;
    const ref = `geoapify:${p.place_id}`;
    const country = String(p.country_code || center.country || '').toUpperCase();
    const raw = p.contact?.phone || p.datasource?.raw?.phone || p.datasource?.raw?.['contact:phone'] || '';
    const e164 = raw ? normalizePhone(String(raw).split(/[;,/]/)[0], country) : null;
    const pk = e164 ? phoneKind(e164) : null;
    const nn = normalizeName(p.name);
    const exists = refs.has(ref) || existing.some((e) => e.name_norm === nn && haversineKm(e.lat, e.lng, p.lat, p.lon) < 0.2);
    groups.get(kind).push({
      ref, name: String(p.name).slice(0, 80), kind, lat: p.lat, lng: p.lon, country,
      address: String(p.address_line2 || p.street || '').slice(0, 120),
      whatsapp: pk === 'mobile' || pk === 'unknown' ? e164 : null, callPhone: pk === 'landline' ? e164 : null, phoneKind: pk, exists,
      distanceM: Math.round(haversineKm(center.lat, center.lng, p.lat, p.lon) * 1000),
    });
  }
  return { place: center, groups: [...groups.entries()].map(([key, items]) => ({ key, items: items.sort((a, b) => a.distanceM - b.distanceM) })) };
}
