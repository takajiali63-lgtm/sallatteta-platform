// In-app subscriptions bought through Google Play / the App Store: product mapping (owner-editable), the opaque account ids,
// the Google Play Developer API client, and ONE function that turns a verified purchase into access (applyEntitlement).
// Rule: access changes only after the server itself checked with Google / Apple — never because the phone says "paid".
import { randomUUID } from 'node:crypto';
import { HttpError } from '../lib/http.js';
import { isCraft } from './categories.js';
import { latestSubscription, activateSubscription, updateSubscriptionFields, logAdminAction } from './cooks.js';
import { creditReferral } from './referrals.js';
import { parseServiceAccount, serviceAccountJwt } from './billingCrypto.js';

export const STATES = ['active', 'grace', 'on_hold', 'paused', 'cancelled', 'expired', 'refunded', 'revoked', 'pending'];
const GRANTING = new Set(['active', 'grace', 'cancelled']);   // cancelled = auto-renew off, still paid until the end
const CUTTING = new Set(['refunded', 'revoked']);
export const GROUPS = { store: ['shops', 'online', 'crafts'], driver: ['drivers'] };
const MONTHS_PLAN = { 1: 'monthly', 3: 'quarterly', 6: 'semiannual', 12: 'yearly' };   // same names as the owner's renewals
export const PRODUCT_RE = /^[a-z0-9][a-z0-9._]{1,99}$/;
const META_KEY = 'billing_products';

const iso = (d) => (d == null || d === '' ? null : new Date(d instanceof Date ? d : (/^\d+$/.test(String(d)) ? Number(d) : d)).toISOString());
const maxIso = (...v) => v.filter(Boolean).sort().pop() || null;

/* ---------------- product mapping (app_meta, edited by the owner) ---------------- */

const p = (subject, group, tier, months = 1) => ({ subject, group, tier, months });
export const DEFAULT_PRODUCTS = {
  'aklatak.shop.basic.monthly': p('store', 'shops', 'basic'),
  'aklatak.shop.ai.monthly': p('store', 'shops', 'ai'),
  'aklatak.online.basic.monthly': p('store', 'online', 'basic'),
  'aklatak.online.ai.monthly': p('store', 'online', 'ai'),
  'aklatak.crafts.basic.monthly': p('store', 'crafts', 'basic'),
  'aklatak.crafts.ai.monthly': p('store', 'crafts', 'ai'),
  'aklatak.driver.basic.monthly': p('driver', 'drivers', 'basic'),
  'aklatak.driver.ai.monthly': p('driver', 'drivers', 'ai'),
};

/** Clean a mapping sent by the admin panel. Returns null when anything is wrong (nothing half-saved). */
export function cleanProducts(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  const entries = Object.entries(input);
  if (entries.length > 60) return null;
  const out = {};
  for (const [id, m] of entries) {
    if (!PRODUCT_RE.test(id) || !m || typeof m !== 'object') return null;
    const subject = m.subject;
    if (!GROUPS[subject] || !GROUPS[subject].includes(m.group)) return null;
    if (!['basic', 'ai'].includes(m.tier) || ![1, 3, 6, 12].includes(Number(m.months))) return null;
    out[id] = p(subject, m.group, m.tier, Number(m.months));
  }
  return out;
}

export async function getProducts(db) {
  const row = await db.one('SELECT value FROM app_meta WHERE key = $1', [META_KEY]);
  if (!row) return { ...DEFAULT_PRODUCTS };
  try { return cleanProducts(JSON.parse(row.value)) || { ...DEFAULT_PRODUCTS }; } catch { return { ...DEFAULT_PRODUCTS }; }
}
export async function saveProducts(db, products) {
  await db.query('INSERT INTO app_meta (key, value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value', [META_KEY, JSON.stringify(products)]);
}

/* ---------------- who is paying ---------------- */

/** Stores pay on the main account (branches follow it, like the owner's renewals). */
export async function payerOf(db, who) {
  if (who.type !== 'store') return { type: 'driver', id: who.id };
  const c = await db.one('SELECT id, parent_id FROM cooks WHERE id = $1', [who.id]);
  return { type: 'store', id: c?.parent_id || who.id };
}
export async function groupOfOwner(db, owner) {
  if (owner.type === 'driver') return 'drivers';
  const c = await db.one('SELECT kind FROM cooks WHERE id = $1', [owner.id]);
  if (c?.kind === 'online_store') return 'online';
  return isCraft(c?.kind) ? 'crafts' : 'shops';
}
/** A product can only be bought by the kind of account it was made for (a shop can't buy the cheaper crafts plan). */
export async function assertProductFor(db, owner, map) {
  if (!map) throw new HttpError(400, 'unknown_product');
  if (map.subject !== owner.type || map.group !== await groupOfOwner(db, owner)) throw new HttpError(403, 'product_not_for_account');
}

/** The stable opaque id handed to the app before a purchase (no personal data, a UUID so Apple accepts it too). */
export async function accountIdFor(db, owner) {
  const row = await db.one('SELECT account_id FROM billing_accounts WHERE owner_type = $1 AND owner_id = $2', [owner.type, owner.id]);
  if (row) return row.account_id;
  await db.query('INSERT INTO billing_accounts (account_id, owner_type, owner_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [randomUUID(), owner.type, owner.id]);
  return (await db.one('SELECT account_id FROM billing_accounts WHERE owner_type = $1 AND owner_id = $2', [owner.type, owner.id])).account_id;
}
export async function ownerOfAccountId(db, accountId) {
  if (!accountId) return null;
  const r = await db.one('SELECT owner_type, owner_id FROM billing_accounts WHERE account_id = $1', [String(accountId).toLowerCase()]);
  return r ? { type: r.owner_type, id: r.owner_id } : null;
}

/* ---------------- configuration (env vars; tests inject theirs) ---------------- */

export function billingEnv(cfg) {
  const e = cfg.billing?.env || process.env;
  return {
    package: e.GOOGLE_PLAY_PACKAGE || '',
    serviceAccount: parseServiceAccount(e.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON || ''),
    serviceAccountSet: !!e.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON,
    rtdnToken: e.GOOGLE_RTDN_TOKEN || '',
    rtdnAudience: e.GOOGLE_RTDN_AUDIENCE || '',
    appleBundle: e.APPLE_BUNDLE_ID || '',
    appleEnv: (e.APPLE_ENVIRONMENT || 'Production') === 'Sandbox' ? 'Sandbox' : 'Production',
    appleEnvSet: !!e.APPLE_ENVIRONMENT,
  };
}

/* ---------------- Google Play Developer API ---------------- */

const API = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications';
const SCOPE = 'https://www.googleapis.com/auth/androidpublisher';

export function createGoogleClient({ fetchImpl }) {
  const tokens = new Map();   // client_email → { token, until }  (an access token lives 1 hour; reused until 1 minute before)
  async function accessToken(sa) {
    const c = tokens.get(sa.client_email);
    if (c && c.until > Date.now()) return c.token;
    const r = await fetchImpl(sa.token_uri || 'https://oauth2.googleapis.com/token', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: serviceAccountJwt(sa, { scope: SCOPE }) }).toString(),
    });
    if (!r.ok) throw new HttpError(502, 'google_auth_failed');
    const j = await r.json();
    tokens.set(sa.client_email, { token: j.access_token, until: Date.now() + (Number(j.expires_in || 3600) - 60) * 1000 });
    return j.access_token;
  }
  async function call(env, method, url) {
    const token = await accessToken(env.serviceAccount);
    const r = await fetchImpl(url, { method, headers: { Authorization: `Bearer ${token}`, ...(method === 'POST' ? { 'Content-Type': 'application/json' } : {}) }, ...(method === 'POST' ? { body: '{}' } : {}) });
    if (r.status === 401) tokens.delete(env.serviceAccount.client_email);
    return r;
  }
  return {
    /** purchases.subscriptionsv2.get — the truth about a purchase token. */
    async getSubscription(env, purchaseToken) {
      const r = await call(env, 'GET', `${API}/${encodeURIComponent(env.package)}/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`);
      if (r.status === 400 || r.status === 404 || r.status === 410) throw new HttpError(400, 'invalid_purchase_token');
      if (!r.ok) throw new HttpError(502, 'google_api_error', { googleStatus: r.status });
      return r.json();
    },
    /** purchases.subscriptions.acknowledge — Google refunds purchases not acknowledged within 3 days. */
    async acknowledge(env, productId, purchaseToken) {
      const r = await call(env, 'POST', `${API}/${encodeURIComponent(env.package)}/purchases/subscriptions/${encodeURIComponent(productId)}/tokens/${encodeURIComponent(purchaseToken)}:acknowledge`);
      return r.ok;
    },
  };
}

export const GOOGLE_STATE = {
  SUBSCRIPTION_STATE_ACTIVE: 'active',
  SUBSCRIPTION_STATE_IN_GRACE_PERIOD: 'grace',
  SUBSCRIPTION_STATE_ON_HOLD: 'on_hold',
  SUBSCRIPTION_STATE_PAUSED: 'paused',
  SUBSCRIPTION_STATE_CANCELED: 'cancelled',
  SUBSCRIPTION_STATE_EXPIRED: 'expired',
  SUBSCRIPTION_STATE_PENDING: 'pending',
  SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED: 'expired',
};

/** Only what we need from Google's answer (no payment details kept). */
export function trimGoogle(sub) {
  return {
    subscriptionState: sub.subscriptionState, latestOrderId: sub.latestOrderId, linkedPurchaseToken: sub.linkedPurchaseToken || undefined,
    acknowledgementState: sub.acknowledgementState, testPurchase: sub.testPurchase ? true : undefined, regionCode: sub.regionCode,
    lineItems: (sub.lineItems || []).map((l) => ({ productId: l.productId, expiryTime: l.expiryTime, autoRenew: l.autoRenewingPlan?.autoRenewEnabled })),
  };
}

/* ---------------- entitlements ---------------- */

export async function findEntitlement(q, platform, { token, otx }) {
  if (token) return q.one('SELECT * FROM billing_entitlements WHERE platform = $1 AND purchase_token = $2', [platform, token]);
  return q.one('SELECT * FROM billing_entitlements WHERE platform = $1 AND original_transaction_id = $2', [platform, otx]);
}

async function saveEntitlement(q, e) {
  const now = new Date().toISOString();
  const cols = [e.product_id, e.owner_type || null, e.owner_id || null, e.state, e.expires_at || null, e.auto_renew ? 1 : 0, e.acknowledged ? 1 : 0,
    e.linked_token || null, e.last_order_id || null, e.environment || null, e.granted_until || null, e.base_sub_until || null, e.base_ai_until || null,
    e.reason || null, now, e.raw == null ? null : (typeof e.raw === 'string' ? e.raw : JSON.stringify(e.raw)).slice(0, 4000)];
  if (e.id) {
    await q.query(`UPDATE billing_entitlements SET product_id=$1, owner_type=$2, owner_id=$3, state=$4, expires_at=$5, auto_renew=$6, acknowledged=$7,
      linked_token=$8, last_order_id=$9, environment=$10, granted_until=$11, base_sub_until=$12, base_ai_until=$13, reason=$14, last_event_at=$15, raw=$16,
      updated_at=$18 WHERE id=$17`, [...cols, e.id, now]);   // own parameter: PostgreSQL types $15 as TEXT (last_event_at)
    return e;
  }
  const row = await q.one(`INSERT INTO billing_entitlements (product_id, owner_type, owner_id, state, expires_at, auto_renew, acknowledged, linked_token,
      last_order_id, environment, granted_until, base_sub_until, base_ai_until, reason, last_event_at, raw, platform, purchase_token, original_transaction_id)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19) RETURNING id`,
  [...cols, e.platform, e.purchase_token || null, e.original_transaction_id || null]);
  e.id = row.id;
  return e;
}

/** The account's current paid ends: { sub, ai } (sub = store subscription / driver customer-requests plan). */
async function ownerEnds(q, owner) {
  if (owner.type === 'store') {
    const s = await latestSubscription(q, owner.id);
    const c = await q.one('SELECT ai_until FROM cooks WHERE id = $1', [owner.id]);
    return { sub: s && s.status === 'active' ? iso(s.expiry_date) : null, ai: c?.ai_until ? iso(c.ai_until) : null, row: s };
  }
  const d = await q.one('SELECT jobs_until, ai_until FROM drivers WHERE id = $1', [owner.id]);
  return { sub: d?.jobs_until ? iso(d.jobs_until) : null, ai: d?.ai_until ? iso(d.ai_until) : null };
}

/** Latest end still given by the account's OTHER store-app purchases (a refund of one never removes what another paid). */
async function othersUntil(q, ent, products, now, aiOnly) {
  const rows = await q.query(`SELECT product_id, expires_at, state, reason FROM billing_entitlements WHERE owner_type = $1 AND owner_id = $2 AND id <> $3`,
    [ent.owner_type, ent.owner_id, ent.id || 0]);
  return maxIso(...rows.filter((r) => GRANTING.has(r.state) && r.reason !== 'replaced' && r.expires_at > now && (!aiOnly || products[r.product_id]?.tier === 'ai')).map((r) => r.expires_at));
}

async function history(q, owner, action, details) {
  // stores: the same audit table as the owner's actions (admin_id NULL = done by the store app purchase); drivers: billing_events only
  if (owner.type === 'store') await logAdminAction(q, null, owner.id, action, details);
}

/**
 * Turn an entitlement's verified state into access, inside the caller's transaction. Idempotent: running it twice with the
 * same state changes nothing (ends only move forward with max(), refunds only move back with min()).
 * Returns the list of changes (for the event log).
 */
export async function applyEntitlement(q, ent, products, { now = new Date() } = {}) {
  const map = products[ent.product_id];
  const changes = [];
  // a product only ever changes the kind of account it was made for (a driver product never extends a store)
  if (!map || !ent.owner_type || !ent.owner_id || map.subject !== ent.owner_type) return changes;
  const owner = { type: ent.owner_type, id: Number(ent.owner_id) };
  const nowIso = now.toISOString();
  const cut = CUTTING.has(ent.state) || ent.reason === 'replaced';
  const target = ent.expires_at ? iso(ent.expires_at) : null;

  if (!cut && GRANTING.has(ent.state) && target && target > nowIso) {
    const ends = await ownerEnds(q, owner);
    if (!ent.granted_until) {   // first time this purchase gives access: remember what the account already had paid for
      ent.base_sub_until = ends.sub && ends.sub > nowIso ? ends.sub : null;
      ent.base_ai_until = ends.ai && ends.ai > nowIso ? ends.ai : null;
    }
    if (owner.type === 'store') {
      const s = ends.row;
      if (s?.status === 'suspended') changes.push({ skip: 'subscription_suspended_by_owner' });
      else if (!(ends.sub && ends.sub >= target)) {
        const running = ends.sub && ends.sub > nowIso;
        // the same function the owner's approval uses in the end (activateSubscription), with the end date Google/Apple gave
        await activateSubscription(q, owner.id, { plan: MONTHS_PLAN[map.months] || 'monthly', startDate: running ? s.start_date : now, expiryDate: new Date(target), paymentStatus: 'paid' });
        changes.push({ field: 'subscription', from: ends.sub, to: target });
      }
      if (map.tier === 'ai' && !(ends.ai && ends.ai >= target)) {
        await q.query('UPDATE cooks SET ai_until = $1 WHERE (id = $2 OR parent_id = $2) AND (ai_until IS NULL OR ai_until < $1)', [target, owner.id]);
        changes.push({ field: 'ai_until', from: ends.ai, to: target });
      }
    } else {
      if (!(ends.sub && ends.sub >= target)) {
        await q.query('UPDATE drivers SET jobs_until = $1 WHERE id = $2', [target, owner.id]);
        changes.push({ field: 'jobs_until', from: ends.sub, to: target });
      }
      if (map.tier === 'ai' && !(ends.ai && ends.ai >= target)) {
        await q.query('UPDATE drivers SET ai_until = $1 WHERE id = $2', [target, owner.id]);
        changes.push({ field: 'ai_until', from: ends.ai, to: target });
      }
    }
    ent.granted_until = maxIso(ent.granted_until, target);
  } else if (cut && ent.granted_until) {
    // refund / revoke / replaced by an upgrade: take back what THIS purchase gave — never below now, never below what the
    // account had paid by other means, never below another store-app purchase that is still running
    const ends = await ownerEnds(q, owner);
    const floorSub = maxIso(nowIso, ent.base_sub_until, await othersUntil(q, ent, products, nowIso, false));
    const floorAi = maxIso(nowIso, ent.base_ai_until, await othersUntil(q, ent, products, nowIso, true));
    if (ends.sub && ends.sub > floorSub) {
      if (owner.type === 'store') await updateSubscriptionFields(q, owner.id, { expiryDate: new Date(floorSub), status: floorSub <= nowIso ? 'expired' : undefined });
      else await q.query('UPDATE drivers SET jobs_until = $1 WHERE id = $2', [floorSub, owner.id]);
      changes.push({ field: owner.type === 'store' ? 'subscription' : 'jobs_until', from: ends.sub, to: floorSub, reason: ent.reason || ent.state });
    }
    if (map.tier === 'ai' && ends.ai && ends.ai > floorAi) {
      if (owner.type === 'store') await q.query('UPDATE cooks SET ai_until = $1 WHERE (id = $2 OR parent_id = $2) AND ai_until > $1', [floorAi, owner.id]);
      else await q.query('UPDATE drivers SET ai_until = $1 WHERE id = $2', [floorAi, owner.id]);
      changes.push({ field: 'ai_until', from: ends.ai, to: floorAi, reason: ent.reason || ent.state });
    }
    ent.granted_until = null;
  }
  // expired / on hold / paused / pending: nothing more is given (what was already paid simply runs out)

  if (owner.type === 'store' && changes.some((c) => c.field)) {
    // the subscription's tier follows the AI entitlement
    const c = await q.one('SELECT ai_until FROM cooks WHERE id = $1', [owner.id]);
    const s = await latestSubscription(q, owner.id);
    if (s) await q.query('UPDATE subscriptions SET tier = $1 WHERE id = $2', [c?.ai_until && iso(c.ai_until) > nowIso ? 'ai' : 'basic', s.id]);
  }
  if (changes.some((c) => c.field)) await history(q, owner, cut ? 'billing_revoke' : 'billing_grant', { platform: ent.platform, productId: ent.product_id, state: ent.state, changes });
  return changes;
}

/**
 * Record one event and apply the new state, all in ONE transaction. The event id makes it once-only:
 * a second delivery of the same notification returns { duplicate: true } and changes nothing.
 * `update(ent)` mutates the entitlement (state, ends…) from what Google/Apple said; `after(q, ent)` runs extra steps
 * in the same transaction (e.g. ending the purchase an upgrade replaced).
 */
export async function processEvent(db, { platform, eventId, type, key, initial, update, after, details }) {
  return db.tx(async (q) => {
    const ev = await q.one(`INSERT INTO billing_events (platform, event_id, type, details) VALUES ($1,$2,$3,$4)
      ON CONFLICT (platform, event_id) DO NOTHING RETURNING id`, [platform, eventId, type, details ? JSON.stringify(details).slice(0, 2000) : null]);
    if (!ev) return { duplicate: true };
    const products = await getProducts(q);
    let ent = await findEntitlement(q, platform, key);
    const before = ent?.state || null;
    if (!ent) ent = { platform, purchase_token: key.token || null, original_transaction_id: key.otx || null, ...initial };
    await update(ent, q);
    await saveEntitlement(q, ent);   // saved first so the refund floor never counts this purchase itself
    const changes = await applyEntitlement(q, ent, products);
    await saveEntitlement(q, ent);
    let extra = [];
    if (after) extra = (await after(q, ent, products)) || [];
    // one referral commission per paid period of a store (like each renewal the owner approves)
    if (ent.owner_type === 'store' && ent._newPeriod && changes.some((c) => c.field === 'subscription')) await creditReferral(q, ent.owner_id, 'renew').catch(() => null);
    await q.query('UPDATE billing_events SET entitlement_id = $1, owner_type = $2, owner_id = $3, state_before = $4, state_after = $5, details = $6 WHERE id = $7',
      [ent.id, ent.owner_type || null, ent.owner_id || null, before, ent.state, JSON.stringify({ ...(details || {}), changes: [...changes, ...extra] }).slice(0, 4000), ev.id]);
    return { duplicate: false, entitlement: ent, changes: [...changes, ...extra] };
  });
}

/** Ending a purchase that an upgrade/downgrade replaced (Google linkedPurchaseToken), in the same transaction. */
export async function endReplaced(q, platform, oldToken, newEnt, products) {
  const old = await findEntitlement(q, platform, { token: oldToken });
  if (!old || old.reason === 'replaced') return [];
  if (old.owner_type && (old.owner_type !== newEnt.owner_type || Number(old.owner_id) !== Number(newEnt.owner_id))) return [];   // never across accounts
  old.reason = 'replaced';
  if (GRANTING.has(old.state)) old.state = 'expired';
  const changes = await applyEntitlement(q, old, products);
  await saveEntitlement(q, old);
  return changes.map((c) => ({ ...c, replacedEntitlement: old.id }));
}

export const publicEntitlement = (e, products) => ({
  id: e.id, platform: e.platform, productId: e.product_id, tier: products[e.product_id]?.tier || null, months: products[e.product_id]?.months || null,
  state: e.state, expiresAt: e.expires_at, autoRenew: !!Number(e.auto_renew), ...(e.platform === 'google' ? { purchaseToken: e.purchase_token } : {}),
});
