// v8.4 catalog rules shared by the routes: product options, availability windows, promotions and the price of a cart.
// Every amount here is computed from the database in integer cents — never from what the phone sends.
import { HttpError } from '../lib/http.js';
import { isOpenNow } from '../lib/hours.js';
import { getCountry } from '../lib/countries.js';

export const toCents = (n) => Math.round(Number(n || 0) * 100);
export const fromCents = (c) => Math.round(Number(c || 0)) / 100;
const HM = /^([01]\d|2[0-3]):[0-5]\d$/;
export const isHM = (s) => HM.test(String(s || ''));
export const tzOf = (country) => getCountry(country || 'LB')?.timezone || 'Asia/Beirut';

/** Is the product inside its daily "available from–to" window (store's local time)? No window = always. */
export function inWindow(from, to, tz, now = new Date()) {
  if (!isHM(from) || !isHM(to) || from === to) return true;
  return isOpenNow({ open: from, close: to, closed: [] }, tz, now) !== false;
}
/** Available for ordering right now: switched on by the store AND inside its time window. */
export const itemAvailable = (mi, tz, now = new Date()) => Number(mi.is_available) === 1 && inWindow(mi.avail_from, mi.avail_to, tz, now);

/** Option groups (with their options) of these products: Map itemId → [{ id, name, min, max, options: [...] }]. */
export async function loadOptions(q, itemIds) {
  const out = new Map();
  const ids = [...new Set(itemIds.map(Number).filter((x) => Number.isInteger(x) && x > 0))];
  if (!ids.length) return out;
  const ph = ids.map((_, i) => `$${i + 1}`).join(',');
  const groups = await q.query(`SELECT id, item_id, name, min_select, max_select FROM item_option_groups WHERE item_id IN (${ph}) ORDER BY sort_order, id`, ids);
  if (!groups.length) return out;
  const gph = groups.map((_, i) => `$${i + 1}`).join(',');
  const opts = await q.query(`SELECT id, group_id, name, price_cents, is_available FROM item_options WHERE group_id IN (${gph}) ORDER BY sort_order, id`, groups.map((g) => g.id));
  for (const g of groups) {
    const list = out.get(g.item_id) || [];
    list.push({ id: g.id, name: g.name, min: Number(g.min_select), max: Number(g.max_select),
      options: opts.filter((o) => o.group_id === g.id).map((o) => ({ id: o.id, name: o.name, priceCents: Number(o.price_cents), available: Number(o.is_available) === 1 })) });
    out.set(g.item_id, list);
  }
  return out;
}

/** The store's offers running now (between their dates, switched on). */
export async function livePromos(q, cookId, nowIso = new Date().toISOString()) {
  return q.query(`SELECT id, item_id, section, kind, value, badge, starts_at, ends_at FROM promotions
    WHERE cook_id = $1 AND active = 1 AND starts_at <= $2 AND ends_at > $2 ORDER BY id`, [cookId, nowIso]);
}
export function discountOf(p, unitCents) {
  if (!p || unitCents <= 0) return 0;
  const d = p.kind === 'percent' ? Math.round((unitCents * Number(p.value)) / 100) : Number(p.value);
  return Math.max(0, Math.min(unitCents, d));
}
/** The best offer for one product (its own offer or its section's), for this unit price. */
export function promoFor(promos, item, unitCents) {
  let best = null, bestD = 0;
  for (const p of promos) {
    if (!(p.item_id ? Number(p.item_id) === Number(item.id) : p.section && p.section === item.section)) continue;
    const d = discountOf(p, unitCents);
    if (d > bestD) { best = p; bestD = d; }
  }
  return best ? { promo: best, cents: bestD } : null;
}
export const promoLabel = (p) => (p.badge ? String(p.badge) : p.kind === 'percent' ? `-${p.value}%` : `-${fromCents(p.value)}`);

/** The menu as customers see it: every product (unavailable ones flagged, not hidden), options and offer price. */
// v8.1: a product that ran out (auto_off) leaves the customer's page by itself; switched-off ones stay greyed as before
const VISIBLE = 'cook_id = $1 AND COALESCE(auto_off, 0) = 0';
const MENU_COLS = `id, name, description, price, currency, section, rx, is_available, avail_from, avail_to, sort_order, CASE WHEN photo IS NULL AND photo_url IS NULL THEN 0 ELSE 1 END AS has_photo`;
/** Above this many products the store page loads by parts (first products of each section, «more», server search). */
export const BIG_MENU = 300;

async function shapeMenu(q, cookId, rows, { country = 'LB', now = new Date() } = {}) {
  const tz = tzOf(country);
  const opts = await loadOptions(q, rows.map((r) => r.id));
  const promos = await livePromos(q, cookId, now.toISOString());
  return rows.map((x) => {
    const base = x.price == null ? null : toCents(x.price);
    const pr = base != null ? promoFor(promos, x, base) : null;
    return {
      id: x.id, name: x.name, description: x.description, price: x.price, currency: x.currency, section: x.section || null, rx: !!Number(x.rx),
      photo: Number(x.has_photo) ? `/api/menu-photo/${x.id}` : null,
      available: itemAvailable(x, tz, now), availFrom: x.avail_from || null, availTo: x.avail_to || null,
      options: opts.get(x.id) || [],
      promo: pr ? { id: pr.promo.id, label: promoLabel(pr.promo), kind: pr.promo.kind, value: pr.promo.kind === 'percent' ? Number(pr.promo.value) : fromCents(pr.promo.value), price: fromCents(base - pr.cents), endsAt: pr.promo.ends_at } : null,
    };
  });
}

/** Every product the customer may see (small stores: the whole menu at once, as before). */
export async function menuView(q, cookId, opt = {}) {
  const rows = await q.query(`SELECT ${MENU_COLS} FROM menu_items WHERE ${VISIBLE} ORDER BY sort_order, id`, [cookId]);
  return shapeMenu(q, cookId, rows, opt);
}

/** How many products the customer may see, and how many per section (sections of big stores show their real size). */
export async function menuCounts(q, cookId) {
  const rows = await q.query(`SELECT section, CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE ${VISIBLE} GROUP BY section`, [cookId]);
  return { total: rows.reduce((a, r) => a + Number(r.n), 0), sections: rows.map((r) => ({ name: r.section || null, n: Number(r.n) })) };
}

/** Big store: the first `per` products of every section (one query). */
export async function menuFirsts(q, cookId, per = 12, opt = {}) {
  const rows = await q.query(`SELECT x.* FROM (SELECT ${MENU_COLS}, ROW_NUMBER() OVER (PARTITION BY COALESCE(section, '') ORDER BY sort_order, id) AS rn
    FROM menu_items WHERE ${VISIBLE}) x WHERE rn <= ${Number(per) | 0} ORDER BY sort_order, id`, [cookId]);
  return shapeMenu(q, cookId, rows, opt);
}

/** A part of a big menu: one section (null = «other»), or a search by name / description / barcode. */
export async function menuSlice(q, cookId, { section, search, offset = 0, limit = 24, ...opt } = {}) {
  const params = [cookId];
  let where = VISIBLE;
  if (section !== undefined) { if (section) { params.push(section); where += ` AND section = $${params.length}`; } else where += ' AND section IS NULL'; }
  const s = String(search || '').trim().toLowerCase().slice(0, 60);
  if (s) {
    params.push(`%${s.replace(/[\\%_]/g, (c) => '\\' + c)}%`, s);
    where += ` AND (LOWER(name) LIKE $${params.length - 1} ESCAPE '\\' OR LOWER(COALESCE(description, '')) LIKE $${params.length - 1} ESCAPE '\\' OR barcode = $${params.length})`;
  }
  const lim = Math.min(Math.max(Number(limit) | 0, 1), 60), off = Math.max(Number(offset) | 0, 0);
  const rows = await q.query(`SELECT ${MENU_COLS} FROM menu_items WHERE ${where} ORDER BY sort_order, id LIMIT ${lim + 1} OFFSET ${off}`, params);
  return { items: await shapeMenu(q, cookId, rows.slice(0, lim), opt), hasMore: rows.length > lim };
}

/**
 * Price a cart from the database. items = [{ id, qty, options: [optionId…] }].
 * Errors the cart can act on: 409 item_unavailable { itemId } (removed / switched off / outside its hours / option off),
 * 422 option_required / too_many_options / option_invalid { itemId, groupId }.
 */
export async function priceLines(q, storeId, items, { country = 'LB', now = new Date() } = {}) {
  const tz = tzOf(country);
  const ids = items.map((it) => Number(it?.id));
  // only the products in the cart (a supermarket may have thousands)
  const want = [...new Set(ids.filter((n) => Number.isInteger(n) && n > 0))].slice(0, 200);
  const menu = new Map(want.length ? (await q.query(`SELECT id, name, price, currency, rx, section, is_available, avail_from, avail_to, stock FROM menu_items WHERE cook_id = $1 AND id IN (${want.map((_, i) => `$${i + 2}`).join(',')})`, [storeId, ...want])).map((r) => [Number(r.id), r]) : []);
  const qtyOf = new Map();
  for (const it of items) { const n = Number(it?.id); qtyOf.set(n, (qtyOf.get(n) || 0) + (Number(it?.qty) || 0)); }
  const opts = await loadOptions(q, ids.filter((id) => menu.has(id)));
  const promos = await livePromos(q, storeId, now.toISOString());
  const lines = [];
  for (const it of items) {
    const id = Number(it?.id), qty = Number(it?.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 50) throw new HttpError(422, 'validation_failed', { fields: { items: 'invalid' } });
    const mi = menu.get(id);
    if (!mi || mi.price == null || !itemAvailable(mi, tz, now)) throw new HttpError(409, 'item_unavailable', { itemId: Number.isInteger(id) ? id : null, name: mi?.name || null });
    if (mi.stock != null && Number(mi.stock) < qtyOf.get(id)) throw new HttpError(409, 'item_unavailable', { itemId: id, name: mi.name, left: Math.max(0, Number(mi.stock)) });
    const chosen = Array.isArray(it.options) ? it.options.map(Number) : [];
    if (chosen.length > 60 || new Set(chosen).size !== chosen.length) throw new HttpError(422, 'option_invalid', { itemId: id });
    const groups = opts.get(id) || [];
    const all = new Map(groups.flatMap((g) => g.options.map((o) => [o.id, { ...o, group: g }])));
    for (const oid of chosen) if (!all.has(oid)) throw new HttpError(422, 'option_invalid', { itemId: id });
    const snap = [];
    for (const g of groups) {
      const picked = chosen.filter((oid) => all.get(oid).group.id === g.id);
      if (picked.length < g.min) throw new HttpError(422, 'option_required', { itemId: id, groupId: g.id, group: g.name });
      if (picked.length > g.max) throw new HttpError(422, 'too_many_options', { itemId: id, groupId: g.id, group: g.name, max: g.max });
      for (const oid of picked) {
        const o = all.get(oid);
        if (!o.available) throw new HttpError(409, 'item_unavailable', { itemId: id, optionId: oid, name: `${mi.name} — ${o.name}` });
        snap.push({ optionId: o.id, group: g.name, name: o.name, priceCents: o.priceCents });
      }
    }
    const unitCents = toCents(mi.price) + snap.reduce((a, o) => a + o.priceCents, 0);
    const pr = promoFor(promos, mi, unitCents);
    lines.push({ id, name: mi.name, qty, currency: mi.currency, rx: !!Number(mi.rx), unitCents, discountCents: pr?.cents || 0, finalCents: unitCents - (pr?.cents || 0),
      promoId: pr?.promo.id || null, promoLabel: pr ? promoLabel(pr.promo) : null, options: snap });
  }
  return { lines, totalCents: lines.reduce((a, l) => a + l.finalCents * l.qty, 0) };
}

/** Save the priced lines of a new order (inside the order's transaction): one row per line + its chosen options. */
export async function insertLines(t, orderId, lines) {
  for (const l of lines) {
    const row = await t.one(`INSERT INTO order_items (order_id, menu_item_id, name, price, qty, unit_cents, discount_cents, promo_id, promo_label)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`, [orderId, l.id, l.name, fromCents(l.finalCents), l.qty, l.unitCents, l.discountCents, l.promoId, l.promoLabel]);
    for (const o of l.options) await t.query('INSERT INTO order_item_options (order_item_id, option_id, group_name, name, price_cents) VALUES ($1,$2,$3,$4,$5)', [row.id, o.optionId, o.group, o.name, o.priceCents]);
  }
}

/**
 * v8.1 stock: take the quantities of a new order (inside its transaction). A product with a quantity goes down by what was
 * ordered; one that reaches 0 is hidden by itself (auto_off) until the store adds stock again. Two customers buying the
 * last piece at the same moment: the second gets 409 item_unavailable (the UPDATE is conditional, nothing goes negative).
 * Products without a quantity (NULL) are not counted, as before.
 */
export async function takeStock(t, orderId, lines) {
  const need = new Map();
  for (const l of lines) need.set(l.id, (need.get(l.id) || 0) + l.qty);
  let took = false;
  for (const [id, qty] of need) {
    const row = await t.one('SELECT stock, name FROM menu_items WHERE id = $1', [id]);
    if (!row || row.stock == null) continue;
    const r = await t.one('UPDATE menu_items SET stock = stock - $1 WHERE id = $2 AND stock IS NOT NULL AND stock >= $1 RETURNING stock', [qty, id]);
    if (!r) throw new HttpError(409, 'item_unavailable', { itemId: id, name: row.name, left: Math.max(0, Number(row.stock)) });
    if (Number(r.stock) <= 0) await t.query('UPDATE menu_items SET is_available = 0, auto_off = 1 WHERE id = $1', [id]);
    took = true;
  }
  if (took) await t.query('UPDATE orders SET stock_taken = 1 WHERE id = $1', [orderId]);
}

/**
 * Give the quantities back when an order is cancelled / rejected / its payment fails — once only (stock_taken 1 → 0),
 * and a product that was hidden only because it ran out comes back. Products removed meanwhile are skipped.
 */
export async function restoreStock(q, orderId) {
  const o = await q.one('UPDATE orders SET stock_taken = 0 WHERE id = $1 AND stock_taken = 1 RETURNING id', [orderId]);
  if (!o) return;
  const rows = await q.query('SELECT menu_item_id AS id, SUM(qty) AS qty FROM order_items WHERE order_id = $1 GROUP BY menu_item_id', [orderId]);
  for (const r of rows) {
    if (r.id == null) continue;
    await q.query(`UPDATE menu_items SET stock = stock + $1, is_available = CASE WHEN auto_off = 1 THEN 1 ELSE is_available END, auto_off = 0
      WHERE id = $2 AND stock IS NOT NULL`, [Number(r.qty), r.id]);
  }
}

/** The lines of an order as saved (with their option snapshot) — old orders never change. */
export async function orderLines(q, orderId) {
  const items = await q.query('SELECT id AS line_id, menu_item_id AS id, name, price, qty, unit_cents, discount_cents, promo_label FROM order_items WHERE order_id = $1 ORDER BY id', [orderId]);
  if (!items.length) return [];
  const ph = items.map((_, i) => `$${i + 1}`).join(',');
  const opts = await q.query(`SELECT order_item_id, group_name, name, price_cents FROM order_item_options WHERE order_item_id IN (${ph}) ORDER BY id`, items.map((i) => i.line_id));
  return items.map((i) => ({
    id: i.id, name: i.name, price: Number(i.price), qty: i.qty,
    discount: i.discount_cents ? fromCents(i.discount_cents) : 0, promo: i.promo_label || null,
    options: opts.filter((o) => o.order_item_id === i.line_id).map((o) => ({ group: o.group_name, name: o.name, price: fromCents(o.price_cents) })),
  }));
}

/** The same lines for many orders in a few queries (lists of orders: no query per order). Returns Map(orderId → lines). */
export async function ordersLines(q, orderIds) {
  const out = new Map(orderIds.map((id) => [Number(id), []]));
  for (let k = 0; k < orderIds.length; k += 200) {
    const ids = orderIds.slice(k, k + 200);
    const items = await q.query(`SELECT id AS line_id, order_id, menu_item_id AS id, name, price, qty, unit_cents, discount_cents, promo_label FROM order_items WHERE order_id IN (${ids.map((_, i) => `$${i + 1}`).join(',')}) ORDER BY id`, ids);
    if (!items.length) continue;
    const opts = [];
    for (let j = 0; j < items.length; j += 500) {
      const part = items.slice(j, j + 500);
      opts.push(...await q.query(`SELECT order_item_id, group_name, name, price_cents FROM order_item_options WHERE order_item_id IN (${part.map((_, i) => `$${i + 1}`).join(',')}) ORDER BY id`, part.map((i) => i.line_id)));
    }
    const byLine = new Map();
    for (const o of opts) { const a = byLine.get(o.order_item_id) || []; a.push({ group: o.group_name, name: o.name, price: fromCents(o.price_cents) }); byLine.set(o.order_item_id, a); }
    for (const i of items) {
      out.get(Number(i.order_id))?.push({ id: i.id, name: i.name, price: Number(i.price), qty: i.qty,
        discount: i.discount_cents ? fromCents(i.discount_cents) : 0, promo: i.promo_label || null, options: byLine.get(i.line_id) || [] });
    }
  }
  return out;
}

/* ---------------- independent drivers' services ---------------- */
// Never allowed, whatever the owner adds: carrying people, and illegal goods (checked on types and descriptions).
const FORBIDDEN = /(passeng|taxi|\brides?\b|rideshare|chauffeur|carpool|weapon|\bguns?\b|narcot|cocain|heroin|cannabis|pasajer|\barmes?\b|\bdrogas?\b|ركاب|راكب|تاكسي|تكسي|نقل اشخاص|نقل أشخاص|توصيل اشخاص|توصيل أشخاص|سلاح|اسلحه|أسلحة|مخدر|حشيش)/i;
export const isForbiddenText = (s) => FORBIDDEN.test(String(s || '').toLowerCase());
const n4 = (ar, en, fr, es) => ({ ar, en, fr, es });
export const DEFAULT_SERVICE_TYPES = [
  { key: 'deliver', errand: 'deliver', names: n4('توصيل غرض', 'Deliver an item', 'Livrer un objet', 'Entregar un objeto') },
  { key: 'buy', errand: 'buy', names: n4('شراء وإحضار', 'Buy & bring', 'Acheter et apporter', 'Comprar y traer') },
  { key: 'documents', errand: 'service', names: n4('معاملات وأوراق', 'Paperwork run', 'Démarches et papiers', 'Trámites y papeles') },
  { key: 'pickup_return', errand: 'deliver', names: n4('استلام وإرجاع', 'Pick up & return', 'Récupérer et rendre', 'Recoger y devolver') },
];
const TYPE_KEY = /^[a-z][a-z0-9_]{1,30}$/;
export async function serviceTypes(db) {
  const row = await db.one(`SELECT value FROM app_meta WHERE key = 'driver_service_types'`);
  try { const l = row ? JSON.parse(row.value) : null; if (Array.isArray(l) && l.length) return l; } catch { /* default */ }
  return DEFAULT_SERVICE_TYPES;
}
/** The owner's list of allowed types (passenger transport / illegal items refused). Returns the clean list or throws 422. */
export async function setServiceTypes(db, list) {
  if (!Array.isArray(list) || !list.length || list.length > 20) throw new HttpError(422, 'validation_failed', { fields: { types: 'invalid' } });
  const seen = new Set(), out = [];
  for (const x of list) {
    const key = String(x?.key || '');
    if (!TYPE_KEY.test(key) || seen.has(key)) throw new HttpError(422, 'validation_failed', { fields: { key: 'invalid' } });
    seen.add(key);
    const names = {};
    for (const l of ['ar', 'en', 'fr', 'es']) names[l] = String(x.names?.[l] || x.names?.ar || key).trim().slice(0, 40);
    if (isForbiddenText(key) || Object.values(names).some(isForbiddenText)) throw new HttpError(422, 'forbidden_service', { key });
    out.push({ key, errand: ['deliver', 'buy'].includes(x.errand) ? x.errand : 'service', names });
  }
  const v = JSON.stringify(out);
  if (await db.one(`SELECT key FROM app_meta WHERE key = 'driver_service_types'`)) await db.query(`UPDATE app_meta SET value = $1 WHERE key = 'driver_service_types'`, [v]);
  else await db.query(`INSERT INTO app_meta (key, value) VALUES ('driver_service_types', $1)`, [v]);
  return out;
}
