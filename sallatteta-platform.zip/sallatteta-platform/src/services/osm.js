// Villages & areas around a point, taken from OpenStreetMap (Overpass API).
// Every place fetched is saved into service_areas, so the village list grows by itself.
// If OpenStreetMap is slow or down, callers simply fall back to the villages already saved.
import { haversineKm } from '../lib/geo.js';
import { normalizeName } from '../../public/assets/normalize.js';

const ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
];
const PLACE_TYPES = 'city|town|village|hamlet|suburb|neighbourhood|quarter|locality';
const CELL_DEG = 0.05; // ~5 km grid: one OpenStreetMap request per cell
const CELL_TTL_DAYS = 30;
const hasArabic = (s) => /[\u0600-\u06FF]/.test(s || '');

/** Raw fetch from Overpass → [{osmId, nameAr, nameEn, lat, lng}] */
export async function overpassPlaces(lat, lng, km, { timeoutMs = 9000 } = {}) {
  const query = `[out:json][timeout:15];node["place"~"^(${PLACE_TYPES})$"](around:${Math.round(km * 1000)},${lat},${lng});out body 400;`;
  let lastErr;
  for (const url of ENDPOINTS) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'sallatteta-platform/2 (home cooks directory)' },
        body: 'data=' + encodeURIComponent(query),
        signal: ctrl.signal,
      });
      if (!res.ok) throw new Error(`overpass ${res.status}`);
      const json = await res.json();
      return (json.elements || []).map((e) => {
        const t = e.tags || {};
        const nameAr = t['name:ar'] || (hasArabic(t.name) ? t.name : null);
        const nameEn = t['name:en'] || t['name:latin'] || (!hasArabic(t.name) ? t.name : null);
        return { osmId: e.id, nameAr: nameAr || nameEn, nameEn: nameEn || null, lat: e.lat, lng: e.lon, type: t.place };
      }).filter((p) => p.nameAr && Number.isFinite(p.lat) && Number.isFinite(p.lng));
    } catch (err) {
      lastErr = err;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastErr || new Error('overpass failed');
}

/**
 * Make sure the places around (lat,lng) are saved. Cached per ~5 km cell for 30 days.
 * fetcher is injectable for tests. Never throws: returns { source: 'osm' | 'cache' | 'fallback' }.
 */
export async function ensurePlacesAround(db, areas, lat, lng, { km = 15, fetcher = overpassPlaces, log = console } = {}) {
  const cell = `osm:${(Math.round(lat / CELL_DEG) * CELL_DEG).toFixed(2)},${(Math.round(lng / CELL_DEG) * CELL_DEG).toFixed(2)}`;
  const cached = await db.one('SELECT value FROM app_meta WHERE key = $1', [cell]);
  if (cached && Date.now() - Number(cached.value) < CELL_TTL_DAYS * 86400_000) return { source: 'cache' };

  let places;
  try {
    places = await fetcher(lat, lng, km);
  } catch (err) {
    log.warn?.(`[osm] places around ${lat},${lng} unavailable: ${err.message}`);
    return { source: 'fallback' };
  }

  let added = 0;
  for (const p of places) {
    // Same name within 3 km of a village we already have → it's the same place.
    const n = normalizeName(p.nameAr);
    const dup = areas.list.find((a) => a.names.includes(n) && haversineKm(a.lat, a.lng, p.lat, p.lng) < 3);
    if (dup) continue;
    const ref = areas.nearest(p.lat, p.lng); // borrow the district of the nearest known village
    const r = await db.query(
      `INSERT INTO service_areas (slug, name_ar, name_en, name_fr, region, district, lat, lng, sort_order)
       VALUES ($1,$2,$3,$3,$4,$4,$5,$6,2000) ON CONFLICT (slug) DO NOTHING RETURNING id`,
      [`osm-${p.osmId}`, p.nameAr.slice(0, 80), (p.nameEn || '').slice(0, 80) || null, ref?.district || null, p.lat, p.lng]);
    if (r.length) {
      added++;
      // keep the in-memory index in step so later duplicates in this batch are caught
      areas.list.push({ id: r[0].id, name_ar: p.nameAr, name_en: p.nameEn, district: ref?.district || null, lat: p.lat, lng: p.lng, names: [n] });
    }
  }
  if (cached) await db.query('UPDATE app_meta SET value = $1 WHERE key = $2', [String(Date.now()), cell]);
  else await db.query('INSERT INTO app_meta (key, value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value', [cell, String(Date.now())]);
  if (added) await areas.load();
  log.info?.(`[osm] ${places.length} places near ${lat},${lng} (${added} new)`);
  return { source: 'osm', added };
}
