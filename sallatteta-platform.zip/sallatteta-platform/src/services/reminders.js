// Automatic reminders — useful, never annoying: each reminder is sent once per step (notif_log), a few steps at most,
// and the non-urgent ones wait outside quiet hours (23:00–08:00, Beirut time). New orders are never held back.
const MIN = 60_000;
const ref = (id) => `AKL${id}`;
const iso = (d = new Date()) => d.toISOString();
const ms = (v) => Date.parse(v instanceof Date ? v.toISOString() : String(v));

/** Quiet hours in the platform's time zone (reminders that can wait are not sent at night). */
export function isQuiet(now = new Date(), tz = 'Asia/Beirut', from = 23, to = 8) {
  const h = Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: tz }).format(now)) % 24;
  return from > to ? h >= from || h < to : h >= from && h < to;
}

async function once(db, kind, refKey, step) {
  try { await db.query('INSERT INTO notif_log (kind, ref_key, step) VALUES ($1,$2,$3)', [kind, String(refKey), step]); return true; } catch { return false; }
}

export async function runReminders(db, push, s, { now = new Date() } = {}) {
  const out = { store: 0, customer: 0, driver: 0 };
  if (!push) return out;
  const t = now.getTime();
  const quiet = isQuiet(now);

  // 1) a new order the store hasn't answered: after N and N+3 minutes (urgent: also at night — the store is open)
  const first = Number(s.remindStoreMin ?? 2);
  const pend = await db.query(`SELECT id, cook_id, created_at FROM orders WHERE status = 'pending' AND created_at <= $1 AND created_at >= $2
    AND (payment_method IS NULL OR payment_method = 'cash' OR payment_status = 'paid')`, [iso(new Date(t - first * MIN)), iso(new Date(t - 60 * MIN))]);
  for (const o of pend) {
    const age = (t - ms(o.created_at)) / MIN;
    const step = age >= first + 3 ? 2 : 1;
    for (let k = 1; k <= step; k += 1) {
      if (await once(db, 'store_pending', o.id, k)) {
        if (k === step) { push.notify('store', o.cook_id, { title: 'Aklatak', key: 'store_pending_remind', vars: { ref: ref(o.id) }, body: `⏰ الطلب ${ref(o.id)} بانتظار تأكيدك`, url: '/store' }); out.store += 1; }
      }
    }
  }

  // 2) delivered but the customer hasn't confirmed: at 15, 45 and 90 minutes (before the automatic confirmation)
  if (!quiet) {
    const base = Number(s.remindConfirmMin ?? 15);
    const steps = [base, base * 3, base * 6].filter((m) => m < Number(s.confirmAfterMin ?? 120));
    const rows = await db.query(`SELECT id, customer_id, delivered_at FROM orders WHERE status = 'delivered' AND confirmed_at IS NULL AND customer_hidden = 0
      AND delivered_at <= $1 AND delivered_at >= $2`, [iso(new Date(t - base * MIN)), iso(new Date(t - Number(s.confirmAfterMin ?? 120) * MIN))]);
    for (const o of rows) {
      const age = (t - ms(o.delivered_at)) / MIN;
      const due = steps.filter((m) => age >= m).length;   // how many reminders are due by now
      if (!due) continue;
      let sent = false;
      for (let k = 1; k <= due; k += 1) if (await once(db, 'cust_confirm', o.id, k)) sent = true;
      if (sent) { push.notify('customer', o.customer_id, { title: 'Aklatak', key: 'cust_confirm_remind', vars: { ref: ref(o.id) }, body: `📦 هل استلمت الطلب ${ref(o.id)}؟ اضغط «استلمت طلبيتي» للتأكيد`, url: `/#/o/${o.id}` }); out.customer += 1; }
    }
  }

  // 3) a driver who still holds stores' money for more than a day: one reminder a day; near the cash limit: one a day too
  if (!quiet) {
    const day = Math.floor(t / (24 * 60 * MIN));
    const limit = Number(s.cashLimit ?? 100);
    const rows = await db.query(`SELECT driver_id, COALESCE(SUM(COALESCE(due_cents, CAST(ROUND(amount * 100) AS INTEGER)) - paid_cents), 0) / 100.0 AS total, MIN(created_at) AS since
      FROM driver_cash_entries WHERE status = 'open' AND direction = 'driver_to_store' GROUP BY driver_id`);
    for (const r of rows) {
      const since = ms(r.since);
      const total = Math.round(Number(r.total) * 100) / 100;
      if (limit > 0 && total >= limit * 0.8 && await once(db, 'driver_limit', r.driver_id, day)) {
        push.notify('driver', r.driver_id, { title: 'Aklatak', key: 'drv_limit', vars: { amount: total, limit }, body: `⚠️ معك ${total}$ للمحلات من أصل حدّ ${limit}$ — سلّمها حتى تستمر طلبات النقد`, url: '/driver' });
        out.driver += 1;
      } else if (t - since > 24 * 60 * MIN && await once(db, 'driver_dues', r.driver_id, day)) {
        push.notify('driver', r.driver_id, { title: 'Aklatak', key: 'drv_dues_remind', vars: { amount: total }, body: `💵 عليك ${total}$ للمحلات — سلّمها لكل محل ثم اضغط «سلّمت»`, url: '/driver' });
        out.driver += 1;
      }
    }
  }
  return out;
}

/** Old reminder records are useless after a few days. */
export async function pruneReminders(db, days = 7) {
  return (await db.query('DELETE FROM notif_log WHERE created_at < $1 RETURNING id', [iso(new Date(Date.now() - days * 24 * 60 * MIN))])).length;
}
