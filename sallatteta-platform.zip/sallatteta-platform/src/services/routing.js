// Road distance & driving time (like the phone's map app), so the distance shown in Aklatak matches "Directions".
// Geoapify Route Matrix: ONE request for up to 50 places. Results are cached per ~100 m of the customer's position
// (the list, the subscriber page and a second visit show the SAME number). If routing is unavailable, the
// straight-line distance is used and labelled as such — never a made-up road distance.

const cacheMap = new Map();                   // key → { m, s, at } (bounded below)
const TTL = 15 * 60_000;
const MAX = 20_000;
const BREAKER = { failures: 0, openUntil: 0 };

const keyOf = (o, t) => `${o.lat.toFixed(3)},${o.lng.toFixed(3)}>${t.id}`;   // ~100 m cells
export const clearRouteCache = () => { cacheMap.clear(); BREAKER.failures = 0; BREAKER.openUntil = 0; };

/** origin {lat,lng}; targets [{id,lat,lng}] → Map(id → { m, s }) for the ones that have a route. */
export async function roadDistances(origin, targets, { key, fetchImpl = fetch, timeoutMs = 7000, mode = 'drive' } = {}) {
  const out = new Map();
  const now = Date.now();
  const missing = [];
  for (const t of targets) {
    if (t.lat == null || t.lng == null) continue;
    const c = cacheMap.get(keyOf(origin, t));
    if (c && now - c.at < TTL) { if (c.m != null) out.set(t.id, { m: c.m, s: c.s }); } else missing.push(t);
  }
  if (!missing.length || !key || now < BREAKER.openUntil) return out;
  for (let i = 0; i < missing.length; i += 50) {
    const batch = missing.slice(i, i + 50);
    const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetchImpl(`https://api.geoapify.com/v1/routematrix?apiKey=${encodeURIComponent(key)}`, {
        method: 'POST', signal: ctrl.signal, headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode, sources: [{ location: [origin.lng, origin.lat] }], targets: batch.map((t) => ({ location: [t.lng, t.lat] })) }),
      });
      if (!res.ok) throw new Error(`routing: HTTP ${res.status}`);
      const row = (await res.json())?.sources_to_targets?.[0] || [];
      batch.forEach((t, j) => {
        const r = row[j];
        const m = r && Number.isFinite(r.distance) ? Math.round(r.distance) : null;
        const s = r && Number.isFinite(r.time) ? Math.round(r.time) : null;
        cacheMap.set(keyOf(origin, t), { m, s, at: Date.now() });
        if (m != null) out.set(t.id, { m, s });
      });
      BREAKER.failures = 0;
    } catch {
      if (++BREAKER.failures >= 3) { BREAKER.openUntil = Date.now() + 60_000; BREAKER.failures = 0; }   // routing down → straight line for a minute
    } finally { clearTimeout(timer); }
  }
  if (cacheMap.size > MAX) for (const k of [...cacheMap.keys()].slice(0, cacheMap.size - MAX)) cacheMap.delete(k);
  return out;
}

/** Replace straight-line distances by road distances where available; keep within radiusM; nearest first. */
export async function withRoadDistances(origin, cooks, { key, fetchImpl, radiusM = null } = {}) {
  const shops = cooks.filter((c) => c.nav || c.kind !== 'cook');           // exact points (home cooks: no exact point is ever shown)
  const roads = await roadDistances(origin, shops.slice(0, 50).map((c) => ({ id: c.id, lat: c.nav?.lat, lng: c.nav?.lng })), { key, fetchImpl });
  const out = cooks.map((c) => {
    const r = roads.get(c.id);
    return r ? { ...c, distanceM: r.m, distanceKm: Math.round(r.m / 100) / 10, driveMin: r.s != null ? Math.max(1, Math.round(r.s / 60)) : null, distanceKind: 'road' } : c;
  });
  return out.filter((c) => radiusM == null || c.distanceM <= radiusM).sort((a, b) => a.distanceM - b.distanceM);
}
