// The ONLY things the AI manager can do: a fixed list of backend tools. Each tool has a permission key, a risk level,
// the categories it applies to, a JSON schema validated on the server, and a handler that uses the normal queries
// scoped to the subscriber's OWN id (ctx.owner.id — never an id from the model). The AI never gets raw database access,
// never touches money / ledgers / payouts, and can't read another subscriber's data.
import { HttpError } from '../../lib/http.js';
import { cleanText } from '../../lib/validate.js';
import { hasProfanity } from '../../lib/profanity.js';
import { isOpenNow } from '../../lib/hours.js';
import { oneStepOn, recordsFromOf, driverRecordsFrom, clampFrom } from '../delivery.js';

const iso = (d = new Date()) => d.toISOString();
const ref = (id) => `AKL${id}`;
const DAY = 86_400_000;
const r2 = (n) => Math.round(Number(n || 0) * 100) / 100;
const parseJson = (s) => { try { return s ? JSON.parse(s) : null; } catch { return null; } };

/** Small JSON-schema check (object/integer/number/string/boolean, enum, min/max, maxLength, required, no extra keys). */
export function validateArgs(schema, input) {
  const errors = {};
  const obj = input == null ? {} : input;
  if (typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, errors: { _: 'not_object' } };
  const props = schema.properties || {};
  for (const k of Object.keys(obj)) if (!props[k]) errors[k] = 'not_allowed';   // e.g. a storeId the model invented
  for (const k of schema.required || []) if (obj[k] === undefined || obj[k] === null || obj[k] === '') errors[k] = 'required';
  const out = {};
  for (const [k, p] of Object.entries(props)) {
    const v = obj[k];
    if (v === undefined || v === null) continue;
    if (p.type === 'integer' && !Number.isInteger(v)) { errors[k] = 'invalid'; continue; }
    if (p.type === 'number' && (typeof v !== 'number' || !Number.isFinite(v))) { errors[k] = 'invalid'; continue; }
    if (p.type === 'string' && typeof v !== 'string') { errors[k] = 'invalid'; continue; }
    if (p.type === 'boolean' && typeof v !== 'boolean') { errors[k] = 'invalid'; continue; }
    if (p.enum && !p.enum.includes(v)) { errors[k] = 'invalid'; continue; }
    if (p.minimum !== undefined && v < p.minimum) { errors[k] = 'out_of_range'; continue; }
    if (p.maximum !== undefined && v > p.maximum) { errors[k] = 'out_of_range'; continue; }
    if (p.type === 'string') {
      const s = cleanText(v);
      if (p.maxLength && s.length > p.maxLength) { errors[k] = 'too_long'; continue; }
      out[k] = s;
    } else out[k] = v;
  }
  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, value: out };
}

const S = {
  none: { type: 'object', properties: {} },
  limit: { type: 'integer', minimum: 1, maximum: 50 },
  id: { type: 'integer', minimum: 1, maximum: 2_147_483_647 },
  period: { type: 'string', enum: ['day', 'week', 'month'] },
};
const TEMPLATES = ['preparing', 'ready_soon', 'delayed', 'thanks', 'booking_reminder'];
const TEMPLATE_AR = {
  preparing: (r, s) => `👨‍🍳 ${s}: طلبك ${r} قيد التحضير`,
  ready_soon: (r, s) => `⏳ ${s}: طلبك ${r} يكاد يجهز`,
  delayed: (r, s) => `🙏 ${s}: نعتذر، طلبك ${r} سيتأخر قليلاً`,
  thanks: (r, s) => `💚 ${s}: شكراً لطلبك ${r}`,
  booking_reminder: (r, s) => `📅 ${s}: تذكير بموعدك ${r}`,
};

async function own(db, sql, params) {
  const row = await db.one(sql, params);
  if (!row) throw new HttpError(404, 'not_found');   // another subscriber's id looks exactly like a missing one
  return row;
}
/** Once per key forever (ai_tasks.task_key is unique) — stops repeated notifications. */
async function onceKey(db, key, kind, owner) {
  const r = await db.query(`INSERT INTO ai_tasks (task_key, kind, owner_type, owner_id, status, updated_at) VALUES ($1,$2,$3,$4,'done',$5)
    ON CONFLICT (task_key) DO NOTHING RETURNING id`, [key, kind, owner.type, owner.id, iso()]);
  return r.length > 0;
}

// ---------- reports shared with the workflows ----------
export async function salesReport(db, owner, period = 'day', now = new Date()) {
  const span = { day: DAY, week: 7 * DAY, month: 30 * DAY }[period] || DAY;
  let from = iso(new Date(now.getTime() - span));
  const to = iso(now);
  if (owner.type === 'driver') {
    from = clampFrom(from, await driverRecordsFrom(db, owner.id));   // v8.5.1 his «fresh account» start
    const e = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n, COALESCE(SUM(fee + bonus), 0) AS s FROM driver_earnings WHERE driver_id = $1 AND reversed = 0 AND created_at >= $2 AND created_at <= $3`, [owner.id, from, to]);
    const er = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n, COALESCE(SUM(price), 0) AS s FROM errands WHERE driver_id = $1 AND status = 'delivered' AND delivered_at >= $2 AND delivered_at <= $3`, [owner.id, from, to]);
    return { period, from, to, storeDeliveries: e.n, storeDeliveryEarnings: r2(e.s), customerRequests: er.n, customerRequestEarnings: r2(er.s), totalEarnings: r2(Number(e.s) + Number(er.s)) };
  }
  // v8.5 one-step orders: an accepted order (no driver) counts as sold at once, like a delivered one
  const oneStep = await oneStepOn(db);
  from = clampFrom(from, await recordsFromOf(db, owner.id));   // v8.5.1 the store's «fresh account» start
  const rows = await db.query(`SELECT CASE WHEN status IN ('preparing','picked_up') AND driver_id IS NULL AND accepted_at IS NOT NULL AND $4 = 1 THEN 'delivered' ELSE status END AS status,
    CAST(COUNT(*) AS INTEGER) AS n, COALESCE(SUM(total), 0) AS s FROM orders WHERE cook_id = $1 AND created_at >= $2 AND created_at <= $3
    GROUP BY CASE WHEN status IN ('preparing','picked_up') AND driver_id IS NULL AND accepted_at IS NOT NULL AND $4 = 1 THEN 'delivered' ELSE status END`, [owner.id, from, to, oneStep ? 1 : 0]);
  const by = Object.fromEntries(rows.map((r) => [r.status, r]));
  const cur = (await db.one('SELECT currency FROM orders WHERE cook_id = $1 ORDER BY id DESC LIMIT 1', [owner.id]))?.currency || 'USD';
  const top = await db.query(`SELECT i.name, CAST(SUM(i.qty) AS INTEGER) AS qty FROM order_items i JOIN orders o ON o.id = i.order_id
    WHERE o.cook_id = $1 AND (o.status = 'delivered' OR ($4 = 1 AND o.status IN ('preparing','picked_up') AND o.driver_id IS NULL AND o.accepted_at IS NOT NULL))
      AND o.created_at >= $2 AND o.created_at <= $3 GROUP BY i.name ORDER BY qty DESC LIMIT 5`, [owner.id, from, to, oneStep ? 1 : 0]);
  const appts = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM appointments WHERE cook_id = $1 AND status = 'done' AND starts_at >= $2 AND starts_at <= $3`, [owner.id, from, to]);
  const visits = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM visit_requests WHERE cook_id = $1 AND status = 'done' AND created_at >= $2 AND created_at <= $3`, [owner.id, from, to]);
  const n = (k) => by[k]?.n || 0;
  return {
    period, from, to, currency: cur,
    orders: rows.reduce((a, r) => a + r.n, 0), delivered: n('delivered'), rejected: n('rejected'), cancelled: n('cancelled'),
    inProgress: n('pending') + n('preparing') + n('searching') + n('assigned') + n('picked_up'),
    revenue: r2(by.delivered?.s || 0), topItems: top, appointmentsDone: appts.n, visitsDone: visits.n,
  };
}

export async function detectProblems(db, owner, now = new Date()) {
  const out = [];
  const t = now.getTime();
  if (owner.type === 'driver') {
    const stale = await db.query(`SELECT id, status FROM errands WHERE driver_id = $1 AND status IN ('assigned','picked_up') AND assigned_at <= $2`, [owner.id, iso(new Date(t - 2 * 3600_000))]);
    for (const e of stale) out.push({ type: 'errand_open_long', errandId: e.id, status: e.status });
    return out;
  }
  const late = await db.query(`SELECT id FROM orders WHERE cook_id = $1 AND status = 'pending' AND created_at <= $2`, [owner.id, iso(new Date(t - 10 * 60_000))]);
  for (const o of late) out.push({ type: 'order_waiting', orderId: o.id, ref: ref(o.id) });
  const prep = await db.query(`SELECT id FROM orders WHERE cook_id = $1 AND status = 'preparing' AND accepted_at <= $2`, [owner.id, iso(new Date(t - 45 * 60_000))]);
  for (const o of prep) out.push({ type: 'preparation_late', orderId: o.id, ref: ref(o.id) });
  const wk = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n, CAST(SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS INTEGER) AS rej,
    CAST(SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS INTEGER) AS can FROM orders WHERE cook_id = $1 AND created_at >= $2`, [owner.id, iso(new Date(t - 7 * DAY))]);
  if (wk.n >= 5 && (wk.rej || 0) / wk.n >= 0.3) out.push({ type: 'many_rejections', rejected: wk.rej, of: wk.n });
  if (wk.n >= 5 && (wk.can || 0) / wk.n >= 0.3) out.push({ type: 'many_cancellations', cancelled: wk.can, of: wk.n });
  const unav = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1 AND is_available = 0', [owner.id]);
  if (unav.n) out.push({ type: 'unavailable_items', count: unav.n });
  const appts = await db.query(`SELECT id FROM appointments WHERE cook_id = $1 AND status = 'pending' AND starts_at > $2 AND starts_at <= $3`, [owner.id, iso(now), iso(new Date(t + DAY))]);
  for (const a of appts) out.push({ type: 'booking_unanswered', appointmentId: a.id });
  return out;
}

/** Accept a new order: the same rule as POST /api/store/orders/:id/accept (pending → preparing, a paid card order only). */
export async function acceptOrder(db, push, storeId, orderId) {
  const r = await db.query(`UPDATE orders SET status = 'preparing', accepted_at = $1 WHERE id = $2 AND cook_id = $3 AND status = 'pending'
    AND payment_status NOT IN ('pending','failed') RETURNING id, customer_id`, [iso(), orderId, storeId]);
  if (!r.length) {
    await own(db, 'SELECT id FROM orders WHERE id = $1 AND cook_id = $2', [orderId, storeId]);
    throw new HttpError(409, 'invalid_transition');
  }
  push?.notify?.('customer', r[0].customer_id, { title: 'Aklatak', key: 'cust_accepted', vars: { ref: ref(orderId) }, body: `✅ قَبِل المتجر طلبك ${ref(orderId)} وبدأ تحضيره`, url: `/#/o/${orderId}` });
  return { orderId, ref: ref(orderId), status: 'preparing' };
}

const txt = (v) => (v == null ? null : String(v).slice(0, 300));
const suggestionText = (item, lang) => {
  const n = item.name;
  return ({
    ar: `${n}: محضَّر طازجاً يومياً بمكوّنات مختارة بعناية${item.section ? ` — من قسم ${item.section}` : ''}. اطلبه الآن واستمتع بالطعم الأصيل.`,
    en: `${n}: freshly prepared every day with carefully chosen ingredients${item.section ? ` — from our ${item.section} section` : ''}. Order now and enjoy the real taste.`,
    fr: `${n} : préparé frais chaque jour avec des ingrédients soigneusement choisis${item.section ? ` — rayon ${item.section}` : ''}. Commandez maintenant !`,
    es: `${n}: preparado fresco cada día con ingredientes cuidadosamente elegidos${item.section ? ` — sección ${item.section}` : ''}. ¡Pídelo ahora!`,
  })[lang] || n;
};

// ---------- the registry ----------
// kind of the permission decides read vs write; alwaysApprove(args) forces the approval queue (irreversible / prices).
export const TOOLS = [
  {
    name: 'read_orders', permission: 'orders_read', risk: 'low', categories: ['shops', 'online'],
    description: "List the subscriber's recent orders (optionally by status).",
    schema: { type: 'object', properties: { status: { type: 'string', enum: ['pending', 'preparing', 'searching', 'assigned', 'picked_up', 'delivered', 'rejected', 'cancelled'] }, limit: S.limit } },
    async handler(ctx, a) {
      const rows = await ctx.db.query(`SELECT o.id, o.status, o.total, o.currency, o.created_at, o.scheduled_at, cu.name AS customer
        FROM orders o JOIN customers cu ON cu.id = o.customer_id WHERE o.cook_id = $1 ${a.status ? 'AND o.status = $2' : ''} ORDER BY o.id DESC LIMIT ${a.limit || 20}`,
      a.status ? [ctx.owner.id, a.status] : [ctx.owner.id]);
      return { orders: rows.map((o) => ({ id: o.id, ref: ref(o.id), status: o.status, total: Number(o.total), currency: o.currency, createdAt: o.created_at, scheduledAt: o.scheduled_at, customer: o.customer })) };
    },
  },
  {
    name: 'list_new_orders', permission: 'orders_read', risk: 'low', categories: ['shops', 'online'],
    description: 'List the new orders waiting for the subscriber to accept.',
    schema: S.none,
    async handler(ctx) {
      const rows = await ctx.db.query(`SELECT o.id, o.total, o.currency, o.created_at FROM orders o WHERE o.cook_id = $1 AND o.status = 'pending'
        AND o.payment_status NOT IN ('pending','failed') ORDER BY o.id LIMIT 50`, [ctx.owner.id]);
      const out = [];
      for (const o of rows) out.push({ id: o.id, ref: ref(o.id), total: Number(o.total), currency: o.currency, createdAt: o.created_at, items: await ctx.db.query('SELECT name, qty FROM order_items WHERE order_id = $1', [o.id]) });
      return { orders: out };
    },
  },
  {
    name: 'order_status_update', permission: 'orders_status', risk: 'high', categories: ['shops', 'online'],
    description: 'Move an order forward. Only allowed transition: pending → preparing (accept). Needs approval.',
    schema: { type: 'object', required: ['orderId', 'to'], properties: { orderId: S.id, to: { type: 'string', enum: ['preparing'] } } },
    summary: (a) => `${ref(a.orderId)} → ${a.to}`,
    async validate(ctx, a) {   // refused before queueing when it isn't this store's order or not waiting any more
      const o = await own(ctx.db, 'SELECT status FROM orders WHERE id = $1 AND cook_id = $2', [a.orderId, ctx.owner.id]);
      if (o.status !== 'pending') throw new HttpError(409, 'invalid_transition');
    },
    async handler(ctx, a) { return acceptOrder(ctx.db, ctx.push, ctx.owner.id, a.orderId); },
  },
  {
    name: 'notify_customer', permission: 'cs_notify', risk: 'medium', categories: ['shops', 'online', 'crafts', 'drivers'],
    description: 'Send the customer of one of YOUR orders / bookings / requests a ready-made in-app notification (template only, once per template).',
    schema: { type: 'object', required: ['template'], properties: { orderId: S.id, appointmentId: S.id, errandId: S.id, template: { type: 'string', enum: TEMPLATES } } },
    summary: (a) => `${a.template} ${a.orderId ? ref(a.orderId) : a.appointmentId ? `#B${a.appointmentId}` : `#E${a.errandId}`}`,
    async handler(ctx, a) {
      const given = ['orderId', 'appointmentId', 'errandId'].filter((k) => a[k]);
      if (given.length !== 1) throw new HttpError(422, 'validation_failed', { fields: { orderId: 'exactly_one' } });
      let customerId, r, url;
      if (a.errandId) {
        if (ctx.owner.type !== 'driver') throw new HttpError(404, 'not_found');
        customerId = (await own(ctx.db, 'SELECT customer_id FROM errands WHERE id = $1 AND driver_id = $2', [a.errandId, ctx.owner.id])).customer_id;
        r = `#E${a.errandId}`; url = `/#/e/${a.errandId}`;
      } else if (ctx.owner.type !== 'store') throw new HttpError(404, 'not_found');
      else if (a.orderId) {
        customerId = (await own(ctx.db, 'SELECT customer_id FROM orders WHERE id = $1 AND cook_id = $2', [a.orderId, ctx.owner.id])).customer_id;
        r = ref(a.orderId); url = `/#/o/${a.orderId}`;
      } else {
        customerId = (await own(ctx.db, 'SELECT customer_id FROM appointments WHERE id = $1 AND cook_id = $2', [a.appointmentId, ctx.owner.id])).customer_id;
        r = `#B${a.appointmentId}`; url = '/#/bookings';
      }
      // never spam: each template once per order/booking/request
      if (!(await onceKey(ctx.db, `notify:${ctx.owner.type}:${ctx.owner.id}:${r}:${a.template}`, 'notify', ctx.owner))) return { sent: false, reason: 'already_sent' };
      ctx.push?.notify?.('customer', customerId, { title: 'Aklatak', key: `ai_${a.template}`, vars: { ref: r, store: ctx.owner.name }, body: TEMPLATE_AR[a.template](r, ctx.owner.name), url });
      return { sent: true, ref: r, template: a.template };
    },
  },
  {
    name: 'read_catalog', permission: 'products_read', risk: 'low', categories: ['shops', 'online', 'crafts'],
    description: "Read the subscriber's products / services with prices.",
    schema: { type: 'object', properties: { limit: { type: 'integer', minimum: 1, maximum: 200 } } },
    async handler(ctx, a) {
      const rows = await ctx.db.query(`SELECT id, name, description, price, currency, is_available, section FROM menu_items WHERE cook_id = $1 ORDER BY sort_order, id LIMIT ${a.limit || 100}`, [ctx.owner.id]);
      return { items: rows.map((i) => ({ id: i.id, name: i.name, description: txt(i.description), price: i.price == null ? null : Number(i.price), currency: i.currency, available: !!Number(i.is_available), section: i.section })) };
    },
  },
  {
    name: 'suggest_description', permission: 'products_suggest', risk: 'low', categories: ['shops', 'online', 'crafts'],
    description: 'Suggest a description for one product (returns text, changes nothing).',
    schema: { type: 'object', required: ['itemId'], properties: { itemId: S.id } },
    async handler(ctx, a) {
      const i = await own(ctx.db, 'SELECT id, name, description, section FROM menu_items WHERE id = $1 AND cook_id = $2', [a.itemId, ctx.owner.id]);
      return { itemId: i.id, name: i.name, current: txt(i.description), suggestion: suggestionText(i, ctx.lang) };
    },
  },
  {
    name: 'prepare_product_update', permission: 'products_update', risk: 'medium', categories: ['shops', 'online', 'crafts'],
    description: 'Change a product name/description/availability/price. A price change always waits for the subscriber.',
    schema: { type: 'object', required: ['itemId'], properties: { itemId: S.id, name: { type: 'string', maxLength: 80 }, description: { type: 'string', maxLength: 500 }, available: { type: 'boolean' }, price: { type: 'number', minimum: 0, maximum: 1_000_000 } } },
    alwaysApprove: (a) => a.price !== undefined,   // publishing prices: always the subscriber's explicit approval
    summary: (a) => `#${a.itemId} ${Object.keys(a).filter((k) => k !== 'itemId').join(',')}`,
    async validate(ctx, a) {
      if (['name', 'description', 'available', 'price'].every((k) => a[k] === undefined)) throw new HttpError(422, 'validation_failed', { fields: { itemId: 'nothing_to_change' } });
      if ((a.name && hasProfanity(a.name)) || (a.description && hasProfanity(a.description))) throw new HttpError(422, 'inappropriate_words');
      if (a.name !== undefined && a.name.length < 2) throw new HttpError(422, 'validation_failed', { fields: { name: 'too_short' } });
      await own(ctx.db, 'SELECT id FROM menu_items WHERE id = $1 AND cook_id = $2', [a.itemId, ctx.owner.id]);
    },
    async handler(ctx, a) {
      const sets = [], vals = [];
      if (a.name !== undefined) { vals.push(a.name); sets.push(`name = $${vals.length}`); }
      if (a.description !== undefined) { vals.push(a.description); sets.push(`description = $${vals.length}`); }
      if (a.available !== undefined) { vals.push(a.available ? 1 : 0); sets.push(`is_available = $${vals.length}`); }
      if (a.price !== undefined) { vals.push(r2(a.price)); sets.push(`price = $${vals.length}`); }
      vals.push(a.itemId, ctx.owner.id);
      const r = await ctx.db.query(`UPDATE menu_items SET ${sets.join(', ')} WHERE id = $${vals.length - 1} AND cook_id = $${vals.length} RETURNING id`, vals);
      if (!r.length) throw new HttpError(404, 'not_found');
      return { itemId: a.itemId, updated: Object.keys(a).filter((k) => k !== 'itemId') };
    },
  },
  {
    name: 'suggest_price', permission: 'products_suggest', risk: 'low', categories: ['shops', 'online', 'crafts'],
    description: 'Suggest a price for one product from its section and sales (text only, nothing changes).',
    schema: { type: 'object', required: ['itemId'], properties: { itemId: S.id } },
    async handler(ctx, a) {
      const i = await own(ctx.db, 'SELECT id, name, price, currency, section FROM menu_items WHERE id = $1 AND cook_id = $2', [a.itemId, ctx.owner.id]);
      const peers = await ctx.db.one(`SELECT AVG(price) AS avg, CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1 AND price IS NOT NULL AND id <> $2 AND COALESCE(section, '') = COALESCE($3, '')`, [ctx.owner.id, i.id, i.section]);
      const sold = await ctx.db.one(`SELECT COALESCE(SUM(qty), 0) AS q FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.cook_id = $1 AND oi.menu_item_id = $2 AND o.status = 'delivered' AND o.created_at >= $3`, [ctx.owner.id, i.id, iso(new Date(Date.now() - 30 * DAY))]);
      const cur = Number(i.price || 0), avg = peers.n ? Number(peers.avg) : cur;
      let suggested = cur;
      if (Number(sold.q) >= 20) suggested = cur * 1.05;                 // sells well → a small increase
      else if (Number(sold.q) === 0 && cur > avg * 1.2) suggested = avg; // nobody buys and dearer than its section
      return { itemId: i.id, name: i.name, currentPrice: cur, sectionAverage: r2(avg), soldLast30Days: Number(sold.q), suggestedPrice: r2(suggested), currency: i.currency, note: 'suggestion only — nothing was changed' };
    },
  },
  {
    name: 'prepare_promotion', permission: 'promotions_prepare', risk: 'high', categories: ['shops', 'online'],
    description: 'Prepare a promotion draft (always waits for the subscriber; it is saved as a draft, prices are not changed).',
    schema: { type: 'object', required: ['title', 'percent', 'days'], properties: { title: { type: 'string', maxLength: 80 }, percent: { type: 'integer', minimum: 1, maximum: 70 }, days: { type: 'integer', minimum: 1, maximum: 30 }, itemId: S.id } },
    alwaysApprove: () => true,
    summary: (a) => `${a.percent}% ${a.days}d`,
    async validate(ctx, a) {
      if (hasProfanity(a.title)) throw new HttpError(422, 'inappropriate_words');
      if (a.itemId) await own(ctx.db, 'SELECT id FROM menu_items WHERE id = $1 AND cook_id = $2', [a.itemId, ctx.owner.id]);
    },
    async handler(ctx, a) {
      const r = await ctx.db.one(`INSERT INTO ai_drafts (owner_type, owner_id, kind, content, status) VALUES ($1,$2,'promotion',$3,'approved') RETURNING id`, [ctx.owner.type, ctx.owner.id, JSON.stringify(a)]);
      return { draftId: r.id, saved: true, note: 'saved as an approved draft; prices unchanged' };
    },
  },
  {
    name: 'read_bookings', permission: 'bookings_read', risk: 'low', categories: ['shops', 'crafts'],
    description: "List the subscriber's appointments (next days by default).",
    schema: { type: 'object', properties: { days: { type: 'integer', minimum: 1, maximum: 60 }, status: { type: 'string', enum: ['pending', 'confirmed', 'declined', 'cancelled', 'done'] } } },
    async handler(ctx, a) {
      const from = iso(new Date(Date.now() - DAY)), to = iso(new Date(Date.now() + (a.days || 14) * DAY));
      const rows = await ctx.db.query(`SELECT ap.id, ap.service, ap.starts_at, ap.status, ap.customer_id, cu.name AS customer FROM appointments ap JOIN customers cu ON cu.id = ap.customer_id
        WHERE ap.cook_id = $1 AND ap.starts_at >= $2 AND ap.starts_at <= $3 ${a.status ? 'AND ap.status = $4' : ''} ORDER BY ap.starts_at LIMIT 100`,
      a.status ? [ctx.owner.id, from, to, a.status] : [ctx.owner.id, from, to]);
      return { bookings: rows.map((b) => ({ id: b.id, service: b.service, startsAt: b.starts_at, status: b.status, customerId: b.customer_id, customer: b.customer })) };
    },
  },
  {
    name: 'read_visit_requests', permission: 'bookings_read', risk: 'low', categories: ['crafts'],
    description: 'List the "come to me" quote requests sent to this craftsperson.',
    schema: { type: 'object', properties: { status: { type: 'string', enum: ['pending', 'accepted', 'declined', 'cancelled', 'done'] } } },
    async handler(ctx, a) {
      const rows = await ctx.db.query(`SELECT id, description, status, distance_m, created_at FROM visit_requests WHERE cook_id = $1 ${a.status ? 'AND status = $2' : ''} ORDER BY id DESC LIMIT 50`, a.status ? [ctx.owner.id, a.status] : [ctx.owner.id]);
      return { requests: rows.map((v) => ({ id: v.id, description: txt(v.description), status: v.status, distanceM: v.distance_m, createdAt: v.created_at })) };
    },
  },
  {
    name: 'create_booking_within_rules', permission: 'bookings_create', risk: 'medium', categories: ['shops', 'crafts'],
    description: 'Book an appointment for one of YOUR existing customers: in the future, within opening hours, not overlapping another one.',
    schema: { type: 'object', required: ['customerId', 'service', 'startsAt'], properties: { customerId: S.id, service: { type: 'string', maxLength: 100 }, startsAt: { type: 'string', maxLength: 40 }, note: { type: 'string', maxLength: 300 } } },
    summary: (a) => `${a.service} @ ${a.startsAt}`,
    async validate(ctx, a) {
      const d = new Date(a.startsAt);
      if (Number.isNaN(d.getTime()) || d.getTime() < Date.now() + 15 * 60_000 || d.getTime() > Date.now() + 60 * DAY) throw new HttpError(422, 'validation_failed', { fields: { startsAt: 'invalid' } });
      if (a.service.length < 2 || hasProfanity(a.service) || (a.note && hasProfanity(a.note))) throw new HttpError(422, 'validation_failed', { fields: { service: 'invalid' } });
      if (!ctx.owner.booking) throw new HttpError(409, 'booking_not_in_plan');
      const hours = parseJson(ctx.owner.hours);
      if (hours && isOpenNow(hours, 'Asia/Beirut', d) === false) throw new HttpError(409, 'outside_opening_hours');
      // only a real customer of this subscriber (ordered, booked or asked a visit before)
      const known = await ctx.db.one(`SELECT 1 AS x FROM orders WHERE cook_id = $1 AND customer_id = $2
        UNION SELECT 1 FROM appointments WHERE cook_id = $1 AND customer_id = $2 UNION SELECT 1 FROM visit_requests WHERE cook_id = $1 AND customer_id = $2`, [ctx.owner.id, a.customerId]);
      if (!known) throw new HttpError(404, 'not_found');
      const clash = await ctx.db.one(`SELECT id FROM appointments WHERE cook_id = $1 AND status IN ('pending','confirmed') AND starts_at > $2 AND starts_at < $3`, [ctx.owner.id, iso(new Date(d.getTime() - 30 * 60_000)), iso(new Date(d.getTime() + 30 * 60_000))]);
      if (clash) throw new HttpError(409, 'slot_taken');
    },
    async handler(ctx, a) {
      await this.validate(ctx, a);   // re-checked at execution (an approval may come hours later)
      const row = await ctx.db.one(`INSERT INTO appointments (cook_id, customer_id, service, starts_at, note, status, decided_at) VALUES ($1,$2,$3,$4,$5,'confirmed',$6) RETURNING id`,
        [ctx.owner.id, a.customerId, a.service, new Date(a.startsAt).toISOString(), a.note || null, iso()]);
      ctx.push?.notify?.('customer', a.customerId, { title: 'Aklatak', key: 'ai_booking_created', vars: { store: ctx.owner.name }, body: `📅 ${ctx.owner.name}: حُجز لك موعد`, url: '/#/bookings' });
      return { appointmentId: row.id, status: 'confirmed' };
    },
  },
  {
    name: 'send_reminder', permission: 'bookings_reminders', risk: 'medium', categories: ['shops', 'crafts'],
    description: 'Remind the customer of an upcoming appointment (once per appointment).',
    schema: { type: 'object', required: ['appointmentId'], properties: { appointmentId: S.id } },
    summary: (a) => `#B${a.appointmentId}`,
    async handler(ctx, a) {
      const ap = await own(ctx.db, `SELECT id, customer_id, status, starts_at FROM appointments WHERE id = $1 AND cook_id = $2`, [a.appointmentId, ctx.owner.id]);
      if (!['pending', 'confirmed'].includes(ap.status) || Date.parse(ap.starts_at) < Date.now()) throw new HttpError(409, 'invalid_state');
      if (!(await onceKey(ctx.db, `remind:${ap.id}`, 'booking_reminder', ctx.owner))) return { sent: false, reason: 'already_sent' };
      ctx.push?.notify?.('customer', ap.customer_id, { title: 'Aklatak', key: 'ai_booking_reminder', vars: { ref: `#B${ap.id}`, store: ctx.owner.name }, body: TEMPLATE_AR.booking_reminder(`#B${ap.id}`, ctx.owner.name), url: '/#/bookings' });
      return { sent: true, appointmentId: ap.id };
    },
  },
  {
    name: 'propose_reschedule', permission: 'bookings_reschedule', risk: 'medium', categories: ['shops', 'crafts'],
    description: 'Propose a new time to the customer (the appointment time itself does not change until the customer agrees).',
    schema: { type: 'object', required: ['appointmentId', 'startsAt'], properties: { appointmentId: S.id, startsAt: { type: 'string', maxLength: 40 } } },
    summary: (a) => `#B${a.appointmentId} → ${a.startsAt}`,
    async handler(ctx, a) {
      const d = new Date(a.startsAt);
      if (Number.isNaN(d.getTime()) || d.getTime() < Date.now() + 15 * 60_000 || d.getTime() > Date.now() + 60 * DAY) throw new HttpError(422, 'validation_failed', { fields: { startsAt: 'invalid' } });
      const ap = await own(ctx.db, 'SELECT id, customer_id, status FROM appointments WHERE id = $1 AND cook_id = $2', [a.appointmentId, ctx.owner.id]);
      if (!['pending', 'confirmed'].includes(ap.status)) throw new HttpError(409, 'invalid_state');
      await ctx.db.query('UPDATE appointments SET store_reply = $1 WHERE id = $2 AND cook_id = $3', [`📅 ${d.toISOString().slice(0, 16).replace('T', ' ')} UTC ?`, ap.id, ctx.owner.id]);
      ctx.push?.notify?.('customer', ap.customer_id, { title: 'Aklatak', key: 'ai_reschedule', vars: { store: ctx.owner.name }, body: `📅 ${ctx.owner.name} يقترح موعداً جديداً`, url: '/#/bookings' });
      return { proposed: d.toISOString(), appointmentId: ap.id };
    },
  },
  {
    name: 'read_errands', permission: 'orders_read', risk: 'low', categories: ['drivers'],
    description: "List the driver's direct customer requests (errands) and their status.",
    schema: { type: 'object', properties: { status: { type: 'string', enum: ['assigned', 'picked_up', 'delivered', 'cancelled'] }, limit: S.limit } },
    async handler(ctx, a) {
      const rows = await ctx.db.query(`SELECT id, kind, status, price, description, created_at, delivered_at FROM errands WHERE driver_id = $1 ${a.status ? 'AND status = $2' : ''} ORDER BY id DESC LIMIT ${a.limit || 20}`, a.status ? [ctx.owner.id, a.status] : [ctx.owner.id]);
      return { errands: rows.map((e) => ({ id: e.id, kind: e.kind, status: e.status, price: Number(e.price), description: txt(e.description), createdAt: e.created_at, deliveredAt: e.delivered_at })) };
    },
  },
  {
    name: 'earnings_report', permission: 'reports_sales', risk: 'low', categories: ['drivers'],
    description: "The driver's earnings for a day / week / month (read-only).",
    schema: { type: 'object', properties: { period: S.period } },
    async handler(ctx, a) { return salesReport(ctx.db, ctx.owner, a.period || 'day'); },
  },
  {
    name: 'sales_report', permission: 'reports_sales', risk: 'low', categories: ['shops', 'online', 'crafts'],
    description: 'Sales report for a day / week / month from the orders.',
    schema: { type: 'object', properties: { period: S.period } },
    async handler(ctx, a) { return salesReport(ctx.db, ctx.owner, a.period || 'day'); },
  },
  {
    name: 'detect_problems', permission: 'reports_problems', risk: 'low', categories: ['shops', 'online', 'crafts', 'drivers'],
    description: 'Find problems: orders waiting too long, late preparation, many rejections/cancellations, unanswered bookings.',
    schema: S.none,
    async handler(ctx) { return { problems: await detectProblems(ctx.db, ctx.owner) }; },
  },
  {
    name: 'draft_marketing_text', permission: 'marketing_draft', risk: 'low', categories: ['shops', 'online', 'crafts', 'drivers'],
    description: 'Write a short marketing text (returned as text; nothing is sent).',
    schema: { type: 'object', properties: { topic: { type: 'string', maxLength: 120 }, itemId: S.id } },
    async handler(ctx, a) {
      let subject = a.topic || '';
      if (a.itemId) subject = (await own(ctx.db, 'SELECT name FROM menu_items WHERE id = $1 AND cook_id = $2', [a.itemId, ctx.owner.id])).name;
      if (hasProfanity(subject)) subject = '';
      const s = ctx.owner.name;
      const draft = ({
        ar: `✨ ${s}${subject ? ` — ${subject}` : ''}: جودة تستحق التجربة! اطلب الآن عبر أكلتك واستمتع بخدمة سريعة.`,
        en: `✨ ${s}${subject ? ` — ${subject}` : ''}: quality worth trying! Order now on Aklatak for fast service.`,
        fr: `✨ ${s}${subject ? ` — ${subject}` : ''} : une qualité à découvrir ! Commandez sur Aklatak.`,
        es: `✨ ${s}${subject ? ` — ${subject}` : ''}: ¡calidad que vale la pena! Pide ahora en Aklatak.`,
      })[ctx.lang] || s;
      return { draft, note: 'text only — nothing was sent' };
    },
  },
  {
    name: 'escalate_to_human', permission: 'cs_escalate', risk: 'low', categories: ['shops', 'online', 'crafts', 'drivers'],
    description: 'Create a task for the subscriber when something needs a human decision.',
    schema: { type: 'object', required: ['reason'], properties: { reason: { type: 'string', maxLength: 300 } } },
    summary: (a) => String(a.reason).slice(0, 60),
    async handler(ctx, a) {
      const key = `human:${ctx.owner.type}:${ctx.owner.id}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
      const r = await ctx.db.one(`INSERT INTO ai_tasks (task_key, kind, owner_type, owner_id, ref, status, result, updated_at) VALUES ($1,'human',$2,$3,$4,'open',$5,$6) RETURNING id`,
        [key, ctx.owner.type, ctx.owner.id, null, a.reason, iso()]);
      ctx.push?.notify?.(ctx.owner.type, ctx.owner.id, { title: 'Aklatak', key: 'ai_task', vars: {}, body: '🤖 المدير الذكي يحتاج قرارك', url: ctx.owner.type === 'driver' ? '/driver' : '/store' });
      return { taskId: r.id };
    },
  },
];

// The customer-service assistant (the business's public assistant) gets ONLY these read-only tools,
// scoped to that store and to the customer's OWN orders.
export const CUSTOMER_TOOLS = [
  {
    name: 'cs_catalog', permission: 'cs_assistant', risk: 'low', categories: ['shops', 'online', 'crafts'],
    description: "The store's available products / services with prices.",
    schema: S.none,
    async handler(ctx) {
      const rows = await ctx.db.query('SELECT id, name, description, price, currency FROM menu_items WHERE cook_id = $1 AND is_available = 1 ORDER BY sort_order, id LIMIT 100', [ctx.owner.id]);
      return { items: rows.map((i) => ({ name: i.name, description: txt(i.description), price: i.price == null ? null : Number(i.price), currency: i.currency })) };
    },
  },
  {
    name: 'cs_my_orders', permission: 'cs_assistant', risk: 'low', categories: ['shops', 'online', 'crafts'],
    description: "The status of the customer's own orders with this store.",
    schema: S.none,
    async handler(ctx) {
      const rows = await ctx.db.query(`SELECT id, status, total, currency, created_at FROM orders WHERE cook_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 10`, [ctx.owner.id, ctx.customerId]);
      return { orders: rows.map((o) => ({ ref: ref(o.id), status: o.status, total: Number(o.total), currency: o.currency, createdAt: o.created_at })) };
    },
  },
];

const ALL_TOOLS = Object.fromEntries([...TOOLS, ...CUSTOMER_TOOLS].map((t) => [t.name, t]));
export const toolByName = (name) => (Object.prototype.hasOwnProperty.call(ALL_TOOLS, name) ? ALL_TOOLS[name] : null);
export const toolsFor = (category) => TOOLS.filter((t) => t.categories.includes(category));
/** Tool definitions in the provider's format (name, description, input_schema). */
export const toolDefs = (list) => list.map((t) => ({ name: t.name, description: t.description, input_schema: t.schema }));
