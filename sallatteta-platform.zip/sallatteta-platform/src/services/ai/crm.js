// CRM preparation (for the future AI marketing), strictly per subscriber.
// Rules: a contact exists ONLY because that customer really ordered / booked / used this subscriber; contacts are created
// from those records automatically (sync). There is NO import, NO scraping and NO purchased lists — on purpose there is
// no endpoint that accepts a list of people. Marketing consent is OFF until the customer gives it; an opt-out or a
// deletion by the customer is remembered (crm_consents) so a later sync never brings the person back from old orders.
import { HttpError } from '../../lib/http.js';

const iso = (d = new Date()) => d.toISOString();
const ms = (v) => (v instanceof Date ? v.getTime() : Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(String(v)) ? String(v) : `${String(v).replace(' ', 'T')}Z`));

/** Who really used this subscriber: [{ customer_id, n, first, last, source }]. */
async function realCustomers(db, owner) {
  if (owner.type === 'driver') {
    return (await db.query(`SELECT customer_id, CAST(COUNT(*) AS INTEGER) AS n, MIN(created_at) AS first, MAX(created_at) AS last FROM errands
      WHERE driver_id = $1 AND status IN ('assigned','picked_up','delivered') GROUP BY customer_id`, [owner.id])).map((r) => ({ ...r, source: 'errand' }));
  }
  const rows = [];
  for (const [sql, source] of [
    [`SELECT customer_id, CAST(COUNT(*) AS INTEGER) AS n, MIN(created_at) AS first, MAX(created_at) AS last FROM orders WHERE cook_id = $1 AND (accepted_at IS NOT NULL OR status = 'delivered') GROUP BY customer_id`, 'order'],
    [`SELECT customer_id, CAST(COUNT(*) AS INTEGER) AS n, MIN(created_at) AS first, MAX(created_at) AS last FROM appointments WHERE cook_id = $1 AND status IN ('confirmed','done') GROUP BY customer_id`, 'appointment'],
    [`SELECT customer_id, CAST(COUNT(*) AS INTEGER) AS n, MIN(created_at) AS first, MAX(created_at) AS last FROM visit_requests WHERE cook_id = $1 AND status IN ('accepted','done') GROUP BY customer_id`, 'visit'],
  ]) for (const r of await db.query(sql, [owner.id])) rows.push({ ...r, source });
  const by = new Map();
  for (const r of rows) {
    const p = by.get(r.customer_id);
    if (!p) by.set(r.customer_id, { ...r });
    else { p.n += r.n; if (ms(r.first) < ms(p.first)) p.first = r.first; if (ms(r.last) > ms(p.last)) p.last = r.last; }
  }
  return [...by.values()];
}

/** Creates / refreshes contacts from real orders. Honors deletions (tombstones) and marketing opt-outs. */
export async function syncContacts(db, owner) {
  const deleted = new Map();
  for (const c of await db.query(`SELECT customer_id, MAX(created_at) AS at FROM crm_consents WHERE owner_type = $1 AND owner_id = $2 AND kind = 'operational' AND granted = 0 GROUP BY customer_id`, [owner.type, owner.id])) deleted.set(c.customer_id, ms(c.at));
  let added = 0;
  for (const r of await realCustomers(db, owner)) {
    if (deleted.has(r.customer_id) && deleted.get(r.customer_id) >= ms(r.last)) continue;   // deleted, no new order since
    const name = (await db.one('SELECT name FROM customers WHERE id = $1', [r.customer_id]))?.name || null;
    const ins = await db.query(`INSERT INTO crm_contacts (owner_type, owner_id, customer_id, name, source, orders_count, first_at, last_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      ON CONFLICT (owner_type, owner_id, customer_id) DO UPDATE SET orders_count = EXCLUDED.orders_count, last_at = EXCLUDED.last_at, updated_at = EXCLUDED.updated_at RETURNING id, created_at`,
    [owner.type, owner.id, r.customer_id, name, r.source, r.n, new Date(ms(r.first)).toISOString(), new Date(ms(r.last)).toISOString(), iso()]);
    if (ins.length && !(await db.one(`SELECT id FROM crm_events WHERE owner_type = $1 AND owner_id = $2 AND customer_id = $3 AND kind = 'created' AND created_at >= $4`, [owner.type, owner.id, r.customer_id, ins[0].created_at]))) {
      await db.query(`INSERT INTO crm_events (owner_type, owner_id, customer_id, kind, details) VALUES ($1,$2,$3,'created',$4)`, [owner.type, owner.id, r.customer_id, r.source]);
      added += 1;
    }
  }
  // marketing opt-outs always win
  await db.query(`UPDATE crm_contacts SET opted_out = 1, mkt_consent = 0 WHERE owner_type = $1 AND owner_id = $2 AND customer_id IN
    (SELECT customer_id FROM crm_consents WHERE owner_type = $1 AND owner_id = $2 AND kind = 'marketing' AND granted = 0)`, [owner.type, owner.id]);
  return { added };
}

export async function listContacts(db, owner) {
  await syncContacts(db, owner);
  return db.query(`SELECT id, name, source, orders_count, first_at, last_at, op_consent, mkt_consent, opted_out FROM crm_contacts WHERE owner_type = $1 AND owner_id = $2 ORDER BY last_at DESC, id DESC LIMIT 2000`, [owner.type, owner.id]);
}

/** The subscriber corrects a contact's name (nothing else is editable: consent belongs to the customer). */
export async function correctContact(db, owner, id, name) {
  const r = await db.query('UPDATE crm_contacts SET name = $1, updated_at = $2 WHERE id = $3 AND owner_type = $4 AND owner_id = $5 RETURNING customer_id', [name, iso(), id, owner.type, owner.id]);
  if (!r.length) throw new HttpError(404, 'not_found');
  await db.query(`INSERT INTO crm_events (owner_type, owner_id, customer_id, kind, details) VALUES ($1,$2,$3,'corrected',NULL)`, [owner.type, owner.id, r[0].customer_id]);
  return { id };
}

async function forget(db, owner, customerId, source) {
  await db.query('DELETE FROM crm_contacts WHERE owner_type = $1 AND owner_id = $2 AND customer_id = $3', [owner.type, owner.id, customerId]);
  await db.query(`INSERT INTO crm_consents (owner_type, owner_id, customer_id, kind, granted, source) VALUES ($1,$2,$3,'operational',0,$4)`, [owner.type, owner.id, customerId, source]);
  await db.query(`INSERT INTO crm_events (owner_type, owner_id, customer_id, kind, details) VALUES ($1,$2,$3,'deleted',$4)`, [owner.type, owner.id, customerId, source]);
}
export async function deleteContact(db, owner, id) {
  const c = await db.one('SELECT customer_id FROM crm_contacts WHERE id = $1 AND owner_type = $2 AND owner_id = $3', [id, owner.type, owner.id]);
  if (!c) throw new HttpError(404, 'not_found');
  await forget(db, owner, c.customer_id, 'subscriber_delete');
  return { deleted: true };
}

export function contactsCsv(rows) {
  const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const head = ['id', 'name', 'source', 'orders', 'first', 'last', 'marketing_consent', 'opted_out'];
  return '﻿' + [head.join(','), ...rows.map((r) => [r.id, r.name, r.source, r.orders_count, r.first_at, r.last_at, r.mkt_consent, r.opted_out].map(q).join(','))].join('\n');
}

/** Customer: no marketing from this subscriber (operational messages about his own orders continue). */
export async function customerOptOut(db, customerId, owner) {
  await db.query(`INSERT INTO crm_consents (owner_type, owner_id, customer_id, kind, granted, source) VALUES ($1,$2,$3,'marketing',0,'customer')`, [owner.type, owner.id, customerId]);
  await db.query('UPDATE crm_contacts SET opted_out = 1, mkt_consent = 0, updated_at = $1 WHERE owner_type = $2 AND owner_id = $3 AND customer_id = $4', [iso(), owner.type, owner.id, customerId]);
  await db.query(`INSERT INTO crm_events (owner_type, owner_id, customer_id, kind, details) VALUES ($1,$2,$3,'opt_out','marketing')`, [owner.type, owner.id, customerId]);
  return { optedOut: true };
}
/** Customer: delete his contact with this subscriber (or with every subscriber when owner is null). */
export async function customerDelete(db, customerId, owner = null) {
  const owners = owner ? [owner] : (await db.query('SELECT owner_type AS type, owner_id AS id FROM crm_contacts WHERE customer_id = $1', [customerId]));
  for (const o of owners) await forget(db, o, customerId, 'customer_delete');
  return { deleted: owners.length };
}
