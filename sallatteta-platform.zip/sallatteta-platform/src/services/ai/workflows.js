// Durable AI jobs (run by src/jobs.js with the usual leases): reminders for orders waiting too long or late in
// preparation, booking reminders, daily / weekly reports. Each operation has a unique key in ai_tasks, so it runs
// at most once whatever the number of runs or instances; failures are retried with backoff and escalated to the
// subscriber after N tries. These jobs only READ orders and notify — they never change an order, so an AI failure
// can never block ordinary order processing (and they don't call any AI provider).
import { getAiConfig, aiCategory } from './entitlement.js';
import { getSettings, decide, PERM } from './permissions.js';
import { TOOLS, salesReport } from './tools.js';
import { aiWatch } from './budget.js';

const MIN = 60_000, DAY = 86_400_000;
const iso = (d = new Date()) => d.toISOString();
const ref = (id) => `AKL${id}`;
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('task timeout')), ms).unref?.())]);
const backoff = (attempt) => Math.min(60, 2 ** attempt) * MIN;   // 2, 4, 8 … minutes, at most an hour

/** Subscribers who may use AI right now (paid, global + category switches on, own master switch on). */
export async function aiOwners(db, now = new Date()) {
  const cfg = await getAiConfig(db);
  if (!cfg.enabled) return { owners: [], config: cfg };
  const t = iso(now);
  const out = [];
  for (const c of await db.query(`SELECT id, full_name, kind, locale, hours, booking FROM cooks WHERE ai_until > $1`, [t])) {
    const category = aiCategory(c.kind || 'cook');
    if (cfg.categories[category]) out.push({ type: 'store', id: c.id, name: c.full_name, kind: c.kind || 'cook', locale: c.locale, hours: c.hours, booking: !!Number(c.booking), category });
  }
  if (cfg.categories.drivers) {
    for (const d of await db.query(`SELECT id, full_name, locale FROM drivers WHERE ai_until > $1`, [t])) out.push({ type: 'driver', id: d.id, name: d.full_name, kind: 'driver', locale: d.locale, category: 'drivers' });
  }
  const ready = [];
  for (const o of out) {
    const st = await getSettings(db, o.type, o.id, o.category);
    if (st.enabled) ready.push({ ...o, levels: st.levels });
  }
  return { owners: ready, config: cfg };
}

// What each kind of task does (also used again by the retries).
const HANDLERS = {
  async late_order({ db, push, owner, ref: r }) {
    const o = await db.one('SELECT id, status FROM orders WHERE id = $1 AND cook_id = $2', [Number(r), owner.id]);
    if (!o || o.status !== 'pending') return { skipped: 'resolved' };
    push.notify('store', owner.id, { title: 'Aklatak', key: 'ai_order_waiting', vars: { ref: ref(o.id) }, body: `🤖 الطلب ${ref(o.id)} ينتظر قبولك منذ مدة`, url: '/store' });
    return { notified: true };
  },
  async prep_late({ db, push, owner, ref: r }) {
    const o = await db.one('SELECT id, status FROM orders WHERE id = $1 AND cook_id = $2', [Number(r), owner.id]);
    if (!o || o.status !== 'preparing') return { skipped: 'resolved' };
    push.notify('store', owner.id, { title: 'Aklatak', key: 'ai_prep_late', vars: { ref: ref(o.id) }, body: `🤖 تحضير الطلب ${ref(o.id)} تجاوز الوقت المتوقع`, url: '/store' });
    return { notified: true };
  },
  async booking_reminder({ db, push, owner, ref: r }) {
    const tool = TOOLS.find((t) => t.name === 'send_reminder');
    return tool.handler({ db, push, owner, lang: owner.locale || 'ar' }, { appointmentId: Number(r) });
  },
};

async function log(db, owner, tool, decision, result) {
  await db.query(`INSERT INTO ai_actions (owner_type, owner_id, actor, tool, risk, args_summary, result_summary, decision) VALUES ($1,$2,'workflow',$3,'low',NULL,$4,$5)`,
    [owner.type, owner.id, tool, JSON.stringify(result ?? null).slice(0, 300), decision]);
}

/** Runs one keyed task at most once. Returns 'done' | 'failed' | 'skipped' (already exists). */
export async function runTask({ db, push, owner, kind, ref: r, key, timeoutMs = 10_000, now = new Date() }) {
  const ins = await db.query(`INSERT INTO ai_tasks (task_key, kind, owner_type, owner_id, ref, status, attempts, updated_at) VALUES ($1,$2,$3,$4,$5,'running',1,$6)
    ON CONFLICT (task_key) DO NOTHING RETURNING id`, [key, kind, owner.type, owner.id, String(r), iso(now)]);
  if (!ins.length) return 'skipped';
  return execTask({ db, push, owner, kind, ref: r, id: ins[0].id, attempt: 1, timeoutMs, now });
}

async function execTask({ db, push, owner, kind, ref: r, id, attempt, timeoutMs, now, maxFailures = 3 }) {
  try {
    const result = await withTimeout(HANDLERS[kind]({ db, push, owner, ref: r }), timeoutMs);
    await db.query(`UPDATE ai_tasks SET status = 'done', result = $1, updated_at = $2 WHERE id = $3`, [JSON.stringify(result).slice(0, 500), iso(), id]);
    await log(db, owner, kind, 'executed', result);
    return 'done';
  } catch (e) {
    if (attempt >= maxFailures) {
      // escalation: the subscriber gets a task to handle it himself
      await db.query(`UPDATE ai_tasks SET status = 'escalated', last_error = $1, updated_at = $2 WHERE id = $3`, [String(e.message).slice(0, 300), iso(), id]);
      await db.query(`INSERT INTO ai_tasks (task_key, kind, owner_type, owner_id, ref, status, result, updated_at) VALUES ($1,'human',$2,$3,$4,'open',$5,$6) ON CONFLICT (task_key) DO NOTHING`,
        [`escalate:${id}`, owner.type, owner.id, String(r), `${kind} failed ${attempt} times`, iso()]);
      await log(db, owner, kind, 'failed', { escalated: true, error: e.message });
      return 'failed';
    }
    await db.query(`UPDATE ai_tasks SET status = 'failed', last_error = $1, next_at = $2, updated_at = $3 WHERE id = $4`, [String(e.message).slice(0, 300), iso(new Date(now.getTime() + backoff(attempt))), iso(), id]);
    return 'failed';
  }
}

/** Failed tasks whose wait is over: claimed one by one (only one runner wins each claim). */
export async function retryFailed({ db, push, owners, now = new Date(), maxFailures = 3 }) {
  let n = 0;
  const byKey = new Map(owners.map((o) => [`${o.type}:${o.id}`, o]));
  for (const t of await db.query(`SELECT id, kind, owner_type, owner_id, ref, attempts FROM ai_tasks WHERE status = 'failed' AND next_at <= $1 ORDER BY id LIMIT 50`, [iso(now)])) {
    const owner = byKey.get(`${t.owner_type}:${t.owner_id}`);
    if (!owner || !HANDLERS[t.kind]) continue;   // no AI any more: left as it is
    const got = await db.query(`UPDATE ai_tasks SET status = 'running', attempts = attempts + 1, updated_at = $1 WHERE id = $2 AND status = 'failed' RETURNING attempts`, [iso(now), t.id]);
    if (!got.length) continue;
    await execTask({ db, push, owner, kind: t.kind, ref: t.ref, id: t.id, attempt: got[0].attempts, timeoutMs: 10_000, now, maxFailures });
    n += 1;
  }
  return n;
}

/** The event-driven reminders. Safe to run every minute on any number of instances. */
export async function runAiWorkflows({ db, push, now = new Date() }) {
  const out = { lateOrders: 0, prepLate: 0, bookingReminders: 0, bookingApprovals: 0, retried: 0, errors: 0 };
  if (!push) return out;
  const { owners, config } = await aiOwners(db, now);
  if (!owners.length) return out;
  const w = config.workflow;
  const t = now.getTime();
  for (const owner of owners) {
    try {
      if (owner.type === 'store' && ['shops', 'online'].includes(owner.category) && (owner.levels.orders_alerts || 'OFF') !== 'OFF') {
        const late = await db.query(`SELECT id FROM orders WHERE cook_id = $1 AND status = 'pending' AND payment_status NOT IN ('pending','failed') AND created_at <= $2 AND created_at >= $3`,
          [owner.id, iso(new Date(t - w.waitMin * MIN)), iso(new Date(t - DAY))]);
        for (const o of late) if (await runTask({ db, push, owner, kind: 'late_order', ref: o.id, key: `late_order:${o.id}`, now }) === 'done') out.lateOrders += 1;
        const prep = await db.query(`SELECT id FROM orders WHERE cook_id = $1 AND status = 'preparing' AND accepted_at <= $2 AND accepted_at >= $3`,
          [owner.id, iso(new Date(t - w.prepMin * MIN)), iso(new Date(t - DAY))]);
        for (const o of prep) if (await runTask({ db, push, owner, kind: 'prep_late', ref: o.id, key: `prep_late:${o.id}`, now }) === 'done') out.prepLate += 1;
      }
      if (owner.type === 'store' && PERM.bookings_reminders.categories.includes(owner.category)) {
        const d = decide(owner.levels.bookings_reminders, PERM.bookings_reminders);
        if (d.decision !== 'deny') {
          const soon = await db.query(`SELECT id FROM appointments WHERE cook_id = $1 AND status = 'confirmed' AND starts_at > $2 AND starts_at <= $3`, [owner.id, iso(now), iso(new Date(t + w.bookingRemindMin * MIN))]);
          for (const a of soon) {
            if (d.decision === 'execute') {
              if (await runTask({ db, push, owner, kind: 'booking_reminder', ref: a.id, key: `booking_reminder:${a.id}`, now }) === 'done') out.bookingReminders += 1;
            } else {
              // ASK_APPROVAL: one approval request per appointment (the key stops duplicates)
              const k = await db.query(`INSERT INTO ai_tasks (task_key, kind, owner_type, owner_id, ref, status, updated_at) VALUES ($1,'booking_reminder_approval',$2,$3,$4,'done',$5) ON CONFLICT (task_key) DO NOTHING RETURNING id`,
                [`booking_reminder_approval:${a.id}`, owner.type, owner.id, String(a.id), iso(now)]);
              if (k.length) {
                await db.query(`INSERT INTO ai_approvals (owner_type, owner_id, tool, args, reason) VALUES ($1,$2,'send_reminder',$3,'workflow')`, [owner.type, owner.id, JSON.stringify({ appointmentId: a.id })]);
                out.bookingApprovals += 1;
              }
            }
          }
        }
      }
    } catch (e) { out.errors += 1; }   // one subscriber's problem never stops the others
  }
  out.retried = await retryFailed({ db, push, owners, now, maxFailures: w.maxFailures });
  return out;
}

const dayKey = (d) => d.toISOString().slice(0, 10);
function weekStart(d) {   // Monday 00:00 UTC of d's week
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7));
  return x;
}

/** Yesterday's daily report and last week's weekly report (each saved once: unique key). */
export async function runAiReports({ db, now = new Date() }) {
  const out = { daily: 0, weekly: 0 };
  const { owners } = await aiOwners(db, now);
  const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const yesterday = new Date(today.getTime() - DAY);
  const thisWeek = weekStart(now), lastWeek = new Date(thisWeek.getTime() - 7 * DAY);
  for (const owner of owners) {
    if ((owner.levels.reports_scheduled || 'OFF') === 'OFF') continue;
    try {
      const save = async (period, key, data) => (await db.query(`INSERT INTO ai_reports (owner_type, owner_id, period, period_key, data) VALUES ($1,$2,$3,$4,$5)
        ON CONFLICT (owner_type, owner_id, period, period_key) DO NOTHING RETURNING id`, [owner.type, owner.id, period, key, JSON.stringify(data)])).length;
      if (!(await db.one('SELECT id FROM ai_reports WHERE owner_type = $1 AND owner_id = $2 AND period = $3 AND period_key = $4', [owner.type, owner.id, 'daily', dayKey(yesterday)]))) {
        out.daily += await save('daily', dayKey(yesterday), await salesReport(db, owner, 'day', today));
      }
      if (!(await db.one('SELECT id FROM ai_reports WHERE owner_type = $1 AND owner_id = $2 AND period = $3 AND period_key = $4', [owner.type, owner.id, 'weekly', dayKey(lastWeek)]))) {
        out.weekly += await save('weekly', dayKey(lastWeek), await salesReport(db, owner, 'week', thisWeek));
      }
    } catch { /* next subscriber */ }
  }
  return out;
}

/** Job definitions for src/jobs.js (leases handled by the job runner). */
export function aiJobs({ db, push }) {
  return [
    { name: 'ai-workflows', everyMs: 60_000, timeoutMs: 120_000, run: async () => runAiWorkflows({ db, push }) },
    { name: 'ai-reports', everyMs: 60 * 60_000, timeoutMs: 5 * 60_000, run: async () => runAiReports({ db }) },
    // v8.2 the owner's AI money: «balance enough for N days», spending vs the AI subscriptions, the platform cap
    { name: 'ai-money-watch', everyMs: 60 * 60_000, timeoutMs: 60_000, run: async () => { const r = await aiWatch({ db, push }); return { alerts: r.alerts.length }; } },
  ];
}
