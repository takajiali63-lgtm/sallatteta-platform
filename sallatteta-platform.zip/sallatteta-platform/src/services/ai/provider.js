// Where the AI's answers come from. Every provider has the same shape (Anthropic Messages style):
//   complete({ system, messages, tools, lang }) → { content: [{type:'text',text} | {type:'tool_use',id,name,input}], usage }
// - 'local' (default): free, deterministic rules in ar/en/fr/es (incl. Lebanese «شو», «قديش», «بدي»), no key, no network.
// - 'anthropic': the Claude API with tool use, a timeout, retries with backoff and a circuit breaker.
// A fake provider can be injected for tests (cfg.aiProviderImpl).

// ---------- language & intents ----------
export function detectLang(text, fallback = 'ar') {
  const s = String(text || '');
  if (/[؀-ۿ]/.test(s)) return 'ar';
  const w = s.toLowerCase();
  if (/[ñ¿¡]|\b(pedidos?|ventas|cuánto|cuanto|quiero|hoy|semana|citas?|mi pedido|ganancias|informe|productos|precio)\b/.test(w)) return 'es';
  if (/[àâçèêëîïôûœ]|\b(commandes?|ventes|combien|je veux|aujourd|semaine|rendez|ma commande|gains|rapport|produits|prix)\b/.test(w)) return 'fr';
  if (/[a-z]/.test(w)) return 'en';
  return fallback;
}
const has = (s, words) => words.some((w) => s.includes(w));
const norm = (s) => String(s || '').toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/[ً-ْـ]/g, '');
const WEEK = ['اسبوع', 'جمعه', 'week', 'semaine', 'semana'];
const MONTH = ['شهر', 'month', 'mois', 'mes '];
const firstInt = (s) => { const m = /(\d{1,9})/.exec(String(s).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))); return m ? Number(m[1]) : null; };

/** Subscriber intents (the manager). Returns [toolName, input] or null. Only tools offered this turn are used. */
export function managerIntent(text, available) {
  const s = norm(text);
  const can = (n) => available.has(n);
  const period = has(s, WEEK) ? 'week' : has(s, MONTH) ? 'month' : 'day';
  const id = firstInt(s);
  const pick = (...opts) => opts.find(([n]) => can(n)) || null;
  if (id && has(s, ['اقبل', 'قبول', 'اقبال', 'accept', 'accepter', 'aceptar', 'acepta'])) return pick(['order_status_update', { orderId: id, to: 'preparing' }]);
  if (has(s, ['مشكل', 'مشاكل', 'متاخر', 'تاخير', 'problem', 'issue', 'late', 'probleme', 'problème', 'retard', 'problema', 'retraso'])) return pick(['detect_problems', {}]);
  if (has(s, ['ارباح', 'ربحت', 'طلعت', 'مدخول', 'earning', 'gains', 'gagné', 'ganancia', 'gané'])) return pick(['earnings_report', { period }], ['sales_report', { period }]);
  if (has(s, ['مبيع', 'بعت', 'بعنا', 'تقرير', 'sales', 'report', 'sold', 'ventes', 'rapport', 'vendu', 'ventas', 'informe', 'vendí'])) return pick(['sales_report', { period }], ['earnings_report', { period }]);
  if (has(s, ['اعلان', 'منشور', 'تسويق', 'بوست', 'marketing', 'post', 'advert', 'publicité', 'publicite', 'annonce', 'anuncio', 'publicidad'])) return pick(['draft_marketing_text', {}]);
  if (id && has(s, ['وصف', 'description', 'descripción', 'descripcion'])) return pick(['suggest_description', { itemId: id }]);
  if (id && has(s, ['سعر', 'اسعار', 'price', 'prix', 'precio'])) return pick(['suggest_price', { itemId: id }]);
  if (has(s, ['موعد', 'مواعيد', 'حجز', 'حجوزات', 'booking', 'appointment', 'rendez', 'réservation', 'reservation', 'cita', 'reserva'])) return pick(['read_bookings', {}], ['read_errands', {}]);
  if (has(s, ['زيار', 'كشف', 'quote', 'visit', 'devis', 'visite', 'presupuesto', 'visita'])) return pick(['read_visit_requests', {}]);
  if (has(s, ['جديد', 'جديده', 'new order', 'pending', 'nouvelle', 'nouvelles', 'nuevo', 'nuevos'])) return pick(['list_new_orders', {}], ['read_errands', { status: 'assigned' }]);
  if (has(s, ['طلب', 'طلبات', 'مشوار', 'مشاوير', 'order', 'errand', 'commande', 'course', 'pedido', 'encargo'])) return pick(['read_orders', {}], ['read_errands', {}]);
  if (has(s, ['منتج', 'منيو', 'قائمه', 'اصناف', 'كتالوج', 'خدمات', 'menu', 'catalog', 'product', 'produit', 'carte', 'producto', 'menú', 'catálogo'])) return pick(['read_catalog', {}]);
  if (has(s, ['انسان', 'موظف', 'حدا يحكي', 'human', 'person', 'humain', 'humano'])) return pick(['escalate_to_human', { reason: String(text).slice(0, 300) }]);
  return null;
}

/** Customer intents (the business's assistant): read-only catalog or his own orders. */
export function customerIntent(text, available) {
  const s = norm(text);
  if (available.has('cs_my_orders') && has(s, ['طلبي', 'طلبيتي', 'وين', 'my order', 'order status', 'ma commande', 'mi pedido', 'pedido', 'commande', 'order'])) return ['cs_my_orders', {}];
  if (available.has('cs_catalog') && has(s, ['شو عند', 'شو في', 'قديش', 'سعر', 'اسعار', 'متوفر', 'متاح', 'عندكم', 'available', 'disponible', 'منيو', 'قائمه', 'منتج', 'بدي', 'menu', 'price', 'have', 'sell', 'prix', 'carte', 'précio', 'precio', 'tienen', 'menú', 'product', 'produit', 'producto'])) return ['cs_catalog', {}];
  return null;
}

// ---------- answers written from tool results (local provider) ----------
const L = {
  none: { ar: 'لا يوجد شيء حالياً.', en: 'Nothing right now.', fr: "Rien pour l'instant.", es: 'Nada por ahora.' },
  help: {
    ar: 'أستطيع مساعدتك في: الطلبات الجديدة، تقرير المبيعات (اليوم/الأسبوع)، المشاكل، المنتجات، المواعيد، ونصوص الإعلانات. اسألني مثلاً: «شو في طلبات جديدة؟» أو «قديش بعت اليوم؟».',
    en: 'I can help with: new orders, sales reports (today/week), problems, products, bookings and marketing texts. Try: "any new orders?" or "how much did I sell today?".',
    fr: 'Je peux aider pour : nouvelles commandes, rapport des ventes (jour/semaine), problèmes, produits, rendez-vous et textes publicitaires.',
    es: 'Puedo ayudar con: pedidos nuevos, informe de ventas (hoy/semana), problemas, productos, citas y textos de marketing.',
  },
  helpCustomer: {
    ar: 'أستطيع أن أعرض لك المنتجات والأسعار، أو حالة طلباتك من هذا المتجر.',
    en: 'I can show you the products and prices, or the status of your orders with this store.',
    fr: "Je peux vous montrer les produits et les prix, ou l'état de vos commandes dans cette boutique.",
    es: 'Puedo mostrarte los productos y precios, o el estado de tus pedidos en esta tienda.',
  },
  queued: { ar: 'جهّزتُ الإجراء وهو بانتظار موافقتك في «الموافقات».', en: 'I prepared it — it is waiting for your approval in "Approvals".', fr: 'C’est préparé et en attente de votre approbation.', es: 'Lo preparé; espera tu aprobación.' },
  denied: { ar: 'لا أملك صلاحية لهذا الإجراء. يمكنك تغييرها من إعدادات المدير الذكي.', en: "I don't have permission for that. You can change it in the AI manager settings.", fr: "Je n'ai pas l'autorisation pour cela. Modifiez-la dans les réglages.", es: 'No tengo permiso para eso. Puedes cambiarlo en los ajustes.' },
  error: { ar: 'تعذّر تنفيذ ذلك: ', en: 'Could not do that: ', fr: 'Impossible : ', es: 'No se pudo: ' },
  done: { ar: 'تمّ ✅', en: 'Done ✅', fr: 'Fait ✅', es: 'Hecho ✅' },
};
const st = {
  pending: { ar: 'بانتظار القبول', en: 'waiting', fr: 'en attente', es: 'pendiente' }, preparing: { ar: 'قيد التحضير', en: 'preparing', fr: 'en préparation', es: 'en preparación' },
  searching: { ar: 'يبحث عن سائق', en: 'finding a driver', fr: 'recherche de livreur', es: 'buscando repartidor' }, assigned: { ar: 'مع السائق', en: 'with the driver', fr: 'avec le livreur', es: 'con el repartidor' },
  picked_up: { ar: 'في الطريق', en: 'on the way', fr: 'en route', es: 'en camino' }, delivered: { ar: 'تم التسليم', en: 'delivered', fr: 'livrée', es: 'entregado' },
  rejected: { ar: 'مرفوض', en: 'rejected', fr: 'refusée', es: 'rechazado' }, cancelled: { ar: 'ملغى', en: 'cancelled', fr: 'annulée', es: 'cancelado' },
  confirmed: { ar: 'مؤكّد', en: 'confirmed', fr: 'confirmé', es: 'confirmada' }, done: { ar: 'منجز', en: 'done', fr: 'terminé', es: 'hecha' },
};
const S = (s, lang) => st[s]?.[lang] || s;
const T = (k, lang) => L[k][lang] || L[k].en;
const P = { day: { ar: 'اليوم', en: 'today', fr: "aujourd'hui", es: 'hoy' }, week: { ar: 'هذا الأسبوع', en: 'this week', fr: 'cette semaine', es: 'esta semana' }, month: { ar: 'هذا الشهر', en: 'this month', fr: 'ce mois', es: 'este mes' } };

export function describeResult(tool, r, lang) {
  if (!r || typeof r !== 'object') return T('done', lang);
  if (r.status === 'queued_for_approval') return T('queued', lang);
  if (r.error) return ['permission_off', 'read_only', 'not_allowed'].includes(r.error) ? T('denied', lang) : T('error', lang) + r.error;
  const lines = (arr, f) => (arr.length ? arr.slice(0, 10).map(f).join('\n') : T('none', lang));
  switch (tool) {
    case 'read_orders': case 'list_new_orders': case 'cs_my_orders':
      return lines(r.orders || [], (o) => `• ${o.ref} — ${S(o.status || 'pending', lang)} — ${o.total} ${o.currency || ''}`);
    case 'read_errands': return lines(r.errands || [], (e) => `• #E${e.id} — ${e.kind} — ${S(e.status, lang)} — ${e.price}`);
    case 'read_catalog': case 'cs_catalog': return lines(r.items || [], (i) => `• ${i.name}${i.price != null ? ` — ${!i.currency || i.currency === 'USD' ? `${i.price}$` : `${i.price} ${i.currency}`}` : ''}`);
    case 'read_bookings': return lines(r.bookings || [], (b) => `• #B${b.id} ${b.service} — ${String(b.startsAt).slice(0, 16).replace('T', ' ')} — ${S(b.status, lang)}`);
    case 'read_visit_requests': return lines(r.requests || [], (v) => `• #V${v.id} — ${S(v.status, lang)} — ${v.description || ''}`);
    case 'sales_report': {
      const p = P[r.period]?.[lang] || r.period;
      return ({ ar: `📊 ${p}: ${r.orders} طلب، سُلِّم ${r.delivered}، رُفض ${r.rejected}، أُلغي ${r.cancelled}. المبيعات: ${r.revenue} ${r.currency}.`,
        en: `📊 ${p}: ${r.orders} orders, ${r.delivered} delivered, ${r.rejected} rejected, ${r.cancelled} cancelled. Sales: ${r.revenue} ${r.currency}.`,
        fr: `📊 ${p} : ${r.orders} commandes, ${r.delivered} livrées, ${r.rejected} refusées. Ventes : ${r.revenue} ${r.currency}.`,
        es: `📊 ${p}: ${r.orders} pedidos, ${r.delivered} entregados, ${r.rejected} rechazados. Ventas: ${r.revenue} ${r.currency}.` })[lang];
    }
    case 'earnings_report': {
      const p = P[r.period]?.[lang] || r.period;
      return ({ ar: `💵 ${p}: ${r.totalEarnings}$ (توصيل المتاجر ${r.storeDeliveryEarnings}$، طلبات الزبائن ${r.customerRequestEarnings}$).`,
        en: `💵 ${p}: ${r.totalEarnings}$ (store deliveries ${r.storeDeliveryEarnings}$, customer requests ${r.customerRequestEarnings}$).`,
        fr: `💵 ${p} : ${r.totalEarnings}$ (livraisons ${r.storeDeliveryEarnings}$, demandes ${r.customerRequestEarnings}$).`,
        es: `💵 ${p}: ${r.totalEarnings}$ (entregas ${r.storeDeliveryEarnings}$, encargos ${r.customerRequestEarnings}$).` })[lang];
    }
    case 'detect_problems': return lines(r.problems || [], (x) => `⚠️ ${x.type}${x.ref ? ` ${x.ref}` : ''}${x.count ? ` (${x.count})` : ''}`);
    case 'suggest_description': return `✍️ ${r.suggestion}`;
    case 'suggest_price': return `💡 ${r.name}: ${r.currentPrice} → ${r.suggestedPrice} ${r.currency || ''}`;
    case 'draft_marketing_text': return r.draft;
    default: return T('done', lang);
  }
}

/** Deterministic provider: one intent per message → one tool call, then an answer written from the tool result. */
export function createLocalProvider() {
  return {
    name: 'local',
    async complete({ messages, tools, lang: fallbackLang = 'ar', mode = 'manager' }) {
      const last = messages[messages.length - 1];
      const userMsg = [...messages].reverse().find((m) => m.role === 'user' && typeof m.content === 'string');
      const lang = detectLang(userMsg?.content, fallbackLang);
      if (Array.isArray(last?.content) && last.content.some((c) => c.type === 'tool_result')) {
        // answer from the results (tool outputs are data: they are only formatted, never obeyed)
        const calls = Object.fromEntries(messages.flatMap((m) => (Array.isArray(m.content) ? m.content : [])).filter((c) => c.type === 'tool_use').map((c) => [c.id, c.name]));
        const text = last.content.filter((c) => c.type === 'tool_result').map((c) => {
          let data; try { data = JSON.parse(c.content); } catch { data = null; }
          return describeResult(calls[c.tool_use_id], data?.data ?? data, lang);
        }).join('\n\n');
        return { content: [{ type: 'text', text }], usage: { input_tokens: 0, output_tokens: 0 } };
      }
      const available = new Set((tools || []).map((t) => t.name));
      const intent = (mode === 'customer' ? customerIntent : managerIntent)(userMsg?.content || '', available);
      if (!intent) return { content: [{ type: 'text', text: T(mode === 'customer' ? 'helpCustomer' : 'help', lang) }], usage: { input_tokens: 0, output_tokens: 0 } };
      return { content: [{ type: 'tool_use', id: `local_${Date.now().toString(36)}`, name: intent[0], input: intent[1] }], usage: { input_tokens: 0, output_tokens: 0 } };
    },
  };
}

// ---------- Anthropic (Claude) ----------
export function createAnthropicProvider({ apiKey, model = 'claude-sonnet-5-5', fetchImpl = globalThis.fetch, timeoutMs = 20_000, retries = 2, backoffMs = 500,
  breakerThreshold = 5, breakerCooldownMs = 60_000, maxTokens = 1024, now = () => Date.now() } = {}) {
  let failures = 0, openUntil = 0;
  const err = (code) => Object.assign(new Error(code), { code });
  async function once(body) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      const r = await fetchImpl('https://api.anthropic.com/v1/messages', {
        method: 'POST', signal: ctl.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify(body),
      });
      if (r.status === 429 || r.status >= 500) throw Object.assign(err('ai_upstream'), { retry: true, status: r.status });
      // 401/403 = a wrong or revoked key; 400 with «credit balance» = the account ran out of credit
      if (r.status === 401 || r.status === 403) throw Object.assign(err('ai_key_invalid'), { retry: false, status: r.status });
      if (!r.ok) {
        let detail = ''; try { detail = JSON.stringify(await r.json()).slice(0, 300); } catch { /* none */ }
        throw Object.assign(err(/credit|balance|billing/i.test(detail) ? 'ai_no_credit' : 'ai_upstream'), { retry: false, status: r.status });
      }
      return await r.json();
    } catch (e) {
      if (e.name === 'AbortError') throw Object.assign(err('ai_timeout'), { retry: true });
      if (!e.code) throw Object.assign(err('ai_network'), { retry: true });
      throw e;
    } finally { clearTimeout(timer); }
  }
  return {
    name: 'anthropic', model,
    get breakerOpen() { return now() < openUntil; },
    async complete({ system, messages, tools, model: useModel = null }) {
      if (!apiKey) throw err('ai_not_configured');
      if (now() < openUntil) throw err('ai_unavailable');   // circuit open: fail fast, don't pile up requests
      // v8.2 prompt caching: the instructions and the tools are the same on every message → the API keeps them and
      // charges a small fraction for them after the first time (the last tool / the system block carry the mark)
      const sys = system ? [{ type: 'text', text: String(system), cache_control: { type: 'ephemeral' } }] : undefined;
      const tl = tools?.length ? tools.map((t, i) => (i === tools.length - 1 ? { ...t, cache_control: { type: 'ephemeral' } } : t)) : null;
      const body = { model: useModel || model, max_tokens: maxTokens, ...(sys ? { system: sys } : {}), messages, ...(tl ? { tools: tl } : {}) };
      let last;
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          const out = await once(body);
          failures = 0;
          return { content: Array.isArray(out.content) ? out.content : [], usage: out.usage || {}, model: out.model || useModel || model };
        } catch (e) {
          last = e;
          if (!e.retry || attempt === retries) break;
          await new Promise((r) => setTimeout(r, backoffMs * 2 ** attempt));
        }
      }
      if (!['ai_key_invalid', 'ai_no_credit'].includes(last?.code)) failures += 1;
      if (failures >= breakerThreshold) { openUntil = now() + breakerCooldownMs; failures = 0; }
      throw last || err('ai_unavailable');
    },
  };
}

/** The provider chosen by AI_PROVIDER (default 'local'); an injected one wins (tests). */
export function createProvider({ env = process.env, impl = null, fetchImpl } = {}) {
  if (impl) return impl;
  if ((env.AI_PROVIDER || 'local') === 'anthropic') {
    return createAnthropicProvider({ apiKey: env.ANTHROPIC_API_KEY, model: env.AI_MODEL || 'claude-sonnet-5-5', timeoutMs: Number(env.AI_TIMEOUT_MS) || 20_000, ...(fetchImpl ? { fetchImpl } : {}) });
  }
  return createLocalProvider();
}
export const providerInfo = (env = process.env, p = null) => ({
  name: p?.name || env.AI_PROVIDER || 'local',
  model: (p?.name || env.AI_PROVIDER) === 'anthropic' ? env.AI_MODEL || 'claude-sonnet-5-5' : null,
  fastModel: (p?.name || env.AI_PROVIDER) === 'anthropic' ? env.AI_MODEL_FAST || 'claude-haiku-5-5' : null,
  keyConfigured: !!env.ANTHROPIC_API_KEY,
});
