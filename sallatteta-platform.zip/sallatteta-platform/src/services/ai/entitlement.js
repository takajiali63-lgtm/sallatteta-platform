// Who may use the AI manager. Three things must ALL be true (checked on every AI endpoint, tool and job):
//   1) the subscriber paid for it: ai_until (set only by the server) is in the future;
//   2) the owner's global AI switch is on;
//   3) AI is on for the subscriber's category (shops / online / crafts / drivers).
// BASIC subscribers get 403 ai_not_subscribed whatever they send. Ordinary orders never depend on any of this.
import { isCraft } from '../categories.js';
import { HttpError } from '../../lib/http.js';

export const CATEGORIES = ['shops', 'online', 'crafts', 'drivers'];

/** 'driver' or a cooks.kind → the AI category used for permissions, limits and switches. */
export function aiCategory(kind) {
  if (kind === 'driver') return 'drivers';
  if (kind === 'online_store') return 'online';
  if (isCraft(kind)) return 'crafts';
  return 'shops';
}

const DEFAULT_CONFIG = {
  enabled: true,
  categories: { shops: true, online: true, crafts: true, drivers: true },
  // monthly allowance per subscriber (messages to the AI, voice minutes)
  limits: { shops: { messages: 1500, voiceMinutes: 120 }, online: { messages: 1500, voiceMinutes: 120 }, crafts: { messages: 600, voiceMinutes: 60 }, drivers: { messages: 600, voiceMinutes: 120 } },
  // unit costs used ONLY for the owner's cost report (integer cents)
  costs: { messageCents: 0, tokenInPerMillionCents: 300, tokenOutPerMillionCents: 1500, voiceMinuteCents: 0 },
  // telephone calls and marketing sending are future features: kept OFF (no provider exists yet)
  channels: { ai_phone_calls: { enabled: false, monthlySpendLimitCents: 0 }, ai_marketing_send: { enabled: false, monthlySpendLimitCents: 0 } },
  // workflow thresholds (minutes)
  workflow: { waitMin: 5, prepMin: 30, bookingRemindMin: 60, maxFailures: 3 },
};

const merge = (base, over) => {
  if (!over || typeof over !== 'object' || Array.isArray(over)) return base;
  const out = { ...base };
  for (const [k, v] of Object.entries(base)) {
    if (v && typeof v === 'object' && !Array.isArray(v)) out[k] = merge(v, over[k]);
    else if (over[k] !== undefined && typeof over[k] === typeof v) out[k] = over[k];
  }
  return out;
};

/** The owner's AI configuration (defaults + what he saved). Read fresh every time so switches apply immediately. */
export async function getAiConfig(db) {
  const row = await db.one(`SELECT value FROM ai_config WHERE key = 'global'`);
  let saved = null;
  try { saved = row ? JSON.parse(row.value) : null; } catch { saved = null; }
  const cfg = merge(DEFAULT_CONFIG, saved);
  // the channels stay disabled in this version whatever is saved (no provider can send yet)
  for (const c of Object.values(cfg.channels)) c.enabled = false;
  return cfg;
}
export async function saveAiConfig(db, cfg) {
  const value = JSON.stringify(merge(DEFAULT_CONFIG, cfg));
  await db.query(`INSERT INTO ai_config (key, value, updated_at) VALUES ('global', $1, $2)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at`, [value, new Date().toISOString()]);
  return getAiConfig(db);
}
export const defaultAiConfig = () => JSON.parse(JSON.stringify(DEFAULT_CONFIG));

/** The subscriber's row (kind, name, locale, ai_until) or null. */
export async function ownerInfo(db, ownerType, ownerId) {
  if (ownerType === 'store') {
    const c = await db.one(`SELECT id, full_name, kind, locale, ai_until, COALESCE(country, 'LB') AS country, hours, booking FROM cooks WHERE id = $1`, [ownerId]);
    return c ? { type: 'store', id: c.id, name: c.full_name, kind: c.kind || 'cook', locale: c.locale, aiUntil: c.ai_until, country: c.country, hours: c.hours, booking: !!Number(c.booking), category: aiCategory(c.kind || 'cook') } : null;
  }
  if (ownerType === 'driver') {
    const d = await db.one(`SELECT id, full_name, locale, ai_until, COALESCE(country, 'LB') AS country FROM drivers WHERE id = $1`, [ownerId]);
    return d ? { type: 'driver', id: d.id, name: d.full_name, kind: 'driver', locale: d.locale, aiUntil: d.ai_until, country: d.country, category: 'drivers' } : null;
  }
  return null;
}

const paid = (until, now = new Date()) => {
  if (!until) return false;
  const t = Date.parse(String(until));
  return Number.isFinite(t) && t > now.getTime();
};

/** Detailed check: { ok, reason, owner, config }. reason: ai_not_subscribed | ai_disabled. */
export async function checkAi(db, ownerType, ownerId, { now = new Date() } = {}) {
  const owner = await ownerInfo(db, ownerType, ownerId);
  if (!owner || !paid(owner.aiUntil, now)) return { ok: false, reason: 'ai_not_subscribed', owner };
  const config = await getAiConfig(db);
  if (!config.enabled || !config.categories[owner.category]) return { ok: false, reason: 'ai_disabled', owner, config };
  return { ok: true, owner, config };
}

/** True only when this subscriber may use AI right now. */
export async function hasAi(db, ownerType, ownerId, opts) {
  return (await checkAi(db, ownerType, ownerId, opts)).ok;
}

/** Throws the right 403 when not allowed; returns { owner, config }. */
export async function requireAi(db, ownerType, ownerId) {
  const r = await checkAi(db, ownerType, ownerId);
  if (!r.ok) throw new HttpError(403, r.reason);
  return r;
}
