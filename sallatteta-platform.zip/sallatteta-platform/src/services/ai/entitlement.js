// Who may use the AI manager. Three things must ALL be true (checked on every AI endpoint, tool and job):
//   1) the subscriber paid for it: ai_until (set only by the server) is in the future;
//   2) the owner's global AI switch is on;
//   3) AI is on for the subscriber's category (shops / online / crafts / drivers).
// BASIC subscribers get 403 ai_not_subscribed whatever they send. Ordinary orders never depend on any of this.
import { isCraft } from '../categories.js';
import { HttpError } from '../../lib/http.js';

export const CATEGORIES = ['shops', 'online', 'crafts', 'drivers'];

/** 'driver' or a cooks.kind → the AI category used for permissions, limits and switches. */
export function aiCategory(kind) {
  if (kind === 'driver') return 'drivers';
  if (kind === 'online_store') return 'online';
  if (isCraft(kind)) return 'crafts';
  return 'shops';
}

const DEFAULT_CONFIG = {
  enabled: true,
  categories: { shops: true, online: true, crafts: true, drivers: true },
  // v8.2 «never stops»: a SAFETY ceiling of messages per subscriber (against robots / abuse), not the normal limit —
  // past it (or past the money budget below) the assistant keeps answering with the free built-in replies
  limits: { shops: { messages: 20000, voiceMinutes: 300 }, online: { messages: 10000, voiceMinutes: 120 }, crafts: { messages: 5000, voiceMinutes: 60 }, drivers: { messages: 5000, voiceMinutes: 120 } },
  // v8.2 the money each subscriber's AI may spend a month, in cents (included in the subscription; packs add more).
  // 80 % → the subscriber is told; 90 % → the manager uses the fast model too; 100 % → free built-in replies.
  budgets: { shops: 800, online: 300, crafts: 200, drivers: 250 },
  // an extra pack the subscriber buys (price in $, budget added in cents) — approved by the owner like a renewal
  pack: { priceUsd: 5, cents: 400 },
  // the two «employees»: the receptionist (customers) on the fast cheap model, the operations manager on the strong one
  models: { manager: 'claude-sonnet-5-5', customer: 'claude-haiku-5-5' },
  // automatic protection (the owner never pays without a reason)
  protect: { monthlyCapCents: 10000, spikeFactor: 10, spikeMinCents: 100, revenueWarnPct: 20, lowBalanceDays: 7 },
  // what the owner loaded on his Anthropic account (he types it when he tops up) → «enough for N days»
  balance: { cents: 0, asOf: '' },
  // stores may connect their own Anthropic key (their usage is then on their account, not the platform's)
  allowOwnKey: true,
  // unit costs (cents per million tokens) — per model; unknown models use the token prices below
  costs: { messageCents: 0, tokenInPerMillionCents: 200, tokenOutPerMillionCents: 1000, voiceMinuteCents: 0 },
  modelCosts: {
    'claude-sonnet-5-5': { in: 200, out: 1000, cacheRead: 10, cacheWrite: 250 },
    'claude-haiku-5-5': { in: 10, out: 50, cacheRead: 1, cacheWrite: 13 },
    'claude-haiku-4-5-20251001': { in: 100, out: 500, cacheRead: 10, cacheWrite: 125 },
  },
  // telephone calls and marketing sending are future features: kept OFF (no provider exists yet)
  channels: { ai_phone_calls: { enabled: false, monthlySpendLimitCents: 0 }, ai_marketing_send: { enabled: false, monthlySpendLimitCents: 0 } },
  // workflow thresholds (minutes)
  workflow: { waitMin: 5, prepMin: 30, bookingRemindMin: 60, maxFailures: 3 },
};

const merge = (base, over) => {
  if (!over || typeof over !== 'object' || Array.isArray(over)) return base;
  const out = { ...base };
  for (const [k, v] of Object.entries(base)) {
    if (v && typeof v === 'object' && !Array.isArray(v)) out[k] = merge(v, over[k]);
    else if (over[k] !== undefined && typeof over[k] === typeof v) out[k] = over[k];
  }
  return out;
};

/** The owner's AI configuration (defaults + what he saved). Read fresh every time so switches apply immediately. */
export async function getAiConfig(db) {
  const row = await db.one(`SELECT value FROM ai_config WHERE key = 'global'`);
  let saved = null;
  try { saved = row ? JSON.parse(row.value) : null; } catch { saved = null; }
  // v8.2: the old monthly message limits (1 500 / 600) become the much higher safety ceilings, once
  if (saved && !saved.v82) {
    const OLD = { shops: 1500, online: 1500, crafts: 600, drivers: 600 };
    for (const [c, n] of Object.entries(OLD)) if (saved.limits?.[c]?.messages === n) saved.limits[c].messages = DEFAULT_CONFIG.limits[c].messages;
  }
  const cfg = merge(DEFAULT_CONFIG, saved);
  // the channels stay disabled in this version whatever is saved (no provider can send yet)
  for (const c of Object.values(cfg.channels)) c.enabled = false;
  return cfg;
}
export async function saveAiConfig(db, cfg) {
  const value = JSON.stringify({ ...merge(DEFAULT_CONFIG, cfg), v82: true });
  await db.query(`INSERT INTO ai_config (key, value, updated_at) VALUES ('global', $1, $2)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at`, [value, new Date().toISOString()]);
  return getAiConfig(db);
}
export const defaultAiConfig = () => JSON.parse(JSON.stringify(DEFAULT_CONFIG));

/** The subscriber's row (kind, name, locale, ai_until) or null. */
export async function ownerInfo(db, ownerType, ownerId) {
  if (ownerType === 'store') {
    const c = await db.one(`SELECT id, full_name, kind, locale, ai_until, COALESCE(country, 'LB') AS country, hours, booking FROM cooks WHERE id = $1`, [ownerId]);
    return c ? { type: 'store', id: c.id, name: c.full_name, kind: c.kind || 'cook', locale: c.locale, aiUntil: c.ai_until, country: c.country, hours: c.hours, booking: !!Number(c.booking), category: aiCategory(c.kind || 'cook') } : null;
  }
  if (ownerType === 'driver') {
    const d = await db.one(`SELECT id, full_name, locale, ai_until, COALESCE(country, 'LB') AS country FROM drivers WHERE id = $1`, [ownerId]);
    return d ? { type: 'driver', id: d.id, name: d.full_name, kind: 'driver', locale: d.locale, aiUntil: d.ai_until, country: d.country, category: 'drivers' } : null;
  }
  return null;
}

const paid = (until, now = new Date()) => {
  if (!until) return false;
  const t = Date.parse(String(until));
  return Number.isFinite(t) && t > now.getTime();
};

/** Detailed check: { ok, reason, owner, config }. reason: ai_not_subscribed | ai_disabled. */
export async function checkAi(db, ownerType, ownerId, { now = new Date() } = {}) {
  const owner = await ownerInfo(db, ownerType, ownerId);
  if (!owner || !paid(owner.aiUntil, now)) return { ok: false, reason: 'ai_not_subscribed', owner };
  const config = await getAiConfig(db);
  if (!config.enabled || !config.categories[owner.category]) return { ok: false, reason: 'ai_disabled', owner, config };
  return { ok: true, owner, config };
}

/** True only when this subscriber may use AI right now. */
export async function hasAi(db, ownerType, ownerId, opts) {
  return (await checkAi(db, ownerType, ownerId, opts)).ok;
}

/** Throws the right 403 when not allowed; returns { owner, config }. */
export async function requireAi(db, ownerType, ownerId) {
  const r = await checkAi(db, ownerType, ownerId);
  if (!r.ok) throw new HttpError(403, r.reason);
  return r;
}
