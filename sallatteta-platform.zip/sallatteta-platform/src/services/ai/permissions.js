// What the AI manager may do for each subscriber: a master switch + one level per permission.
//   OFF           — the AI can't use it at all
//   READ_ONLY     — the AI may read/suggest, never change anything
//   ASK_APPROVAL  — changes wait in "approvals" until the subscriber presses approve
//   AUTO_EXECUTE  — low/medium-risk changes run by themselves (never for high-risk permissions)
// Some actions ALWAYS wait for approval whatever the level (irreversible, money/account, publishing prices) — see tools.js
// (alwaysApprove). Changes apply to the next action immediately, are audited, and never change the subscription price.
import { HttpError } from '../../lib/http.js';

export const LEVELS = ['OFF', 'READ_ONLY', 'ASK_APPROVAL', 'AUTO_EXECUTE'];
export const GROUPS = ['orders', 'customer_service', 'products', 'bookings', 'marketing', 'reports', 'voice'];
const ALL = ['shops', 'online', 'crafts', 'drivers'];

// kind: 'read' (reads or returns text only) | 'write' (changes something or contacts someone)
export const PERMISSIONS = [
  { key: 'orders_read', group: 'orders', risk: 'low', kind: 'read', categories: ['shops', 'online', 'drivers'], desc: 'Read your orders / service requests and their status' },
  { key: 'orders_alerts', group: 'orders', risk: 'low', kind: 'read', categories: ['shops', 'online'], desc: 'Remind you about orders waiting too long or late in preparation' },
  { key: 'orders_status', group: 'orders', risk: 'high', kind: 'write', categories: ['shops', 'online'], desc: 'Accept a new order (pending → preparing) with the same rules as your screen' },
  { key: 'cs_assistant', group: 'customer_service', risk: 'medium', kind: 'read', categories: ['shops', 'online', 'crafts'], def: 'OFF', desc: 'Answer your customers in your page (catalog and their own order status, read-only)' },
  { key: 'cs_notify', group: 'customer_service', risk: 'medium', kind: 'write', categories: ALL, desc: 'Send a customer a ready-made in-app notification about his own order/booking' },
  { key: 'cs_escalate', group: 'customer_service', risk: 'low', kind: 'write', categories: ALL, desc: 'Create a task for you when something needs a human' },
  { key: 'products_read', group: 'products', risk: 'low', kind: 'read', categories: ['shops', 'online', 'crafts'], desc: 'Read your catalog' },
  { key: 'products_suggest', group: 'products', risk: 'low', kind: 'read', categories: ['shops', 'online', 'crafts'], desc: 'Suggest descriptions and prices (text only, nothing changes)' },
  { key: 'products_update', group: 'products', risk: 'medium', kind: 'write', categories: ['shops', 'online', 'crafts'], desc: 'Prepare product changes (a price change always needs your approval)' },
  { key: 'promotions_prepare', group: 'products', risk: 'high', kind: 'write', categories: ['shops', 'online'], desc: 'Prepare promotions (always needs your approval)' },
  { key: 'bookings_read', group: 'bookings', risk: 'low', kind: 'read', categories: ['shops', 'crafts', 'drivers'], desc: 'Read your appointments, visit requests and customer requests' },
  { key: 'bookings_create', group: 'bookings', risk: 'medium', kind: 'write', categories: ['shops', 'crafts'], desc: 'Book an appointment for one of your customers, within your rules' },
  { key: 'bookings_reminders', group: 'bookings', risk: 'medium', kind: 'write', categories: ['shops', 'crafts'], desc: 'Remind customers of their appointment' },
  { key: 'bookings_reschedule', group: 'bookings', risk: 'medium', kind: 'write', categories: ['shops', 'crafts'], desc: 'Propose a new time to a customer' },
  { key: 'marketing_draft', group: 'marketing', risk: 'low', kind: 'read', categories: ALL, desc: 'Write marketing texts for you (text only)' },
  { key: 'marketing_send', group: 'marketing', risk: 'high', kind: 'write', categories: ALL, desc: 'Send marketing messages (not available yet)' },
  { key: 'reports_sales', group: 'reports', risk: 'low', kind: 'read', categories: ALL, desc: 'Sales / earnings reports' },
  { key: 'reports_problems', group: 'reports', risk: 'low', kind: 'read', categories: ALL, desc: 'Detect problems (late orders, many rejections…)' },
  { key: 'reports_scheduled', group: 'reports', risk: 'low', kind: 'read', categories: ALL, desc: 'Save a daily and weekly report' },
  { key: 'voice_use', group: 'voice', risk: 'low', kind: 'read', categories: ALL, desc: 'Talk to the manager by voice in the app' },
];
export const PERM = Object.fromEntries(PERMISSIONS.map((p) => [p.key, p]));

/** The level a permission has when the subscriber never touched it: safe by default. */
export function defaultLevel(p) {
  if (p.def) return p.def;
  if (p.risk === 'high') return 'OFF';                 // high-risk permissions start OFF
  if (p.kind === 'read') return 'READ_ONLY';
  return p.risk === 'low' ? 'AUTO_EXECUTE' : 'ASK_APPROVAL';
}
export const allowedLevels = (p) => (p.risk === 'high' ? LEVELS.filter((l) => l !== 'AUTO_EXECUTE') : LEVELS);
export const permsFor = (category) => PERMISSIONS.filter((p) => p.categories.includes(category));

const parse = (s) => { try { const o = JSON.parse(s || '{}'); return o && typeof o === 'object' ? o : {}; } catch { return {}; } };

/** { enabled, levels: {key: level} } for the subscriber's category (always fresh from the database). */
export async function getSettings(db, ownerType, ownerId, category) {
  const row = await db.one('SELECT enabled, perms FROM ai_settings WHERE owner_type = $1 AND owner_id = $2', [ownerType, ownerId]);
  const saved = parse(row?.perms);
  const levels = {};
  for (const p of permsFor(category)) {
    let l = LEVELS.includes(saved[p.key]) ? saved[p.key] : defaultLevel(p);
    if (p.risk === 'high' && l === 'AUTO_EXECUTE') l = 'ASK_APPROVAL';   // defence in depth: never AUTO for high risk
    levels[p.key] = l;
  }
  return { enabled: row ? Number(row.enabled) === 1 : true, levels };
}

/** Saves the switch / levels the subscriber sent (validated), audits every change. Returns the new settings. */
export async function updateSettings(db, ownerType, ownerId, category, body, actor) {
  const fields = {};
  const perms = body.perms ?? {};
  if (typeof perms !== 'object' || Array.isArray(perms)) throw new HttpError(422, 'validation_failed', { fields: { perms: 'invalid' } });
  if (body.enabled !== undefined && typeof body.enabled !== 'boolean') fields.enabled = 'invalid';
  const mine = new Set(permsFor(category).map((p) => p.key));
  for (const [k, v] of Object.entries(perms)) {
    if (!mine.has(k)) fields[k] = 'unknown_permission';
    else if (!LEVELS.includes(v)) fields[k] = 'invalid';
    else if (!allowedLevels(PERM[k]).includes(v)) fields[k] = 'auto_not_allowed';
  }
  if (Object.keys(fields).length) throw new HttpError(422, 'validation_failed', { fields });
  const before = await getSettings(db, ownerType, ownerId, category);
  const levels = { ...before.levels, ...perms };
  const enabled = body.enabled === undefined ? before.enabled : body.enabled;
  const now = new Date().toISOString();
  await db.tx(async (t) => {
    await t.query(`INSERT INTO ai_settings (owner_type, owner_id, enabled, perms, updated_at) VALUES ($1,$2,$3,$4,$5)
      ON CONFLICT (owner_type, owner_id) DO UPDATE SET enabled = EXCLUDED.enabled, perms = EXCLUDED.perms, updated_at = EXCLUDED.updated_at`,
    [ownerType, ownerId, enabled ? 1 : 0, JSON.stringify(levels), now]);
    if (enabled !== before.enabled) await t.query('INSERT INTO ai_settings_audit (owner_type, owner_id, actor, perm_key, old_level, new_level) VALUES ($1,$2,$3,$4,$5,$6)', [ownerType, ownerId, actor, 'master', before.enabled ? 'ON' : 'OFF', enabled ? 'ON' : 'OFF']);
    for (const [k, v] of Object.entries(perms)) {
      if (before.levels[k] !== v) await t.query('INSERT INTO ai_settings_audit (owner_type, owner_id, actor, perm_key, old_level, new_level) VALUES ($1,$2,$3,$4,$5,$6)', [ownerType, ownerId, actor, k, before.levels[k], v]);
    }
  });
  return getSettings(db, ownerType, ownerId, category);
}

/**
 * What happens to a tool call at this level: 'execute' | 'queue' | 'deny'.
 * reason explains a deny (permission_off | read_only) or a forced queue (always_approval).
 */
export function decide(level, perm, { alwaysApprove = false } = {}) {
  if (!level || level === 'OFF') return { decision: 'deny', reason: 'permission_off' };
  if (perm.kind === 'read') return { decision: 'execute' };
  if (level === 'READ_ONLY') return { decision: 'deny', reason: 'read_only' };
  if (level === 'ASK_APPROVAL') return { decision: 'queue', reason: 'ask_approval' };
  if (perm.risk === 'high') return { decision: 'queue', reason: 'high_risk' };
  if (alwaysApprove) return { decision: 'queue', reason: 'always_approval' };
  return { decision: 'execute' };
}
