// Shared gate for the future outbound channels (telephone calls, marketing sending). In this version both are OFF:
// the only provider is 'none' and the owner's flags are forced false, so any call → 409 channel_disabled.
import { HttpError } from '../../../lib/http.js';
import { getAiConfig } from '../entitlement.js';

/**
 * Checks every rule a future provider must respect BEFORE anything leaves the platform:
 * owner flag on, a real provider registered, the monthly spending limit not reached, and the person's consent.
 */
export async function channelGate({ db, flag, registry, providerName = 'none', spentCents = 0, costCents = 0, consent = false }) {
  const cfg = await getAiConfig(db);
  const f = cfg.channels[flag];
  const provider = registry[providerName];
  if (!f?.enabled || !provider || providerName === 'none') throw new HttpError(409, 'channel_disabled', { channel: flag });
  if (spentCents + costCents > Number(f.monthlySpendLimitCents || 0)) throw new HttpError(409, 'channel_spend_limit', { channel: flag });
  if (!consent) throw new HttpError(409, 'no_consent', { channel: flag });
  return provider;
}
