// AI marketing sending — FUTURE, kept disabled (admin flag ai_marketing_send = false, provider 'none' only).
//
// What a real provider will need:
//  - an approved channel (WhatsApp Business templates, SMS or e-mail provider) with keys in env vars;
//  - recipients ONLY from crm_contacts of that subscriber with mkt_consent = 1 and opted_out = 0 (never imported lists);
//  - an unsubscribe link/keyword in every message that writes crm_consents (marketing, granted = 0);
//  - interface: { name, async send({ contacts, text, lang }) → { sent, costCents } }, rate limits per subscriber;
//  - the gate below: owner flag on + monthly spending limit + consent; every send audited in ai_actions.
import { channelGate } from './common.js';

export const MARKETING_PROVIDERS = {
  none: { name: 'none', async send() { return { sent: 0, costCents: 0 }; } },
};

/** Send a marketing message for a subscriber. Today: always 409 channel_disabled. */
export async function sendMarketing({ db, owner, text, consent = false, providerName = process.env.AI_MARKETING_PROVIDER || 'none' }) {
  const provider = await channelGate({ db, flag: 'ai_marketing_send', registry: MARKETING_PROVIDERS, providerName, consent });
  return provider.send({ owner, text });
}
