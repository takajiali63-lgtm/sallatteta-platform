// AI telephone calls — FUTURE, kept disabled (admin flag ai_phone_calls = false, provider 'none' only).
//
// What a real provider will need (to add it here and to the registry):
//  - an account with a voice/telephony API (e.g. a SIP/PSTN provider) and its keys in env vars (never in the code);
//  - a verified caller number per country, and the local rules for automated calls (hours, opt-in, recording notice);
//  - interface: { name, async call({ to, script, lang, maxSeconds }) → { callId, costCents } } with a timeout and retries;
//  - the gate below: owner flag on + monthly spending limit + the customer's OPERATIONAL consent for this subscriber;
//  - a webhook for call results, recorded in ai_actions; per-call cost metered in ai_usage.
// A closed app cannot listen or call: everything here would run on the server, never on the phone's microphone.
import { channelGate } from './common.js';

export const TELEPHONY_PROVIDERS = {
  none: { name: 'none', async call() { return { callId: null, costCents: 0 }; } },
};

/** Place an AI call for a subscriber. Today: always 409 channel_disabled. */
export async function placeCall({ db, owner, to, consent = false, providerName = process.env.AI_PHONE_PROVIDER || 'none' }) {
  const provider = await channelGate({ db, flag: 'ai_phone_calls', registry: TELEPHONY_PROVIDERS, providerName, consent });
  return provider.call({ owner, to });
}
