// v8.2 the AI money, kept under control so the owner never pays without a reason (owner's request, 12 Oct 2026):
// - every subscriber has a monthly AI budget in money (packs add more); the platform has a monthly cap;
// - unusual spending pauses that subscriber's paid AI (free built-in replies meanwhile) and tells the owner;
// - the owner types what he loaded on his Anthropic account → «enough for N days», warned a week ahead;
// - stores may use their own Anthropic key, kept encrypted (AES-256-GCM) and never shown again.
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import { getAiConfig, aiCategory } from './entitlement.js';

export const monthKey = (d = new Date()) => d.toISOString().slice(0, 7);
const dayStart = (d = new Date()) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));

/** Cost of one answer in cents, from the model's prices (cache reads are a fraction of the input price). */
export function costOf(config, model, usage = {}) {
  const table = config.modelCosts || {};
  const key = Object.keys(table).find((k) => model && (model === k || String(model).startsWith(k)));
  const base = config.costs || {};
  const p = key ? table[key] : { in: base.tokenInPerMillionCents || 0, out: base.tokenOutPerMillionCents || 0, cacheRead: (base.tokenInPerMillionCents || 0) / 10, cacheWrite: (base.tokenInPerMillionCents || 0) * 1.25 };
  const n = (x) => Number(x) || 0;
  return (n(usage.input_tokens) * p.in + n(usage.output_tokens) * p.out + n(usage.cache_read_input_tokens) * p.cacheRead + n(usage.cache_creation_input_tokens) * p.cacheWrite) / 1e6;
}

/* ---------- own keys ---------- */
const keyOf = (secret) => createHash('sha256').update(`aklatak-ai-key:${secret}`).digest();
export function sealKey(secret, plain) {
  const iv = randomBytes(12);
  const c = createCipheriv('aes-256-gcm', keyOf(secret), iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
}
export function openKey(secret, sealed) {
  try {
    const [iv, tag, enc] = String(sealed).split('.').map((x) => Buffer.from(x, 'base64'));
    const d = createDecipheriv('aes-256-gcm', keyOf(secret), iv);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
  } catch { return null; }
}
export const KEY_RE = /^sk-ant-[A-Za-z0-9_-]{20,200}$/;

/* ---------- the platform's picture ---------- */
/** This month: what the platform paid, per day for the last 7 days, the AI subscribers' monthly value. */
export async function aiMoney(db, config, now = new Date()) {
  const month = monthKey(now);
  const m = await db.one('SELECT COALESCE(SUM(cost_cents), 0) AS c, COALESCE(SUM(own_cost_cents), 0) AS own, COALESCE(SUM(free_replies), 0) AS free FROM ai_usage WHERE month = $1', [month]);
  const since = new Date(dayStart(now).getTime() - 7 * 86_400_000).toISOString();
  const w = await db.one(`SELECT COALESCE(SUM(cost_mc), 0) AS mc FROM ai_actions WHERE created_at >= $1 AND created_at < $2 AND COALESCE(own_key, 0) = 0`, [since, dayStart(now).toISOString()]);
  const today = await db.one(`SELECT COALESCE(SUM(cost_mc), 0) AS mc FROM ai_actions WHERE created_at >= $1 AND COALESCE(own_key, 0) = 0`, [dayStart(now).toISOString()]);
  const perDay = Number(w.mc) / 1000 / 7;
  // what the AI subscribers pay a month (stores with AI now × the category's monthly AI price, drivers likewise)
  let revenueCents = 0;
  try {
    const row = await db.one(`SELECT value FROM app_meta WHERE key = 'plans'`);
    const plans = row ? JSON.parse(row.value) : {};
    const price = (g, def) => Number(plans?.ai?.[g]?.[1]?.price ?? def);
    const t = now.toISOString();
    for (const r of await db.query(`SELECT kind, CAST(COUNT(*) AS INTEGER) AS n FROM cooks WHERE ai_until > $1 GROUP BY kind`, [t])) {
      const g = aiCategory(r.kind || 'cook');
      revenueCents += Number(r.n) * price(g, { shops: 30, online: 12, crafts: 8 }[g]) * 100;
    }
    const d = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM drivers WHERE ai_until > $1`, [t]);
    revenueCents += Number(d.n) * price('drivers', 10) * 100;
  } catch { /* best effort */ }
  // what is left on the owner's Anthropic account (what he loaded − what was spent since)
  let balanceLeft = null, daysLeft = null;
  if (config.balance?.asOf && Number(config.balance.cents) > 0) {
    const s = await db.one(`SELECT COALESCE(SUM(cost_mc), 0) AS mc FROM ai_actions WHERE created_at >= $1 AND COALESCE(own_key, 0) = 0`, [config.balance.asOf]);
    balanceLeft = Math.max(0, Number(config.balance.cents) - Number(s.mc) / 1000);
    daysLeft = perDay > 0 ? Math.floor(balanceLeft / perDay) : null;
  }
  const cap = Number(config.protect?.monthlyCapCents || 0);
  const monthCents = Number(m.c);
  return {
    month, monthCents: Math.round(monthCents * 100) / 100, ownKeyCents: Math.round(Number(m.own) * 100) / 100, freeReplies: Number(m.free),
    todayCents: Math.round(Number(today.mc) / 10) / 100, perDayCents: Math.round(perDay * 100) / 100,
    capCents: cap, capPct: cap ? Math.round((monthCents / cap) * 100) : null, capReached: cap > 0 && monthCents >= cap,
    revenueCents: Math.round(revenueCents), revenuePct: revenueCents ? Math.round((monthCents / revenueCents) * 1000) / 10 : null,
    balanceLeftCents: balanceLeft == null ? null : Math.round(balanceLeft), daysLeft,
  };
}

/** Once a day at most per subject: tells the owner (low balance, spending vs revenue, platform cap). */
async function once(db, key) {
  const r = await db.one('SELECT value FROM app_meta WHERE key = $1', [key]);
  if (r) return false;
  await db.query(`INSERT INTO app_meta (key, value) VALUES ($1, '1') ON CONFLICT (key) DO NOTHING`, [key]);
  return true;
}
export async function aiWatch({ db, push, now = new Date() }) {
  const config = await getAiConfig(db);
  const x = await aiMoney(db, config, now);
  const day = now.toISOString().slice(0, 10);
  const out = [];
  const tell = async (key, body) => { if (await once(db, key)) { push?.notifyAdmins?.({ title: 'Aklatak — الإدارة', body, url: '/admin/#dx-ai' }); out.push(key); } };
  if (x.daysLeft != null && x.daysLeft < Number(config.protect?.lowBalanceDays || 7)) await tell(`ai_low_balance:${day}`, `💳 رصيد الذكاء الاصطناعي يكفي ${x.daysLeft} يوماً تقريباً (${(x.balanceLeftCents / 100).toFixed(2)}$). اشحن الرصيد لتبقى على أمان.`);
  if (x.capPct != null && x.capPct >= 80) await tell(`ai_cap80:${x.month}`, `🤖 صرف الذكاء الاصطناعي بلغ ${x.capPct}% من السقف الشهري (${(x.monthCents / 100).toFixed(2)}$). عند 100% تنتقل الردود إلى المجانية تلقائياً.`);
  if (x.revenuePct != null && x.revenuePct >= Number(config.protect?.revenueWarnPct || 20)) await tell(`ai_revenue:${x.month}`, `🤖 صرف الذكاء الاصطناعي ${x.revenuePct}% من اشتراكات المدير الذكي هذا الشهر.`);
  return { alerts: out, ...x };
}
