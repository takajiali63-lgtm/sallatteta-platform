import { createServer } from 'node:http';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadConfig } from './config.js';
import { openDb, migrate } from './db/index.js';
import { HttpError, sendJson, serveFile } from './lib/http.js';
import { RateLimiter } from './lib/security.js';
import { publicRoutes } from './routes/public.js';
import { adminRoutes, createAdminUser } from './routes/admin.js';
import { expireSubscriptions } from './services/cooks.js';
import { AreaIndex } from './services/areas.js';
import { cookRoutes } from './routes/cook.js';
import { createStorage } from './services/storage.js';
import { imageStore } from './services/images.js';
import { MemoryCache } from './lib/cache.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC_DIR = resolve(root, 'public');
const ADMIN_DIR = resolve(root, 'admin-ui');
const LOCALES_DIR = resolve(root, 'locales');

function securityHeaders(cfg) {
  const h = {
    'Content-Security-Policy': [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: blob:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join('; '),
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'geolocation=(self), camera=(), microphone=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
  };
  if (cfg.isProd) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  return h;
}

export async function createApp(overrides = {}) {
  const cfg = { ...loadConfig(), ...overrides };
  const db = await openDb(cfg);
  await migrate(db);

  // First admin from env (only if no admin exists yet) — useful on Render free plan (no shell).
  const adminCount = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM admin_users');
  if (adminCount.n === 0 && cfg.bootstrapAdmin.username && cfg.bootstrapAdmin.password) {
    await createAdminUser(db, cfg.bootstrapAdmin.username, cfg.bootstrapAdmin.password);
    console.log(`[setup] created first admin user "${cfg.bootstrapAdmin.username}"`);
  }

  const limiters = {
    search: new RateLimiter({ windowMs: 10 * 60_000, max: overrides.searchLimit ?? 30 }),
    contact: new RateLimiter({ windowMs: 10 * 60_000, max: 40 }),
    apply: new RateLimiter({ windowMs: 60 * 60_000, max: overrides.applyLimit ?? 5 }),
    login: new RateLimiter({ windowMs: 15 * 60_000, max: overrides.loginLimit ?? 10 }),
    lookup: new RateLimiter({ windowMs: 60_000, max: overrides.lookupLimit ?? 120 }),
    feedback: new RateLimiter({ windowMs: 60 * 60_000, max: overrides.feedbackLimit ?? 5 }),
    places: new RateLimiter({ windowMs: 10 * 60_000, max: overrides.placesLimit ?? 30 }),
  };
  const areas = await new AreaIndex(db).load();
  const storage = createStorage(cfg, overrides.storageFetch ? { fetchImpl: overrides.storageFetch } : {});
  const images = imageStore(storage);
  const cache = new MemoryCache();
  const ctx = { db, cfg, limiters, areas, images, cache };
  const routes = [...publicRoutes(ctx), ...cookRoutes(ctx), ...adminRoutes(ctx)];
  const headers = securityHeaders(cfg);

  async function handle(req, res) {
    for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
    const url = new URL(req.url, 'http://localhost');
    const path = url.pathname;
    try {
      for (const [method, pattern, handler] of routes) {
        const m = pattern.exec(path);
        if (m) {
          if (req.method !== method) continue;
          return await handler(req, res, m);
        }
      }
      if (path.startsWith('/api/')) throw new HttpError(404, 'not_found');
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'method_not_allowed');

      // Admin UI (path configurable via ADMIN_PATH, never indexed)
      if (path === cfg.adminPath) {
        res.writeHead(301, { Location: cfg.adminPath + '/' });
        return res.end();
      }
      if (path.startsWith(cfg.adminPath + '/')) {
        const rel = path.slice(cfg.adminPath.length).replace(/^\/+/, '') || 'index.html';
        if (await serveFile(res, ADMIN_DIR, rel, { extraHeaders: { 'X-Robots-Tag': 'noindex, nofollow' } })) return;
        throw new HttpError(404, 'not_found');
      }
      if (path.startsWith('/locales/')) {
        if (await serveFile(res, LOCALES_DIR, path.slice('/locales/'.length), { cache: 'no-cache' })) return;
        throw new HttpError(404, 'not_found');
      }
      const pages = { '/': 'index.html', '/join': 'join.html', '/account': 'account.html' };
      const rel = pages[path] || (/^\/c\/\d+\/?$/.test(path) ? 'cook.html' : path);
      const cache = rel.startsWith('/assets/') && /\.(svg|png|jpg|woff2?)$/.test(rel) ? 'public, max-age=86400' : 'no-cache';
      if (await serveFile(res, PUBLIC_DIR, rel, { cache })) return;
      throw new HttpError(404, 'not_found');
    } catch (err) {
      if (res.headersSent) { res.destroy(); return; }
      if (err instanceof HttpError) {
        const extra = err.status === 429 ? { 'Retry-After': String(err.extra.retryAfterSec || 60) } : {};
        if (!path.startsWith('/api/') && err.status === 404) {
          res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
          return res.end('<!doctype html><meta charset="utf-8"><title>404</title><p dir="rtl">الصفحة غير موجودة. <a href="/">الرئيسية</a></p>');
        }
        return sendJson(res, err.status, { error: err.code, ...err.extra }, extra);
      }
      console.error('[error]', req.method, path, err);
      return sendJson(res, 500, { error: 'server_error' });
    }
  }

  const server = createServer((req, res) => { handle(req, res); });
  // Behind a load balancer: keep connections a bit longer than the balancer's idle timeout, and cap slow requests.
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 66_000;
  server.requestTimeout = 30_000;
  const sweep = async () => {
    try {
      const n = await expireSubscriptions(db);
      if (n) console.log(`[sweep] marked ${n} subscription(s) as expired`);
      const nowIso = new Date().toISOString();
      await db.query('DELETE FROM admin_sessions WHERE expires_at <= $1', [nowIso]);
      await db.query('DELETE FROM cook_sessions WHERE expires_at <= $1', [nowIso]);
    } catch (e) { console.error('[sweep]', e.message); }
  };
  await sweep();
  const timer = setInterval(sweep, 15 * 60_000);
  timer.unref();

  return {
    server, db, cfg, sweep, areas, storage,
    async close() {
      clearInterval(timer);
      Object.values(limiters).forEach((l) => l.stop());
      await new Promise((r) => server.close(r));
      await db.close();
    },
  };
}

// Run directly: `node src/server.js`
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const app = await createApp();
  app.server.listen(app.cfg.port, () => {
    console.log(`سلة تيتا running on http://localhost:${app.cfg.port}  (admin: ${app.cfg.adminPath}, db: ${app.db.kind}, images: ${app.storage.kind})`);
    if (!app.cfg.adminWhatsapp) console.warn('[warn] ADMIN_WHATSAPP_NUMBER is not set — cook applications cannot be forwarded to WhatsApp');
  });
  const stop = async () => { await app.close(); process.exit(0); };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}
