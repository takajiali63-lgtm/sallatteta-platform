// v8.4 catalog API: product options & availability, promotions ("offers"), preparation status, craftspeople's quotes and
// jobs, independent drivers' services (public listing, booking) and drivers' quotes on customers' requests.
// Prices are always computed on the server from the database (integer cents); every write checks who owns what.
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, imageBytesOk } from '../lib/validate.js';
import { assertClean } from '../lib/profanity.js';
import { makeGuards } from '../lib/guards.js';
import { clientIp } from '../lib/security.js';
import { checkCsrf } from '../lib/sessions.js';
import { haversineKm, isValidLatLng } from '../lib/geo.js';
import { cleanHours, isOpenNow } from '../lib/hours.js';
import { VISIBLE_SQL } from '../services/cooks.js';
import { deliverySettings, driverBusy, lockAccount } from '../services/delivery.js';
import { driverPosition, checkTake } from '../services/dues.js';
import {
  priceLines, toCents, fromCents, isHM, tzOf, discountOf, promoLabel, serviceTypes, setServiceTypes, isForbiddenText,
} from '../services/catalog.js';

const iso = () => new Date().toISOString();
const VIS = `${VISIBLE_SQL} AND COALESCE(c.suspended,0) = 0`;   // paid, approved, not hidden, not suspended ($1 = now)
const qNum = (v) => (v == null || String(v).trim() === '' ? NaN : Number(v));
const parseJson = (s) => { try { return s ? JSON.parse(s) : null; } catch { return null; } };
const firstName = (n) => String(n || '').trim().split(/\s+/)[0];
const ok = (res, data = { ok: true }, status = 200) => sendJson(res, status, data);
const notFound = () => new HttpError(404, 'not_found');
const stateError = () => new HttpError(409, 'invalid_state');
const hasPlace = (c) => c?.lat != null && c?.lng != null && !(Number(c.lat) === 0 && Number(c.lng) === 0);
const ref = (id) => `AKL${id}`;

export function catalogRoutes(ctx) {
  const { db, cfg, limiters = {}, push = { notify() {}, notifyAdmins() {} }, settings = null, areas = null } = ctx;
  const { customer, store, driver, owner, limit, sessions } = makeGuards(ctx);
  const S = deliverySettings(db);
  const q = (req) => new URL(req.url, 'http://x').searchParams;
  const countryQ = (req) => { const c = String(q(req).get('country') || '').toUpperCase(); return /^[A-Z]{2}$/.test(c) ? c : null; };
  const countryHidden = (c) => { const site = settings?.get?.() || {}; return !!c && ((site.countriesHidden || []).includes(c) || (site.countriesRemoved || []).includes(c)); };
  const paging = (req, def = 20, max = 40) => {
    const p = q(req);
    return { size: Math.min(max, Math.max(1, Number(p.get('limit')) || def)), page: Math.max(0, Math.min(500, Math.floor(Number(p.get('page')) || 0))) };
  };

  /* ================= product options & availability window (store) ================= */
  async function ownItem(cookId, itemId) {
    const it = await db.one('SELECT id, name, avail_from, avail_to FROM menu_items WHERE id = $1 AND cook_id = $2', [itemId, cookId]);
    if (!it) throw notFound();   // another store's product looks like a missing one
    return it;
  }
  async function extrasOf(itemId) {
    const groups = await db.query('SELECT id, name, min_select, max_select FROM item_option_groups WHERE item_id = $1 ORDER BY sort_order, id', [itemId]);
    const out = [];
    for (const g of groups) {
      const opts = await db.query('SELECT id, name, price_cents, is_available FROM item_options WHERE group_id = $1 ORDER BY sort_order, id', [g.id]);
      out.push({ id: g.id, name: g.name, min: g.min_select, max: g.max_select, options: opts.map((o) => ({ id: o.id, name: o.name, price: fromCents(o.price_cents), available: !!Number(o.is_available) })) });
    }
    return out;
  }

  /* ================= promotions ================= */
  async function promoRows(cookId) {
    return (await db.query(`SELECT p.*, mi.name AS item_name FROM promotions p LEFT JOIN menu_items mi ON mi.id = p.item_id WHERE p.cook_id = $1 ORDER BY p.id DESC LIMIT 200`, [cookId]))
      .map((p) => ({ id: p.id, itemId: p.item_id, itemName: p.item_name || null, section: p.section || null, kind: p.kind, value: p.kind === 'percent' ? Number(p.value) : fromCents(p.value),
        badge: p.badge || null, startsAt: p.starts_at, endsAt: p.ends_at, active: !!Number(p.active), live: !!Number(p.active) && p.starts_at <= iso() && p.ends_at > iso() }));
  }
  function promoInput(b, v) {
    const kind = v.oneOf('kind', b.kind, ['percent', 'fixed']);
    let value = null;
    if (kind === 'percent') value = v.int('value', b.value, { min: 1, max: 90 });
    else if (kind === 'fixed') { const x = v.number('value', b.value, { min: 0.01, max: 100000 }); value = x == null ? null : toCents(x); }
    const badge = v.text('badge', b.badge, { max: 24, required: false });
    const starts = b.startsAt ? v.date('startsAt', b.startsAt) : new Date();
    const ends = v.date('endsAt', b.endsAt);
    if (starts && ends && !(ends > starts)) v.fail('endsAt', 'before_start');
    if (ends && ends.getTime() > Date.now() + 366 * 864e5) v.fail('endsAt', 'too_far');
    if (ends && ends.getTime() <= Date.now()) v.fail('endsAt', 'in_past');
    return { kind, value, badge, starts, ends };
  }

  /* ================= independent drivers ================= */
  // Listed = active account + "customer requests" plan running + public switch on + at least one active service.
  const LISTED = `d.status = 'active' AND d.services_on = 1 AND d.jobs_until > $1 AND EXISTS (SELECT 1 FROM driver_services s WHERE s.driver_id = d.id AND s.active = 1)`;
  async function svcInput(b, v, types) {
    const type = v.oneOf('type', b.type, types.map((x) => x.key));
    const description = v.text('description', b.description, { min: 5, max: 300, multiline: true });
    const priceMode = v.oneOf('priceMode', b.priceMode, ['fixed', 'quote']);
    const price = priceMode === 'fixed' ? v.number('price', b.price, { min: 0.5, max: 1000 }) : null;
    const areaMode = v.oneOf('areaMode', b.areaMode, ['radius', 'areas']);
    let center = null, radius = null, areaIds = null;
    if (areaMode === 'radius') {
      const lat = Number(b.center?.lat), lng = Number(b.center?.lng);
      if (!isValidLatLng(lat, lng) || (lat === 0 && lng === 0)) v.fail('center', 'invalid'); else center = { lat, lng };
      radius = v.number('radiusKm', b.radiusKm, { min: 1, max: 50 });
    } else if (areaMode === 'areas') {
      const ids = Array.isArray(b.areaIds) ? [...new Set(b.areaIds.map(Number))] : [];
      if (!ids.length || ids.length > 30 || ids.some((id) => !Number.isInteger(id) || (areas && !areas.get(id)))) v.fail('areaIds', 'invalid'); else areaIds = ids;
    }
    let hours = null;
    if (b.hours != null && b.hours !== '') { hours = cleanHours(b.hours); if (hours === undefined) v.fail('hours', 'invalid'); }
    const minNotice = b.minNoticeMin == null || b.minNoticeMin === '' ? 0 : v.int('minNoticeMin', b.minNoticeMin, { min: 0, max: 1440 });
    const bookingNote = v.text('bookingNote', b.bookingNote, { max: 200, required: false, multiline: true });
    v.assert();
    assertClean(HttpError, { description, bookingNote });
    // never: carrying passengers, illegal goods — whatever the type
    if (isForbiddenText(description) || isForbiddenText(bookingNote)) throw new HttpError(422, 'forbidden_service');
    return { type, description, priceMode, priceCents: price == null ? null : toCents(price), areaMode, center, radius, areaIds, hours, minNotice, bookingNote, active: b.active === false ? 0 : 1 };
  }
  const svcView = (s, types, lang = 'ar') => {
    const t = types.find((x) => x.key === s.type);
    return {
      id: s.id, type: s.type, typeName: t?.names?.[lang] || t?.names?.ar || s.type, description: s.description, priceMode: s.price_mode,
      price: s.price_cents != null ? fromCents(s.price_cents) : null, areaMode: s.area_mode, radiusKm: s.radius_km != null ? Number(s.radius_km) : null,
      areas: (parseJson(s.area_ids) || []).map((id) => { const a = areas?.get(id); return a ? { id, name: lang === 'ar' ? a.name_ar : (a.name_en || a.name_ar) } : null; }).filter(Boolean),
      hours: parseJson(s.hours), minNoticeMin: Number(s.min_notice_min || 0), bookingNote: s.booking_note || '', active: !!Number(s.active),
    };
  };
  /** km from a customer to a service (its circle centre, or the nearest chosen town), and whether he is inside. */
  function cover(s, lat, lng) {
    if (s.area_mode === 'radius' && s.center_lat != null) {
      const km = haversineKm(lat, lng, s.center_lat, s.center_lng);
      return { km, inside: km <= Number(s.radius_km || 0) + 1 };
    }
    let best = Infinity;
    for (const id of parseJson(s.area_ids) || []) { const a = areas?.get(id); if (a) best = Math.min(best, haversineKm(lat, lng, a.lat, a.lng)); }
    return { km: best, inside: best <= 5 };   // a town's centre ± 5 km
  }
  async function ratingOf(driverId) {
    const r = await db.one('SELECT CAST(COUNT(rating) AS INTEGER) AS n, AVG(rating) AS a FROM errands WHERE driver_id = $1 AND rating IS NOT NULL', [driverId]);
    return { count: Number(r?.n || 0), avg: r?.n ? Math.round(Number(r.a) * 10) / 10 : null };
  }
  const langOf = (req) => { const l = String(q(req).get('lang') || '').slice(0, 2); return ['ar', 'en', 'fr', 'es'].includes(l) ? l : 'ar'; };

  return [
    /* -------- options & availability (store) -------- */
    ['GET', /^\/api\/store\/menu\/(\d+)\/extras$/, store(async (req, res, m, cookId) => {
      const it = await ownItem(cookId, Number(m[1]));
      return ok(res, { groups: await extrasOf(it.id), availFrom: it.avail_from || null, availTo: it.avail_to || null });
    })],
    // Replaces the whole set of option groups of one product + its time window (simple for the phone screen).
    // Old orders keep their own copy of names and prices, so editing here never changes them.
    ['PUT', /^\/api\/store\/menu\/(\d+)\/extras$/, store(async (req, res, m, cookId) => {
      const it = await ownItem(cookId, Number(m[1]));
      const b = await readJson(req, 32 * 1024);
      const v = new Validator();
      const groupsIn = Array.isArray(b.groups) ? b.groups : [];
      if (groupsIn.length > 10) v.fail('groups', 'too_many');
      const groups = [];
      groupsIn.slice(0, 10).forEach((g, gi) => {
        const name = v.text(`groups.${gi}.name`, g?.name, { min: 1, max: 40 });
        const opts = Array.isArray(g?.options) ? g.options : [];
        if (!opts.length || opts.length > 20) v.fail(`groups.${gi}.options`, 'invalid');
        const options = opts.slice(0, 20).map((o, oi) => ({
          name: v.text(`groups.${gi}.options.${oi}.name`, o?.name, { min: 1, max: 40 }),
          cents: toCents(v.number(`groups.${gi}.options.${oi}.price`, o?.price ?? 0, { min: 0, max: 10000 }) || 0),
          available: o?.available === false ? 0 : 1,
        }));
        const min = v.int(`groups.${gi}.min`, g?.min ?? (g?.required ? 1 : 0), { min: 0, max: 20 });
        const max = v.int(`groups.${gi}.max`, g?.max ?? 1, { min: 1, max: 20 });
        if (Number.isInteger(min) && Number.isInteger(max) && (min > max || max > options.length)) v.fail(`groups.${gi}.max`, 'invalid');
        groups.push({ name, min, max, options });
      });
      let availFrom = null, availTo = null;
      if (b.availFrom || b.availTo) {
        if (!isHM(b.availFrom) || !isHM(b.availTo) || b.availFrom === b.availTo) v.fail('avail', 'invalid'); else { availFrom = b.availFrom; availTo = b.availTo; }
      }
      v.assert();
      assertClean(HttpError, Object.fromEntries(groups.flatMap((g, gi) => [[`g${gi}`, g.name], ...g.options.map((o, oi) => [`g${gi}o${oi}`, o.name])])));
      await db.tx(async (t) => {
        await t.query('DELETE FROM item_option_groups WHERE item_id = $1 AND cook_id = $2', [it.id, cookId]);
        for (const [gi, g] of groups.entries()) {
          const row = await t.one('INSERT INTO item_option_groups (cook_id, item_id, name, min_select, max_select, sort_order) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [cookId, it.id, g.name, g.min, g.max, gi]);
          for (const [oi, o] of g.options.entries()) await t.query('INSERT INTO item_options (group_id, name, price_cents, is_available, sort_order) VALUES ($1,$2,$3,$4,$5)', [row.id, o.name, o.cents, o.available, oi]);
        }
        await t.query('UPDATE menu_items SET avail_from = $1, avail_to = $2 WHERE id = $3 AND cook_id = $4', [availFrom, availTo, it.id, cookId]);
      });
      ctx.cache?.clear?.('feed:');
      return ok(res, { groups: await extrasOf(it.id), availFrom, availTo });
    })],

    // The cart asks before sending: today's prices, offers and what is no longer available (nothing is saved).
    ['POST', /^\/api\/delivery\/cart\/price$/, async (req, res) => {
      checkCsrf(req);
      await limit(limiters.lookup, `cart:${clientIp(req, cfg.trustProxy)}`);
      const b = await readJson(req);
      const storeId = Number(b.storeId);
      const items = Array.isArray(b.items) ? b.items : [];
      if (!Number.isInteger(storeId) || !items.length || items.length > 50) throw new HttpError(422, 'validation_failed', { fields: { items: 'invalid' } });
      const st = await db.one(`SELECT c.id, COALESCE(c.country, 'LB') AS country FROM cooks c WHERE c.id = $2 AND ${VIS}`, [iso(), storeId]);
      if (!st) throw notFound();
      const { lines, totalCents } = await priceLines(db, storeId, items, { country: st.country });
      return ok(res, { lines: lines.map((l) => ({ id: l.id, qty: l.qty, name: l.name, unit: fromCents(l.unitCents), discount: fromCents(l.discountCents), price: fromCents(l.finalCents), promo: l.promoLabel, options: l.options.map((o) => ({ id: o.optionId, name: o.name, price: fromCents(o.priceCents) })) })), total: fromCents(totalCents), currency: lines[0]?.currency || 'USD' });
    }],

    /* -------- promotions -------- */
    ['GET', /^\/api\/store\/promotions$/, store(async (req, res, m, cookId) => ok(res, { promotions: await promoRows(cookId) }))],
    ['POST', /^\/api\/store\/promotions$/, store(async (req, res, m, cookId) => {
      const b = await readJson(req);
      const v = new Validator();
      const p = promoInput(b, v);
      const itemId = b.itemId == null || b.itemId === '' ? null : v.int('itemId', b.itemId, { min: 1 });
      const section = itemId ? null : v.text('section', b.section, { min: 1, max: 40 });
      v.assert();
      assertClean(HttpError, { badge: p.badge });
      if (itemId) await ownItem(cookId, itemId);   // only its own products
      else {
        const has = await db.one('SELECT id FROM menu_items WHERE cook_id = $1 AND section = $2', [cookId, section]);
        const secs = parseJson((await db.one('SELECT menu_sections FROM cooks WHERE id = $1', [cookId]))?.menu_sections) || [];
        if (!has && !secs.includes(section)) throw new HttpError(422, 'validation_failed', { fields: { section: 'invalid' } });
      }
      const live = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM promotions WHERE cook_id = $1 AND active = 1 AND ends_at > $2`, [cookId, iso()]);
      if (live.n >= 50) throw new HttpError(409, 'too_many_items');
      const row = await db.one(`INSERT INTO promotions (cook_id, item_id, section, kind, value, badge, starts_at, ends_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [cookId, itemId, section, p.kind, p.value, p.badge, p.starts.toISOString(), p.ends.toISOString()]);
      ctx.cache?.clear?.('feed:');
      return ok(res, { id: row.id, promotions: await promoRows(cookId) }, 201);
    })],
    ['PATCH', /^\/api\/store\/promotions\/(\d+)$/, store(async (req, res, m, cookId) => {
      const b = await readJson(req);
      const r = await db.query('UPDATE promotions SET active = $1 WHERE id = $2 AND cook_id = $3 RETURNING id', [b.active === false ? 0 : 1, Number(m[1]), cookId]);
      if (!r.length) throw notFound();
      return ok(res, { promotions: await promoRows(cookId) });
    })],
    ['DELETE', /^\/api\/store\/promotions\/(\d+)$/, store(async (req, res, m, cookId) => {
      const r = await db.query('DELETE FROM promotions WHERE id = $1 AND cook_id = $2 RETURNING id', [Number(m[1]), cookId]);
      if (!r.length) throw notFound();
      return ok(res, { promotions: await promoRows(cookId) });
    })],

    // «Offers» on the home page. Location optional: without it every running offer of the country, newest first (never
    // called "nearest"); with it only offers around (25 km), nearest first. Paged like the store list.
    ['GET', /^\/api\/delivery\/offers$/, async (req, res) => {
      const p = q(req);
      const country = countryQ(req) || 'LB';   // always one country, never all
      if (countryHidden(country)) return ok(res, { offers: [], page: 0, hasMore: false, sorted: 'newest' });
      const lat = qNum(p.get('lat')), lng = qNum(p.get('lng'));
      const hasLoc = isValidLatLng(lat, lng) && !(lat === 0 && lng === 0);
      const { size, page } = paging(req, 20, 40);
      const now = iso();
      const params = [now, now];   // $1 for the subscription check (timestamps), $2 for the offers' text dates (PostgreSQL types each once)
      let where = `${VIS} AND p.active = 1 AND p.starts_at <= $2 AND p.ends_at > $2 AND (p.item_id IS NULL OR (mi.is_available = 1 AND mi.price IS NOT NULL))`;
      if (country) { params.push(country); where += ` AND COALESCE(c.country, 'LB') = $${params.length}`; }
      const km = Math.max(1, Number((await S.get()).storesRadiusKm) || 25);   // same «stores visible within» as the store lists
      if (hasLoc) {
        const dLat = km / 111.32, dLng = dLat / Math.max(0.2, Math.cos((lat * Math.PI) / 180));
        params.push(lat - dLat, lat + dLat, lng - dLng, lng + dLng);
        const k = params.length;
        where += ` AND c.lat BETWEEN $${k - 3} AND $${k - 2} AND c.lng BETWEEN $${k - 1} AND $${k}`;
      }
      const cid = await sessions.customer.ownerId(req).catch(() => null);
      const blocked = cid ? (parseJson((await db.one('SELECT blocked_stores FROM customers WHERE id = $1', [cid]))?.blocked_stores) || []) : [];
      const sql = `SELECT p.id, p.kind, p.value, p.badge, p.ends_at, p.section, p.item_id, mi.name AS item_name, mi.price AS item_price, mi.currency, CASE WHEN mi.photo IS NULL THEN 0 ELSE 1 END AS item_photo,
          c.id AS store_id, c.full_name, c.kind AS store_kind, c.photo_url, CASE WHEN c.photo IS NULL THEN 0 ELSE 1 END AS has_photo, c.lat, c.lng
        FROM promotions p JOIN cooks c ON c.id = p.cook_id LEFT JOIN menu_items mi ON mi.id = p.item_id WHERE ${where}`;
      const view = (r) => {
        const base = r.item_price != null ? toCents(r.item_price) : null;
        return {
          id: r.id, label: promoLabel(r), kind: r.kind, value: r.kind === 'percent' ? Number(r.value) : fromCents(r.value), endsAt: r.ends_at, section: r.section || null,
          store: { id: r.store_id, name: r.full_name, kind: r.store_kind, photoUrl: r.photo_url || (Number(r.has_photo) ? `/media/cooks/${r.store_id}.jpg` : null) },
          item: r.item_id ? { id: r.item_id, name: r.item_name, photo: Number(r.item_photo) ? `/api/menu-photo/${r.item_id}` : null, price: fromCents(base), newPrice: fromCents(base - discountOf(r, base)), currency: r.currency || 'USD' } : null,
          distanceM: hasLoc && hasPlace(r) ? Math.round(haversineKm(lat, lng, r.lat, r.lng) * 1000) : null,
        };
      };
      let list, hasMore;
      if (hasLoc) {
        list = (await db.query(sql, params)).map(view).filter((x) => x.distanceM != null && x.distanceM <= km * 1000 && !blocked.includes(x.store.id));
        list.sort((a, b) => a.distanceM - b.distanceM || b.id - a.id);
        hasMore = list.length > (page + 1) * size;
        list = list.slice(page * size, (page + 1) * size);
      } else {
        const rows = await db.query(`${sql} ORDER BY p.id DESC LIMIT ${size + 1} OFFSET ${page * size}`, params);
        hasMore = rows.length > size;
        list = rows.slice(0, size).map(view).filter((x) => !blocked.includes(x.store.id));
      }
      return ok(res, { offers: list, page, hasMore, sorted: hasLoc ? 'distance' : 'newest' });
    }],

    /* -------- preparation: "ready for pickup" (store's own orders only) -------- */
    ['POST', /^\/api\/store\/orders\/(\d+)\/ready$/, store(async (req, res, m, cookId) => {
      const o = await db.one('SELECT id, status, customer_id, driver_id, ready_at FROM orders WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (!o) throw notFound();
      if (o.ready_at || !['preparing', 'searching', 'assigned'].includes(o.status)) throw stateError();
      const r = await db.query(`UPDATE orders SET ready_at = $1 WHERE id = $2 AND cook_id = $3 AND ready_at IS NULL RETURNING id`, [iso(), o.id, cookId]);
      if (!r.length) throw stateError();
      push.notify('customer', o.customer_id, { title: 'Aklatak', key: 'cust_order_ready', vars: { ref: ref(o.id) }, body: `✅ طلبك ${ref(o.id)} جاهز`, url: `/#/o/${o.id}` });
      if (o.driver_id && o.status === 'assigned') push.notify('driver', o.driver_id, { title: 'Aklatak', key: 'drv_order_ready', vars: { ref: ref(o.id) }, body: `📦 الطلب ${ref(o.id)} جاهز للاستلام`, url: '/driver' });
      return ok(res, { readyAt: iso() });
    })],

    /* -------- gallery captions (portfolio of craftspeople, every business page) -------- */
    ['PATCH', /^\/api\/store\/photos\/(\d+)$/, store(async (req, res, m, cookId) => {
      const b = await readJson(req);
      const v = new Validator();
      const caption = v.text('caption', b.caption, { max: 80, required: false });
      v.assert();
      assertClean(HttpError, { caption });
      const r = await db.query('UPDATE cook_photos SET caption = $1 WHERE id = $2 AND cook_id = $3 RETURNING id', [caption || null, Number(m[1]), cookId]);
      if (!r.length) throw notFound();
      return ok(res);
    })],

    /* -------- craftspeople: quote → accepted once → scheduled → in progress → completed → confirmed -------- */
    ['POST', /^\/api\/store\/visits\/(\d+)\/quote$/, store(async (req, res, m, cookId) => {
      const b = await readJson(req);
      const v = new Validator();
      const price = v.number('price', b.price, { min: 1, max: 100000 });
      const note = v.text('note', b.note, { max: 300, required: false, multiline: true });
      const validHours = b.validHours == null || b.validHours === '' ? 48 : v.int('validHours', b.validHours, { min: 1, max: 24 * 14 });
      let when = null;
      if (b.when) { const d = new Date(b.when); if (Number.isNaN(d.getTime()) || d.getTime() < Date.now() - 3600_000 || d.getTime() > Date.now() + 90 * 864e5) v.fail('when', 'invalid'); else when = d.toISOString(); }
      v.assert();
      assertClean(HttpError, { note });
      const vr = await db.one('SELECT id, status, job_status, customer_id FROM visit_requests WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (!vr) throw notFound();
      if (!['pending', 'accepted'].includes(vr.status) || vr.job_status) throw stateError();
      const id = await db.tx(async (t) => {
        await t.query(`UPDATE visit_quotes SET status = 'withdrawn', decided_at = $1 WHERE visit_id = $2 AND status = 'sent'`, [iso(), vr.id]);   // a new price replaces the old one
        const row = await t.one('INSERT INTO visit_quotes (visit_id, cook_id, price_cents, note, valid_until) VALUES ($1,$2,$3,$4,$5) RETURNING id',
          [vr.id, cookId, toCents(price), note, new Date(Date.now() + validHours * 3600_000).toISOString()]);
        if (when) await t.query('UPDATE visit_requests SET job_at = $1 WHERE id = $2', [when, vr.id]);
        return row.id;
      });
      push.notify('customer', vr.customer_id, { title: 'Aklatak', key: 'cust_visit_quote', vars: { amount: price }, body: `💬 عرض سعر جديد: ${price}$`, url: '/#/orders/visits' });
      return ok(res, { id }, 201);
    })],
    ['POST', /^\/api\/store\/visits\/(\d+)\/job\/(start|complete)$/, store(async (req, res, m, cookId) => {
      const from = m[2] === 'start' ? ['scheduled'] : ['scheduled', 'in_progress'];
      const next = m[2] === 'start' ? 'in_progress' : 'completed';
      const vr = await db.one('SELECT id, customer_id FROM visit_requests WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (!vr) throw notFound();
      const r = await db.query(`UPDATE visit_requests SET job_status = $1${next === 'completed' ? ', completed_at = $4' : ''} WHERE id = $2 AND cook_id = $3 AND job_status IN (${from.map((x) => `'${x}'`).join(',')}) RETURNING id`,
        next === 'completed' ? [next, vr.id, cookId, iso()] : [next, vr.id, cookId]);
      if (!r.length) throw stateError();
      if (next === 'completed') push.notify('customer', vr.customer_id, { title: 'Aklatak', key: 'cust_visit_done', vars: {}, body: '✔️ أنهى الحِرفي العمل — يرجى التأكيد', url: '/#/orders/visits' });
      return ok(res, { jobStatus: next });
    })],
    ['POST', /^\/api\/customer\/visits\/(\d+)\/quotes\/(\d+)\/(accept|reject)$/, customer(async (req, res, m, cid) => {
      const vq = await db.one(`SELECT q.id, q.price_cents, q.status, q.valid_until, q.cook_id, v.id AS visit_id FROM visit_quotes q JOIN visit_requests v ON v.id = q.visit_id
        WHERE q.id = $1 AND v.id = $2 AND v.customer_id = $3`, [Number(m[2]), Number(m[1]), cid]);
      if (!vq) throw notFound();
      if (vq.status !== 'sent') throw stateError();
      if (m[3] === 'reject') {
        await db.query(`UPDATE visit_quotes SET status = 'rejected', decided_at = $1 WHERE id = $2 AND status = 'sent'`, [iso(), vq.id]);
        push.notify('store', vq.cook_id, { title: 'Aklatak', body: '❌ رفض الزبون عرض السعر', url: '/store' });
        return ok(res);
      }
      if (vq.valid_until <= iso()) throw new HttpError(409, 'quote_expired');
      // ONE acceptance only: the visit moves from "no job" to "scheduled" with a conditional update (two taps → one wins)
      const won = await db.tx(async (t) => {
        const r = await t.query(`UPDATE visit_requests SET status = 'accepted', job_status = 'scheduled', price_cents = $1, decided_at = $2
          WHERE id = $3 AND customer_id = $4 AND job_status IS NULL AND status IN ('pending','accepted') RETURNING id`, [vq.price_cents, iso(), vq.visit_id, cid]);
        if (!r.length) return false;
        await t.query(`UPDATE visit_quotes SET status = 'accepted', decided_at = $1 WHERE id = $2`, [iso(), vq.id]);
        await t.query(`UPDATE visit_quotes SET status = 'rejected', decided_at = $1 WHERE visit_id = $2 AND id <> $3 AND status = 'sent'`, [iso(), vq.visit_id, vq.id]);
        return true;
      });
      if (!won) throw new HttpError(409, 'already_accepted');
      push.notify('store', vq.cook_id, { title: 'Aklatak', key: 'store_quote_accepted', vars: { amount: fromCents(vq.price_cents) }, body: `✅ قَبِل الزبون عرضك ${fromCents(vq.price_cents)}$`, url: '/store' });
      return ok(res, { jobStatus: 'scheduled', price: fromCents(vq.price_cents) });
    })],
    ['POST', /^\/api\/customer\/visits\/(\d+)\/confirm$/, customer(async (req, res, m, cid) => {
      const r = await db.query(`UPDATE visit_requests SET job_status = 'confirmed', status = 'done', confirmed_at = $1 WHERE id = $2 AND customer_id = $3 AND job_status = 'completed' RETURNING cook_id`, [iso(), Number(m[1]), cid]);
      if (!r.length) throw stateError();
      push.notify('store', r[0].cook_id, { title: 'Aklatak', body: '✅ أكّد الزبون انتهاء العمل', url: '/store' });
      return ok(res);
    })],

    /* -------- independent drivers: his services (driver) -------- */
    ['GET', /^\/api\/driver\/services$/, driver(async (req, res, m, id) => {
      const types = await serviceTypes(db);
      const d = await db.one('SELECT services_on, jobs_until, CASE WHEN profile_photo IS NULL THEN 0 ELSE 1 END AS has_photo FROM drivers WHERE id = $1', [id]);
      const rows = await db.query('SELECT * FROM driver_services WHERE driver_id = $1 ORDER BY id', [id]);
      return ok(res, { on: !!Number(d.services_on), jobsActive: !!d.jobs_until && d.jobs_until > iso(), hasPhoto: !!Number(d.has_photo), types,
        services: rows.map((s) => ({ ...svcView(s, types, langOf(req)), center: s.center_lat != null ? { lat: s.center_lat, lng: s.center_lng } : null, areaIds: parseJson(s.area_ids) || [] })) });
    }, { activeOnly: false })],
    ['POST', /^\/api\/driver\/services$/, driver(async (req, res, m, id) => {
      const s = await svcInput(await readJson(req), new Validator(), await serviceTypes(db));
      const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM driver_services WHERE driver_id = $1', [id]);
      if (n.n >= 10) throw new HttpError(409, 'too_many_items');
      const row = await db.one(`INSERT INTO driver_services (driver_id, type, description, price_mode, price_cents, area_mode, center_lat, center_lng, radius_km, area_ids, hours, min_notice_min, booking_note, active)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING id`,
        [id, s.type, s.description, s.priceMode, s.priceCents, s.areaMode, s.center?.lat ?? null, s.center?.lng ?? null, s.radius, s.areaIds ? JSON.stringify(s.areaIds) : null, s.hours ? JSON.stringify(s.hours) : null, s.minNotice, s.bookingNote, s.active]);
      return ok(res, { id: row.id }, 201);
    })],
    ['PUT', /^\/api\/driver\/services\/(\d+)$/, driver(async (req, res, m, id) => {
      const own = await db.one('SELECT id FROM driver_services WHERE id = $1 AND driver_id = $2', [Number(m[1]), id]);
      if (!own) throw notFound();   // another driver's service looks like a missing one
      const s = await svcInput(await readJson(req), new Validator(), await serviceTypes(db));
      await db.query(`UPDATE driver_services SET type = $1, description = $2, price_mode = $3, price_cents = $4, area_mode = $5, center_lat = $6, center_lng = $7, radius_km = $8, area_ids = $9, hours = $10, min_notice_min = $11, booking_note = $12, active = $13
        WHERE id = $14 AND driver_id = $15`, [s.type, s.description, s.priceMode, s.priceCents, s.areaMode, s.center?.lat ?? null, s.center?.lng ?? null, s.radius, s.areaIds ? JSON.stringify(s.areaIds) : null, s.hours ? JSON.stringify(s.hours) : null, s.minNotice, s.bookingNote, s.active, own.id, id]);
      return ok(res);
    })],
    ['DELETE', /^\/api\/driver\/services\/(\d+)$/, driver(async (req, res, m, id) => {
      const r = await db.query('DELETE FROM driver_services WHERE id = $1 AND driver_id = $2 RETURNING id', [Number(m[1]), id]);
      if (!r.length) throw notFound();
      return ok(res);
    })],
    ['POST', /^\/api\/driver\/services-switch$/, driver(async (req, res, m, id) => {
      const b = await readJson(req);
      await db.query('UPDATE drivers SET services_on = $1 WHERE id = $2', [b.on === true ? 1 : 0, id]);
      return ok(res, { on: b.on === true });
    })],
    // public profile photo (the ID selfie stays private)
    ['POST', /^\/api\/driver\/profile-photo$/, driver(async (req, res, m, id) => {
      await limit(limiters.upload, `dprofile:${id}`);
      const b = await readJson(req, 500_000);
      if (b.photo === null) { await db.query('UPDATE drivers SET profile_mime = NULL, profile_photo = NULL WHERE id = $1', [id]); return ok(res); }
      const s = String(b.photo || '');
      if (!imageBytesOk(s) || s.length > 400_000) throw new HttpError(422, 'validation_failed', { fields: { photo: 'invalid' } });
      await db.query('UPDATE drivers SET profile_mime = $1, profile_photo = $2 WHERE id = $3', [/^data:(image\/\w+);/.exec(s)[1], s.split(',')[1], id]);
      return ok(res);
    })],

    /* -------- independent drivers: public listing and profile (no exact location ever) -------- */
    ['GET', /^\/api\/delivery\/service-types$/, async (req, res) => ok(res, { types: await serviceTypes(db) })],
    ['GET', /^\/api\/delivery\/drivers$/, async (req, res) => {
      const p = q(req);
      const country = countryQ(req) || 'LB';
      if (countryHidden(country)) return ok(res, { drivers: [], page: 0, hasMore: false, sorted: 'rating' });
      const lat = qNum(p.get('lat')), lng = qNum(p.get('lng'));
      const hasLoc = isValidLatLng(lat, lng) && !(lat === 0 && lng === 0);
      const type = String(p.get('type') || '');
      const { size, page } = paging(req, 20, 40);
      const lang = langOf(req);
      const types = await serviceTypes(db);
      const drivers = await db.query(`SELECT d.id, d.full_name, d.vehicle, CASE WHEN d.profile_photo IS NULL THEN 0 ELSE 1 END AS has_photo FROM drivers d
        WHERE ${LISTED} AND COALESCE(d.country, 'LB') = $2 ORDER BY d.id DESC LIMIT 2000`, [iso(), country]);
      const out = [];
      for (const d of drivers) {
        let svcs = (await db.query('SELECT * FROM driver_services WHERE driver_id = $1 AND active = 1 ORDER BY id', [d.id])).filter((s) => types.some((x) => x.key === s.type));
        if (type) svcs = svcs.filter((s) => s.type === type);
        let km = null;
        if (hasLoc) {
          const c = svcs.map((s) => cover(s, lat, lng)).filter((x) => x.inside);
          if (!c.length) continue;   // with a location: only drivers who serve it
          km = Math.min(...c.map((x) => x.km));
        }
        if (!svcs.length) continue;
        const tz = tzOf(country);
        out.push({ id: d.id, name: firstName(d.full_name), vehicle: d.vehicle, photo: Number(d.has_photo) ? `/api/delivery/drivers/${d.id}/photo` : null, rating: await ratingOf(d.id),
          // rounded to the km and never below 1 km: shows "how far", never where he is
          distanceM: km == null ? null : Math.max(1, Math.round(km)) * 1000,
          openNow: svcs.some((s) => isOpenNow(parseJson(s.hours), tz) !== false),
          services: svcs.map((s) => { const v = svcView(s, types, lang); return { id: v.id, type: v.type, typeName: v.typeName, priceMode: v.priceMode, price: v.price }; }) });
      }
      if (hasLoc) out.sort((a, b) => a.distanceM - b.distanceM || (b.rating.avg ?? 0) - (a.rating.avg ?? 0));
      else out.sort((a, b) => (b.rating.avg ?? 0) - (a.rating.avg ?? 0) || b.rating.count - a.rating.count || b.id - a.id);
      return ok(res, { drivers: out.slice(page * size, (page + 1) * size), page, hasMore: out.length > (page + 1) * size, sorted: hasLoc ? 'distance' : 'rating', types });
    }],
    ['GET', /^\/api\/delivery\/drivers\/(\d+)$/, async (req, res, m) => {
      const country = countryQ(req);
      const d = await db.one(`SELECT d.id, d.full_name, d.vehicle, COALESCE(d.country, 'LB') AS country, CASE WHEN d.profile_photo IS NULL THEN 0 ELSE 1 END AS has_photo FROM drivers d WHERE d.id = $2 AND ${LISTED}`, [iso(), Number(m[1])]);
      if (!d || (country && country !== d.country)) throw notFound();
      const types = await serviceTypes(db);
      const lang = langOf(req);
      const tz = tzOf(d.country);
      const p = q(req);
      const lat = qNum(p.get('lat')), lng = qNum(p.get('lng'));
      const hasLoc = isValidLatLng(lat, lng) && !(lat === 0 && lng === 0);
      const svcs = (await db.query('SELECT * FROM driver_services WHERE driver_id = $1 AND active = 1 ORDER BY id', [d.id])).filter((s) => types.some((x) => x.key === s.type));
      return ok(res, { driver: { id: d.id, name: firstName(d.full_name), vehicle: d.vehicle, photo: Number(d.has_photo) ? `/api/delivery/drivers/${d.id}/photo` : null, rating: await ratingOf(d.id),
        services: svcs.map((s) => {
          const c = hasLoc ? cover(s, lat, lng) : null;
          return { ...svcView(s, types, lang), openNow: isOpenNow(parseJson(s.hours), tz) !== false, servesYou: c ? c.inside : null, distanceM: c && Number.isFinite(c.km) ? Math.max(1, Math.round(c.km)) * 1000 : null };
        }) } });
    }],
    ['GET', /^\/api\/delivery\/drivers\/(\d+)\/photo$/, async (req, res, m) => {
      const d = await db.one(`SELECT d.profile_mime, d.profile_photo FROM drivers d WHERE d.id = $2 AND d.status = 'active' AND d.services_on = 1 AND d.jobs_until > $1`, [iso(), Number(m[1])]);
      if (!d?.profile_photo) throw notFound();
      const body = Buffer.from(d.profile_photo, 'base64');
      res.writeHead(200, { 'Content-Type': d.profile_mime, 'Content-Length': body.length, 'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' });
      res.end(body);
    }],

    // The customer asks ONE driver for one of his services. It becomes a request addressed to him only; the price comes
    // from him (his fixed price is sent as his quote right away, or he sends one). Never a restaurant order.
    ['POST', /^\/api\/delivery\/drivers\/(\d+)\/book$/, customer(async (req, res, m, cid) => {
      await limit(limiters.contact, `book:${cid}`);
      const b = await readJson(req);
      const v = new Validator();
      const serviceId = v.int('serviceId', b.serviceId, { min: 1 });
      const description = v.text('description', b.description, { min: 3, max: 500, multiline: true });
      const f = b.from || {}, to = b.to || {};
      const fl = [Number(f.lat), Number(f.lng)], tl = [Number(to.lat), Number(to.lng)];
      if (!isValidLatLng(...fl)) v.fail('from', 'invalid');
      if (!isValidLatLng(...tl)) v.fail('to', 'invalid');
      const fromDetails = v.text('fromDetails', f.details, { max: 300, required: false });
      const toDetails = v.text('toDetails', to.details, { max: 300, required: false });
      v.assert();
      assertClean(HttpError, { description, fromDetails, toDetails });
      if (isForbiddenText(description)) throw new HttpError(422, 'forbidden_service');
      const d = await db.one(`SELECT d.id, COALESCE(d.country, 'LB') AS country FROM drivers d WHERE d.id = $2 AND ${LISTED}`, [iso(), Number(m[1])]);
      if (!d) throw notFound();
      const svc = await db.one('SELECT * FROM driver_services WHERE id = $1 AND driver_id = $2 AND active = 1', [serviceId, d.id]);
      const types = await serviceTypes(db);
      const type = svc && types.find((x) => x.key === svc.type);
      if (!svc || !type) throw notFound();
      const me = await db.one(`SELECT COALESCE(country, 'LB') AS country FROM customers WHERE id = $1`, [cid]);
      if (me.country !== d.country) throw notFound();   // every country is separate
      if (isOpenNow(parseJson(svc.hours), tzOf(d.country)) === false) throw new HttpError(409, 'driver_closed');
      if (!cover(svc, fl[0], fl[1]).inside) throw new HttpError(422, 'outside_service_area');
      const s = await S.get();
      let purchase = null;
      if (type.errand === 'buy' && b.purchaseValue != null && b.purchaseValue !== '') {
        const pv = Number(b.purchaseValue);
        if (!Number.isFinite(pv) || pv < 0 || pv > s.maxPurchaseValue) throw new HttpError(422, 'validation_failed', { fields: { purchaseValue: 'out_of_range' } });
        purchase = pv;
      }
      const open = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM errands WHERE customer_id = $1 AND status IN ('searching','assigned','picked_up')`, [cid]);
      if (open.n >= 3) throw new HttpError(409, 'too_many_pending');
      const dist = Math.round(haversineKm(fl[0], fl[1], tl[0], tl[1]) * 1000);
      const e = await db.tx(async (t) => {
        const row = await t.one(`INSERT INTO errands (customer_id, kind, description, from_lat, from_lng, from_details, to_lat, to_lng, to_details, price, purchase_value, distance_m, search_started_at, country, quote_mode, target_driver_id, service_id)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,0,$10,$11,$12,$13,1,$14,$15) RETURNING id`,
          [cid, type.errand, description, fl[0], fl[1], fromDetails, tl[0], tl[1], toDetails, purchase, dist, iso(), d.country, d.id, svc.id]);
        await t.query('INSERT INTO errand_offers (errand_id, driver_id) VALUES ($1,$2)', [row.id, d.id]);   // only him
        if (svc.price_mode === 'fixed' && svc.price_cents > 0) await t.query('INSERT INTO errand_quotes (errand_id, driver_id, price_cents, note) VALUES ($1,$2,$3,$4)', [row.id, d.id, svc.price_cents, null]);
        return row;
      });
      push.notify('driver', d.id, { title: 'Aklatak', key: 'drv_direct_request', vars: {}, body: '📩 طلب خدمة موجّه إليك', url: '/driver' });
      return ok(res, { id: e.id, quoteMode: true }, 201);
    })],

    /* -------- drivers' quotes on customers' requests -------- */
    ['POST', /^\/api\/driver\/errands\/(\d+)\/quote$/, driver(async (req, res, m, id) => {
      const b = await readJson(req);
      const v = new Validator();
      const price = v.number('price', b.price, { min: 0.5, max: 500 });
      const note = v.text('note', b.note, { max: 200, required: false, multiline: true });
      v.assert();
      assertClean(HttpError, { note });
      const d = await db.one('SELECT jobs_until FROM drivers WHERE id = $1', [id]);
      if (!d.jobs_until || d.jobs_until <= iso()) throw new HttpError(403, 'jobs_subscription_required');
      // only a request that was sent to him (nearby, or addressed to him), still open, priced by quotes
      const e = await db.one(`SELECT e.id, e.customer_id, e.status, e.quote_mode FROM errands e JOIN errand_offers f ON f.errand_id = e.id AND f.driver_id = $2 AND f.status = 'sent' WHERE e.id = $1`, [Number(m[1]), id]);
      if (!e) throw notFound();
      if (e.status !== 'searching' || !Number(e.quote_mode)) throw stateError();
      // the money rules: a driver blocked (debt to the platform, open big-order exception) can't offer
      const pos = await driverPosition(db, await S.get(), id);
      if (pos.blocked) checkTake(pos, await S.get(), null);
      const prev = await db.one('SELECT id, status FROM errand_quotes WHERE errand_id = $1 AND driver_id = $2', [e.id, id]);
      if (prev && prev.status !== 'sent' && prev.status !== 'withdrawn') throw stateError();
      if (prev) await db.query(`UPDATE errand_quotes SET price_cents = $1, note = $2, status = 'sent', created_at = $3 WHERE id = $4`, [toCents(price), note, iso(), prev.id]);
      else await db.query('INSERT INTO errand_quotes (errand_id, driver_id, price_cents, note) VALUES ($1,$2,$3,$4)', [e.id, id, toCents(price), note]);
      push.notify('customer', e.customer_id, { title: 'Aklatak', key: 'cust_errand_quote', vars: { amount: price }, body: `💬 عرض سائق: ${price}$`, url: `/#/e/${e.id}` });
      return ok(res, { price }, prev ? 200 : 201);
    })],
    ['POST', /^\/api\/driver\/errands\/(\d+)\/quote\/withdraw$/, driver(async (req, res, m, id) => {
      const r = await db.query(`UPDATE errand_quotes SET status = 'withdrawn', decided_at = $1 WHERE errand_id = $2 AND driver_id = $3 AND status = 'sent' RETURNING id`, [iso(), Number(m[1]), id]);
      if (!r.length) throw notFound();
      return ok(res);
    })],
    ['GET', /^\/api\/customer\/errands\/(\d+)\/quotes$/, customer(async (req, res, m, cid) => {
      const e = await db.one('SELECT id FROM errands WHERE id = $1 AND customer_id = $2', [Number(m[1]), cid]);
      if (!e) throw notFound();
      const rows = await db.query(`SELECT q.id, q.driver_id, q.price_cents, q.note, q.status, q.created_at, d.full_name, d.vehicle, CASE WHEN d.profile_photo IS NULL THEN 0 ELSE 1 END AS has_photo
        FROM errand_quotes q JOIN drivers d ON d.id = q.driver_id WHERE q.errand_id = $1 AND q.status IN ('sent','accepted') ORDER BY q.price_cents, q.id`, [e.id]);
      const out = [];
      for (const r of rows) out.push({ id: r.id, price: fromCents(r.price_cents), note: r.note || '', status: r.status, createdAt: r.created_at,
        driver: { id: r.driver_id, name: firstName(r.full_name), vehicle: r.vehicle, photo: Number(r.has_photo) ? `/api/delivery/drivers/${r.driver_id}/photo` : null, rating: await ratingOf(r.driver_id) } });
      return ok(res, { quotes: out });
    })],
    // The customer picks a quote: in ONE transaction the request goes to that driver at that price and the other quotes
    // close. Two taps / two tabs at the same moment → the conditional update lets only one win.
    ['POST', /^\/api\/customer\/errands\/(\d+)\/quotes\/(\d+)\/accept$/, customer(async (req, res, m, cid) => {
      const s = await S.get();
      const out = await db.tx(async (t) => {
        const qr = await t.one(`SELECT q.id, q.driver_id, q.price_cents, q.status, e.id AS errand_id, e.status AS errand_status FROM errand_quotes q JOIN errands e ON e.id = q.errand_id
          WHERE q.id = $1 AND e.id = $2 AND e.customer_id = $3`, [Number(m[2]), Number(m[1]), cid]);
        if (!qr) throw notFound();
        if (qr.errand_status !== 'searching' || qr.status !== 'sent') throw new HttpError(409, 'offer_gone');
        await lockAccount(t, db.kind, 'driver', qr.driver_id);
        const pos = await driverPosition(t, s, qr.driver_id);
        if (pos.blocked || await driverBusy(t, qr.driver_id)) throw new HttpError(409, 'driver_unavailable');
        const now = iso();
        const r = await t.query(`UPDATE errands SET status = 'assigned', driver_id = $1, price = $2, assigned_at = $3, claim_until = NULL WHERE id = $4 AND status = 'searching' RETURNING id`,
          [qr.driver_id, fromCents(qr.price_cents), now, qr.errand_id]);
        if (!r.length) throw new HttpError(409, 'offer_gone');
        await t.query(`UPDATE errand_quotes SET status = 'accepted', decided_at = $1 WHERE id = $2`, [now, qr.id]);
        const losers = await t.query(`UPDATE errand_quotes SET status = 'closed', decided_at = $1 WHERE errand_id = $2 AND id <> $3 AND status = 'sent' RETURNING driver_id`, [now, qr.errand_id, qr.id]);
        await t.query(`UPDATE errand_offers SET status = 'won' WHERE errand_id = $1 AND driver_id = $2 AND status = 'sent'`, [qr.errand_id, qr.driver_id]);
        await t.query(`UPDATE errand_offers SET status = 'lost', lost_at = $1 WHERE errand_id = $2 AND driver_id <> $3 AND status = 'sent'`, [now, qr.errand_id, qr.driver_id]);
        return { ...qr, losers: losers.map((x) => x.driver_id) };
      });
      push.notify('driver', out.driver_id, { title: 'Aklatak', key: 'drv_quote_won', vars: { amount: fromCents(out.price_cents) }, body: `✅ قَبِل الزبون عرضك ${fromCents(out.price_cents)}$`, url: '/driver' });
      for (const l of out.losers) push.notify('driver', l, { title: 'Aklatak', key: 'drv_quote_lost', vars: {}, body: 'اختار الزبون عرضاً آخر', url: '/driver' });
      return ok(res, { errandId: out.errand_id, driverId: out.driver_id, price: fromCents(out.price_cents) });
    })],
    ['POST', /^\/api\/customer\/errands\/(\d+)\/rate$/, customer(async (req, res, m, cid) => {
      const b = await readJson(req);
      const v = new Validator();
      const stars = v.int('stars', b.stars, { min: 1, max: 5 });
      v.assert();
      const r = await db.query(`UPDATE errands SET rating = $1 WHERE id = $2 AND customer_id = $3 AND status = 'delivered' AND driver_id IS NOT NULL RETURNING id`, [stars, Number(m[1]), cid]);
      if (!r.length) throw stateError();
      return ok(res);
    })],

    /* -------- owner -------- */
    ['GET', /^\/api\/admin\/catalog\/service-types$/, owner(async (req, res) => ok(res, { types: await serviceTypes(db) }))],
    ['PUT', /^\/api\/admin\/catalog\/service-types$/, owner(async (req, res, m, a) => {
      const types = await setServiceTypes(db, (await readJson(req)).types);
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,NULL,$2,$3)', [a.id, 'driver_service_types', JSON.stringify(types.map((x) => x.key))]);
      return ok(res, { types });
    })],
    ['GET', /^\/api\/admin\/catalog\/overview$/, owner(async (req, res) => {
      const n = async (sql, p = []) => Number((await db.one(sql, p))?.n || 0);
      const now = iso();
      return ok(res, {
        promotionsLive: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM promotions WHERE active = 1 AND starts_at <= $1 AND ends_at > $1`, [now]),
        optionGroups: await n('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM item_option_groups'),
        driversListed: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM drivers d WHERE ${LISTED}`, [now]),
        quotesOpen: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM errand_quotes WHERE status = 'sent'`),
        visitQuotesOpen: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM visit_quotes WHERE status = 'sent'`),
        services: await db.query(`SELECT s.id, s.type, s.description, s.price_mode, s.price_cents, s.active, s.created_at, d.id AS driver_id, d.full_name, d.phone, COALESCE(d.country, 'LB') AS country
          FROM driver_services s JOIN drivers d ON d.id = s.driver_id ORDER BY s.id DESC LIMIT 200`),
      });
    })],
    ['POST', /^\/api\/admin\/catalog\/driver-services\/(\d+)\/(disable|enable)$/, owner(async (req, res, m, a) => {
      const r = await db.query('UPDATE driver_services SET active = $1 WHERE id = $2 RETURNING driver_id', [m[2] === 'enable' ? 1 : 0, Number(m[1])]);
      if (!r.length) throw notFound();
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,NULL,$2,$3)', [a.id, `driver_service_${m[2]}`, JSON.stringify({ serviceId: Number(m[1]), driverId: r[0].driver_id })]);
      return ok(res);
    })],
  ];
}
