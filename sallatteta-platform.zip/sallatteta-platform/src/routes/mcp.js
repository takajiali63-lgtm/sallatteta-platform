// v8.3 the owner's Claude connector (owner's request, 12 Oct 2026: «اربطك عل لوحة الإدارة»).
// A small remote MCP server at /mcp (JSON-RPC over HTTP, JSON answers) so the owner can tell Claude, from the Claude
// app, «change this price», «give that store the AI MANAGER for 2 months», «what is pending?»…
//
// Safety, by design:
//  - a secret key made in the admin panel (shown once, kept only as a hash, revocable at once);
//  - every tool goes through the SAME admin endpoints as the panel (same checks, same limits) via a short-lived admin
//    session that is deleted right after the call;
//  - a fixed, short list of tools: NO deleting accounts or data, NO moving money, NO payment numbers, NO passwords;
//  - every change is first shown as «before → after» (preview); it is applied only when called again with confirm=true;
//  - every call (preview or applied) is written in the admin log as «Claude».
import { request as httpRequest } from 'node:http';
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { makeGuards } from '../lib/guards.js';
import { randomToken, sha256 } from '../lib/security.js';

const META = 'mcp_tokens';
const PROTOCOLS = ['2025-06-18', '2025-03-26', '2024-11-05'];
const MAX_TOKENS = 10;
// money-flow switches of the delivery settings stay in the panel only
const DELIVERY_LOCKED = new Set(['payoutThreshold', 'storeMinWithdraw', 'dailyWithdrawMax', 'autoPayStores', 'platformMoney', 'settleLinkMin', 'v79']);
const MONTHS = ['1', '3', '12'];
const AI_GROUPS = ['shops', 'online', 'crafts', 'drivers'];

/* ---------- small helpers ---------- */
const isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);
const getAt = (o, path) => path.reduce((a, k) => (a == null ? undefined : a[k]), o);
function flatten(o, pre = [], out = []) {
  for (const [k, v] of Object.entries(o || {})) {
    if (isObj(v)) flatten(v, [...pre, k], out);
    else out.push([[...pre, k], v]);
  }
  return out;
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
/** «before → after» for each value the patch would set (only the ones that really change). */
const diff = (current, patch) => flatten(patch).map(([p, after]) => ({ field: p.join('.'), before: getAt(current, p) ?? null, after }))
  .filter((c) => !same(c.before, c.after));
const usd = (cents) => (cents == null ? null : Math.round(Number(cents)) / 100);
const cents = (v, field) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0 || n > 1_000_000) throw new ToolError(`${field}: invalid amount`);
  return Math.round(n * 100);
};
class ToolError extends Error {}
/** JSON-RPC body: an object or a batch (array); any JSON content type. */
async function readBody(req, limit = 256 * 1024) {
  let size = 0; const chunks = [];
  for await (const c of req) { size += c.length; if (size > limit) throw new Error('too large'); chunks.push(c); }
  const v = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  if (!v || typeof v !== 'object') throw new Error('bad');
  return v;
}

/* ---------- token store (app_meta) ---------- */
async function readTokens(db) {
  const r = await db.one('SELECT value FROM app_meta WHERE key = $1', [META]);
  try { const l = r ? JSON.parse(r.value) : []; return Array.isArray(l) ? l : []; } catch { return []; }
}
async function writeTokens(db, list) {
  const v = JSON.stringify(list);
  if (await db.one('SELECT key FROM app_meta WHERE key = $1', [META])) await db.query('UPDATE app_meta SET value = $1 WHERE key = $2', [v, META]);
  else await db.query('INSERT INTO app_meta (key, value) VALUES ($1, $2)', [META, v]);
}
const publicToken = (t) => ({ id: t.id, label: t.label, createdAt: t.createdAt, lastUsedAt: t.lastUsedAt || null, hint: t.hint });

/* ---------- the tools ---------- */
const S = (props, required = []) => ({ type: 'object', properties: props, required, additionalProperties: false });
const CONFIRM = { type: 'boolean', description: 'false/absent = preview only (nothing saved). true = apply the change shown in the preview.' };
const PRICES = { type: 'object', description: 'Prices in USD by number of months, e.g. {"1": 20, "3": 54, "12": 200}', additionalProperties: { type: 'number' } };

export const TOOL_DEFS = [
  { name: 'overview', write: false, description: 'Today on Aklatak: orders, active orders, drivers, pending renewals/payouts/complaints, stores\' cash still with drivers, and the AI spending this month (USD).', inputSchema: S({}) },
  { name: 'list_stores', write: false, description: 'Find stores/restaurants (main stores and branches) by name or phone. Returns id, name, category, country, status, suspended, branches, monthly price.', inputSchema: S({ q: { type: 'string', description: 'part of the name or phone (optional)' } }) },
  { name: 'get_prices', write: false, description: 'All subscription prices: stores basic / with drivers by months, AI MANAGER monthly price per group (no discount: 3 and 12 months = monthly × months, per branch), branch percent, drivers\' requests plan, per-category plans and limits, and whether payments are Google Play only.', inputSchema: S({}) },
  { name: 'set_prices', write: true, description: 'Change subscription prices (USD). Preview first; apply with confirm=true. Example: {"store":{"basic":{"1":20}},"ai":{"shops":30}}. ai = MONTHLY AI price per group (shops, online, crafts, drivers). aiHidden = hide the AI MANAGER from the subscription pages of stores / drivers.',
    inputSchema: S({ store: S({ basic: PRICES, delivery: PRICES }), driverJobs: PRICES, ai: { type: 'object', properties: Object.fromEntries(AI_GROUPS.map((g) => [g, { type: 'number' }])), additionalProperties: false }, branchPercent: { type: 'number', description: 'each extra branch pays this % of the main price' }, aiHidden: S({ stores: { type: 'boolean' }, drivers: { type: 'boolean' } }), confirm: CONFIRM }) },
  { name: 'set_category_plan', write: true, description: 'Set one category\'s own prices and limits (e.g. kind "restaurant"): products, photos, basic/delivery/ai prices by months. Use null to clear a value (= general). Preview first; apply with confirm=true.',
    inputSchema: S({ kind: { type: 'string' }, products: { type: ['integer', 'null'] }, photos: { type: ['integer', 'null'] }, basic: PRICES, delivery: PRICES, ai: PRICES, confirm: CONFIRM }, ['kind']) },
  { name: 'get_ai_config', write: false, description: 'The AI MANAGER settings: on/off per group, monthly AI budget per subscriber (USD), extra pack, models, protection (platform monthly cap…), the loaded balance and days left, and this month\'s spending.', inputSchema: S({}) },
  { name: 'set_ai_config', write: true, description: 'Change the AI settings (amounts in USD). Preview first; apply with confirm=true.',
    inputSchema: S({ enabled: { type: 'boolean' }, categories: { type: 'object', properties: Object.fromEntries(AI_GROUPS.map((g) => [g, { type: 'boolean' }])), additionalProperties: false },
      budgetsUsd: { type: 'object', description: 'monthly AI budget per subscriber, by group', properties: Object.fromEntries(AI_GROUPS.map((g) => [g, { type: 'number' }])), additionalProperties: false },
      packPriceUsd: { type: 'number' }, packBudgetUsd: { type: 'number' }, monthlyCapUsd: { type: 'number', description: 'platform-wide AI spending cap per month' },
      balanceUsd: { type: 'number', description: 'what the owner just loaded on the Anthropic account' }, lowBalanceDays: { type: 'integer' }, allowOwnKey: { type: 'boolean' }, confirm: CONFIRM }) },
  { name: 'get_delivery_settings', write: false, description: 'Delivery settings: radii (km), drivers per offer, timers, delivery fee by distance, drivers\' cash limit…', inputSchema: S({}) },
  { name: 'set_delivery_settings', write: true, description: 'Change delivery settings (same names as get_delivery_settings). Money-flow switches (withdrawals, auto payouts, platform money) are not available here. Preview first; apply with confirm=true.',
    inputSchema: { type: 'object', properties: { settings: { type: 'object', description: 'e.g. {"storesRadiusKm": 30, "offerBatch": 6}' }, confirm: CONFIRM }, required: ['settings'], additionalProperties: false } },
  { name: 'list_pending', write: false, description: 'What waits for the owner: subscription renewal requests and AI pack requests.', inputSchema: S({}) },
  { name: 'decide_renewal', write: true, description: 'Approve or reject a pending renewal request (id from list_pending). Preview first; apply with confirm=true.',
    inputSchema: S({ id: { type: 'integer' }, decision: { type: 'string', enum: ['approve', 'reject'] }, confirm: CONFIRM }, ['id', 'decision']) },
  { name: 'store_ai', write: true, description: 'Give a store (or branch) the AI MANAGER for N months (added to what it has), or months=0 to stop it. Preview first; apply with confirm=true.',
    inputSchema: S({ storeId: { type: 'integer' }, months: { type: 'integer', minimum: 0, maximum: 12 }, confirm: CONFIRM }, ['storeId', 'months']) },
  { name: 'suspend_account', write: true, description: 'Suspend (read-only) or re-activate a store or a driver. Nothing is deleted. Preview first; apply with confirm=true.',
    inputSchema: S({ type: { type: 'string', enum: ['store', 'driver'] }, id: { type: 'integer' }, action: { type: 'string', enum: ['suspend', 'activate'] }, confirm: CONFIRM }, ['type', 'id', 'action']) },
  { name: 'broadcast', write: true, description: 'Send a message to all drivers or all stores (shown in their app until it expires). Preview first; send with confirm=true.',
    inputSchema: S({ audience: { type: 'string', enum: ['drivers', 'stores'] }, body: { type: 'string' }, days: { type: 'integer', minimum: 1, maximum: 365 }, confirm: CONFIRM }, ['audience', 'body']) },
];
const TOOLS = new Map(TOOL_DEFS.map((t) => [t.name, t]));

/** Each tool: (args, call) → { preview?, changes?, result } — call(method, path, body) uses the admin API. */
const IMPL = {
  async overview(a, call) {
    const o = await call('GET', '/api/admin/delivery/overview');
    const m = (await call('GET', '/api/admin/ai/money')).money || {};
    return { result: { ...o, ai: { monthUsd: usd(m.monthCents), todayUsd: usd(m.todayCents), perDayUsd: usd(m.perDayCents), capUsd: usd(m.capCents), capPct: m.capPct, balanceLeftUsd: usd(m.balanceLeftCents), daysLeft: m.daysLeft, revenueUsd: usd(m.revenueCents), revenuePct: m.revenuePct, freeReplies: m.freeReplies } } };
  },
  async list_stores(a, call) {
    const { stores } = await call('GET', `/api/admin/delivery/stores${a.q ? `?q=${encodeURIComponent(String(a.q).slice(0, 40))}` : ''}`);
    return { result: { count: stores.length, stores: stores.slice(0, 100).map((s) => ({ id: s.id, name: s.full_name, kind: s.kind, country: s.country, status: s.status, suspended: !!Number(s.suspended), branchOf: s.parent_id || null, branches: s.branches ?? null, monthlyPrice: s.price ?? null, deliveryMode: s.delivery_mode })) } };
  },
  async get_prices(a, call) {
    const { plans } = await call('GET', '/api/admin/plans');
    const st = await call('GET', '/api/admin/settings');
    const p = (g) => Object.fromEntries(Object.entries(g || {}).map(([k, v]) => [k, v.price]));
    return { result: { currency: 'USD', store: { basic: p(plans.store.basic), delivery: p(plans.store.delivery) }, branchPercent: plans.branchPercent, driverJobs: p(plans.driverJobs),
      aiMonthly: Object.fromEntries(Object.entries(plans.ai || {}).map(([g, v]) => [g, v['1']?.price])), aiHidden: plans.aiHidden || {}, aiRule: 'no discount: months × monthly, for each branch that has it',
      categoryPlans: st.catPlans || {}, googlePlayOnly: st.googleOnly !== false } };
  },
  async set_prices(a, call, confirm) {
    const { plans } = await call('GET', '/api/admin/plans');
    const patch = {}, view = {};
    const tier = (src, path) => {
      if (!src) return;
      for (const [m, v] of Object.entries(src)) {
        if (!MONTHS.includes(String(m))) throw new ToolError(`${path.join('.')}.${m}: months must be 1, 3 or 12`);
        const n = Number(v); if (!Number.isFinite(n) || n < 0 || n > 100000) throw new ToolError(`${path.join('.')}.${m}: invalid price`);
        let o = patch; for (const k of path) o = (o[k] ||= {}); (o[m] = { price: n });
        let w = view; for (const k of path) w = (w[k] ||= {}); w[m] = n;
      }
    };
    tier(a.store?.basic, ['store', 'basic']); tier(a.store?.delivery, ['store', 'delivery']); tier(a.driverJobs, ['driverJobs']);
    for (const [g, v] of Object.entries(a.ai || {})) {
      if (!AI_GROUPS.includes(g)) throw new ToolError(`ai.${g}: unknown group`);
      const n = Number(v); if (!Number.isFinite(n) || n < 0 || n > 100000) throw new ToolError(`ai.${g}: invalid price`);
      ((patch.ai ||= {})[g] = { 1: { price: n } }); ((view.aiMonthly ||= {})[g] = n);
    }
    if (a.branchPercent !== undefined) { patch.branchPercent = a.branchPercent; view.branchPercent = a.branchPercent; }
    if (a.aiHidden) { patch.aiHidden = {}; view.aiHidden = {}; for (const k of ['stores', 'drivers']) if (typeof a.aiHidden[k] === 'boolean') { patch.aiHidden[k] = a.aiHidden[k]; view.aiHidden[k] = a.aiHidden[k]; } }
    const current = { store: { basic: {}, delivery: {} }, driverJobs: {}, aiMonthly: {}, branchPercent: plans.branchPercent, aiHidden: plans.aiHidden || {} };
    for (const t of ['basic', 'delivery']) for (const [k, v] of Object.entries(plans.store[t])) current.store[t][k] = v.price;
    for (const [k, v] of Object.entries(plans.driverJobs)) current.driverJobs[k] = v.price;
    for (const [g, v] of Object.entries(plans.ai)) current.aiMonthly[g] = v['1']?.price;
    const changes = diff(current, view);
    if (!changes.length) return { changes, result: 'nothing to change (same values)' };
    if (!confirm) return { preview: true, changes };
    await call('PUT', '/api/admin/plans', patch);
    return { changes, result: 'saved' };
  },
  async set_category_plan(a, call, confirm) {
    const kind = String(a.kind || '');
    if (!/^[a-z][a-z0-9_]{1,30}$/.test(kind)) throw new ToolError('kind: invalid');
    const st = await call('GET', '/api/admin/settings');
    const all = JSON.parse(JSON.stringify(st.catPlans || {}));
    const cur = all[kind] || {};
    const next = JSON.parse(JSON.stringify(cur));
    for (const k of ['products', 'photos']) if (a[k] !== undefined) { if (a[k] === null) delete next[k]; else next[k] = a[k]; }
    for (const t of ['basic', 'delivery', 'ai']) if (a[t]) {
      next[t] = { ...(next[t] || {}) };
      for (const [m, v] of Object.entries(a[t])) { if (!MONTHS.includes(String(m))) throw new ToolError(`${t}.${m}: months must be 1, 3 or 12`); if (v === null) delete next[t][m]; else next[t][m] = v; }
      if (!Object.keys(next[t]).length) delete next[t];
    }
    const keys = new Set([...flatten(cur), ...flatten(next)].map(([p]) => p.join('.')));
    const changes = [...keys].map((f) => ({ field: `${kind}.${f}`, before: getAt(cur, f.split('.')) ?? null, after: getAt(next, f.split('.')) ?? null })).filter((c) => !same(c.before, c.after));
    if (!changes.length) return { changes, result: 'nothing to change (same values)' };
    if (!confirm) return { preview: true, changes };
    if (Object.keys(next).length) all[kind] = next; else delete all[kind];
    await call('PUT', '/api/admin/settings', { catPlans: all });
    return { changes, result: 'saved' };
  },
  async get_ai_config(a, call) {
    const { config: c } = await call('GET', '/api/admin/ai/config');
    const m = (await call('GET', '/api/admin/ai/money')).money || {};
    return { result: { enabled: c.enabled, categories: c.categories, budgetsUsd: Object.fromEntries(Object.entries(c.budgets).map(([k, v]) => [k, usd(v)])),
      pack: { priceUsd: c.pack.priceUsd, budgetUsd: usd(c.pack.cents) }, models: c.models, monthlyCapUsd: usd(c.protect.monthlyCapCents), lowBalanceDays: c.protect.lowBalanceDays,
      allowOwnKey: c.allowOwnKey, balance: { loadedUsd: usd(c.balance.cents), asOf: c.balance.asOf || null, leftUsd: usd(m.balanceLeftCents), daysLeft: m.daysLeft },
      thisMonth: { spentUsd: usd(m.monthCents), capPct: m.capPct, revenueUsd: usd(m.revenueCents), spentPctOfRevenue: m.revenuePct } } };
  },
  async set_ai_config(a, call, confirm) {
    const { config: c } = await call('GET', '/api/admin/ai/config');
    const body = {}, view = {}, current = {};
    if (a.enabled !== undefined) { body.enabled = a.enabled; view.enabled = a.enabled; current.enabled = c.enabled; }
    if (a.categories) { body.categories = a.categories; view.categories = a.categories; current.categories = c.categories; }
    if (a.budgetsUsd) { body.budgets = {}; view.budgetsUsd = {}; current.budgetsUsd = {}; for (const [g, v] of Object.entries(a.budgetsUsd)) { body.budgets[g] = cents(v, `budgetsUsd.${g}`); view.budgetsUsd[g] = Number(v); current.budgetsUsd[g] = usd(c.budgets[g]); } }
    if (a.packPriceUsd !== undefined) { (body.pack ||= {}).priceUsd = Number(a.packPriceUsd); view.packPriceUsd = Number(a.packPriceUsd); current.packPriceUsd = c.pack.priceUsd; }
    if (a.packBudgetUsd !== undefined) { (body.pack ||= {}).cents = cents(a.packBudgetUsd, 'packBudgetUsd'); view.packBudgetUsd = Number(a.packBudgetUsd); current.packBudgetUsd = usd(c.pack.cents); }
    if (a.monthlyCapUsd !== undefined) { (body.protect ||= {}).monthlyCapCents = cents(a.monthlyCapUsd, 'monthlyCapUsd'); view.monthlyCapUsd = Number(a.monthlyCapUsd); current.monthlyCapUsd = usd(c.protect.monthlyCapCents); }
    if (a.lowBalanceDays !== undefined) { (body.protect ||= {}).lowBalanceDays = a.lowBalanceDays; view.lowBalanceDays = a.lowBalanceDays; current.lowBalanceDays = c.protect.lowBalanceDays; }
    if (a.balanceUsd !== undefined) { body.balance = { cents: cents(a.balanceUsd, 'balanceUsd') }; view.balanceUsd = Number(a.balanceUsd); current.balanceUsd = usd(c.balance.cents); }
    if (a.allowOwnKey !== undefined) { body.allowOwnKey = a.allowOwnKey; view.allowOwnKey = a.allowOwnKey; current.allowOwnKey = c.allowOwnKey; }
    const changes = diff(current, view);
    if (!changes.length) return { changes, result: 'nothing to change (same values)' };
    if (!confirm) return { preview: true, changes };
    await call('PUT', '/api/admin/ai/config', body);
    return { changes, result: 'saved' };
  },
  async get_delivery_settings(a, call) {
    const { settings } = await call('GET', '/api/admin/delivery/settings');
    const out = { ...settings }; for (const k of DELIVERY_LOCKED) delete out[k];
    return { result: out };
  },
  async set_delivery_settings(a, call, confirm) {
    if (!isObj(a.settings)) throw new ToolError('settings: object expected');
    const { settings } = await call('GET', '/api/admin/delivery/settings');
    const patch = {};
    for (const [k, v] of Object.entries(a.settings)) {
      if (DELIVERY_LOCKED.has(k)) throw new ToolError(`${k}: this money setting can only be changed in the admin panel`);
      if (!(k in settings)) throw new ToolError(`${k}: unknown setting`);
      patch[k] = v;
    }
    const changes = Object.entries(patch).map(([k, v]) => ({ field: k, before: settings[k] ?? null, after: v })).filter((c) => !same(c.before, c.after));
    if (!changes.length) return { changes, result: 'nothing to change (same values)' };
    if (!confirm) return { preview: true, changes };
    await call('PUT', '/api/admin/delivery/settings', patch);
    return { changes, result: 'saved' };
  },
  async list_pending(a, call) {
    const { renewals } = await call('GET', '/api/admin/renewals?status=pending');
    const m = await call('GET', '/api/admin/ai/money');
    return { result: {
      renewals: renewals.map((r) => ({ id: r.id, store: r.store, storeId: r.cook_id, kind: r.kind, tier: r.tier, months: r.months, branches: r.branches, amount: r.amount, method: r.method, reference: r.reference, aiBranches: r.aiBranches, createdAt: r.created_at })),
      aiPacks: (m.packs || []).filter((p) => p.status === 'pending').map((p) => ({ id: p.id, name: p.name, ownerType: p.owner_type, price: p.price, budgetUsd: usd(p.cents), method: p.method, createdAt: p.created_at, note: 'approve AI packs in the admin panel' })),
    } };
  },
  async decide_renewal(a, call, confirm) {
    const { renewals } = await call('GET', '/api/admin/renewals?status=pending');
    const r = renewals.find((x) => Number(x.id) === Number(a.id));
    if (!r) throw new ToolError('no pending renewal with this id');
    const changes = [{ field: `renewal ${r.id} (${r.store}, ${r.months} months, ${r.amount}$)`, before: 'pending', after: a.decision === 'approve' ? 'approved' : 'rejected' }];
    if (!confirm) return { preview: true, changes };
    await call('POST', `/api/admin/renewals/${r.id}/${a.decision}`, {});
    return { changes, result: 'done' };
  },
  async store_ai(a, call, confirm, db) {
    const c = await db.one('SELECT id, full_name, ai_until FROM cooks WHERE id = $1', [Number(a.storeId)]);
    if (!c) throw new ToolError('store not found');
    const months = Number(a.months);
    if (!Number.isInteger(months) || months < 0 || months > 12) throw new ToolError('months: 0 to 12');
    const now = new Date();
    const from = c.ai_until && Date.parse(c.ai_until) > now.getTime() ? new Date(c.ai_until) : now;
    const until = months ? new Date(from.getFullYear(), from.getMonth() + months, from.getDate(), from.getHours(), from.getMinutes()).toISOString() : null;
    const changes = [{ field: `AI MANAGER of «${c.full_name}» (#${c.id}) until`, before: c.ai_until || null, after: until }];
    if (!confirm) return { preview: true, changes };
    const r = await call('POST', `/api/admin/stores/${c.id}/ai`, { months });
    return { changes: [{ ...changes[0], after: r.aiUntil }], result: 'saved' };
  },
  async suspend_account(a, call, confirm, db) {
    const table = a.type === 'driver' ? 'drivers' : 'cooks';
    const row = await db.one(`SELECT id, full_name, ${a.type === 'driver' ? 'status' : 'suspended'} AS s FROM ${table} WHERE id = $1`, [Number(a.id)]);
    if (!row) throw new ToolError('not found');
    const was = a.type === 'driver' ? row.s === 'suspended' : !!Number(row.s);
    const changes = [{ field: `${a.type} «${row.full_name}» (#${row.id})`, before: was ? 'suspended' : 'active', after: a.action === 'suspend' ? 'suspended' : 'active' }].filter((c) => c.before !== c.after);
    if (!changes.length) return { changes, result: 'already like this' };
    if (!confirm) return { preview: true, changes };
    await call('POST', `/api/admin/accounts/${a.type}/${row.id}/${a.action}`, {});
    return { changes, result: 'done' };
  },
  async broadcast(a, call, confirm) {
    const body = String(a.body || '').trim();
    if (body.length < 2 || body.length > 2000) throw new ToolError('body: 2 to 2000 characters');
    const changes = [{ field: `message to all ${a.audience}${a.days ? ` for ${a.days} days` : ''}`, before: null, after: body }];
    if (!confirm) return { preview: true, changes };
    const r = await call('POST', '/api/admin/broadcasts', { audience: a.audience, body, ...(a.days ? { days: a.days } : {}) });
    return { changes, result: `sent (#${r.id})` };
  },
};

/* ---------- routes ---------- */
export function mcpRoutes(ctx) {
  const { db } = ctx;
  const { owner, sessions } = makeGuards(ctx);
  const hits = new Map();   // per key: calls in the current minute
  const rateOk = (id, max = 60) => {
    const now = Date.now(), h = hits.get(id);
    if (!h || now - h.at > 60_000) { hits.set(id, { at: now, n: 1 }); return true; }
    return ++h.n <= max;
  };

  async function authed(req) {
    const raw = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
    if (!raw || raw.length < 20 || raw.length > 200) return null;
    const hash = sha256(raw);
    const list = await readTokens(db);
    const t = list.find((x) => x.hash === hash);
    if (!t) return null;
    const a = await db.one('SELECT id, role FROM admin_users WHERE id = $1 AND disabled = 0', [t.adminId]);
    if (!a || a.role === 'agent') return null;
    if (!t.lastUsedAt || Date.now() - Date.parse(t.lastUsedAt) > 60_000) { t.lastUsedAt = new Date().toISOString(); await writeTokens(db, list); }
    return { token: t, admin: a };
  }

  /** The admin API, called through this same server with a session that lives only for this call. */
  function loopback(req, cookie) {
    const port = req.socket.localPort;
    return (method, path, body) => new Promise((resolve, reject) => {
      const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
      const r = httpRequest({ host: '127.0.0.1', port, method, path, headers: { Cookie: cookie, 'X-Requested-With': 'fetch', 'User-Agent': 'aklatak-mcp', ...(data ? { 'Content-Type': 'application/json', 'Content-Length': data.length } : {}) } }, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          let json = null; try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { json = null; }
          if (res.statusCode >= 400) return reject(new ToolError(`${json?.error || 'error'}${json?.fields ? ` ${JSON.stringify(json.fields)}` : ''} (HTTP ${res.statusCode})`));
          resolve(json || {});
        });
      });
      r.on('error', reject);
      r.setTimeout(20_000, () => r.destroy(new Error('timeout')));
      if (data) r.write(data);
      r.end();
    });
  }

  async function callTool(req, who, name, args) {
    const def = TOOLS.get(name);
    if (!def) throw Object.assign(new Error('unknown tool'), { rpc: -32602 });
    const a = isObj(args) ? args : {};
    const confirm = def.write && a.confirm === true;
    const cookie = (await sessions.admin.create(who.admin.id)).split(';')[0];
    const fake = { headers: { cookie } };
    let out, error = null;
    try {
      out = await IMPL[name](a, loopback(req, cookie), confirm, db);
    } catch (e) {
      error = e instanceof ToolError ? e.message : 'failed';
      if (!(e instanceof ToolError)) ctx.cfg?.quiet || console.error('[mcp]', name, e);
    } finally {
      await sessions.admin.destroy(fake).catch(() => {});
    }
    // the admin log: who (Claude, which key), what, preview or applied, before → after
    if (def.write || error) {
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1, NULL, $2, $3)', [who.admin.id, 'mcp_call',
        JSON.stringify({ by: 'Claude', key: who.token.label, tool: name, applied: !!(confirm && !error && !out?.preview && out?.changes?.length), changes: out?.changes, error }).slice(0, 4000)]);
    }
    if (error) return { content: [{ type: 'text', text: `Error: ${error}` }], isError: true };
    const text = out.preview
      ? `PREVIEW ONLY — nothing was saved.\n${out.changes.map((c) => `• ${c.field}: ${JSON.stringify(c.before)} → ${JSON.stringify(c.after)}`).join('\n')}\nTo apply, ask the owner to confirm, then call ${name} again with the same arguments and confirm=true.`
      : JSON.stringify(out.changes ? { result: out.result, changes: out.changes } : out.result, null, 1);
    return { content: [{ type: 'text', text }], structuredContent: out.changes ? { result: out.result ?? 'preview', changes: out.changes, preview: !!out.preview } : (isObj(out.result) ? out.result : { result: out.result }) };
  }

  async function rpc(req, who, msg) {
    const id = msg?.id;
    const isNote = id === undefined || id === null;
    const reply = (result) => (isNote ? null : { jsonrpc: '2.0', id, result });
    const fail = (code, message) => (isNote ? null : { jsonrpc: '2.0', id, error: { code, message } });
    if (!msg || msg.jsonrpc !== '2.0' || typeof msg.method !== 'string') return fail(-32600, 'invalid request');
    switch (msg.method) {
      case 'initialize': {
        const asked = msg.params?.protocolVersion;
        return reply({ protocolVersion: PROTOCOLS.includes(asked) ? asked : PROTOCOLS[0], capabilities: { tools: { listChanged: false } },
          serverInfo: { name: 'aklatak-admin', title: 'Aklatak admin', version: '8.5.1' },
          instructions: 'Aklatak (أكلتك) owner tools. Reply to the owner in Lebanese Arabic. Every change is previewed first (before → after); only call again with confirm=true after the owner clearly agrees. No deleting, no money transfers, no passwords — those stay in the admin panel.' });
      }
      case 'notifications/initialized': case 'notifications/cancelled': return null;
      case 'ping': return reply({});
      case 'tools/list': return reply({ tools: TOOL_DEFS.map(({ name, description, inputSchema, write }) => ({ name, description, inputSchema, annotations: { readOnlyHint: !write, destructiveHint: false, idempotentHint: !write } })) });
      case 'tools/call': {
        if (!rateOk(`k${who.token.id}`)) return fail(-32000, 'rate limited: too many calls, wait a minute');
        try { return reply(await callTool(req, who, String(msg.params?.name || ''), msg.params?.arguments)); } catch (e) { return fail(e.rpc || -32603, e.message); }
      }
      case 'resources/list': return reply({ resources: [] });
      case 'prompts/list': return reply({ prompts: [] });
      default: return fail(-32601, 'method not found');
    }
  }

  const handler = async (req, res, m) => {
    const who = await authed(req);
    if (!who) {
      if (!rateOk(`ip${req.socket.remoteAddress}`, 30)) throw new HttpError(429, 'rate_limited', { retryAfterSec: 60 });
      return sendJson(res, 401, { jsonrpc: '2.0', id: null, error: { code: -32001, message: 'unauthorized: add the key from the admin panel (🔌 Claude) as «Authorization: Bearer …»' } });
    }
    let body;
    try { body = await readBody(req); } catch { return sendJson(res, 400, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'parse error' } }); }
    const list = Array.isArray(body) ? body.slice(0, 20) : [body];
    const out = [];
    for (const msg of list) { const r = await rpc(req, who, msg); if (r) out.push(r); }
    if (!out.length) { res.writeHead(202, { 'Cache-Control': 'no-store' }); return res.end(); }
    return sendJson(res, 200, Array.isArray(body) ? out : out[0], { 'Cache-Control': 'no-store' });
  };
  const noStream = async (req, res) => { res.writeHead(405, { Allow: 'POST', 'Cache-Control': 'no-store' }); res.end(); };

  return [
    ['POST', /^\/mcp\/?$/, handler],
    ['GET', /^\/mcp\/?$/, noStream],
    ['DELETE', /^\/mcp\/?$/, noStream],

    // ===== owner: the keys Claude uses (made here, shown once, kept as a hash, revocable) =====
    ['GET', /^\/api\/admin\/mcp$/, owner(async (req, res) => {
      const tokens = await readTokens(db);
      const log = await db.query(`SELECT id, details, created_at FROM admin_actions WHERE action = 'mcp_call' ORDER BY id DESC LIMIT 30`);
      return sendJson(res, 200, { ok: true, tokens: tokens.map(publicToken), tools: TOOL_DEFS.map((t) => ({ name: t.name, write: t.write })),
        log: log.map((r) => { let d = {}; try { d = JSON.parse(r.details); } catch { /* ignore */ } return { id: r.id, at: r.created_at, tool: d.tool, applied: !!d.applied, error: d.error || null, changes: (d.changes || []).slice(0, 5) }; }) });
    })],
    ['POST', /^\/api\/admin\/mcp\/tokens$/, owner(async (req, res, m, a) => {
      const b = await readJson(req);
      const label = String(b.label || 'Claude').trim().slice(0, 40) || 'Claude';
      const list = await readTokens(db);
      if (list.length >= MAX_TOKENS) throw new HttpError(409, 'too_many_keys');
      const token = `akl_${randomToken(32)}`;
      const t = { id: randomToken(6), hash: sha256(token), label, adminId: a.id, createdAt: new Date().toISOString(), lastUsedAt: null, hint: `…${token.slice(-4)}` };
      list.push(t);
      await writeTokens(db, list);
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1, NULL, $2, $3)', [a.id, 'mcp_key_created', JSON.stringify({ label })]);
      return sendJson(res, 201, { ok: true, token, key: publicToken(t) });
    })],
    ['DELETE', /^\/api\/admin\/mcp\/tokens\/([A-Za-z0-9_-]{4,20})$/, owner(async (req, res, m, a) => {
      const list = await readTokens(db);
      const t = list.find((x) => x.id === m[1]);
      if (!t) throw new HttpError(404, 'not_found');
      await writeTokens(db, list.filter((x) => x.id !== m[1]));
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1, NULL, $2, $3)', [a.id, 'mcp_key_revoked', JSON.stringify({ label: t.label })]);
      return sendJson(res, 200, { ok: true });
    })],
  ];
}
