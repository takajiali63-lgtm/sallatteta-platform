// v7 delivery API: customers order in the app, the store sets the delivery fee (paid from its balance) and sends the
// order to the nearest drivers; the first driver to accept gets it; the store then forwards the customer's location.
// The platform is an intermediary: it never sells, prepares or delivers anything itself.
import { randomInt } from 'node:crypto';
import { hmacHex } from '../lib/security.js';
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, imageBytesOk } from '../lib/validate.js';
import { normalizePhone } from '../lib/whatsapp.js';
import { hashPassword, verifyPassword, clientIp, sha256 } from '../lib/security.js';
import { sessionManager, checkCsrf } from '../lib/sessions.js';
import { haversineKm, isValidLatLng } from '../lib/geo.js';
import { isOpenNow } from '../lib/hours.js';
import { isCraft, isPrivateKind } from '../services/categories.js';
import { VISIBLE_SQL } from '../services/cooks.js';
const VIS = `${VISIBLE_SQL} AND COALESCE(c.suspended,0) = 0`;   // paid, approved, not hidden, not suspended ($1 = now)
import {
  deliverySettings, balance, ledgerAdd, dispatch, addWarning, activeWarnings, setSuspended, accountExists,
  maybeOpenPayout, storeReport, driverReport, dispatchErrand, lockAccount,
} from '../services/delivery.js';

const DUMMY_HASH = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAA';
const DOC_KINDS = ['selfie', 'idCard', 'license', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'];
const DOC_MAX = 450_000;        // ~330 KB per image (the app shrinks photos before sending) — keeps the free database small
const iso = () => new Date().toISOString();
const meters = (a, b, c, d) => Math.round(haversineKm(a, b, c, d) * 1000);
const parseJson = (s) => { try { return s ? JSON.parse(s) : null; } catch { return null; } };

export function deliveryRoutes({ db, cfg, limiters, sms }) {
  const S = deliverySettings(db);
  const custSessions = sessionManager({ db, cfg, table: 'customer_sessions', cookie: 'st_cust', ownerColumn: 'customer_id', hours: 24 * 365 });
  const driverSessions = sessionManager({ db, cfg, table: 'driver_sessions', cookie: 'st_driver', ownerColumn: 'driver_id', hours: 24 * 90 });
  const cookSessions = sessionManager({ db, cfg, table: 'cook_sessions', cookie: 'st_cook', ownerColumn: 'cook_id', hours: 24 * 60 });
  const adminSessions = sessionManager({ db, cfg, table: 'admin_sessions', cookie: 'st_admin', ownerColumn: 'admin_id', hours: 12 });

  const ip = (req) => clientIp(req, cfg.trustProxy);
  async function limit(limiter, key) {
    if (!limiter) return;
    const r = await limiter.take(key);
    if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
  }

  // ---------- guards ----------
  const customer = (fn) => async (req, res, m) => {
    const id = await custSessions.ownerId(req);
    if (!id) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const c = await db.one('SELECT id, status FROM customers WHERE id = $1', [id]);
    if (!c) throw new HttpError(401, 'unauthorized');
    if (c.status === 'suspended' && req.method !== 'GET') throw new HttpError(403, 'account_suspended');
    return fn(req, res, m, id);
  };
  const store = (fn) => async (req, res, m) => {
    const id = await cookSessions.ownerId(req);
    if (!id) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const c = await db.one('SELECT id, status, suspended FROM cooks WHERE id = $1', [id]);
    if (!c || c.status === 'rejected') throw new HttpError(401, 'unauthorized');
    if (Number(c.suspended) && req.method !== 'GET') throw new HttpError(403, 'account_suspended');
    return fn(req, res, m, id);
  };
  const driver = (fn, { activeOnly = true } = {}) => async (req, res, m) => {
    const id = await driverSessions.ownerId(req);
    if (!id) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const d = await db.one('SELECT id, status FROM drivers WHERE id = $1', [id]);
    if (!d || d.status === 'rejected') throw new HttpError(401, 'unauthorized');
    if (activeOnly && d.status !== 'active') throw new HttpError(403, d.status === 'suspended' ? 'account_suspended' : 'account_pending');
    return fn(req, res, m, id);
  };
  const owner = (fn) => async (req, res, m) => {
    const id = await adminSessions.ownerId(req);
    if (!id) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const a = await db.one('SELECT id, role FROM admin_users WHERE id = $1 AND disabled = 0', [id]);
    if (!a) throw new HttpError(401, 'unauthorized');
    if (a.role === 'agent') throw new HttpError(403, 'forbidden');
    await limit(limiters.admin, `a${a.id}`);
    return fn(req, res, m, a);
  };

  const q = (req) => new URL(req.url, 'http://x').searchParams;
  const cOf = (req) => { const c = String(q(req).get('country') || '').toUpperCase(); return /^[A-Z]{2}$/.test(c) ? c : null; };
  const ok = (res, data = { ok: true }, status = 200) => sendJson(res, status, data);
  const mustOrder = async (sql, params) => {
    const o = await db.one(sql, params);
    if (!o) throw new HttpError(404, 'not_found');
    return o;
  };
  const stateError = () => new HttpError(409, 'invalid_state');

  async function warningsOf(type, id) {
    const s = await S.get();
    const rows = await db.query(`SELECT id, reason, created_at, expires_at FROM warnings WHERE account_type = $1 AND account_id = $2 AND expires_at > $3 ORDER BY id DESC`, [type, id, iso()]);
    return { count: rows.length, max: s.maxWarnings, items: rows.map((r) => ({ id: r.id, reason: r.reason, at: r.created_at, expiresAt: r.expires_at })) };
  }

  // ---------- customer sign-in (name + phone; SMS code once a provider key is set) ----------
  async function issueCode(phone) {
    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    await db.query('DELETE FROM otp_codes WHERE phone = $1', [phone]);
    await db.query('INSERT INTO otp_codes (phone, code_hash, expires_at) VALUES ($1,$2,$3)',
      [phone, sha256(`${phone}:${code}`), new Date(Date.now() + 10 * 60_000).toISOString()]);
    await sms.send(phone, `${cfg.brand?.name || 'Aklatak'}: ${code}`);
  }
  async function checkCode(phone, code) {
    const row = await db.one('SELECT id, code_hash, expires_at, attempts FROM otp_codes WHERE phone = $1 ORDER BY id DESC', [phone]);
    if (!row || row.expires_at < iso() || row.attempts >= 5) throw new HttpError(401, 'code_expired');
    if (row.code_hash !== sha256(`${phone}:${String(code || '').trim()}`)) {
      await db.query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1', [row.id]);
      throw new HttpError(401, 'code_invalid');
    }
    await db.query('DELETE FROM otp_codes WHERE phone = $1', [phone]);
  }
  function phoneOf(v, body, field = 'phone') {
    const p = normalizePhone(body[field], body.country || 'LB');
    if (!p) v.fail(field, 'invalid');
    return p;
  }

  async function customerMe(id) {
    const c = await db.one('SELECT id, name, phone, status, country FROM customers WHERE id = $1', [id]);
    const addresses = await db.query('SELECT id, label, lat, lng, details FROM customer_addresses WHERE customer_id = $1 ORDER BY id', [id]);
    const favorites = (await db.query('SELECT cook_id FROM customer_favorites WHERE customer_id = $1', [id])).map((r) => r.cook_id);
    return { id: c.id, name: c.name, phone: c.phone, status: c.status, country: c.country, addresses, favorites, warnings: await warningsOf('customer', id), smsVerification: sms.enabled };
  }

  // ---------- store listing for customers ----------
  function storeView(c, lat, lng) {
    const hours = parseJson(c.hours);
    const open = Number(c.accepting_orders ?? 1) === 1 && isOpenNow(hours) !== false;
    return {
      id: c.id, name: c.full_name, kind: c.kind, specialty: c.specialty || null, photoUrl: c.photo_url || (Number(c.has_photo) ? `/media/cooks/${c.id}.jpg` : null),
      delivery: c.delivery_mode === 'delivery' || c.delivery_mode === 'self', ownDelivery: c.delivery_mode === 'self',
      whatsapp: c.delivery_mode === 'none' ? c.whatsapp : null, booking: !!Number(c.booking || 0),
      pinned: !!Number(c.pinned), open,
      distanceM: Number.isFinite(lat) ? meters(lat, lng, c.lat, c.lng) : null,
      // Homes (home cooks, craftspeople) never reveal their exact location.
      ...(isPrivateKind(c.kind) ? {} : { lat: c.lat, lng: c.lng }),
    };
  }

  return [
    // ===== customer account =====
    ['GET', /^\/api\/customer\/config$/, async (req, res) => { const s = await S.get(); return ok(res, { smsVerification: sms.enabled, cartIdleMin: s.cartIdleMin, maxPurchaseValue: s.maxPurchaseValue }); }],

    ['POST', /^\/api\/customer\/code$/, async (req, res) => {
      checkCsrf(req);
      const body = await readJson(req);
      const v = new Validator();
      const phone = phoneOf(v, body);
      v.assert();
      await limit(limiters.login, `otp:${ip(req)}`);
      await limit(limiters.login, `otp:${phone}`);
      if (!sms.enabled) return ok(res, { codeRequired: false });
      try { await issueCode(phone); } catch { throw new HttpError(503, 'sms_unavailable'); }
      return ok(res, { codeRequired: true });
    }],

    ['POST', /^\/api\/customer\/login$/, async (req, res) => {
      checkCsrf(req);
      await limit(limiters.login, `cust:${ip(req)}`);
      const body = await readJson(req);
      const v = new Validator();
      const phone = phoneOf(v, body);
      v.assert();
      if (sms.enabled) await checkCode(phone, body.code);
      let c = await db.one('SELECT id, status FROM customers WHERE phone = $1', [phone]);
      if (!c) {
        const name = v.text('name', body.name, { min: 2, max: 60 });
        if (body.acceptTerms !== true) v.fail('acceptTerms', 'required');
        v.assert();
        c = await db.one(`INSERT INTO customers (name, phone, country, locale, terms_accepted_at) VALUES ($1,$2,$3,$4,$5) RETURNING id, status`,
          [name, phone, String(body.country || 'LB').slice(0, 2).toUpperCase(), body.locale ? String(body.locale).slice(0, 5) : null, iso()]);
      }
      if (c.status === 'suspended') throw new HttpError(403, 'account_suspended');
      const cookie = await custSessions.create(c.id);
      return sendJson(res, 200, await customerMe(c.id), { 'Set-Cookie': cookie });
    }],

    ['POST', /^\/api\/customer\/logout$/, async (req, res) => {
      checkCsrf(req);
      return sendJson(res, 200, { ok: true }, { 'Set-Cookie': await custSessions.destroy(req) });
    }],

    ['GET', /^\/api\/customer\/me$/, customer(async (req, res, m, id) => ok(res, await customerMe(id)))],

    ['POST', /^\/api\/customer\/addresses$/, customer(async (req, res, m, id) => {
      const b = await readJson(req);
      const v = new Validator();
      const label = v.text('label', b.label, { max: 40 });
      const lat = Number(b.lat), lng = Number(b.lng);
      if (!isValidLatLng(lat, lng)) v.fail('location', 'invalid');
      const details = v.text('details', b.details, { max: 300, required: false, multiline: true });
      v.assert();
      const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM customer_addresses WHERE customer_id = $1', [id]);
      if (n.n >= 10) throw new HttpError(409, 'too_many_addresses');
      const row = await db.one('INSERT INTO customer_addresses (customer_id, label, lat, lng, details) VALUES ($1,$2,$3,$4,$5) RETURNING id', [id, label, lat, lng, details]);
      return ok(res, { id: row.id }, 201);
    })],

    ['DELETE', /^\/api\/customer\/addresses\/(\d+)$/, customer(async (req, res, m, id) => {
      await db.query('DELETE FROM customer_addresses WHERE id = $1 AND customer_id = $2', [Number(m[1]), id]);
      return ok(res);
    })],

    ['POST', /^\/api\/customer\/favorites\/(\d+)$/, customer(async (req, res, m, id) => {
      const b = await readJson(req);
      const cookId = Number(m[1]);
      if (b.on === false) await db.query('DELETE FROM customer_favorites WHERE customer_id = $1 AND cook_id = $2', [id, cookId]);
      else {
        if (!(await db.one('SELECT id FROM cooks WHERE id = $1', [cookId]))) throw new HttpError(404, 'not_found');
        await db.query('INSERT INTO customer_favorites (customer_id, cook_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [id, cookId]);
      }
      return ok(res);
    })],

    // Google Play requires in-app account deletion. Orders stay for the store's records, without the person's details.
    ['POST', /^\/api\/customer\/me\/delete$/, customer(async (req, res, m, id) => {
      await db.query('DELETE FROM customer_addresses WHERE customer_id = $1', [id]);
      await db.query('DELETE FROM customer_favorites WHERE customer_id = $1', [id]);
      await db.query(`UPDATE customers SET name = 'محذوف', phone = $1 WHERE id = $2`, [`deleted-${id}-${Date.now()}`, id]);
      await custSessions.destroyAll(id);
      return sendJson(res, 200, { ok: true }, { 'Set-Cookie': await custSessions.destroy(req) });
    })],

    // ===== stores for customers =====
    ['GET', /^\/api\/delivery\/stores$/, async (req, res) => {
      const p = q(req);
      const lat = Number(p.get('lat')), lng = Number(p.get('lng'));
      const hasLoc = isValidLatLng(lat, lng);
      const kind = p.get('category');
      const text = String(p.get('q') || '').trim().slice(0, 60);
      const params = [iso()];
      let where = VIS;
      if (kind) { params.push(kind); where += ` AND c.kind = $${params.length}`; }
      const country = String(p.get('country') || '').toUpperCase();
      if (/^[A-Z]{2}$/.test(country)) { params.push(country); where += ` AND COALESCE(c.country, 'LB') = $${params.length}`; }   // every country is separate
      if (text) {
        params.push(`%${text.toLowerCase()}%`);
        const i = params.length;
        where += ` AND (LOWER(c.full_name) LIKE $${i} OR LOWER(COALESCE(c.specialty,'')) LIKE $${i}
                   OR EXISTS (SELECT 1 FROM menu_items mi WHERE mi.cook_id = c.id AND mi.is_available = 1 AND LOWER(mi.name) LIKE $${i}))`;
      }
      const rows = await db.query(`SELECT c.id, c.full_name, c.kind, c.specialty, c.photo_url, CASE WHEN c.photo IS NULL THEN 0 ELSE 1 END AS has_photo, c.delivery_mode, c.whatsapp, c.pinned, c.accepting_orders, c.hours, c.lat, c.lng, c.booking FROM cooks c WHERE ${where}`, params);
      let list = rows.map((c) => storeView(c, hasLoc ? lat : NaN, lng));
      if (hasLoc) list = list.filter((s) => s.distanceM <= 25_000);
      list.sort((a, b) => (b.pinned - a.pinned) || ((a.distanceM ?? 0) - (b.distanceM ?? 0)));
      return ok(res, { stores: list.slice(0, 200) });
    }],

    ['GET', /^\/api\/delivery\/stores\/(\d+)$/, async (req, res, m) => {
      const p = q(req);
      const cc = String(p.get('country') || '').toUpperCase();
      const c = await db.one(`SELECT c.id, c.full_name, c.kind, c.specialty, c.photo_url, CASE WHEN c.photo IS NULL THEN 0 ELSE 1 END AS has_photo, c.delivery_mode, c.whatsapp, c.pinned, c.accepting_orders, c.hours, c.lat, c.lng, c.bio, c.allow_directions, c.booking
        FROM cooks c WHERE c.id = $2 AND ${VIS}${/^[A-Z]{2}$/.test(cc) ? ` AND COALESCE(c.country, 'LB') = $3` : ''}`, /^[A-Z]{2}$/.test(cc) ? [iso(), Number(m[1]), cc] : [iso(), Number(m[1])]);
      if (!c) throw new HttpError(404, 'not_found');
      const lat = Number(p.get('lat')), lng = Number(p.get('lng'));
      const menu = await db.query('SELECT id, name, description, price, currency FROM menu_items WHERE cook_id = $1 AND is_available = 1 ORDER BY sort_order, id', [c.id]);
      return ok(res, { store: { ...storeView(c, isValidLatLng(lat, lng) ? lat : NaN, lng), bio: c.bio || '', directions: Number(c.allow_directions ?? 1) === 1, hours: parseJson(c.hours) }, menu });
    }],

    // ===== customer orders =====
    ['POST', /^\/api\/orders$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      const v = new Validator();
      const storeId = v.int('storeId', b.storeId, { min: 1 });
      const lat = Number(b.lat), lng = Number(b.lng);
      if (!isValidLatLng(lat, lng)) v.fail('location', 'invalid');
      const details = v.text('details', b.details, { max: 300, required: false, multiline: true });
      const note = v.text('note', b.note, { max: 300, required: false, multiline: true });
      let scheduledAt = null;
      if (b.scheduledAt) {
        const d = new Date(b.scheduledAt);
        if (Number.isNaN(d.getTime()) || d.getTime() < Date.now() - 60_000 || d.getTime() > Date.now() + 14 * 864e5) v.fail('scheduledAt', 'invalid');
        else scheduledAt = d.toISOString();
      }
      const items = Array.isArray(b.items) ? b.items : [];
      if (!items.length || items.length > 50) v.fail('items', 'invalid');
      v.assert();
      const st = await db.one(`SELECT c.id, c.lat, c.lng, c.delivery_mode, c.accepting_orders, c.hours, COALESCE(c.country, 'LB') AS country FROM cooks c WHERE c.id = $2 AND ${VIS}`, [iso(), storeId]);
      if (!st) throw new HttpError(404, 'not_found');
      const me = await db.one(`SELECT COALESCE(country, 'LB') AS country FROM customers WHERE id = $1`, [customerId]);
      if (me.country !== st.country) throw new HttpError(404, 'not_found');   // every country is separate
      if (!['delivery', 'self'].includes(st.delivery_mode)) throw new HttpError(409, 'store_no_delivery');
      if (!scheduledAt && (Number(st.accepting_orders) !== 1 || isOpenNow(parseJson(st.hours)) === false)) throw new HttpError(409, 'store_closed');
      const menu = new Map((await db.query('SELECT id, name, price, currency FROM menu_items WHERE cook_id = $1 AND is_available = 1', [storeId])).map((r) => [r.id, r]));
      const lines = [];
      for (const it of items) {
        const mi = menu.get(Number(it?.id));
        const qty = Number(it?.qty);
        if (!mi || mi.price == null || !Number.isInteger(qty) || qty < 1 || qty > 50) throw new HttpError(422, 'validation_failed', { fields: { items: 'invalid' } });
        lines.push({ id: mi.id, name: mi.name, price: Number(mi.price), qty, currency: mi.currency });
      }
      const total = Math.round(lines.reduce((a, l) => a + l.price * l.qty, 0) * 100) / 100;
      const id = await db.tx(async (t) => {
        const o = await t.one(`INSERT INTO orders (cook_id, customer_id, total, currency, lat, lng, address_details, note, scheduled_at, distance_m, country)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
          [storeId, customerId, total, lines[0].currency || 'USD', lat, lng, details, note, scheduledAt, meters(st.lat, st.lng, lat, lng), st.country]);
        for (const l of lines) await t.query('INSERT INTO order_items (order_id, menu_item_id, name, price, qty) VALUES ($1,$2,$3,$4,$5)', [o.id, l.id, l.name, l.price, l.qty]);
        return o.id;
      });
      return ok(res, { id, total }, 201);
    })],

    ['GET', /^\/api\/customer\/orders$/, customer(async (req, res, m, id) => {
      const rows = await db.query(`SELECT o.id, o.status, o.total, o.currency, o.created_at, o.cook_id, c.full_name AS store
        FROM orders o JOIN cooks c ON c.id = o.cook_id WHERE o.customer_id = $1 ORDER BY o.id DESC LIMIT 50`, [id]);
      return ok(res, { orders: rows });
    })],

    ['GET', /^\/api\/customer\/orders\/(\d+)$/, customer(async (req, res, m, id) => {
      const o = await mustOrder(`SELECT o.*, c.full_name AS store FROM orders o JOIN cooks c ON c.id = o.cook_id WHERE o.id = $1 AND o.customer_id = $2`, [Number(m[1]), id]);
      const items = await db.query('SELECT menu_item_id AS id, name, price, qty FROM order_items WHERE order_id = $1', [o.id]);
      let drv = null;
      if (o.driver_id && ['assigned', 'picked_up', 'delivered'].includes(o.status)) {
        const d = await db.one('SELECT full_name, phone, vehicle FROM drivers WHERE id = $1', [o.driver_id]);
        if (d) drv = { name: d.full_name.split(' ')[0], phone: d.phone, vehicle: d.vehicle };
      }
      // The delivery fee is between the store and the driver: never shown to the customer.
      return ok(res, { order: { id: o.id, status: o.status, store: o.store, storeId: o.cook_id, total: o.total, currency: o.currency, items, createdAt: o.created_at, scheduledAt: o.scheduled_at, driver: drv, selfDelivery: !!Number(o.self_delivery) } });
    })],

    ['POST', /^\/api\/customer\/orders\/(\d+)\/cancel$/, customer(async (req, res, m, id) => {
      const o = await mustOrder('SELECT id, status FROM orders WHERE id = $1 AND customer_id = $2', [Number(m[1]), id]);
      if (o.status !== 'pending') throw stateError();
      await db.query(`UPDATE orders SET status = 'cancelled', closed_at = $1, close_reason = 'customer' WHERE id = $2`, [iso(), o.id]);
      return ok(res);
    })],

    // ===== store (merchant) =====
    ['GET', /^\/api\/store\/orders$/, store(async (req, res, m, cookId) => {
      const s = await S.get();
      const active = q(req).get('active') !== '0';
      const rows = await db.query(`SELECT o.*, cu.name AS customer_name, cu.phone AS customer_phone FROM orders o JOIN customers cu ON cu.id = o.customer_id
        WHERE o.cook_id = $1 ${active ? `AND o.status IN ('pending','preparing','searching','assigned','picked_up')` : ''} ORDER BY o.id DESC LIMIT 100`, [cookId]);
      const out = [];
      for (const o of rows) {
        const items = await db.query('SELECT name, price, qty FROM order_items WHERE order_id = $1', [o.id]);
        let drv = null;
        if (o.driver_id) {
          const d = await db.one('SELECT id, full_name, phone, vehicle, lat, lng FROM drivers WHERE id = $1', [o.driver_id]);
          if (d) drv = { id: d.id, name: d.full_name, phone: d.phone, vehicle: d.vehicle };
        }
        const sent = o.status === 'searching' ? (await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM order_offers WHERE order_id = $1 AND status = 'sent'`, [o.id])).n : 0;
        out.push({
          id: o.id, status: o.status, total: o.total, currency: o.currency, items, note: o.note, scheduledAt: o.scheduled_at,
          customer: { name: o.customer_name, phone: o.customer_phone }, distanceM: o.distance_m, deliveryFee: o.delivery_fee,
          driversNotified: sent, locationSent: !!Number(o.location_sent), driver: drv, createdAt: o.created_at, selfDelivery: !!Number(o.self_delivery),
          canRaise: o.status === 'searching' && o.search_started_at && (Date.now() - Date.parse(o.search_started_at)) >= s.raiseAfterSec * 1000,
        });
      }
      return ok(res, { orders: out, balance: await balance(db, 'store', cookId) });
    })],

    ['POST', /^\/api\/store\/orders\/(\d+)\/(accept|reject)$/, store(async (req, res, m, cookId) => {
      const o = await mustOrder('SELECT id, status FROM orders WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (o.status !== 'pending') throw stateError();
      if (m[2] === 'accept') await db.query(`UPDATE orders SET status = 'preparing', accepted_at = $1 WHERE id = $2`, [iso(), o.id]);
      else await db.query(`UPDATE orders SET status = 'rejected', closed_at = $1, close_reason = 'store' WHERE id = $2`, [iso(), o.id]);
      return ok(res);
    })],

    // Set the delivery fee and look for a driver. The fee is held from the store's balance.
    ['POST', /^\/api\/store\/orders\/(\d+)\/(search|raise)$/, store(async (req, res, m, cookId) => {
      const b = await readJson(req);
      const v = new Validator();
      const fee = v.number('fee', b.fee, { min: 0.5, max: 1000 });
      v.assert();
      const s = await S.get();
      const st = await db.one('SELECT id, lat, lng, country FROM cooks WHERE id = $1', [cookId]);
      const result = await db.tx(async (t) => {
        const o = await t.one('SELECT * FROM orders WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
        if (!o) throw new HttpError(404, 'not_found');
        const raising = m[2] === 'raise';
        if (raising ? o.status !== 'searching' : o.status !== 'preparing') throw stateError();
        const mode = (await t.one('SELECT delivery_mode FROM cooks WHERE id = $1', [cookId])).delivery_mode;
        if (mode !== 'delivery') throw new HttpError(409, 'drivers_not_in_plan');
        if (raising && fee <= Number(o.delivery_fee)) throw new HttpError(422, 'validation_failed', { fields: { fee: 'must_be_higher' } });
        const held = raising ? Number(o.delivery_fee) : 0;
        await lockAccount(t, db.kind, 'store', cookId);
        const bal = await balance(t, 'store', cookId);
        if (bal + held < fee) throw new HttpError(402, 'insufficient_balance', { balance: bal, needed: fee });
        if (raising) await ledgerAdd(t, 'store', cookId, held, 'release', { orderId: o.id, note: 'fee raised' });
        await ledgerAdd(t, 'store', cookId, -fee, 'hold', { orderId: o.id });
        await t.query(`UPDATE orders SET status = 'searching', delivery_fee = $1, search_started_at = $2 WHERE id = $3`, [fee, iso(), o.id]);
        return { ...o, delivery_fee: fee };
      });
      const sent = await dispatch(db, result, st, s);
      return ok(res, { driversNotified: sent, balance: await balance(db, 'store', cookId) });
    })],

    ['POST', /^\/api\/store\/orders\/(\d+)\/send-location$/, store(async (req, res, m, cookId) => {
      const o = await mustOrder('SELECT id, status FROM orders WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (!['assigned', 'picked_up'].includes(o.status)) throw stateError();
      await db.query('UPDATE orders SET location_sent = 1 WHERE id = $1', [o.id]);
      return ok(res);
    })],

    ['POST', /^\/api\/store\/orders\/(\d+)\/cancel$/, store(async (req, res, m, cookId) => {
      await db.tx(async (t) => {
        const o = await t.one('SELECT id, status, delivery_fee FROM orders WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
        if (!o) throw new HttpError(404, 'not_found');
        if (!['preparing', 'searching', 'assigned'].includes(o.status)) throw stateError();
        if (['searching', 'assigned'].includes(o.status) && o.delivery_fee) await ledgerAdd(t, 'store', cookId, Number(o.delivery_fee), 'release', { orderId: o.id, note: 'cancelled' });
        await t.query(`UPDATE order_offers SET status = 'lost' WHERE order_id = $1 AND status = 'sent'`, [o.id]);
        await t.query(`UPDATE orders SET status = 'cancelled', closed_at = $1, close_reason = 'store' WHERE id = $2`, [iso(), o.id]);
      });
      return ok(res);
    })],

    ['POST', /^\/api\/store\/accepting$/, store(async (req, res, m, cookId) => {
      const b = await readJson(req);
      await db.query('UPDATE cooks SET accepting_orders = $1 WHERE id = $2', [b.on === false ? 0 : 1, cookId]);
      return ok(res);
    })],

    ['GET', /^\/api\/store\/wallet$/, store(async (req, res, m, cookId) => {
      const ledger = await db.query('SELECT amount, kind, order_id, note, created_at FROM wallet_ledger WHERE account_type = $1 AND account_id = $2 ORDER BY id DESC LIMIT 50', ['store', cookId]);
      const topups = await db.query('SELECT id, amount, method, status, created_at FROM topups WHERE cook_id = $1 ORDER BY id DESC LIMIT 20', [cookId]);
      const c = await db.one('SELECT delivery_mode, accepting_orders FROM cooks WHERE id = $1', [cookId]);
      return ok(res, { balance: await balance(db, 'store', cookId), ledger, topups, deliveryMode: c.delivery_mode, accepting: Number(c.accepting_orders ?? 1) === 1, warnings: await warningsOf('store', cookId) });
    })],

    ['POST', /^\/api\/store\/topups$/, store(async (req, res, m, cookId) => {
      await limit(limiters.upload, `topup:${cookId}`);
      const b = await readJson(req, 600_000);
      const v = new Validator();
      const amount = v.number('amount', b.amount, { min: 1, max: 10000 });
      const method = v.oneOf('method', b.method, ['whish', 'omt', 'other']);
      const reference = v.text('reference', b.reference, { max: 80, required: false });
      if (!b.receipt || !imageBytesOk(b.receipt) || String(b.receipt).length > DOC_MAX) v.fail('receipt', 'invalid');
      v.assert();
      const pending = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM topups WHERE cook_id = $1 AND status = 'pending'`, [cookId]);
      if (pending.n >= 5) throw new HttpError(409, 'too_many_pending');
      const mime = /^data:(image\/\w+);/.exec(b.receipt)[1];
      const row = await db.one('INSERT INTO topups (cook_id, amount, method, reference, receipt_mime, receipt) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
        [cookId, amount, method, reference, mime, String(b.receipt).split(',')[1]]);
      return ok(res, { id: row.id }, 201);
    })],

    ['GET', /^\/api\/store\/report$/, store(async (req, res, m, cookId) => {
      const p = q(req);
      return ok(res, { report: await storeReport(db, cookId, { period: p.get('period'), from: p.get('from'), to: p.get('to') }) });
    })],

    // ===== drivers =====
    ['POST', /^\/api\/driver\/apply$/, async (req, res) => {
      checkCsrf(req);
      await limit(limiters.apply, `driver:${ip(req)}`);
      const b = await readJson(req, 3_500_000);
      const v = new Validator();
      const fullName = v.text('fullName', b.fullName, { min: 3, max: 80 });
      const phone = phoneOf(v, b);
      const password = String(b.password || '');
      if (password.length < 5 || password.length > 100) v.fail('password', 'too_short');
      const vehicle = v.oneOf('vehicle', b.vehicle, ['moto', 'car']);
      const plate = v.text('plate', b.plate, { max: 20 });
      const walletProvider = v.oneOf('walletProvider', b.walletProvider, ['whish', 'omt']);
      const walletNumber = normalizePhone(b.walletNumber, b.country || 'LB') || v.fail('walletNumber', 'invalid');
      if (b.acceptTerms !== true) v.fail('acceptTerms', 'required');
      const docs = b.docs || {};
      for (const k of DOC_KINDS) {
        if (!docs[k] || !imageBytesOk(docs[k])) v.fail(`docs.${k}`, 'required');
        else if (String(docs[k]).length > DOC_MAX) v.fail(`docs.${k}`, 'too_large');
      }
      v.assert();
      if (await db.one('SELECT id FROM drivers WHERE phone = $1', [phone])) throw new HttpError(409, 'phone_taken');
      const hash = await hashPassword(password);
      const id = await db.tx(async (t) => {
        const d = await t.one(`INSERT INTO drivers (full_name, phone, password_hash, vehicle, plate, wallet_provider, wallet_number, country, locale, terms_accepted_at)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
          [fullName, phone, hash, vehicle, plate, walletProvider, walletNumber, String(b.country || 'LB').slice(0, 2).toUpperCase(), b.locale ? String(b.locale).slice(0, 5) : null, iso()]);
        for (const k of DOC_KINDS) {
          const s = String(docs[k]);
          await t.query('INSERT INTO driver_documents (driver_id, kind, mime, data) VALUES ($1,$2,$3,$4)', [d.id, k, /^data:(image\/\w+);/.exec(s)[1], s.split(',')[1]]);
        }
        return d.id;
      });
      return ok(res, { id, status: 'pending' }, 201);
    }],

    ['POST', /^\/api\/driver\/login$/, async (req, res) => {
      checkCsrf(req);
      await limit(limiters.login, `driver:${ip(req)}`);
      const b = await readJson(req);
      const phone = normalizePhone(b.phone, b.country || 'LB');
      const d = phone ? await db.one('SELECT id, password_hash, status FROM drivers WHERE phone = $1', [phone]) : null;
      const good = await verifyPassword(String(b.password || ''), d?.password_hash || DUMMY_HASH);
      if (!d || !good || d.status === 'rejected') throw new HttpError(401, 'invalid_credentials');
      const cookie = await driverSessions.create(d.id);
      return sendJson(res, 200, { ok: true, status: d.status }, { 'Set-Cookie': cookie });
    }],

    ['POST', /^\/api\/driver\/logout$/, async (req, res) => {
      checkCsrf(req);
      const id = await driverSessions.ownerId(req);
      if (id) await db.query('UPDATE drivers SET available = 0 WHERE id = $1', [id]);
      return sendJson(res, 200, { ok: true }, { 'Set-Cookie': await driverSessions.destroy(req) });
    }],

    ['GET', /^\/api\/driver\/me$/, driver(async (req, res, m, id) => {
      const d = await db.one('SELECT id, full_name, phone, vehicle, plate, wallet_provider, wallet_number, status, available, loc_at, jobs_until FROM drivers WHERE id = $1', [id]);
      const s = await S.get();
      const fresh = d.loc_at && Date.now() - Date.parse(d.loc_at) < s.driverStaleSec * 1000;
      return ok(res, {
        id: d.id, name: d.full_name, phone: d.phone, vehicle: d.vehicle, plate: d.plate, wallet: { provider: d.wallet_provider, number: d.wallet_number },
        status: d.status, available: !!Number(d.available) && !!fresh, balance: await balance(db, 'driver', id), payoutThreshold: s.payoutThreshold,
        warnings: await warningsOf('driver', id),
        jobs: { active: !!d.jobs_until && d.jobs_until > iso(), until: d.jobs_until || null, price: s.jobsPrice },
      });
    }, { activeOnly: false })],

    ['POST', /^\/api\/driver\/availability$/, driver(async (req, res, m, id) => {
      const b = await readJson(req);
      const on = b.available === true;
      const lat = Number(b.lat), lng = Number(b.lng);
      if (on && !isValidLatLng(lat, lng)) throw new HttpError(422, 'validation_failed', { fields: { location: 'required' } });
      if (on) await db.query('UPDATE drivers SET available = 1, lat = $1, lng = $2, loc_at = $3 WHERE id = $4', [lat, lng, iso(), id]);
      else await db.query('UPDATE drivers SET available = 0 WHERE id = $1', [id]);
      return ok(res, { available: on });
    })],

    ['POST', /^\/api\/driver\/location$/, driver(async (req, res, m, id) => {
      const b = await readJson(req);
      const lat = Number(b.lat), lng = Number(b.lng);
      if (!isValidLatLng(lat, lng)) throw new HttpError(422, 'validation_failed', { fields: { location: 'invalid' } });
      await db.query('UPDATE drivers SET lat = $1, lng = $2, loc_at = $3 WHERE id = $4', [lat, lng, iso(), id]);
      return ok(res);
    })],

    // Offers show distances and the fee only — never the customer's exact location.
    ['GET', /^\/api\/driver\/offers$/, driver(async (req, res, m, id) => {
      const d = await db.one('SELECT lat, lng FROM drivers WHERE id = $1', [id]);
      const rows = await db.query(`SELECT f.id, f.fee, o.id AS order_id, o.distance_m, c.full_name AS store, c.lat, c.lng
        FROM order_offers f JOIN orders o ON o.id = f.order_id JOIN cooks c ON c.id = o.cook_id
        WHERE f.driver_id = $1 AND f.status = 'sent' AND o.status = 'searching' ORDER BY f.id DESC`, [id]);
      const er = await db.query(`SELECT f.id, e.id AS errand_id, e.kind, e.description, e.price, e.purchase_value, e.distance_m, e.from_lat, e.from_lng
        FROM errand_offers f JOIN errands e ON e.id = f.errand_id WHERE f.driver_id = $1 AND f.status = 'sent' AND e.status = 'searching' ORDER BY f.id DESC`, [id]);
      return ok(res, {
        offers: rows.map((r) => ({
          type: 'store', id: r.id, orderId: r.order_id, store: r.store, fee: r.fee, storeToCustomerM: r.distance_m,
          toStoreM: d.lat != null ? meters(d.lat, d.lng, r.lat, r.lng) : null,
        })).concat(er.map((r) => ({
          // distances, price and what is wanted — exact addresses only after accepting
          type: 'errand', id: r.id, errandId: r.errand_id, kind: r.kind, description: r.description, fee: r.price, purchaseValue: r.purchase_value,
          totalM: r.distance_m, toStartM: d.lat != null ? meters(d.lat, d.lng, r.from_lat, r.from_lng) : null,
        }))),
      });
    })],

    ['POST', /^\/api\/driver\/offers\/(\d+)\/(accept|decline)$/, driver(async (req, res, m, id) => {
      const offerId = Number(m[1]);
      if (m[2] === 'decline') {
        await db.query(`UPDATE order_offers SET status = 'declined' WHERE id = $1 AND driver_id = $2 AND status = 'sent'`, [offerId, id]);
        return ok(res);
      }
      const orderId = await db.tx(async (t) => {
        const f = await t.one(`SELECT id, order_id FROM order_offers WHERE id = $1 AND driver_id = $2 AND status = 'sent'`, [offerId, id]);
        if (!f) throw new HttpError(409, 'offer_gone');
        const busy = await t.one(`SELECT id FROM orders WHERE driver_id = $1 AND status IN ('assigned','picked_up') UNION SELECT id FROM errands WHERE driver_id = $1 AND status IN ('assigned','picked_up')`, [id]);
        if (busy) throw new HttpError(409, 'driver_busy');
        // Only one driver can win: the update succeeds only while the order is still searching.
        const won = await t.query(`UPDATE orders SET status = 'assigned', driver_id = $1, assigned_at = $2 WHERE id = $3 AND status = 'searching' RETURNING id`, [id, iso(), f.order_id]);
        if (!won.length) throw new HttpError(409, 'offer_gone');
        await t.query(`UPDATE order_offers SET status = 'lost' WHERE order_id = $1 AND id <> $2 AND status = 'sent'`, [f.order_id, f.id]);
        await t.query(`UPDATE order_offers SET status = 'won' WHERE id = $1`, [f.id]);
        return f.order_id;
      });
      return ok(res, { orderId });
    })],

    ['GET', /^\/api\/driver\/current$/, driver(async (req, res, m, id) => {
      const o = await db.one(`SELECT o.*, c.full_name AS store, c.whatsapp AS store_phone, c.lat AS slat, c.lng AS slng, c.area_label,
          cu.name AS customer_name, cu.phone AS customer_phone
        FROM orders o JOIN cooks c ON c.id = o.cook_id JOIN customers cu ON cu.id = o.customer_id
        WHERE o.driver_id = $1 AND o.status IN ('assigned','picked_up') ORDER BY o.id DESC`, [id]);
      if (!o) {
        const e = await db.one(`SELECT e.*, cu.name AS customer_name, cu.phone AS customer_phone FROM errands e JOIN customers cu ON cu.id = e.customer_id
          WHERE e.driver_id = $1 AND e.status IN ('assigned','picked_up') ORDER BY e.id DESC`, [id]);
        if (!e) return ok(res, { order: null, errand: null });
        const messages = await db.query('SELECT id, from_type, body, created_at FROM errand_messages WHERE errand_id = $1 ORDER BY id', [e.id]);
        return ok(res, {
          order: null,
          errand: {
            id: e.id, kind: e.kind, status: e.status, description: e.description, fee: e.price, purchaseValue: e.purchase_value, totalM: e.distance_m,
            from: { lat: e.from_lat, lng: e.from_lng, details: e.from_details }, to: { lat: e.to_lat, lng: e.to_lng, details: e.to_details },
            customer: { name: e.customer_name, phone: e.customer_phone }, messages,
          },
        });
      }
      const sent = !!Number(o.location_sent);
      return ok(res, {
        order: {
          id: o.id, status: o.status, fee: o.delivery_fee, storeToCustomerM: o.distance_m,
          store: { name: o.store, phone: o.store_phone, lat: o.slat, lng: o.slng, area: o.area_label },
          locationSent: sent,
          customer: sent ? { name: o.customer_name, phone: o.customer_phone, lat: o.lat, lng: o.lng, details: o.address_details } : null,
        },
      });
    })],

    ['POST', /^\/api\/driver\/orders\/(\d+)\/(picked|delivered)$/, driver(async (req, res, m, id) => {
      await db.tx(async (t) => {
        const o = await t.one('SELECT id, status, delivery_fee FROM orders WHERE id = $1 AND driver_id = $2', [Number(m[1]), id]);
        if (!o) throw new HttpError(404, 'not_found');
        if (m[2] === 'picked') {
          if (o.status !== 'assigned') throw stateError();
          await t.query(`UPDATE orders SET status = 'picked_up', picked_at = $1 WHERE id = $2`, [iso(), o.id]);
        } else {
          if (!['assigned', 'picked_up'].includes(o.status)) throw stateError();
          await t.query(`UPDATE orders SET status = 'delivered', delivered_at = $1, closed_at = $1 WHERE id = $2`, [iso(), o.id]);
          await ledgerAdd(t, 'driver', id, Number(o.delivery_fee || 0), 'earning', { orderId: o.id });
        }
      });
      return ok(res, { balance: await balance(db, 'driver', id) });
    })],

    ['GET', /^\/api\/driver\/report$/, driver(async (req, res, m, id) => {
      const p = q(req);
      return ok(res, { report: await driverReport(db, id, { period: p.get('period'), from: p.get('from'), to: p.get('to') }) });
    }, { activeOnly: false })],

    // Store with its own delivery: no driver, no fee from the balance. preparing → on the way → delivered.
    ['POST', /^\/api\/store\/orders\/(\d+)\/(self-dispatch|self-delivered)$/, store(async (req, res, m, cookId) => {
      const o = await mustOrder('SELECT id, status, self_delivery FROM orders WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (m[2] === 'self-dispatch') {
        if (o.status !== 'preparing') throw stateError();
        await db.query(`UPDATE orders SET status = 'picked_up', self_delivery = 1, picked_at = $1 WHERE id = $2`, [iso(), o.id]);
      } else {
        if (o.status !== 'picked_up' || !Number(o.self_delivery)) throw stateError();
        await db.query(`UPDATE orders SET status = 'delivered', delivered_at = $1, closed_at = $1 WHERE id = $2`, [iso(), o.id]);
      }
      return ok(res);
    })],

    // ===== appointments (clinics, salons …): only where the booking option is on =====
    ['POST', /^\/api\/appointments$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      const v = new Validator();
      const storeId = v.int('storeId', b.storeId, { min: 1 });
      const service = v.text('service', b.service, { min: 2, max: 100 });
      const note = v.text('note', b.note, { max: 300, required: false, multiline: true });
      const d = new Date(b.startsAt);
      if (Number.isNaN(d.getTime()) || d.getTime() < Date.now() || d.getTime() > Date.now() + 90 * 864e5) v.fail('startsAt', 'invalid');
      v.assert();
      const st = await db.one(`SELECT c.id, c.booking FROM cooks c WHERE c.id = $2 AND ${VIS}`, [iso(), storeId]);
      if (!st) throw new HttpError(404, 'not_found');
      if (!Number(st.booking)) throw new HttpError(409, 'booking_not_in_plan');
      const open = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM appointments WHERE customer_id = $1 AND status IN ('pending','confirmed') AND starts_at > $2`, [customerId, iso()]);
      if (open.n >= 10) throw new HttpError(409, 'too_many_pending');
      const row = await db.one('INSERT INTO appointments (cook_id, customer_id, service, starts_at, note) VALUES ($1,$2,$3,$4,$5) RETURNING id',
        [storeId, customerId, service, d.toISOString(), note]);
      return ok(res, { id: row.id }, 201);
    })],

    ['GET', /^\/api\/customer\/appointments$/, customer(async (req, res, m, id) => {
      const rows = await db.query(`SELECT a.id, a.service, a.starts_at, a.status, a.note, c.full_name AS store, a.cook_id
        FROM appointments a JOIN cooks c ON c.id = a.cook_id WHERE a.customer_id = $1 ORDER BY a.starts_at DESC LIMIT 100`, [id]);
      return ok(res, { appointments: rows });
    })],

    ['POST', /^\/api\/customer\/appointments\/(\d+)\/cancel$/, customer(async (req, res, m, id) => {
      const a = await mustOrder('SELECT id, status FROM appointments WHERE id = $1 AND customer_id = $2', [Number(m[1]), id]);
      if (!['pending', 'confirmed'].includes(a.status)) throw stateError();
      await db.query(`UPDATE appointments SET status = 'cancelled', decided_at = $1 WHERE id = $2`, [iso(), a.id]);
      return ok(res);
    })],

    // The subscriber's appointment book.
    ['GET', /^\/api\/store\/appointments$/, store(async (req, res, m, cookId) => {
      const rows = await db.query(`SELECT a.id, a.service, a.starts_at, a.status, a.note, cu.name AS customer_name, cu.phone AS customer_phone
        FROM appointments a JOIN customers cu ON cu.id = a.customer_id WHERE a.cook_id = $1 ORDER BY a.starts_at LIMIT 300`, [cookId]);
      return ok(res, { appointments: rows });
    })],

    ['POST', /^\/api\/store\/appointments\/(\d+)\/(confirm|decline|done)$/, store(async (req, res, m, cookId) => {
      const a = await mustOrder('SELECT id, status FROM appointments WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      const next = { confirm: 'confirmed', decline: 'declined', done: 'done' }[m[2]];
      const from = m[2] === 'done' ? ['confirmed'] : ['pending'];
      if (!from.includes(a.status)) throw stateError();
      await db.query('UPDATE appointments SET status = $1, decided_at = $2 WHERE id = $3', [next, iso(), a.id]);
      return ok(res);
    })],

    // ===== "come to me": the customer calls a craftsperson to his place =====
    ['POST', /^\/api\/visits$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      const v = new Validator();
      const storeId = v.int('craftId', b.craftId, { min: 1 });
      const description = v.text('description', b.description, { min: 5, max: 500, multiline: true });
      const details = v.text('details', b.details, { max: 300, required: false, multiline: true });
      const lat = Number(b.lat), lng = Number(b.lng);
      if (!isValidLatLng(lat, lng)) v.fail('location', 'invalid');
      v.assert();
      const c = await db.one(`SELECT c.id, c.kind, c.lat, c.lng FROM cooks c WHERE c.id = $2 AND ${VIS}`, [iso(), storeId]);
      if (!c || !isCraft(c.kind)) throw new HttpError(404, 'not_found');
      const open = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM visit_requests WHERE customer_id = $1 AND status = 'pending'`, [customerId]);
      if (open.n >= 5) throw new HttpError(409, 'too_many_pending');
      const row = await db.one('INSERT INTO visit_requests (cook_id, customer_id, description, lat, lng, details, distance_m) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id',
        [c.id, customerId, description, lat, lng, details, meters(c.lat, c.lng, lat, lng)]);
      return ok(res, { id: row.id }, 201);
    })],

    ['GET', /^\/api\/customer\/visits$/, customer(async (req, res, m, id) => {
      const rows = await db.query(`SELECT v.id, v.description, v.status, v.created_at, c.full_name AS craft, CASE WHEN v.status = 'accepted' THEN c.whatsapp ELSE NULL END AS phone
        FROM visit_requests v JOIN cooks c ON c.id = v.cook_id WHERE v.customer_id = $1 ORDER BY v.id DESC LIMIT 50`, [id]);
      return ok(res, { visits: rows });
    })],

    ['POST', /^\/api\/customer\/visits\/(\d+)\/cancel$/, customer(async (req, res, m, id) => {
      const r = await mustOrder('SELECT id, status FROM visit_requests WHERE id = $1 AND customer_id = $2', [Number(m[1]), id]);
      if (!['pending', 'accepted'].includes(r.status)) throw stateError();
      await db.query(`UPDATE visit_requests SET status = 'cancelled', decided_at = $1 WHERE id = $2`, [iso(), r.id]);
      return ok(res);
    })],

    // The craftsperson sees the distance first; the customer's location and phone only after accepting.
    ['GET', /^\/api\/store\/visits$/, store(async (req, res, m, cookId) => {
      const rows = await db.query(`SELECT v.*, cu.name AS customer_name, cu.phone AS customer_phone FROM visit_requests v JOIN customers cu ON cu.id = v.customer_id
        WHERE v.cook_id = $1 ORDER BY v.id DESC LIMIT 100`, [cookId]);
      return ok(res, {
        visits: rows.map((r) => {
          const shared = ['accepted', 'done'].includes(r.status);
          return {
            id: r.id, description: r.description, status: r.status, distanceM: r.distance_m, createdAt: r.created_at, customerName: r.customer_name,
            customer: shared ? { phone: r.customer_phone, lat: r.lat, lng: r.lng, details: r.details } : null,
          };
        }),
      });
    })],

    ['POST', /^\/api\/store\/visits\/(\d+)\/(accept|decline|done)$/, store(async (req, res, m, cookId) => {
      const r = await mustOrder('SELECT id, status FROM visit_requests WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      const next = { accept: 'accepted', decline: 'declined', done: 'done' }[m[2]];
      if ((m[2] === 'done' ? 'accepted' : 'pending') !== r.status) throw stateError();
      await db.query('UPDATE visit_requests SET status = $1, decided_at = $2 WHERE id = $3', [next, iso(), r.id]);
      return ok(res);
    })],

    // ===== withdrawals: driver & store, to any Whish/OMT number, confirmed with the account password =====
    ['GET', /^\/api\/(driver|store)\/withdrawals$/, async (req, res, m) => {
      const type = m[1];
      const id = type === 'driver' ? await driverSessions.ownerId(req) : await cookSessions.ownerId(req);
      if (!id) throw new HttpError(401, 'unauthorized');
      const s = await S.get();
      const rows = await db.query('SELECT id, amount, provider, number, status, created_at, decided_at FROM withdrawals WHERE account_type = $1 AND account_id = $2 ORDER BY id DESC LIMIT 100', [type, id]);
      const ledger = await db.query('SELECT amount, kind, order_id, note, created_at FROM wallet_ledger WHERE account_type = $1 AND account_id = $2 ORDER BY id DESC LIMIT 100', [type, id]);
      return ok(res, { balance: await balance(db, type, id), minimum: type === 'driver' ? s.payoutThreshold : s.storeMinWithdraw, dailyMax: s.dailyWithdrawMax, withdrawals: rows, ledger });
    }],

    ['POST', /^\/api\/(driver|store)\/withdrawals$/, async (req, res, m) => {
      checkCsrf(req);
      const type = m[1];
      const id = type === 'driver' ? await driverSessions.ownerId(req) : await cookSessions.ownerId(req);
      if (!id) throw new HttpError(401, 'unauthorized');
      await limit(limiters.login, `wd:${type}:${id}`);            // slows down password guessing
      const acct = type === 'driver'
        ? await db.one('SELECT password_hash, status FROM drivers WHERE id = $1', [id])
        : await db.one('SELECT password_hash, status, suspended FROM cooks WHERE id = $1', [id]);
      if (!acct || acct.status === 'suspended' || acct.status === 'rejected' || Number(acct.suspended)) throw new HttpError(403, 'account_suspended');
      const b = await readJson(req);
      const v = new Validator();
      const amount = v.number('amount', b.amount, { min: 0.01, max: 100000 });
      const provider = v.oneOf('provider', b.provider, ['whish', 'omt']);
      const number = normalizePhone(b.number, b.country || 'LB') || v.fail('number', 'invalid');
      v.assert();
      if (!(await verifyPassword(String(b.password || ''), acct.password_hash || DUMMY_HASH))) throw new HttpError(401, 'wrong_password');
      const s = await S.get();
      const minimum = type === 'driver' ? s.payoutThreshold : s.storeMinWithdraw;
      const row = await db.tx(async (t) => {
        await lockAccount(t, db.kind, type, id);
        const bal = await balance(t, type, id);
        if (amount > bal) throw new HttpError(402, 'insufficient_balance', { balance: bal });
        if (amount < minimum) throw new HttpError(422, 'below_minimum', { minimum });
        const day = await t.one(`SELECT COALESCE(SUM(amount),0) AS s FROM withdrawals WHERE account_type = $1 AND account_id = $2 AND status <> 'rejected' AND created_at >= $3`,
          [type, id, new Date(Date.now() - 864e5).toISOString()]);
        if (Number(day.s) + amount > s.dailyWithdrawMax) throw new HttpError(422, 'daily_limit', { dailyMax: s.dailyWithdrawMax });
        const w = await t.one('INSERT INTO withdrawals (account_type, account_id, amount, provider, number, ip_hash) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
          [type, id, Math.round(amount * 100) / 100, provider, number, hmacHex(cfg.sessionSecret, ip(req)).slice(0, 16)]);
        await ledgerAdd(t, type, id, -amount, 'payout', { note: `withdrawal #${w.id} ${provider} ${number}` });
        return w;
      });
      // When a Whish/OMT payout key is set, the transfer is sent here automatically (see docs/DELIVERY.md).
      return ok(res, { id: row.id, status: 'pending', balance: await balance(db, type, id) }, 201);
    }],

    ['GET', /^\/api\/admin\/withdrawals$/, owner(async (req, res) => {
      const p = q(req);
      const st = p.get('status') || 'pending';
      const params = [st];
      let extra = '';
      if (p.get('type') && p.get('id')) { params.push(p.get('type'), Number(p.get('id'))); extra = ' AND w.account_type = $2 AND w.account_id = $3'; }
      const rows = await db.query(`SELECT w.*, CASE WHEN w.account_type = 'driver' THEN d.full_name ELSE c.full_name END AS name,
          CASE WHEN w.account_type = 'driver' THEN d.phone ELSE c.whatsapp END AS phone
        FROM withdrawals w LEFT JOIN drivers d ON w.account_type = 'driver' AND d.id = w.account_id LEFT JOIN cooks c ON w.account_type = 'store' AND c.id = w.account_id
        WHERE ${st === 'all' ? '$1 = $1' : 'w.status = $1'}${extra} ORDER BY w.id DESC LIMIT 300`, params);
      return ok(res, { withdrawals: rows });
    })],

    ['POST', /^\/api\/admin\/withdrawals\/(\d+)\/(paid|reject)$/, owner(async (req, res, m) => {
      await db.tx(async (t) => {
        const w = await t.one('SELECT id, account_type, account_id, amount, status FROM withdrawals WHERE id = $1', [Number(m[1])]);
        if (!w) throw new HttpError(404, 'not_found');
        if (w.status !== 'pending') throw stateError();
        const done = await t.query(`UPDATE withdrawals SET status = $1, decided_at = $2 WHERE id = $3 AND status = 'pending' RETURNING id`, [m[2] === 'paid' ? 'paid' : 'rejected', iso(), w.id]);
        if (!done.length) throw stateError();
        if (m[2] === 'reject') await ledgerAdd(t, w.account_type, w.account_id, Number(w.amount), 'adjust', { note: `withdrawal #${w.id} refused` });
      });
      return ok(res);
    })],

    // Full money log of one account (admin).
    ['GET', /^\/api\/admin\/ledger$/, owner(async (req, res) => {
      const p = q(req);
      const v = new Validator();
      const type = v.oneOf('type', p.get('type'), ['store', 'driver']);
      const id = v.int('id', p.get('id'), { min: 1 });
      v.assert();
      const ledger = await db.query('SELECT amount, kind, order_id, note, created_at FROM wallet_ledger WHERE account_type = $1 AND account_id = $2 ORDER BY id DESC LIMIT 300', [type, id]);
      const withdrawals = await db.query('SELECT id, amount, provider, number, status, created_at, decided_at FROM withdrawals WHERE account_type = $1 AND account_id = $2 ORDER BY id DESC LIMIT 100', [type, id]);
      return ok(res, { balance: await balance(db, type, id), ledger, withdrawals, warnings: (await warningsOf(type, id)).items });
    })],

    // ===== errands: the customer asks a driver directly (deliver / bring from a shop / service). Cash between them. =====
    ['POST', /^\/api\/errands$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      const s = await S.get();
      const v = new Validator();
      const kind = v.oneOf('kind', b.kind, ['deliver', 'buy', 'service']);
      const description = v.text('description', b.description, { min: 3, max: 500, multiline: true });
      const price = v.number('price', b.price, { min: s.errandMinPrice, max: 500 });
      const f = b.from || {}, to = b.to || {};
      const fl = [Number(f.lat), Number(f.lng)], tl = [Number(to.lat), Number(to.lng)];
      if (!isValidLatLng(...fl)) v.fail('from', 'invalid');
      if (!isValidLatLng(...tl)) v.fail('to', 'invalid');
      const fromDetails = v.text('fromDetails', f.details, { max: 300, required: false });
      const toDetails = v.text('toDetails', to.details, { max: 300, required: false });
      let purchase = null;
      if (kind === 'buy' && b.purchaseValue != null && b.purchaseValue !== '') purchase = v.number('purchaseValue', b.purchaseValue, { min: 0, max: s.maxPurchaseValue });
      v.assert();
      const open = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM errands WHERE customer_id = $1 AND status IN ('searching','assigned','picked_up')`, [customerId]);
      if (open.n >= 3) throw new HttpError(409, 'too_many_pending');
      await limit(limiters.contact, `errand:${customerId}`);
      const me = await db.one(`SELECT COALESCE(country, 'LB') AS country FROM customers WHERE id = $1`, [customerId]);
      const e = await db.one(`INSERT INTO errands (customer_id, kind, description, from_lat, from_lng, from_details, to_lat, to_lng, to_details, price, purchase_value, distance_m, search_started_at, country)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
        [customerId, kind, description, fl[0], fl[1], fromDetails, tl[0], tl[1], toDetails, price, purchase, meters(fl[0], fl[1], tl[0], tl[1]), iso(), me.country]);
      const sent = await dispatchErrand(db, e, s);
      return ok(res, { id: e.id, driversNotified: sent, distanceM: e.distance_m }, 201);
    })],

    ['GET', /^\/api\/customer\/errands$/, customer(async (req, res, m, id) => {
      const rows = await db.query(`SELECT id, kind, description, status, price, created_at FROM errands WHERE customer_id = $1 ORDER BY id DESC LIMIT 50`, [id]);
      return ok(res, { errands: rows });
    })],

    ['GET', /^\/api\/customer\/errands\/(\d+)$/, customer(async (req, res, m, id) => {
      const e = await mustOrder('SELECT * FROM errands WHERE id = $1 AND customer_id = $2', [Number(m[1]), id]);
      const s = await S.get();
      let drv = null;
      if (e.driver_id) {
        const d = await db.one('SELECT full_name, phone, vehicle FROM drivers WHERE id = $1', [e.driver_id]);
        if (d) drv = { name: d.full_name.split(' ')[0], phone: d.phone, vehicle: d.vehicle };
      }
      const sent = e.status === 'searching' ? (await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM errand_offers WHERE errand_id = $1 AND status = 'sent'`, [e.id])).n : 0;
      const messages = e.driver_id ? await db.query('SELECT id, from_type, body, created_at FROM errand_messages WHERE errand_id = $1 ORDER BY id', [e.id]) : [];
      return ok(res, {
        errand: {
          id: e.id, kind: e.kind, description: e.description, status: e.status, price: e.price, purchaseValue: e.purchase_value, distanceM: e.distance_m,
          from: { lat: e.from_lat, lng: e.from_lng, details: e.from_details }, to: { lat: e.to_lat, lng: e.to_lng, details: e.to_details },
          driversNotified: sent, canRaise: e.status === 'searching' && (Date.now() - Date.parse(e.search_started_at)) >= s.raiseAfterSec * 1000,
          driver: drv, createdAt: e.created_at, messages,
        },
      });
    })],

    ['POST', /^\/api\/customer\/errands\/(\d+)\/(cancel|raise)$/, customer(async (req, res, m, id) => {
      const e = await mustOrder('SELECT * FROM errands WHERE id = $1 AND customer_id = $2', [Number(m[1]), id]);
      if (m[2] === 'cancel') {
        if (!['searching', 'assigned'].includes(e.status)) throw stateError();
        await db.query(`UPDATE errand_offers SET status = 'lost' WHERE errand_id = $1 AND status = 'sent'`, [e.id]);
        await db.query(`UPDATE errands SET status = 'cancelled', closed_at = $1, close_reason = 'customer' WHERE id = $2`, [iso(), e.id]);
        return ok(res);
      }
      if (e.status !== 'searching') throw stateError();
      const b = await readJson(req);
      const v = new Validator();
      const price = v.number('price', b.price, { min: Number(e.price) + 0.01, max: 500 });
      v.assert();
      await db.query('UPDATE errands SET price = $1, search_started_at = $2 WHERE id = $3', [price, iso(), e.id]);
      const sent = await dispatchErrand(db, { ...e, price }, await S.get());
      return ok(res, { driversNotified: sent });
    })],

    // Chat (after a driver accepted). Both sides post; the owner only sees it when a complaint is filed.
    ['POST', /^\/api\/errands\/(\d+)\/messages$/, async (req, res, m) => {
      checkCsrf(req);
      const e = await db.one('SELECT id, customer_id, driver_id, status FROM errands WHERE id = $1', [Number(m[1])]);
      if (!e) throw new HttpError(404, 'not_found');
      const cid = await custSessions.ownerId(req), did = await driverSessions.ownerId(req);
      const from = cid && cid === e.customer_id ? 'customer' : did && did === e.driver_id ? 'driver' : null;
      if (!from) throw new HttpError(403, 'forbidden');
      if (!e.driver_id || ['cancelled'].includes(e.status)) throw stateError();
      await limit(limiters.lookup, `chat:${from}:${from === 'customer' ? cid : did}`);
      const b = await readJson(req);
      const v = new Validator();
      const body = v.text('body', b.body, { min: 1, max: 1000, multiline: true });
      v.assert();
      await db.query('INSERT INTO errand_messages (errand_id, from_type, body) VALUES ($1,$2,$3)', [e.id, from, body]);
      return ok(res, { ok: true }, 201);
    }],

    ['POST', /^\/api\/driver\/errand-offers\/(\d+)\/(accept|decline)$/, driver(async (req, res, m, id) => {
      const offerId = Number(m[1]);
      if (m[2] === 'decline') {
        await db.query(`UPDATE errand_offers SET status = 'declined' WHERE id = $1 AND driver_id = $2 AND status = 'sent'`, [offerId, id]);
        return ok(res);
      }
      const d = await db.one('SELECT jobs_until FROM drivers WHERE id = $1', [id]);
      if (!d.jobs_until || d.jobs_until <= iso()) throw new HttpError(403, 'jobs_subscription_required');
      const errandId = await db.tx(async (t) => {
        const f = await t.one(`SELECT id, errand_id FROM errand_offers WHERE id = $1 AND driver_id = $2 AND status = 'sent'`, [offerId, id]);
        if (!f) throw new HttpError(409, 'offer_gone');
        const busy = await t.one(`SELECT id FROM orders WHERE driver_id = $1 AND status IN ('assigned','picked_up') UNION SELECT id FROM errands WHERE driver_id = $1 AND status IN ('assigned','picked_up')`, [id]);
        if (busy) throw new HttpError(409, 'driver_busy');
        const won = await t.query(`UPDATE errands SET status = 'assigned', driver_id = $1, assigned_at = $2 WHERE id = $3 AND status = 'searching' RETURNING id`, [id, iso(), f.errand_id]);
        if (!won.length) throw new HttpError(409, 'offer_gone');
        await t.query(`UPDATE errand_offers SET status = 'lost' WHERE errand_id = $1 AND id <> $2 AND status = 'sent'`, [f.errand_id, f.id]);
        await t.query(`UPDATE errand_offers SET status = 'won' WHERE id = $1`, [f.id]);
        return f.errand_id;
      });
      return ok(res, { errandId });
    })],

    ['POST', /^\/api\/driver\/errands\/(\d+)\/(picked|delivered)$/, driver(async (req, res, m, id) => {
      const e = await mustOrder('SELECT id, status FROM errands WHERE id = $1 AND driver_id = $2', [Number(m[1]), id]);
      if (m[2] === 'picked') {
        if (e.status !== 'assigned') throw stateError();
        await db.query(`UPDATE errands SET status = 'picked_up', picked_at = $1 WHERE id = $2`, [iso(), e.id]);
      } else {
        if (!['assigned', 'picked_up'].includes(e.status)) throw stateError();
        await db.query(`UPDATE errands SET status = 'delivered', delivered_at = $1, closed_at = $1 WHERE id = $2`, [iso(), e.id]);
      }
      return ok(res);
    })],

    ['POST', /^\/api\/admin\/drivers\/(\d+)\/jobs$/, owner(async (req, res, m) => {
      const b = await readJson(req);
      const v = new Validator();
      const months = v.int('months', b.months, { min: 0, max: 24 });
      v.assert();
      const d = await db.one('SELECT id, jobs_until FROM drivers WHERE id = $1', [Number(m[1])]);
      if (!d) throw new HttpError(404, 'not_found');
      let until = null;
      if (months > 0) {
        const from = d.jobs_until && d.jobs_until > iso() ? new Date(d.jobs_until) : new Date();
        from.setUTCMonth(from.getUTCMonth() + months);
        until = from.toISOString();
      }
      await db.query('UPDATE drivers SET jobs_until = $1 WHERE id = $2', [until, d.id]);
      return ok(res, { until });
    })],

    ['GET', /^\/api\/admin\/errands$/, owner(async (req, res) => {
      const rows = await db.query(`SELECT e.id, e.kind, e.status, e.price, e.purchase_value, e.distance_m, e.created_at, cu.name AS customer, d.full_name AS driver,
          EXISTS (SELECT 1 FROM complaints c WHERE c.errand_id = e.id) AS has_complaint
        FROM errands e JOIN customers cu ON cu.id = e.customer_id LEFT JOIN drivers d ON d.id = e.driver_id ${cOf(req) ? `WHERE COALESCE(e.country,'LB') = $1` : ''} ORDER BY e.id DESC LIMIT 200`, cOf(req) ? [cOf(req)] : []);
      return ok(res, { errands: rows });
    })],

    // The private chat is shown to the owner only when there is a complaint about this errand.
    ['GET', /^\/api\/admin\/errands\/(\d+)\/messages$/, owner(async (req, res, m) => {
      const id = Number(m[1]);
      if (!(await db.one('SELECT id FROM complaints WHERE errand_id = $1', [id]))) throw new HttpError(403, 'no_complaint');
      return ok(res, { messages: await db.query('SELECT from_type, body, created_at FROM errand_messages WHERE errand_id = $1 ORDER BY id', [id]) });
    })],

    // ===== delete anything (owner): keeps the admin panel tidy =====
    ['DELETE', /^\/api\/admin\/(drivers|customers|orders|errands|complaints|warnings|withdrawals|topups)\/(\d+)$/, owner(async (req, res, m) => {
      const what = m[1], id = Number(m[2]);
      await db.tx(async (t) => {
        if (what === 'drivers') {
          if (!(await t.one('SELECT id FROM drivers WHERE id = $1', [id]))) throw new HttpError(404, 'not_found');
          await t.query(`DELETE FROM wallet_ledger WHERE account_type = 'driver' AND account_id = $1`, [id]);
          await t.query(`DELETE FROM withdrawals WHERE account_type = 'driver' AND account_id = $1`, [id]);
          await t.query(`DELETE FROM warnings WHERE account_type = 'driver' AND account_id = $1`, [id]);
          await t.query(`DELETE FROM complaints WHERE (from_type = 'driver' AND from_id = $1) OR (against_type = 'driver' AND against_id = $1)`, [id]);
          await t.query('DELETE FROM drivers WHERE id = $1', [id]);            // documents, sessions and offers go with it
        } else if (what === 'customers') {
          if (!(await t.one('SELECT id FROM customers WHERE id = $1', [id]))) throw new HttpError(404, 'not_found');
          await t.query(`DELETE FROM warnings WHERE account_type = 'customer' AND account_id = $1`, [id]);
          await t.query(`DELETE FROM complaints WHERE (from_type = 'customer' AND from_id = $1) OR (against_type = 'customer' AND against_id = $1)`, [id]);
          await t.query('DELETE FROM customers WHERE id = $1', [id]);          // addresses, orders, errands, chats, appointments go with it
        } else if (what === 'withdrawals' || what === 'topups') {
          const r = await t.one(`SELECT status FROM ${what} WHERE id = $1`, [id]);
          if (!r) throw new HttpError(404, 'not_found');
          if (r.status === 'pending') throw stateError();                   // decide it first (money is involved)
          await t.query(`DELETE FROM ${what} WHERE id = $1`, [id]);
        } else {
          const table = { orders: 'orders', errands: 'errands', complaints: 'complaints', warnings: 'warnings' }[what];
          const r = await t.query(`DELETE FROM ${table} WHERE id = $1 RETURNING id`, [id]);
          if (!r.length) throw new HttpError(404, 'not_found');
        }
      });
      return ok(res);
    })],

    // Store: remove its delivery data (balance history, withdrawals, warnings, complaints) before deleting the store itself.
    ['DELETE', /^\/api\/admin\/delivery\/stores\/(\d+)\/leftovers$/, owner(async (req, res, m) => {
      const id = Number(m[1]);
      await db.query(`DELETE FROM wallet_ledger WHERE account_type = 'store' AND account_id = $1`, [id]);
      await db.query(`DELETE FROM withdrawals WHERE account_type = 'store' AND account_id = $1`, [id]);
      await db.query(`DELETE FROM warnings WHERE account_type = 'store' AND account_id = $1`, [id]);
      await db.query(`DELETE FROM complaints WHERE (from_type = 'store' AND from_id = $1) OR (against_type = 'store' AND against_id = $1)`, [id]);
      return ok(res);
    })],

    // Clear finished things older than N days in one go (balances are not touched).
    ['POST', /^\/api\/admin\/delivery\/cleanup$/, owner(async (req, res) => {
      const b = await readJson(req);
      const v = new Validator();
      const days = v.int('days', b.days, { min: 1, max: 3650 });
      v.assert();
      const before = new Date(Date.now() - days * 864e5).toISOString();
      const n = async (sql) => (await db.query(sql, [before])).length;
      const out = {
        orders: await n(`DELETE FROM orders WHERE status IN ('delivered','rejected','cancelled') AND created_at < $1 RETURNING id`),
        errands: await n(`DELETE FROM errands WHERE status IN ('delivered','cancelled') AND created_at < $1 RETURNING id`),
        complaints: await n(`DELETE FROM complaints WHERE status <> 'open' AND created_at < $1 RETURNING id`),
        withdrawals: await n(`DELETE FROM withdrawals WHERE status <> 'pending' AND created_at < $1 RETURNING id`),
        topups: await n(`DELETE FROM topups WHERE status <> 'pending' AND created_at < $1 RETURNING id`),
        appointments: await n(`DELETE FROM appointments WHERE status IN ('declined','cancelled','done') AND created_at < $1 RETURNING id`),
        visits: await n(`DELETE FROM visit_requests WHERE status IN ('declined','cancelled','done') AND created_at < $1 RETURNING id`),
      };
      return ok(res, out);
    })],

    // ===== complaints: any party of an order can complain about another party =====
    ['POST', /^\/api\/complaints$/, async (req, res) => {
      checkCsrf(req);
      const b = await readJson(req);
      const v = new Validator();
      const isErrand = b.errandId != null;
      const orderId = v.int(isErrand ? 'errandId' : 'orderId', isErrand ? b.errandId : b.orderId, { min: 1 });
      const against = v.oneOf('against', b.against, isErrand ? ['driver', 'customer'] : ['store', 'driver', 'customer']);
      const text = v.text('text', b.text, { min: 5, max: 1000, multiline: true });
      v.assert();
      const o = isErrand
        ? await db.one('SELECT id, NULL AS cook_id, customer_id, driver_id FROM errands WHERE id = $1', [orderId])
        : await db.one('SELECT id, cook_id, customer_id, driver_id FROM orders WHERE id = $1', [orderId]);
      if (!o) throw new HttpError(404, 'not_found');
      const who = [
        ['customer', await custSessions.ownerId(req), o.customer_id],
        ['store', await cookSessions.ownerId(req), o.cook_id],
        ['driver', await driverSessions.ownerId(req), o.driver_id],
      ].find(([, sid, oid]) => sid && sid === oid);
      if (!who) throw new HttpError(403, 'forbidden');
      const targetId = { customer: o.customer_id, store: o.cook_id, driver: o.driver_id }[against];
      if (!targetId || against === who[0]) throw new HttpError(422, 'validation_failed', { fields: { against: 'invalid' } });
      await limit(limiters.feedback, `complaint:${who[0]}:${who[1]}`);
      await db.query('INSERT INTO complaints (order_id, errand_id, from_type, from_id, against_type, against_id, text) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [isErrand ? null : o.id, isErrand ? o.id : null, who[0], who[1], against, targetId, text]);
      return ok(res, { ok: true }, 201);
    }],

    // ===== admin (owner) =====
    ['GET', /^\/api\/admin\/delivery\/overview$/, owner(async (req, res) => {
      const s = await S.get();
      const day = new Date(); day.setUTCHours(0, 0, 0, 0);
      const cn = cOf(req);
      // with a country chosen, every number is for that country only
      const n = async (sql, p = []) => (await db.one(sql, cn ? [...p, cn] : p)).n;
      const C = (col, i) => (cn ? ` AND COALESCE(${col},'LB') = $${i}` : '');
      return ok(res, {
        ordersToday: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM orders o WHERE o.created_at >= $1${C('o.country', 2)}`, [day.toISOString()]),
        activeOrders: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM orders o WHERE o.status IN ('pending','preparing','searching','assigned','picked_up')${C('o.country', 1)}`),
        driversAvailable: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM drivers WHERE status = 'active' AND available = 1 AND loc_at >= $1${C('country', 2)}`, [new Date(Date.now() - s.driverStaleSec * 1000).toISOString()]),
        driversPending: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM drivers WHERE status = 'pending'${C('country', 1)}`),
        topupsPending: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM topups t JOIN cooks c ON c.id = t.cook_id WHERE t.status = 'pending'${C('c.country', 1)}`),
        payoutsDue: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM withdrawals w LEFT JOIN drivers d ON w.account_type = 'driver' AND d.id = w.account_id LEFT JOIN cooks c ON w.account_type = 'store' AND c.id = w.account_id
          WHERE w.status = 'pending'${cn ? ` AND COALESCE(d.country, c.country, 'LB') = $1` : ''}`),
        complaintsOpen: await n(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM complaints WHERE status = 'open'${cn ? ' AND $1 = $1' : ''}`),
      });
    })],

    ['GET', /^\/api\/admin\/delivery\/settings$/, owner(async (req, res) => ok(res, { settings: await S.get(), smsVerification: sms.enabled }))],
    ['PUT', /^\/api\/admin\/delivery\/settings$/, owner(async (req, res) => ok(res, { settings: await S.set(await readJson(req)) }))],

    ['GET', /^\/api\/admin\/drivers$/, owner(async (req, res) => {
      const st = q(req).get('status'), cn = cOf(req);
      const conds = [], params = [];
      if (st) { params.push(st); conds.push(`status = $${params.length}`); }
      if (cn) { params.push(cn); conds.push(`COALESCE(country,'LB') = $${params.length}`); }
      const rows = await db.query(`SELECT id, full_name, phone, vehicle, plate, status, available, country, wallet_provider, wallet_number, created_at FROM drivers
        ${conds.length ? 'WHERE ' + conds.join(' AND ') : ''} ORDER BY id DESC LIMIT 500`, params);
      for (const r of rows) { r.balance = await balance(db, 'driver', r.id); r.warnings = await activeWarnings(db, 'driver', r.id); }
      return ok(res, { drivers: rows });
    })],

    ['GET', /^\/api\/admin\/drivers\/(\d+)$/, owner(async (req, res, m) => {
      const d = await db.one('SELECT id, full_name, phone, vehicle, plate, status, available, country, wallet_provider, wallet_number, admin_notes, terms_accepted_at, jobs_until, created_at FROM drivers WHERE id = $1', [Number(m[1])]);
      if (!d) throw new HttpError(404, 'not_found');
      const docs = await db.query('SELECT id, kind FROM driver_documents WHERE driver_id = $1 ORDER BY id', [d.id]);
      return ok(res, { driver: { ...d, balance: await balance(db, 'driver', d.id), warnings: await warningsOf('driver', d.id) }, documents: docs });
    })],

    // Private documents: streamed to the owner only, never cached, never on public storage.
    ['GET', /^\/api\/admin\/drivers\/(\d+)\/documents\/(\d+)$/, owner(async (req, res, m) => {
      const doc = await db.one('SELECT mime, data FROM driver_documents WHERE id = $1 AND driver_id = $2', [Number(m[2]), Number(m[1])]);
      if (!doc) throw new HttpError(404, 'not_found');
      const body = Buffer.from(doc.data, 'base64');
      res.writeHead(200, { 'Content-Type': doc.mime, 'Content-Length': body.length, 'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff' });
      res.end(body);
    })],

    ['POST', /^\/api\/admin\/drivers\/(\d+)\/status$/, owner(async (req, res, m) => {
      const b = await readJson(req);
      const v = new Validator();
      const status = v.oneOf('status', b.status, ['active', 'rejected', 'suspended']);
      v.assert();
      const id = Number(m[1]);
      if (!(await accountExists(db, 'driver', id))) throw new HttpError(404, 'not_found');
      if (status === 'suspended') await setSuspended(db, 'driver', id, true);
      else await db.query(`UPDATE drivers SET status = $1, available = 0 WHERE id = $2`, [status, id]);
      return ok(res);
    })],

    ['GET', /^\/api\/admin\/customers$/, owner(async (req, res) => {
      const text = String(q(req).get('q') || '').trim().slice(0, 40), cn = cOf(req);
      const rows = await db.query(`SELECT id, name, phone, status, country, created_at FROM customers WHERE phone NOT LIKE 'deleted-%'
        ${text ? 'AND (LOWER(name) LIKE $1 OR phone LIKE $1)' : ''} ${cn ? `AND COALESCE(country,'LB') = $${text ? 2 : 1}` : ''} ORDER BY id DESC LIMIT 300`,
        [...(text ? [`%${text.toLowerCase()}%`] : []), ...(cn ? [cn] : [])]);
      for (const r of rows) r.warnings = await activeWarnings(db, 'customer', r.id);
      return ok(res, { customers: rows });
    })],

    ['GET', /^\/api\/admin\/orders$/, owner(async (req, res) => {
      const st = q(req).get('status');
      const rows = await db.query(`SELECT o.id, o.status, o.total, o.delivery_fee, o.created_at, c.full_name AS store, cu.name AS customer, d.full_name AS driver
        FROM orders o JOIN cooks c ON c.id = o.cook_id JOIN customers cu ON cu.id = o.customer_id LEFT JOIN drivers d ON d.id = o.driver_id
        WHERE 1 = 1 ${st === 'active' ? `AND o.status IN ('pending','preparing','searching','assigned','picked_up')` : ''} ${cOf(req) ? `AND COALESCE(c.country,'LB') = $1` : ''} ORDER BY o.id DESC LIMIT 200`, cOf(req) ? [cOf(req)] : []);
      return ok(res, { orders: rows });
    })],

    ['GET', /^\/api\/admin\/topups$/, owner(async (req, res) => {
      const st = q(req).get('status') || 'pending';
      const rows = await db.query(`SELECT t.id, t.cook_id, t.amount, t.method, t.reference, t.status, t.created_at, c.full_name AS store
        FROM topups t JOIN cooks c ON c.id = t.cook_id WHERE t.status = $1 ORDER BY t.id DESC LIMIT 200`, [st]);
      return ok(res, { topups: rows });
    })],

    ['GET', /^\/api\/admin\/topups\/(\d+)\/receipt$/, owner(async (req, res, m) => {
      const t = await db.one('SELECT receipt_mime, receipt FROM topups WHERE id = $1', [Number(m[1])]);
      if (!t?.receipt) throw new HttpError(404, 'not_found');
      const body = Buffer.from(t.receipt, 'base64');
      res.writeHead(200, { 'Content-Type': t.receipt_mime, 'Content-Length': body.length, 'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff' });
      res.end(body);
    })],

    ['POST', /^\/api\/admin\/topups\/(\d+)\/(approve|reject)$/, owner(async (req, res, m) => {
      await db.tx(async (t) => {
        const tp = await t.one(`SELECT id, cook_id, amount, method, status FROM topups WHERE id = $1`, [Number(m[1])]);
        if (!tp) throw new HttpError(404, 'not_found');
        if (tp.status !== 'pending') throw stateError();
        const done = await t.query(`UPDATE topups SET status = $1, decided_at = $2 WHERE id = $3 AND status = 'pending' RETURNING id`, [m[2] === 'approve' ? 'approved' : 'rejected', iso(), tp.id]);
        if (!done.length) throw stateError();
        if (m[2] === 'approve') await ledgerAdd(t, 'store', tp.cook_id, Number(tp.amount), 'topup', { note: `${tp.method} #${tp.id}` });
      });
      return ok(res);
    })],

    ['POST', /^\/api\/admin\/stores\/(\d+)\/wallet-adjust$/, owner(async (req, res, m) => {
      const b = await readJson(req);
      const v = new Validator();
      const amount = v.number('amount', b.amount, { min: -10000, max: 10000 });
      const note = v.text('note', b.note, { max: 120 });
      v.assert();
      if (!(await accountExists(db, 'store', Number(m[1])))) throw new HttpError(404, 'not_found');
      await ledgerAdd(db, 'store', Number(m[1]), amount, 'adjust', { note });
      return ok(res, { balance: await balance(db, 'store', Number(m[1])) });
    })],

    ['GET', /^\/api\/admin\/payouts$/, owner(async (req, res) => {
      const st = q(req).get('status') || 'due';
      const rows = await db.query(`SELECT p.id, p.driver_id, p.amount, p.provider, p.number, p.status, p.paid_at, p.created_at, d.full_name AS driver
        FROM payouts p JOIN drivers d ON d.id = p.driver_id WHERE p.status = $1 ORDER BY p.id DESC LIMIT 200`, [st]);
      return ok(res, { payouts: rows });
    })],

    ['POST', /^\/api\/admin\/payouts\/(\d+)\/paid$/, owner(async (req, res, m) => {
      const s = await S.get();
      const driverId = await db.tx(async (t) => {
        const p = await t.one('SELECT id, driver_id, amount, status FROM payouts WHERE id = $1', [Number(m[1])]);
        if (!p) throw new HttpError(404, 'not_found');
        if (p.status !== 'due') throw stateError();
        await t.query(`UPDATE payouts SET status = 'paid', paid_at = $1 WHERE id = $2`, [iso(), p.id]);
        await ledgerAdd(t, 'driver', p.driver_id, -Number(p.amount), 'payout', { note: `payout #${p.id}` });
        return p.driver_id;
      });
      return ok(res);
    })],

    ['GET', /^\/api\/admin\/complaints$/, owner(async (req, res) => {
      const st = q(req).get('status') || 'open';
      const rows = await db.query('SELECT id, order_id, errand_id, from_type, from_id, against_type, against_id, text, status, created_at FROM complaints WHERE status = $1 ORDER BY id DESC LIMIT 300', [st]);
      return ok(res, { complaints: rows });
    })],

    ['POST', /^\/api\/admin\/complaints\/(\d+)\/(warn|dismiss)$/, owner(async (req, res, m) => {
      const c = await db.one('SELECT id, against_type, against_id, status FROM complaints WHERE id = $1', [Number(m[1])]);
      if (!c) throw new HttpError(404, 'not_found');
      if (c.status !== 'open') throw stateError();
      if (m[2] === 'dismiss') {
        await db.query(`UPDATE complaints SET status = 'dismissed', decided_at = $1 WHERE id = $2`, [iso(), c.id]);
        return ok(res);
      }
      const b = await readJson(req);
      const v = new Validator();
      const reason = v.text('reason', b.reason, { min: 3, max: 300 });
      v.assert();
      const w = await addWarning(db, await S.get(), { type: c.against_type, id: c.against_id, reason, complaintId: c.id });
      await db.query(`UPDATE complaints SET status = 'warned', decided_at = $1 WHERE id = $2`, [iso(), c.id]);
      return ok(res, w);
    })],

    ['POST', /^\/api\/admin\/warnings$/, owner(async (req, res) => {
      const b = await readJson(req);
      const v = new Validator();
      const type = v.oneOf('type', b.type, ['store', 'driver', 'customer']);
      const id = v.int('id', b.id, { min: 1 });
      const reason = v.text('reason', b.reason, { min: 3, max: 300 });
      v.assert();
      if (!(await accountExists(db, type, id))) throw new HttpError(404, 'not_found');
      return ok(res, await addWarning(db, await S.get(), { type, id, reason }), 201);
    })],

    ['GET', /^\/api\/admin\/warnings$/, owner(async (req, res) => {
      const p = q(req);
      const v = new Validator();
      const type = v.oneOf('type', p.get('type'), ['store', 'driver', 'customer']);
      const id = v.int('id', p.get('id'), { min: 1 });
      v.assert();
      return ok(res, await warningsOf(type, id));
    })],

    ['POST', /^\/api\/admin\/accounts\/(store|driver|customer)\/(\d+)\/(suspend|activate)$/, owner(async (req, res, m) => {
      const id = Number(m[2]);
      if (!(await accountExists(db, m[1], id))) throw new HttpError(404, 'not_found');
      await setSuspended(db, m[1], id, m[3] === 'suspend');
      return ok(res);
    })],

    ['GET', /^\/api\/admin\/delivery\/stores$/, owner(async (req, res) => {
      const text = String(q(req).get('q') || '').trim().slice(0, 40), cn = cOf(req);
      const rows = await db.query(`SELECT id, full_name, kind, country, whatsapp, delivery_mode, booking, pinned, suspended, is_hidden, status FROM cooks
        WHERE status <> 'rejected' ${text ? 'AND (LOWER(full_name) LIKE $1 OR whatsapp LIKE $1)' : ''} ${cn ? `AND COALESCE(country,'LB') = $${text ? 2 : 1}` : ''} ORDER BY pinned DESC, id DESC LIMIT 300`,
        [...(text ? [`%${text.toLowerCase()}%`] : []), ...(cn ? [cn] : [])]);
      for (const r of rows) { r.balance = await balance(db, 'store', r.id); r.warnings = await activeWarnings(db, 'store', r.id); }
      return ok(res, { stores: rows });
    })],

    ['POST', /^\/api\/admin\/stores\/(\d+)\/delivery$/, owner(async (req, res, m) => {
      const b = await readJson(req);
      const v = new Validator();
      const mode = b.mode === undefined ? undefined : v.oneOf('mode', b.mode, ['delivery', 'self', 'none']);
      v.assert();
      const id = Number(m[1]);
      if (!(await accountExists(db, 'store', id))) throw new HttpError(404, 'not_found');
      if (mode) await db.query('UPDATE cooks SET delivery_mode = $1 WHERE id = $2', [mode, id]);
      if (b.pinned !== undefined) await db.query('UPDATE cooks SET pinned = $1 WHERE id = $2', [b.pinned ? 1 : 0, id]);
      if (b.booking !== undefined) await db.query('UPDATE cooks SET booking = $1 WHERE id = $2', [b.booking ? 1 : 0, id]);
      return ok(res);
    })],
  ];
}
