// v8.3 AI Operations Manager API. Every subscriber endpoint checks the AI entitlement first (403 ai_not_subscribed for
// BASIC, 403 ai_disabled when the owner switched AI off) — whatever the body contains, even a tool name.
// Turning AI off never touches ordinary order processing: nothing in the order routes depends on this module.
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator } from '../lib/validate.js';
import { assertClean } from '../lib/profanity.js';
import { RateLimiter } from '../lib/ratelimit.js';
import { makeGuards } from '../lib/guards.js';
import { requireAi, checkAi, getAiConfig, saveAiConfig, CATEGORIES, ownerInfo } from '../services/ai/entitlement.js';
import { getSettings, updateSettings, permsFor, allowedLevels, GROUPS, LEVELS } from '../services/ai/permissions.js';
import { createAiRuntime, usageCost, monthKey } from '../services/ai/runner.js';
import { aiMoney, sealKey, KEY_RE } from '../services/ai/budget.js';
import { imageBytesOk } from '../lib/validate.js';
import { createProvider, providerInfo } from '../services/ai/provider.js';
import { toolsFor } from '../services/ai/tools.js';
import { listContacts, correctContact, deleteContact, contactsCsv, customerOptOut, customerDelete } from '../services/ai/crm.js';
import { placeCall } from '../services/ai/channels/telephony.js';
import { sendMarketing } from '../services/ai/channels/marketing.js';

const ok = (res, data = {}, status = 200) => sendJson(res, status, { ok: true, ...data });
const parse = (s) => { try { return JSON.parse(s); } catch { return null; } };
const q = (req) => new URL(req.url, 'http://x').searchParams;

export function aiRoutes(ctx) {
  const { db, cfg, limiters = {}, push = null } = ctx;
  const { store, driver, customer, owner, limit, sessions } = makeGuards(ctx);
  const provider = createProvider({ impl: cfg.aiProviderImpl || null });
  const ai = createAiRuntime({ db, push, provider, log: cfg.quiet ? {} : console, secret: cfg.sessionSecret || '', ownProviderFactory: cfg.aiOwnProviderFactory || null });
  // AI limiters share the app's rate-limit store (memory / Postgres / Redis), like the others
  const rlStore = limiters.contact?.store;
  const scale = cfg.rateLimitScale || 1;
  const L = (name, windowMs, max) => (rlStore ? new RateLimiter({ name, windowMs, max: max * scale, store: rlStore, log: cfg.quiet ? {} : console }) : null);
  const aiLimit = L('ai-chat', 60_000, cfg.aiChatLimit ?? 30);
  const aiCustLimit = L('ai-cust', 10 * 60_000, cfg.aiCustomerLimit ?? 15);
  const aiStoreLimit = L('ai-store', 60_000, cfg.aiStoreLimit ?? 60);

  /** Store OR driver (?as=driver|store when one phone has both sessions). Passes { type, id }. */
  const subscriber = (fn) => async (req, res, m) => {
    const as = q(req).get('as');
    let type = as === 'driver' || as === 'store' ? as : null;
    if (!type) type = (await sessions.store.ownerId(req).catch(() => null)) ? 'store' : (await sessions.driver.ownerId(req).catch(() => null)) ? 'driver' : null;
    if (!type) throw new HttpError(401, 'unauthorized');
    const guard = type === 'store' ? store : driver;
    return guard((rq, rs, mm, id) => fn(rq, rs, mm, { type, id }))(req, res, m);
  };
  /** subscriber + the AI entitlement → fn(req, res, m, owner, config) */
  const withAi = (fn) => subscriber(async (req, res, m, who) => {
    const { owner: o, config } = await requireAi(db, who.type, who.id);
    return fn(req, res, m, o, config);
  });

  const settingsView = async (o) => {
    const st = await getSettings(db, o.type, o.id, o.category);
    const tools = toolsFor(o.category);
    const perms = permsFor(o.category).map((p) => ({ key: p.key, group: p.group, risk: p.risk, kind: p.kind, level: st.levels[p.key], allowed: allowedLevels(p),
      descKey: `ai.perm.${p.key}`, desc: p.desc, tools: tools.filter((t) => t.permission === p.key).map((t) => t.name) }));
    return { enabled: st.enabled, category: o.category, levels: LEVELS, groups: GROUPS.map((g) => ({ key: g, perms: perms.filter((p) => p.group === g) })).filter((g) => g.perms.length), priceUnaffected: true };
  };

  return [
    // ---------- subscriber: settings ----------
    ['GET', /^\/api\/ai\/settings$/, withAi(async (req, res, m, o) => ok(res, await settingsView(o)))],
    ['PUT', /^\/api\/ai\/settings$/, withAi(async (req, res, m, o) => {
      const b = await readJson(req);
      await updateSettings(db, o.type, o.id, o.category, { enabled: b.enabled, perms: b.perms }, `${o.type}:${o.id}`);
      return ok(res, await settingsView(o));
    })],

    // ---------- subscriber: the manager chat ----------
    ['POST', /^\/api\/ai\/manager\/chat$/, withAi(async (req, res, m, o, config) => {
      await limit(aiLimit, `${o.type}${o.id}`);
      const b = await readJson(req);
      const v = new Validator();
      const message = v.text('message', b.message, { min: 1, max: 1000, multiline: true });
      v.assert();
      // fields like "tool" / "tools" / "args" in the body are ignored: the client can never pick a tool
      const out = await ai.runTurn({ owner: o, config, actor: 'subscriber', message });
      return ok(res, { ...out, voice: b.voice === true });
    })],

    // ---------- subscriber: more AI budget this month (a pack, paid like a renewal; the owner approves) ----------
    ['POST', /^\/api\/ai\/pack$/, withAi(async (req, res, m, o, config) => {
      if (ctx.settings?.get?.()?.googleOnly !== false) throw new HttpError(409, 'google_play_only');   // bought in the Play app
      const b = await readJson(req, 600_000);
      const v = new Validator();
      const method = v.oneOf('method', b.method, ['whish', 'omt', 'other']);
      const reference = v.text('reference', b.reference, { max: 80, required: false });
      if (!b.receipt || !imageBytesOk(b.receipt) || String(b.receipt).length > 560_000) v.fail('receipt', 'invalid');
      v.assert();
      const pending = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM ai_packs WHERE owner_type = $1 AND owner_id = $2 AND status = 'pending'`, [o.type, o.id]);
      if (pending.n >= 2) throw new HttpError(409, 'too_many_pending');
      const mm = /^data:(image\/\w+);base64,/.exec(String(b.receipt));
      const row = await db.one(`INSERT INTO ai_packs (owner_type, owner_id, price, cents, method, reference, receipt_mime, receipt, month, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
        [o.type, o.id, Number(config.pack.priceUsd), Number(config.pack.cents), method, reference, mm?.[1] || 'image/jpeg', String(b.receipt).split(',')[1], monthKey(), new Date().toISOString()]);
      push?.notifyAdmins?.({ title: 'Aklatak — الإدارة', body: `🤖 طلب رصيد إضافي للمدير الذكي (${config.pack.priceUsd}$) — ${o.name}`, url: '/admin/#dx-ai' });
      return ok(res, { id: row.id, price: Number(config.pack.priceUsd) }, 201);
    })],
    // ---------- subscriber: use my own Anthropic key (optional; stored encrypted, never shown again) ----------
    ['PUT', /^\/api\/ai\/own-key$/, withAi(async (req, res, m, o, config) => {
      if (!config.allowOwnKey) throw new HttpError(403, 'own_key_off');
      const b = await readJson(req);
      const key = String(b.key || '').trim();
      if (!KEY_RE.test(key)) throw new HttpError(422, 'validation_failed', { fields: { key: 'invalid' } });
      await db.query(`INSERT INTO ai_keys (owner_type, owner_id, enc, last4, status, updated_at) VALUES ($1,$2,$3,$4,'ok',$5)
        ON CONFLICT (owner_type, owner_id) DO UPDATE SET enc = EXCLUDED.enc, last4 = EXCLUDED.last4, status = 'ok', fail_note = NULL, updated_at = EXCLUDED.updated_at`,
      [o.type, o.id, sealKey(cfg.sessionSecret, key), key.slice(-4), new Date().toISOString()]);
      ai.forgetOwnKey(o);
      return ok(res, { usage: await ai.usage(o, config) });
    })],
    ['DELETE', /^\/api\/ai\/own-key$/, withAi(async (req, res, m, o, config) => {
      await db.query('DELETE FROM ai_keys WHERE owner_type = $1 AND owner_id = $2', [o.type, o.id]);
      ai.forgetOwnKey(o);
      return ok(res, { usage: await ai.usage(o, config) });
    })],

    // ---------- subscriber: approvals ----------
    ['GET', /^\/api\/ai\/approvals$/, withAi(async (req, res, m, o) => {
      const rows = await db.query(`SELECT id, tool, args, reason, status, result, decided_at, created_at FROM ai_approvals WHERE owner_type = $1 AND owner_id = $2
        ORDER BY CASE WHEN status = 'pending' THEN 0 ELSE 1 END, id DESC LIMIT 100`, [o.type, o.id]);
      const tasks = await db.query(`SELECT id, kind, ref, result AS reason, created_at FROM ai_tasks WHERE owner_type = $1 AND owner_id = $2 AND kind = 'human' AND status = 'open' ORDER BY id DESC LIMIT 50`, [o.type, o.id]);
      return ok(res, { approvals: rows.map((r) => ({ ...r, args: parse(r.args), result: parse(r.result) })), tasks });
    })],
    ['POST', /^\/api\/ai\/approvals\/(\d+)\/(approve|reject)$/, withAi(async (req, res, m, o) => {
      const id = Number(m[1]);
      return ok(res, m[2] === 'approve' ? await ai.approve(o, id) : await ai.reject(o, id));
    })],
    ['POST', /^\/api\/ai\/tasks\/(\d+)\/close$/, withAi(async (req, res, m, o) => {
      const r = await db.query(`UPDATE ai_tasks SET status = 'closed', updated_at = $1 WHERE id = $2 AND owner_type = $3 AND owner_id = $4 AND kind = 'human' AND status = 'open' RETURNING id`, [new Date().toISOString(), Number(m[1]), o.type, o.id]);
      if (!r.length) throw new HttpError(404, 'not_found');
      return ok(res);
    })],

    // ---------- subscriber: audit log, reports, usage ----------
    ['GET', /^\/api\/ai\/actions$/, withAi(async (req, res, m, o) => {
      const n = Math.min(200, Math.max(1, Number(q(req).get('limit')) || 50));
      return ok(res, { actions: await db.query(`SELECT id, actor, tool, risk, args_summary, result_summary, decision, approval_id, created_at FROM ai_actions WHERE owner_type = $1 AND owner_id = $2 ORDER BY id DESC LIMIT ${n}`, [o.type, o.id]) });
    })],
    ['GET', /^\/api\/ai\/reports$/, withAi(async (req, res, m, o) => {
      const rows = await db.query('SELECT id, period, period_key, data, created_at FROM ai_reports WHERE owner_type = $1 AND owner_id = $2 ORDER BY period_key DESC, id DESC LIMIT 60', [o.type, o.id]);
      return ok(res, { reports: rows.map((r) => ({ ...r, data: parse(r.data) })) });
    })],
    ['GET', /^\/api\/ai\/usage$/, withAi(async (req, res, m, o, config) => ok(res, { usage: { ...(await ai.usage(o, config)), googleOnly: ctx.settings?.get?.()?.googleOnly !== false } }))],

    // ---------- subscriber: voice (speech-to-text / text-to-speech run in the phone's browser; only seconds come here) ----------
    ['POST', /^\/api\/ai\/voice\/session$/, withAi(async (req, res, m, o, config) => ok(res, await ai.voiceStart(o, config), 201))],
    ['POST', /^\/api\/ai\/voice\/session\/(\d+)\/heartbeat$/, withAi(async (req, res, m, o, config) => {
      const b = await readJson(req);
      const v = new Validator();
      const seconds = v.int('seconds', b.seconds ?? 0, { min: 0, max: 120 });
      v.assert();
      return ok(res, await ai.voiceBeat(o, config, Number(m[1]), seconds));
    })],
    ['POST', /^\/api\/ai\/voice\/session\/(\d+)\/end$/, withAi(async (req, res, m, o) => ok(res, await ai.voiceEnd(o, Number(m[1]))))],

    // ---------- subscriber: CRM (own contacts only) ----------
    ['GET', /^\/api\/ai\/crm\/contacts$/, withAi(async (req, res, m, o) => ok(res, { contacts: await listContacts(db, o) }))],
    ['PUT', /^\/api\/ai\/crm\/contacts\/(\d+)$/, withAi(async (req, res, m, o) => {
      const b = await readJson(req);
      const v = new Validator();
      const name = v.text('name', b.name, { min: 2, max: 80 });
      v.assert();
      assertClean(HttpError, { name });
      return ok(res, await correctContact(db, o, Number(m[1]), name));
    })],
    ['DELETE', /^\/api\/ai\/crm\/contacts\/(\d+)$/, withAi(async (req, res, m, o) => ok(res, await deleteContact(db, o, Number(m[1]))))],
    ['GET', /^\/api\/ai\/crm\/export$/, withAi(async (req, res, m, o) => {
      const body = Buffer.from(contactsCsv(await listContacts(db, o)));
      await db.query(`INSERT INTO crm_events (owner_type, owner_id, customer_id, kind, details) VALUES ($1,$2,NULL,'export',NULL)`, [o.type, o.id]);
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="contacts.csv"', 'Cache-Control': 'no-store', 'Content-Length': body.length });
      return res.end(body);
    })],

    // ---------- subscriber: future channels (disabled → 409 channel_disabled) ----------
    ['POST', /^\/api\/ai\/channels\/phone\/call$/, withAi(async (req, res, m, o) => { await readJson(req); return ok(res, await placeCall({ db, owner: o })); })],
    ['POST', /^\/api\/ai\/channels\/marketing\/send$/, withAi(async (req, res, m, o) => { await readJson(req); return ok(res, await sendMarketing({ db, owner: o })); })],

    // ---------- customer: the business's customer-service assistant (read-only, own orders only) ----------
    ['POST', /^\/api\/ai\/store\/(\d+)\/chat$/, customer(async (req, res, m, customerId) => {
      const storeId = Number(m[1]);
      // v8.2: a customer writing too fast, or a very busy store this minute, is still answered — by the free replies
      // (no AI cost), never with an error; each customer and each store has its own counter (nothing app-wide)
      let busy = null;
      for (const [lim, key] of [[aiCustLimit, `c${customerId}:${storeId}`], [aiStoreLimit, `s${storeId}`]]) {
        try { await limit(lim, key); } catch (e) { if (e?.status === 429) busy = 'busy'; else throw e; }
      }
      const st = await db.one(`SELECT id FROM cooks WHERE id = $1 AND status = 'approved' AND COALESCE(suspended, 0) = 0`, [storeId]);
      if (!st) throw new HttpError(404, 'not_found');
      const { owner: o, config } = await requireAi(db, 'store', storeId);
      const b = await readJson(req);
      const v = new Validator();
      const message = v.text('message', b.message, { min: 1, max: 500, multiline: true });
      v.assert();
      const out = await ai.runTurn({ owner: o, config, actor: 'customer', customerId, message, forceFree: busy });
      return ok(res, { reply: out.reply, lang: out.lang });
    })],
    // does this store offer the assistant? (lets the app show the button; no details leak)
    ['GET', /^\/api\/ai\/store\/(\d+)\/assistant$/, async (req, res, m) => {
      const r = await checkAi(db, 'store', Number(m[1]));
      if (!r.ok) return ok(res, { available: false });
      const s = await getSettings(db, 'store', r.owner.id, r.owner.category);
      return ok(res, { available: s.enabled && (s.levels.cs_assistant || 'OFF') !== 'OFF' });
    }],
    // the customer's privacy choices (always available, AI or not)
    ['POST', /^\/api\/ai\/crm\/opt-out$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      const v = new Validator();
      const ownerType = v.oneOf('ownerType', b.ownerType, ['store', 'driver']);
      const ownerId = v.int('ownerId', b.ownerId, { min: 1 });
      v.assert();
      if (!(await ownerInfo(db, ownerType, ownerId))) throw new HttpError(404, 'not_found');
      return ok(res, await customerOptOut(db, customerId, { type: ownerType, id: ownerId }));
    })],
    ['POST', /^\/api\/ai\/crm\/forget$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      if (b.ownerType == null) return ok(res, await customerDelete(db, customerId, null));
      const v = new Validator();
      const ownerType = v.oneOf('ownerType', b.ownerType, ['store', 'driver']);
      const ownerId = v.int('ownerId', b.ownerId, { min: 1 });
      v.assert();
      return ok(res, await customerDelete(db, customerId, { type: ownerType, id: ownerId }));
    })],

    // ---------- owner (admin panel) ----------
    ['GET', /^\/api\/admin\/ai\/config$/, owner(async (req, res) => ok(res, { config: await getAiConfig(db), provider: providerInfo(process.env, provider), categories: CATEGORIES }))],
    ['PUT', /^\/api\/admin\/ai\/config$/, owner(async (req, res, m, a) => {
      const b = await readJson(req);
      const before = await getAiConfig(db);
      const next = JSON.parse(JSON.stringify(before));
      const bad = {};
      const int = (v, max) => Number.isInteger(v) && v >= 0 && v <= max;
      if (b.enabled !== undefined) { if (typeof b.enabled === 'boolean') next.enabled = b.enabled; else bad.enabled = 'invalid'; }
      for (const c of CATEGORIES) {
        if (b.categories?.[c] !== undefined) { if (typeof b.categories[c] === 'boolean') next.categories[c] = b.categories[c]; else bad[`categories.${c}`] = 'invalid'; }
        for (const k of ['messages', 'voiceMinutes']) {
          const v = b.limits?.[c]?.[k];
          if (v !== undefined) { if (int(v, 1_000_000)) next.limits[c][k] = v; else bad[`limits.${c}.${k}`] = 'invalid'; }
        }
      }
      for (const k of Object.keys(next.costs)) { const v = b.costs?.[k]; if (v !== undefined) { if (int(v, 1_000_000)) next.costs[k] = v; else bad[`costs.${k}`] = 'invalid'; } }
      for (const k of Object.keys(next.workflow)) { const v = b.workflow?.[k]; if (v !== undefined) { if (int(v, 10_000) && v >= 1) next.workflow[k] = v; else bad[`workflow.${k}`] = 'invalid'; } }
      for (const k of Object.keys(next.channels)) { const v = b.channels?.[k]?.monthlySpendLimitCents; if (v !== undefined) { if (int(v, 100_000_000)) next.channels[k].monthlySpendLimitCents = v; else bad[`channels.${k}`] = 'invalid'; } }
      // v8.2 budgets (cents / month per subscriber), the extra pack, the two models, protection, the loaded balance
      for (const c of CATEGORIES) { const v = b.budgets?.[c]; if (v !== undefined) { if (int(v, 1_000_000)) next.budgets[c] = v; else bad[`budgets.${c}`] = 'invalid'; } }
      if (b.pack?.priceUsd !== undefined) { const v = Number(b.pack.priceUsd); if (Number.isFinite(v) && v > 0 && v <= 10_000) next.pack.priceUsd = Math.round(v * 100) / 100; else bad['pack.priceUsd'] = 'invalid'; }
      if (b.pack?.cents !== undefined) { if (int(b.pack.cents, 10_000_000) && b.pack.cents > 0) next.pack.cents = b.pack.cents; else bad['pack.cents'] = 'invalid'; }
      for (const k of ['manager', 'customer']) { const v = b.models?.[k]; if (v !== undefined) { if (typeof v === 'string' && /^claude-[a-z0-9.-]{3,60}$/.test(v)) next.models[k] = v; else bad[`models.${k}`] = 'invalid'; } }
      for (const k of Object.keys(next.protect)) { const v = b.protect?.[k]; if (v !== undefined) { if (int(v, 100_000_000)) next.protect[k] = v; else bad[`protect.${k}`] = 'invalid'; } }
      if (b.balance?.cents !== undefined) { if (int(b.balance.cents, 100_000_000)) { next.balance.cents = b.balance.cents; next.balance.asOf = new Date().toISOString(); } else bad['balance.cents'] = 'invalid'; }
      if (b.allowOwnKey !== undefined) { if (typeof b.allowOwnKey === 'boolean') next.allowOwnKey = b.allowOwnKey; else bad.allowOwnKey = 'invalid'; }
      if (Object.keys(bad).length) throw new HttpError(422, 'validation_failed', { fields: bad });
      const saved = await saveAiConfig(db, next);
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1, NULL, $2, $3)', [a.id, 'ai_config', JSON.stringify({ before: { enabled: before.enabled, categories: before.categories }, after: { enabled: saved.enabled, categories: saved.categories } }).slice(0, 1000)]);
      return ok(res, { config: saved });
    })],
    ['GET', /^\/api\/admin\/ai\/usage$/, owner(async (req, res) => {
      const month = /^\d{4}-\d{2}$/.test(q(req).get('month') || '') ? q(req).get('month') : monthKey();
      const config = await getAiConfig(db);
      const rows = await db.query(`SELECT u.*, CASE WHEN u.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name
        FROM ai_usage u LEFT JOIN cooks c ON u.owner_type = 'store' AND c.id = u.owner_id LEFT JOIN drivers d ON u.owner_type = 'driver' AND d.id = u.owner_id
        WHERE u.month = $1 ORDER BY u.messages DESC LIMIT 1000`, [month]);
      const subs = rows.map((u) => ({ ownerType: u.owner_type, ownerId: u.owner_id, name: u.name, category: u.category, messages: u.messages, toolCalls: u.tool_calls, tokensIn: u.tokens_in, tokensOut: u.tokens_out, voiceSeconds: u.voice_seconds, costCents: usageCost(u, config.costs) }));
      const byCategory = Object.fromEntries(CATEGORIES.map((c) => [c, subs.filter((s) => s.category === c).reduce((a, s) => ({ subscribers: a.subscribers + 1, messages: a.messages + s.messages, voiceSeconds: a.voiceSeconds + s.voiceSeconds, costCents: a.costCents + s.costCents }), { subscribers: 0, messages: 0, voiceSeconds: 0, costCents: 0 })]));
      return ok(res, { month, subscribers: subs, byCategory, totalCents: subs.reduce((a, s) => a + s.costCents, 0) });
    })],
    // v8.2 the AI money: this month, today, per day, what is left on the account (≈ days), vs the AI subscriptions
    ['GET', /^\/api\/admin\/ai\/money$/, owner(async (req, res) => {
      const config = await getAiConfig(db);
      const paused = await db.query(`SELECT u.owner_type, u.owner_id, u.paused_until, CASE WHEN u.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name FROM ai_usage u
        LEFT JOIN cooks c ON u.owner_type = 'store' AND c.id = u.owner_id LEFT JOIN drivers d ON u.owner_type = 'driver' AND d.id = u.owner_id WHERE u.month = $1 AND u.paused_until > $2`, [monthKey(), new Date().toISOString()]);
      const packs = await db.query(`SELECT p.id, p.owner_type, p.owner_id, p.price, p.cents, p.method, p.reference, p.status, p.created_at, CASE WHEN p.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name
        FROM ai_packs p LEFT JOIN cooks c ON p.owner_type = 'store' AND c.id = p.owner_id LEFT JOIN drivers d ON p.owner_type = 'driver' AND d.id = p.owner_id ORDER BY p.id DESC LIMIT 100`);
      return ok(res, { money: await aiMoney(db, config), paused: paused.map((x) => ({ ownerType: x.owner_type, ownerId: x.owner_id, name: x.name, until: x.paused_until })), packs });
    })],
    ['GET', /^\/api\/admin\/ai\/packs\/(\d+)\/receipt$/, owner(async (req, res, m) => {
      const r = await db.one('SELECT receipt_mime, receipt FROM ai_packs WHERE id = $1', [Number(m[1])]);
      if (!r?.receipt) throw new HttpError(404, 'not_found');
      const body = Buffer.from(r.receipt, 'base64');
      res.writeHead(200, { 'Content-Type': r.receipt_mime, 'Content-Length': body.length, 'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff' });
      return res.end(body);
    })],
    // approve: the budget is added to THIS month of that subscriber (once — the pack leaves «pending» only once)
    ['POST', /^\/api\/admin\/ai\/packs\/(\d+)\/(approve|reject)$/, owner(async (req, res, m, a) => {
      const st = m[2] === 'approve' ? 'approved' : 'rejected';
      const r = await db.query(`UPDATE ai_packs SET status = $1, decided_at = $2 WHERE id = $3 AND status = 'pending' RETURNING owner_type, owner_id, cents`, [st, new Date().toISOString(), Number(m[1])]);
      if (!r.length) throw new HttpError(409, 'invalid_state');
      const p = r[0];
      if (st === 'approved') {
        const info = await ownerInfo(db, p.owner_type, p.owner_id);
        await db.query(`INSERT INTO ai_usage (owner_type, owner_id, month, category) VALUES ($1,$2,$3,$4) ON CONFLICT (owner_type, owner_id, month) DO NOTHING`, [p.owner_type, p.owner_id, monthKey(), info?.category || 'shops']);
        await db.query(`UPDATE ai_usage SET extra_cents = extra_cents + $1, warned = 0 WHERE owner_type = $2 AND owner_id = $3 AND month = $4`, [p.cents, p.owner_type, p.owner_id, monthKey()]);
        push?.notify?.(p.owner_type, p.owner_id, { title: 'Aklatak', key: 'ai_pack_ok', vars: {}, body: '🤖 أُضيف الرصيد إلى مديرك الذكي — عاد يعمل كاملاً.', url: p.owner_type === 'driver' ? '/driver' : '/store' });
      }
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1, NULL, $2, $3)', [a.id, `ai_pack_${st}`, JSON.stringify({ id: Number(m[1]) })]);
      return ok(res, { status: st });
    })],
    // the owner brings a paused subscriber back (after looking at the unusual spending)
    ['POST', /^\/api\/admin\/ai\/unpause$/, owner(async (req, res) => {
      const b = await readJson(req);
      const v = new Validator();
      const ownerType = v.oneOf('ownerType', b.ownerType, ['store', 'driver']);
      const ownerId = v.int('ownerId', b.ownerId, { min: 1 });
      v.assert();
      await db.query('UPDATE ai_usage SET paused_until = NULL WHERE owner_type = $1 AND owner_id = $2 AND month = $3', [ownerType, ownerId, monthKey()]);
      return ok(res);
    })],
    ['GET', /^\/api\/admin\/ai\/actions$/, owner(async (req, res) => ok(res, { actions: await db.query(`SELECT a.*, CASE WHEN a.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name FROM ai_actions a
      LEFT JOIN cooks c ON a.owner_type = 'store' AND c.id = a.owner_id LEFT JOIN drivers d ON a.owner_type = 'driver' AND d.id = a.owner_id ORDER BY a.id DESC LIMIT 300`) }))],
    ['GET', /^\/api\/admin\/ai\/approvals$/, owner(async (req, res) => {
      const counts = await db.query(`SELECT status, CAST(COUNT(*) AS INTEGER) AS n FROM ai_approvals GROUP BY status`);
      const pending = await db.query(`SELECT a.id, a.owner_type, a.owner_id, a.tool, a.reason, a.created_at, CASE WHEN a.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name FROM ai_approvals a
        LEFT JOIN cooks c ON a.owner_type = 'store' AND c.id = a.owner_id LEFT JOIN drivers d ON a.owner_type = 'driver' AND d.id = a.owner_id WHERE a.status = 'pending' ORDER BY a.id DESC LIMIT 200`);
      return ok(res, { counts: Object.fromEntries(counts.map((r) => [r.status, r.n])), pending });
    })],
  ];
}
