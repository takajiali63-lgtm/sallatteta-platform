// v8.3 AI Operations Manager API. Every subscriber endpoint checks the AI entitlement first (403 ai_not_subscribed for
// BASIC, 403 ai_disabled when the owner switched AI off) — whatever the body contains, even a tool name.
// Turning AI off never touches ordinary order processing: nothing in the order routes depends on this module.
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator } from '../lib/validate.js';
import { assertClean } from '../lib/profanity.js';
import { RateLimiter } from '../lib/ratelimit.js';
import { makeGuards } from '../lib/guards.js';
import { requireAi, checkAi, getAiConfig, saveAiConfig, CATEGORIES, ownerInfo } from '../services/ai/entitlement.js';
import { getSettings, updateSettings, permsFor, allowedLevels, GROUPS, LEVELS } from '../services/ai/permissions.js';
import { createAiRuntime, usageCost, monthKey } from '../services/ai/runner.js';
import { createProvider, providerInfo } from '../services/ai/provider.js';
import { toolsFor } from '../services/ai/tools.js';
import { listContacts, correctContact, deleteContact, contactsCsv, customerOptOut, customerDelete } from '../services/ai/crm.js';
import { placeCall } from '../services/ai/channels/telephony.js';
import { sendMarketing } from '../services/ai/channels/marketing.js';

const ok = (res, data = {}, status = 200) => sendJson(res, status, { ok: true, ...data });
const parse = (s) => { try { return JSON.parse(s); } catch { return null; } };
const q = (req) => new URL(req.url, 'http://x').searchParams;

export function aiRoutes(ctx) {
  const { db, cfg, limiters = {}, push = null } = ctx;
  const { store, driver, customer, owner, limit, sessions } = makeGuards(ctx);
  const provider = createProvider({ impl: cfg.aiProviderImpl || null });
  const ai = createAiRuntime({ db, push, provider, log: cfg.quiet ? {} : console });
  // AI limiters share the app's rate-limit store (memory / Postgres / Redis), like the others
  const rlStore = limiters.contact?.store;
  const scale = cfg.rateLimitScale || 1;
  const L = (name, windowMs, max) => (rlStore ? new RateLimiter({ name, windowMs, max: max * scale, store: rlStore, log: cfg.quiet ? {} : console }) : null);
  const aiLimit = L('ai-chat', 60_000, cfg.aiChatLimit ?? 30);
  const aiCustLimit = L('ai-cust', 10 * 60_000, cfg.aiCustomerLimit ?? 15);
  const aiStoreLimit = L('ai-store', 60_000, cfg.aiStoreLimit ?? 60);

  /** Store OR driver (?as=driver|store when one phone has both sessions). Passes { type, id }. */
  const subscriber = (fn) => async (req, res, m) => {
    const as = q(req).get('as');
    let type = as === 'driver' || as === 'store' ? as : null;
    if (!type) type = (await sessions.store.ownerId(req).catch(() => null)) ? 'store' : (await sessions.driver.ownerId(req).catch(() => null)) ? 'driver' : null;
    if (!type) throw new HttpError(401, 'unauthorized');
    const guard = type === 'store' ? store : driver;
    return guard((rq, rs, mm, id) => fn(rq, rs, mm, { type, id }))(req, res, m);
  };
  /** subscriber + the AI entitlement → fn(req, res, m, owner, config) */
  const withAi = (fn) => subscriber(async (req, res, m, who) => {
    const { owner: o, config } = await requireAi(db, who.type, who.id);
    return fn(req, res, m, o, config);
  });

  const settingsView = async (o) => {
    const st = await getSettings(db, o.type, o.id, o.category);
    const tools = toolsFor(o.category);
    const perms = permsFor(o.category).map((p) => ({ key: p.key, group: p.group, risk: p.risk, kind: p.kind, level: st.levels[p.key], allowed: allowedLevels(p),
      descKey: `ai.perm.${p.key}`, desc: p.desc, tools: tools.filter((t) => t.permission === p.key).map((t) => t.name) }));
    return { enabled: st.enabled, category: o.category, levels: LEVELS, groups: GROUPS.map((g) => ({ key: g, perms: perms.filter((p) => p.group === g) })).filter((g) => g.perms.length), priceUnaffected: true };
  };

  return [
    // ---------- subscriber: settings ----------
    ['GET', /^\/api\/ai\/settings$/, withAi(async (req, res, m, o) => ok(res, await settingsView(o)))],
    ['PUT', /^\/api\/ai\/settings$/, withAi(async (req, res, m, o) => {
      const b = await readJson(req);
      await updateSettings(db, o.type, o.id, o.category, { enabled: b.enabled, perms: b.perms }, `${o.type}:${o.id}`);
      return ok(res, await settingsView(o));
    })],

    // ---------- subscriber: the manager chat ----------
    ['POST', /^\/api\/ai\/manager\/chat$/, withAi(async (req, res, m, o, config) => {
      await limit(aiLimit, `${o.type}${o.id}`);
      const b = await readJson(req);
      const v = new Validator();
      const message = v.text('message', b.message, { min: 1, max: 1000, multiline: true });
      v.assert();
      // fields like "tool" / "tools" / "args" in the body are ignored: the client can never pick a tool
      const out = await ai.runTurn({ owner: o, config, actor: 'subscriber', message });
      return ok(res, { ...out, voice: b.voice === true });
    })],

    // ---------- subscriber: approvals ----------
    ['GET', /^\/api\/ai\/approvals$/, withAi(async (req, res, m, o) => {
      const rows = await db.query(`SELECT id, tool, args, reason, status, result, decided_at, created_at FROM ai_approvals WHERE owner_type = $1 AND owner_id = $2
        ORDER BY CASE WHEN status = 'pending' THEN 0 ELSE 1 END, id DESC LIMIT 100`, [o.type, o.id]);
      const tasks = await db.query(`SELECT id, kind, ref, result AS reason, created_at FROM ai_tasks WHERE owner_type = $1 AND owner_id = $2 AND kind = 'human' AND status = 'open' ORDER BY id DESC LIMIT 50`, [o.type, o.id]);
      return ok(res, { approvals: rows.map((r) => ({ ...r, args: parse(r.args), result: parse(r.result) })), tasks });
    })],
    ['POST', /^\/api\/ai\/approvals\/(\d+)\/(approve|reject)$/, withAi(async (req, res, m, o) => {
      const id = Number(m[1]);
      return ok(res, m[2] === 'approve' ? await ai.approve(o, id) : await ai.reject(o, id));
    })],
    ['POST', /^\/api\/ai\/tasks\/(\d+)\/close$/, withAi(async (req, res, m, o) => {
      const r = await db.query(`UPDATE ai_tasks SET status = 'closed', updated_at = $1 WHERE id = $2 AND owner_type = $3 AND owner_id = $4 AND kind = 'human' AND status = 'open' RETURNING id`, [new Date().toISOString(), Number(m[1]), o.type, o.id]);
      if (!r.length) throw new HttpError(404, 'not_found');
      return ok(res);
    })],

    // ---------- subscriber: audit log, reports, usage ----------
    ['GET', /^\/api\/ai\/actions$/, withAi(async (req, res, m, o) => {
      const n = Math.min(200, Math.max(1, Number(q(req).get('limit')) || 50));
      return ok(res, { actions: await db.query(`SELECT id, actor, tool, risk, args_summary, result_summary, decision, approval_id, created_at FROM ai_actions WHERE owner_type = $1 AND owner_id = $2 ORDER BY id DESC LIMIT ${n}`, [o.type, o.id]) });
    })],
    ['GET', /^\/api\/ai\/reports$/, withAi(async (req, res, m, o) => {
      const rows = await db.query('SELECT id, period, period_key, data, created_at FROM ai_reports WHERE owner_type = $1 AND owner_id = $2 ORDER BY period_key DESC, id DESC LIMIT 60', [o.type, o.id]);
      return ok(res, { reports: rows.map((r) => ({ ...r, data: parse(r.data) })) });
    })],
    ['GET', /^\/api\/ai\/usage$/, withAi(async (req, res, m, o, config) => ok(res, { usage: await ai.usage(o, config) }))],

    // ---------- subscriber: voice (speech-to-text / text-to-speech run in the phone's browser; only seconds come here) ----------
    ['POST', /^\/api\/ai\/voice\/session$/, withAi(async (req, res, m, o, config) => ok(res, await ai.voiceStart(o, config), 201))],
    ['POST', /^\/api\/ai\/voice\/session\/(\d+)\/heartbeat$/, withAi(async (req, res, m, o, config) => {
      const b = await readJson(req);
      const v = new Validator();
      const seconds = v.int('seconds', b.seconds ?? 0, { min: 0, max: 120 });
      v.assert();
      return ok(res, await ai.voiceBeat(o, config, Number(m[1]), seconds));
    })],
    ['POST', /^\/api\/ai\/voice\/session\/(\d+)\/end$/, withAi(async (req, res, m, o) => ok(res, await ai.voiceEnd(o, Number(m[1]))))],

    // ---------- subscriber: CRM (own contacts only) ----------
    ['GET', /^\/api\/ai\/crm\/contacts$/, withAi(async (req, res, m, o) => ok(res, { contacts: await listContacts(db, o) }))],
    ['PUT', /^\/api\/ai\/crm\/contacts\/(\d+)$/, withAi(async (req, res, m, o) => {
      const b = await readJson(req);
      const v = new Validator();
      const name = v.text('name', b.name, { min: 2, max: 80 });
      v.assert();
      assertClean(HttpError, { name });
      return ok(res, await correctContact(db, o, Number(m[1]), name));
    })],
    ['DELETE', /^\/api\/ai\/crm\/contacts\/(\d+)$/, withAi(async (req, res, m, o) => ok(res, await deleteContact(db, o, Number(m[1]))))],
    ['GET', /^\/api\/ai\/crm\/export$/, withAi(async (req, res, m, o) => {
      const body = Buffer.from(contactsCsv(await listContacts(db, o)));
      await db.query(`INSERT INTO crm_events (owner_type, owner_id, customer_id, kind, details) VALUES ($1,$2,NULL,'export',NULL)`, [o.type, o.id]);
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="contacts.csv"', 'Cache-Control': 'no-store', 'Content-Length': body.length });
      return res.end(body);
    })],

    // ---------- subscriber: future channels (disabled → 409 channel_disabled) ----------
    ['POST', /^\/api\/ai\/channels\/phone\/call$/, withAi(async (req, res, m, o) => { await readJson(req); return ok(res, await placeCall({ db, owner: o })); })],
    ['POST', /^\/api\/ai\/channels\/marketing\/send$/, withAi(async (req, res, m, o) => { await readJson(req); return ok(res, await sendMarketing({ db, owner: o })); })],

    // ---------- customer: the business's customer-service assistant (read-only, own orders only) ----------
    ['POST', /^\/api\/ai\/store\/(\d+)\/chat$/, customer(async (req, res, m, customerId) => {
      const storeId = Number(m[1]);
      await limit(aiCustLimit, `c${customerId}:${storeId}`);
      await limit(aiStoreLimit, `s${storeId}`);
      const st = await db.one(`SELECT id FROM cooks WHERE id = $1 AND status = 'approved' AND COALESCE(suspended, 0) = 0`, [storeId]);
      if (!st) throw new HttpError(404, 'not_found');
      const { owner: o, config } = await requireAi(db, 'store', storeId);
      const b = await readJson(req);
      const v = new Validator();
      const message = v.text('message', b.message, { min: 1, max: 500, multiline: true });
      v.assert();
      const out = await ai.runTurn({ owner: o, config, actor: 'customer', customerId, message });
      return ok(res, { reply: out.reply, lang: out.lang });
    })],
    // does this store offer the assistant? (lets the app show the button; no details leak)
    ['GET', /^\/api\/ai\/store\/(\d+)\/assistant$/, async (req, res, m) => {
      const r = await checkAi(db, 'store', Number(m[1]));
      if (!r.ok) return ok(res, { available: false });
      const s = await getSettings(db, 'store', r.owner.id, r.owner.category);
      return ok(res, { available: s.enabled && (s.levels.cs_assistant || 'OFF') !== 'OFF' });
    }],
    // the customer's privacy choices (always available, AI or not)
    ['POST', /^\/api\/ai\/crm\/opt-out$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      const v = new Validator();
      const ownerType = v.oneOf('ownerType', b.ownerType, ['store', 'driver']);
      const ownerId = v.int('ownerId', b.ownerId, { min: 1 });
      v.assert();
      if (!(await ownerInfo(db, ownerType, ownerId))) throw new HttpError(404, 'not_found');
      return ok(res, await customerOptOut(db, customerId, { type: ownerType, id: ownerId }));
    })],
    ['POST', /^\/api\/ai\/crm\/forget$/, customer(async (req, res, m, customerId) => {
      const b = await readJson(req);
      if (b.ownerType == null) return ok(res, await customerDelete(db, customerId, null));
      const v = new Validator();
      const ownerType = v.oneOf('ownerType', b.ownerType, ['store', 'driver']);
      const ownerId = v.int('ownerId', b.ownerId, { min: 1 });
      v.assert();
      return ok(res, await customerDelete(db, customerId, { type: ownerType, id: ownerId }));
    })],

    // ---------- owner (admin panel) ----------
    ['GET', /^\/api\/admin\/ai\/config$/, owner(async (req, res) => ok(res, { config: await getAiConfig(db), provider: providerInfo(process.env, provider), categories: CATEGORIES }))],
    ['PUT', /^\/api\/admin\/ai\/config$/, owner(async (req, res, m, a) => {
      const b = await readJson(req);
      const before = await getAiConfig(db);
      const next = JSON.parse(JSON.stringify(before));
      const bad = {};
      const int = (v, max) => Number.isInteger(v) && v >= 0 && v <= max;
      if (b.enabled !== undefined) { if (typeof b.enabled === 'boolean') next.enabled = b.enabled; else bad.enabled = 'invalid'; }
      for (const c of CATEGORIES) {
        if (b.categories?.[c] !== undefined) { if (typeof b.categories[c] === 'boolean') next.categories[c] = b.categories[c]; else bad[`categories.${c}`] = 'invalid'; }
        for (const k of ['messages', 'voiceMinutes']) {
          const v = b.limits?.[c]?.[k];
          if (v !== undefined) { if (int(v, 1_000_000)) next.limits[c][k] = v; else bad[`limits.${c}.${k}`] = 'invalid'; }
        }
      }
      for (const k of Object.keys(next.costs)) { const v = b.costs?.[k]; if (v !== undefined) { if (int(v, 1_000_000)) next.costs[k] = v; else bad[`costs.${k}`] = 'invalid'; } }
      for (const k of Object.keys(next.workflow)) { const v = b.workflow?.[k]; if (v !== undefined) { if (int(v, 10_000) && v >= 1) next.workflow[k] = v; else bad[`workflow.${k}`] = 'invalid'; } }
      for (const k of Object.keys(next.channels)) { const v = b.channels?.[k]?.monthlySpendLimitCents; if (v !== undefined) { if (int(v, 100_000_000)) next.channels[k].monthlySpendLimitCents = v; else bad[`channels.${k}`] = 'invalid'; } }
      if (Object.keys(bad).length) throw new HttpError(422, 'validation_failed', { fields: bad });
      const saved = await saveAiConfig(db, next);
      await db.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1, NULL, $2, $3)', [a.id, 'ai_config', JSON.stringify({ before: { enabled: before.enabled, categories: before.categories }, after: { enabled: saved.enabled, categories: saved.categories } }).slice(0, 1000)]);
      return ok(res, { config: saved });
    })],
    ['GET', /^\/api\/admin\/ai\/usage$/, owner(async (req, res) => {
      const month = /^\d{4}-\d{2}$/.test(q(req).get('month') || '') ? q(req).get('month') : monthKey();
      const config = await getAiConfig(db);
      const rows = await db.query(`SELECT u.*, CASE WHEN u.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name
        FROM ai_usage u LEFT JOIN cooks c ON u.owner_type = 'store' AND c.id = u.owner_id LEFT JOIN drivers d ON u.owner_type = 'driver' AND d.id = u.owner_id
        WHERE u.month = $1 ORDER BY u.messages DESC LIMIT 1000`, [month]);
      const subs = rows.map((u) => ({ ownerType: u.owner_type, ownerId: u.owner_id, name: u.name, category: u.category, messages: u.messages, toolCalls: u.tool_calls, tokensIn: u.tokens_in, tokensOut: u.tokens_out, voiceSeconds: u.voice_seconds, costCents: usageCost(u, config.costs) }));
      const byCategory = Object.fromEntries(CATEGORIES.map((c) => [c, subs.filter((s) => s.category === c).reduce((a, s) => ({ subscribers: a.subscribers + 1, messages: a.messages + s.messages, voiceSeconds: a.voiceSeconds + s.voiceSeconds, costCents: a.costCents + s.costCents }), { subscribers: 0, messages: 0, voiceSeconds: 0, costCents: 0 })]));
      return ok(res, { month, subscribers: subs, byCategory, totalCents: subs.reduce((a, s) => a + s.costCents, 0) });
    })],
    ['GET', /^\/api\/admin\/ai\/actions$/, owner(async (req, res) => ok(res, { actions: await db.query(`SELECT a.*, CASE WHEN a.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name FROM ai_actions a
      LEFT JOIN cooks c ON a.owner_type = 'store' AND c.id = a.owner_id LEFT JOIN drivers d ON a.owner_type = 'driver' AND d.id = a.owner_id ORDER BY a.id DESC LIMIT 300`) }))],
    ['GET', /^\/api\/admin\/ai\/approvals$/, owner(async (req, res) => {
      const counts = await db.query(`SELECT status, CAST(COUNT(*) AS INTEGER) AS n FROM ai_approvals GROUP BY status`);
      const pending = await db.query(`SELECT a.id, a.owner_type, a.owner_id, a.tool, a.reason, a.created_at, CASE WHEN a.owner_type = 'store' THEN c.full_name ELSE d.full_name END AS name FROM ai_approvals a
        LEFT JOIN cooks c ON a.owner_type = 'store' AND c.id = a.owner_id LEFT JOIN drivers d ON a.owner_type = 'driver' AND d.id = a.owner_id WHERE a.status = 'pending' ORDER BY a.id DESC LIMIT 200`);
      return ok(res, { counts: Object.fromEntries(counts.map((r) => [r.status, r.n])), pending });
    })],
  ];
}
