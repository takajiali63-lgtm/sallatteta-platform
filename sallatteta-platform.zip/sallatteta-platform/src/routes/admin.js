import { HttpError, readJson, sendJson, parseCookies } from '../lib/http.js';
import { Validator, validatePhoto } from '../lib/validate.js';
import { roundTo } from '../lib/geo.js';
import { normalizePhone } from '../lib/whatsapp.js';
import { hashPassword, verifyPassword, randomToken, sha256, clientIp } from '../lib/security.js';
import {
  effectiveStatus, setCookServices, logAdminAction, latestSubscription, activateSubscription,
  renewSubscription, setSubscriptionStatus, updateSubscriptionFields, PLAN_KEYS, PAYMENT_STATUSES, SUBSCRIPTION_STATUSES,
} from '../services/cooks.js';
import { SERVICE_TYPES } from '../db/seed-data.js';
import { sendPhoto } from './public.js';

const COOKIE = 'st_admin';
const SESSION_HOURS = 12;

export async function createAdminUser(db, username, password) {
  if (!/^[A-Za-z0-9_.\-]{3,40}$/.test(username || '')) throw new Error('Username: 3-40 chars, letters/digits/._-');
  if (String(password || '').length < 10) throw new Error('Password must be at least 10 characters');
  const hash = await hashPassword(password);
  const existing = await db.one('SELECT id FROM admin_users WHERE username = $1', [username]);
  if (existing) {
    await db.query('UPDATE admin_users SET password_hash = $1 WHERE id = $2', [hash, existing.id]);
    await db.query('DELETE FROM admin_sessions WHERE admin_id = $1', [existing.id]);
    return { id: existing.id, updated: true };
  }
  const row = await db.one('INSERT INTO admin_users (username, password_hash) VALUES ($1,$2) RETURNING id', [username, hash]);
  return { id: row.id, updated: false };
}

export function adminRoutes({ db, cfg, limiters }) {
  const cookieAttrs = `Path=/; HttpOnly; SameSite=Strict${cfg.isProd ? '; Secure' : ''}`;

  async function currentAdmin(req) {
    const token = parseCookies(req.headers.cookie)[COOKIE];
    if (!token) return null;
    return db.one(
      `SELECT u.id, u.username FROM admin_sessions s JOIN admin_users u ON u.id = s.admin_id
       WHERE s.token_hash = $1 AND s.expires_at > $2`, [sha256(token), new Date().toISOString()]);
  }

  // CSRF defence for state-changing calls: SameSite=Strict cookie + custom header + Origin check.
  function checkCsrf(req) {
    if (req.headers['x-requested-with'] !== 'fetch') throw new HttpError(403, 'csrf');
    const origin = req.headers.origin;
    if (origin) {
      const host = req.headers['x-forwarded-host'] || req.headers.host;
      try { if (new URL(origin).host !== host) throw new Error(); } catch { throw new HttpError(403, 'csrf'); }
    }
  }

  // Wraps handlers that need a logged-in admin.
  const guard = (fn) => async (req, res, m) => {
    const admin = await currentAdmin(req);
    if (!admin) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    return fn(req, res, m, admin);
  };

  async function loadCook(id) {
    const cook = await db.one(
      `SELECT c.id, c.full_name, c.whatsapp, c.area_id, c.area_label, c.lat, c.lng, c.service_radius_km, c.bio,
         c.requested_plan, c.status, c.admin_notes, c.created_at, c.updated_at,
         CASE WHEN c.photo IS NULL THEN 0 ELSE 1 END AS has_photo
       FROM cooks c WHERE c.id = $1`, [id]);
    if (!cook) throw new HttpError(404, 'not_found');
    const services = (await db.query(
      `SELECT st.key FROM cook_service_types cst JOIN service_types st ON st.id = cst.service_type_id
       WHERE cst.cook_id = $1 ORDER BY st.sort_order`, [id])).map((r) => r.key);
    const sub = await latestSubscription(db, id);
    const stats = await db.one(
      `SELECT (SELECT CAST(COUNT(*) AS INTEGER) FROM request_impressions WHERE cook_id = $1) AS impressions,
              (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events WHERE cook_id = $1) AS whatsapp_clicks`, [id]);
    return { ...cook, services, subscription: sub, effectiveStatus: effectiveStatus(cook, sub), stats };
  }

  function readCookFields(body, v, { partial }) {
    const out = {};
    const req = !partial;
    if (!partial || body.fullName !== undefined) out.full_name = v.text('fullName', body.fullName, { min: 2, max: 80, required: req || true });
    if (!partial || body.whatsapp !== undefined) {
      const raw = v.text('whatsapp', body.whatsapp, { min: 6, max: 25 });
      out.whatsapp = raw ? normalizePhone(raw, cfg.defaultCountryCode) : undefined;
      if (raw && !out.whatsapp) v.fail('whatsapp', 'invalid_phone');
    }
    if (!partial || body.areaId !== undefined) out.area_id = v.int('areaId', body.areaId, { min: 1 });
    if (body.lat !== undefined && body.lat !== null && body.lat !== '') out.lat = v.number('lat', body.lat, { min: -90, max: 90 });
    if (body.lng !== undefined && body.lng !== null && body.lng !== '') out.lng = v.number('lng', body.lng, { min: -180, max: 180 });
    if (!partial || body.radiusKm !== undefined) out.service_radius_km = v.number('radiusKm', body.radiusKm, { min: 1, max: cfg.maxServiceRadiusKm });
    if (body.bio !== undefined) out.bio = v.text('bio', body.bio, { max: 300, required: false, multiline: true });
    if (body.adminNotes !== undefined) out.admin_notes = v.text('adminNotes', body.adminNotes, { max: 1000, required: false, multiline: true });
    if (body.photo !== undefined) out.photo = validatePhoto(body.photo, v);
    if (!partial || body.services !== undefined) {
      const s = Array.isArray(body.services) ? [...new Set(body.services)].filter((x) => SERVICE_TYPES.includes(x)) : [];
      if (!s.length) v.fail('services', 'required');
      out.services = s;
    }
    return out;
  }

  async function applyArea(fields) {
    if (fields.area_id) {
      const area = await db.one('SELECT id, name_ar, lat, lng FROM service_areas WHERE id = $1', [fields.area_id]);
      if (!area) throw new HttpError(422, 'validation_failed', { fields: { areaId: 'invalid' } });
      fields.area_label = area.name_ar;
      if (fields.lat === undefined) fields.lat = area.lat;
      if (fields.lng === undefined) fields.lng = area.lng;
    }
    if (fields.lat !== undefined) fields.lat = roundTo(fields.lat, 4);
    if (fields.lng !== undefined) fields.lng = roundTo(fields.lng, 4);
  }

  function readSubFields(body, v, { requirePlan = true } = {}) {
    return {
      plan: v.oneOf('plan', body.plan, PLAN_KEYS, { required: requirePlan }),
      startDate: v.date('startDate', body.startDate, { required: false }),
      expiryDate: v.date('expiryDate', body.expiryDate, { required: false }),
      paymentStatus: v.oneOf('paymentStatus', body.paymentStatus, PAYMENT_STATUSES, { required: false }),
    };
  }

  const subError = (e) => {
    if (e.code === 'expiry_before_start') throw new HttpError(422, 'validation_failed', { fields: { expiryDate: 'expiry_before_start' } });
    throw e;
  };

  return [
    ['POST', /^\/api\/admin\/login$/, async (req, res) => {
      const r = limiters.login.take(clientIp(req, cfg.trustProxy));
      if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
      checkCsrf(req);
      const body = await readJson(req, 4 * 1024);
      const user = await db.one('SELECT id, password_hash FROM admin_users WHERE username = $1', [String(body.username || '').trim()]);
      // Always run a hash comparison to keep timing similar for unknown users.
      const ok = await verifyPassword(body.password || '', user?.password_hash || 'scrypt$16384$8$1$AAAA$AAAA');
      if (!user || !ok) throw new HttpError(401, 'invalid_credentials');
      const token = randomToken(32);
      const expires = new Date(Date.now() + SESSION_HOURS * 3600_000);
      await db.query('INSERT INTO admin_sessions (admin_id, token_hash, expires_at) VALUES ($1,$2,$3)', [user.id, sha256(token), expires.toISOString()]);
      await db.query('UPDATE admin_users SET last_login_at = $1 WHERE id = $2', [new Date().toISOString(), user.id]);
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': `${COOKIE}=${token}; ${cookieAttrs}; Max-Age=${SESSION_HOURS * 3600}` });
    }],

    ['POST', /^\/api\/admin\/logout$/, async (req, res) => {
      checkCsrf(req);
      const token = parseCookies(req.headers.cookie)[COOKIE];
      if (token) await db.query('DELETE FROM admin_sessions WHERE token_hash = $1', [sha256(token)]);
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': `${COOKIE}=; ${cookieAttrs}; Max-Age=0` });
    }],

    ['GET', /^\/api\/admin\/me$/, guard(async (req, res, m, admin) => {
      sendJson(res, 200, { username: admin.username, adminWhatsappConfigured: !!cfg.adminWhatsapp });
    })],

    ['GET', /^\/api\/admin\/stats$/, guard(async (req, res) => {
      const since = new Date(Date.now() - 30 * 86400_000).toISOString();
      const now = new Date().toISOString();
      const s = await db.one(
        `SELECT
          (SELECT CAST(COUNT(*) AS INTEGER) FROM requests WHERE created_at >= $1) AS searches_30d,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM requests) AS searches_total,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events WHERE created_at >= $1) AS whatsapp_clicks_30d,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events) AS whatsapp_clicks_total,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM requests WHERE created_at >= $1 AND results_count = 0) AS empty_searches_30d,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM cooks c WHERE c.status = 'approved' AND EXISTS (SELECT 1 FROM subscriptions s
             WHERE s.cook_id = c.id AND s.status = 'active' AND s.start_date <= $2 AND s.expiry_date > $2)) AS active_cooks,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM cooks WHERE status = 'pending') AS pending_applications`, [since, now]);
      sendJson(res, 200, s);
    })],

    ['GET', /^\/api\/admin\/cooks$/, guard(async (req, res) => {
      const url = new URL(req.url, 'http://x');
      const filter = url.searchParams.get('filter') || 'all';
      const q = (url.searchParams.get('q') || '').trim().toLowerCase();
      const rows = await db.query(
        `SELECT c.id, c.full_name, c.whatsapp, c.area_label, c.service_radius_km, c.status, c.created_at, c.requested_plan,
           s.id AS sub_id, s.plan, s.status AS sub_status, s.payment_status, s.start_date, s.expiry_date,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM request_impressions i WHERE i.cook_id = c.id) AS impressions,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events e WHERE e.cook_id = c.id) AS whatsapp_clicks
         FROM cooks c LEFT JOIN subscriptions s ON s.id = (SELECT MAX(id) FROM subscriptions WHERE cook_id = c.id)
         ORDER BY c.created_at DESC, c.id DESC`);
      const now = new Date();
      const list = rows.map((r) => {
        const sub = r.sub_id ? { status: r.sub_status, start_date: r.start_date, expiry_date: r.expiry_date } : null;
        return {
          id: r.id, fullName: r.full_name, whatsapp: r.whatsapp, area: r.area_label, radiusKm: r.service_radius_km,
          cookStatus: r.status, requestedPlan: r.requested_plan, createdAt: r.created_at,
          plan: r.plan, subscriptionStatus: r.sub_status, paymentStatus: r.payment_status,
          startDate: r.start_date, expiryDate: r.expiry_date,
          effectiveStatus: effectiveStatus(r, sub, now),
          impressions: r.impressions, whatsappClicks: r.whatsapp_clicks,
        };
      }).filter((c) => (filter === 'all' || c.effectiveStatus === filter))
        .filter((c) => !q || c.fullName.toLowerCase().includes(q) || c.whatsapp.includes(q.replace(/\D/g, '') || '§') || (c.area || '').includes(q));
      sendJson(res, 200, { cooks: list });
    })],

    ['GET', /^\/api\/admin\/cooks\/(\d+)$/, guard(async (req, res, m) => {
      sendJson(res, 200, await loadCook(Number(m[1])));
    })],

    ['GET', /^\/api\/admin\/cooks\/(\d+)\/photo$/, guard(async (req, res, m) => {
      sendPhoto(res, (await db.one('SELECT photo FROM cooks WHERE id = $1', [Number(m[1])]))?.photo);
    })],

    // Add a cook manually (optionally activating immediately).
    ['POST', /^\/api\/admin\/cooks$/, guard(async (req, res, m, admin) => {
      const body = await readJson(req, 256 * 1024);
      const v = new Validator();
      const f = readCookFields(body, v, { partial: false });
      const activate = body.activate ? readSubFields(body.activate, v) : null;
      v.assert();
      await applyArea(f);
      const id = await db.tx(async (q) => {
        const row = await q.one(
          `INSERT INTO cooks (full_name, whatsapp, area_id, area_label, lat, lng, service_radius_km, bio, photo, admin_notes, requested_plan, status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'approved') RETURNING id`,
          [f.full_name, f.whatsapp, f.area_id, f.area_label, f.lat, f.lng, f.service_radius_km, f.bio ?? null, f.photo ?? null,
            f.admin_notes ?? null, activate?.plan ?? null]);
        await setCookServices(q, row.id, f.services);
        return row.id;
      });
      if (activate) {
        await activateSubscription(db, id, { ...activate, paymentStatus: activate.paymentStatus || 'paid' }).catch(subError);
      }
      await logAdminAction(db, admin.id, id, 'create', { activate: !!activate });
      sendJson(res, 201, await loadCook(id));
    })],

    ['PATCH', /^\/api\/admin\/cooks\/(\d+)$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await loadCook(id);
      const body = await readJson(req, 256 * 1024);
      const v = new Validator();
      const f = readCookFields(body, v, { partial: true });
      v.assert();
      await applyArea(f);
      const cols = ['full_name', 'whatsapp', 'area_id', 'area_label', 'lat', 'lng', 'service_radius_km', 'bio', 'photo', 'admin_notes']
        .filter((k) => f[k] !== undefined);
      if (cols.length) {
        const sets = cols.map((k, i) => `${k} = $${i + 1}`).join(', ');
        await db.query(`UPDATE cooks SET ${sets}, updated_at = $${cols.length + 1} WHERE id = $${cols.length + 2}`,
          [...cols.map((k) => f[k]), new Date().toISOString(), id]);
      }
      if (f.services) await setCookServices(db, id, f.services);
      await logAdminAction(db, admin.id, id, 'edit', { fields: [...cols, ...(f.services ? ['services'] : [])] });
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/(approve|reject)$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await loadCook(id);
      const status = m[2] === 'approve' ? 'approved' : 'rejected';
      await db.query('UPDATE cooks SET status = $1, updated_at = $2 WHERE id = $3', [status, new Date().toISOString(), id]);
      await logAdminAction(db, admin.id, id, m[2]);
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/subscription\/activate$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await loadCook(id);
      const body = await readJson(req);
      const v = new Validator();
      const s = readSubFields(body, v);
      v.assert();
      await activateSubscription(db, id, { ...s, paymentStatus: s.paymentStatus || 'paid' }).catch(subError);
      await logAdminAction(db, admin.id, id, 'activate', s);
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/subscription\/renew$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await loadCook(id);
      const body = await readJson(req);
      const v = new Validator();
      const plan = v.oneOf('plan', body.plan, PLAN_KEYS);
      const paymentStatus = v.oneOf('paymentStatus', body.paymentStatus, PAYMENT_STATUSES, { required: false });
      v.assert();
      await renewSubscription(db, id, { plan, paymentStatus: paymentStatus || 'paid' }).catch(subError);
      await logAdminAction(db, admin.id, id, 'renew', { plan });
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/subscription\/(suspend|expire)$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await loadCook(id);
      const status = m[2] === 'suspend' ? 'suspended' : 'expired';
      const sub = await setSubscriptionStatus(db, id, status);
      if (!sub) throw new HttpError(409, 'no_subscription');
      await logAdminAction(db, admin.id, id, m[2]);
      sendJson(res, 200, await loadCook(id));
    })],

    // Edit dates / plan / payment status of the current subscription directly.
    ['PATCH', /^\/api\/admin\/cooks\/(\d+)\/subscription$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await loadCook(id);
      const body = await readJson(req);
      const v = new Validator();
      const s = readSubFields(body, v, { requirePlan: false });
      s.status = v.oneOf('status', body.status, SUBSCRIPTION_STATUSES, { required: false }) ?? undefined;
      v.assert();
      const cur = await latestSubscription(db, id);
      if (!cur) throw new HttpError(409, 'no_subscription');
      const start = s.startDate || (cur.start_date && new Date(cur.start_date));
      const end = s.expiryDate || (cur.expiry_date && new Date(cur.expiry_date));
      if (start && end && end <= start) throw new HttpError(422, 'validation_failed', { fields: { expiryDate: 'expiry_before_start' } });
      await updateSubscriptionFields(db, id, {
        plan: s.plan ?? undefined, paymentStatus: s.paymentStatus ?? undefined,
        startDate: s.startDate ?? undefined, expiryDate: s.expiryDate ?? undefined, status: s.status,
      });
      await logAdminAction(db, admin.id, id, 'edit_subscription', body);
      sendJson(res, 200, await loadCook(id));
    })],

    ['GET', /^\/api\/admin\/areas$/, guard(async (req, res) => {
      sendJson(res, 200, { areas: await db.query('SELECT id, slug, name_ar, name_en, region, lat, lng, is_active FROM service_areas ORDER BY sort_order, id') });
    })],

    ['POST', /^\/api\/admin\/areas$/, guard(async (req, res) => {
      const body = await readJson(req);
      const v = new Validator();
      const nameAr = v.text('nameAr', body.nameAr, { min: 2, max: 60 });
      const nameEn = v.text('nameEn', body.nameEn, { max: 60, required: false });
      const lat = v.number('lat', body.lat, { min: -90, max: 90 });
      const lng = v.number('lng', body.lng, { min: -180, max: 180 });
      v.assert();
      const slug = `area-${Date.now().toString(36)}`;
      const row = await db.one(
        `INSERT INTO service_areas (slug, name_ar, name_en, name_fr, region, lat, lng, sort_order)
         VALUES ($1,$2,$3,$3,'custom',$4,$5,1000) RETURNING id`, [slug, nameAr, nameEn, lat, lng]);
      sendJson(res, 201, { id: row.id });
    })],
  ];
}
