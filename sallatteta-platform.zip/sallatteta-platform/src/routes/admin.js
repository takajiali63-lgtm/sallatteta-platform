import { randomInt } from 'node:crypto';
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, validatePhoto } from '../lib/validate.js';
import { roundTo } from '../lib/geo.js';
import { normalizePhone, buildWhatsAppLink, fillTemplate } from '../lib/whatsapp.js';
import { hashPassword, verifyPassword, clientIp } from '../lib/security.js';
import { sessionManager, checkCsrf, publicBaseUrl } from '../lib/sessions.js';
import { t } from '../lib/i18n.js';
import {
  effectiveStatus, setCookServices, setServedAreas, servedAreaIds, logAdminAction, latestSubscription, activateSubscription,
  renewSubscription, setSubscriptionStatus, updateSubscriptionFields, ratingsFor, cookStats,
  PLAN_KEYS, PAYMENT_STATUSES, SUBSCRIPTION_STATUSES,
} from '../services/cooks.js';
import { SERVICE_TYPES, DISTRICTS } from '../db/seed-data.js';
import { sendPhoto } from './public.js';

const DUMMY_HASH = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAA';

export async function createAdminUser(db, username, password) {
  const name = String(username || '').trim().toLowerCase();
  if (!/^[a-z0-9_.\-]{3,40}$/.test(name)) throw new Error('Username: 3-40 chars, letters/digits/._-');
  if (String(password || '').length < 10) throw new Error('Password must be at least 10 characters');
  const hash = await hashPassword(password);
  const existing = await db.one('SELECT id FROM admin_users WHERE LOWER(username) = $1', [name]);
  if (existing) {
    await db.query('UPDATE admin_users SET password_hash = $1 WHERE id = $2', [hash, existing.id]);
    await db.query('DELETE FROM admin_sessions WHERE admin_id = $1', [existing.id]);
    return { id: existing.id, updated: true };
  }
  const row = await db.one('INSERT INTO admin_users (username, password_hash) VALUES ($1,$2) RETURNING id', [name, hash]);
  return { id: row.id, updated: false };
}

// Easy to read aloud / type on a phone: no 0/O, 1/l/I.
function generatePassword() {
  const letters = 'abcdefghjkmnpqrstuvwxyz', digits = '23456789';
  let p = '';
  for (let i = 0; i < 4; i++) p += letters[randomInt(letters.length)];
  for (let i = 0; i < 4; i++) p += digits[randomInt(digits.length)];
  return p;
}

export function adminRoutes({ db, cfg, limiters, areas }) {
  const sessions = sessionManager({ db, cfg, table: 'admin_sessions', cookie: 'st_admin', ownerColumn: 'admin_id', hours: 12 });

  const guard = (fn) => async (req, res, m) => {
    const adminId = await sessions.ownerId(req);
    if (!adminId) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const admin = await db.one('SELECT id, username FROM admin_users WHERE id = $1', [adminId]);
    if (!admin) throw new HttpError(401, 'unauthorized');
    return fn(req, res, m, admin);
  };

  async function loadCook(id) {
    const cook = await db.one(
      `SELECT c.id, c.full_name, c.whatsapp, c.area_id, c.area_label, c.lat, c.lng, c.bio, c.service_radius_km, c.requested_plan, c.status, c.admin_notes,
         c.created_at, c.updated_at, CASE WHEN c.photo IS NULL THEN 0 ELSE 1 END AS has_photo,
         CASE WHEN c.password_hash IS NULL THEN 0 ELSE 1 END AS has_password
       FROM cooks c WHERE c.id = $1`, [id]);
    if (!cook) throw new HttpError(404, 'not_found');
    const services = (await db.query(
      `SELECT st.key FROM cook_service_types cst JOIN service_types st ON st.id = cst.service_type_id WHERE cst.cook_id = $1 ORDER BY st.sort_order`,
      [id])).map((r) => r.key);
    const sub = await latestSubscription(db, id);
    const served = (await servedAreaIds(db, id)).map((aid) => areas.view(areas.get(aid))).filter(Boolean);
    const warnings = await db.query('SELECT id, message, created_at FROM cook_warnings WHERE cook_id = $1 ORDER BY created_at DESC', [id]);
    const photos = await db.query('SELECT id, caption, is_hidden, created_at FROM cook_photos WHERE cook_id = $1 ORDER BY created_at DESC', [id]);
    const feedback = await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM feedback WHERE cook_id = $1`, [id]);
    const stats = await cookStats(db, id);
    return {
      ...cook,
      services,
      servedAreas: served,
      subscription: sub,
      effectiveStatus: effectiveStatus(cook, sub),
      stats: { ...stats, impressions: stats.impressions_total, whatsapp_clicks: stats.whatsapp_total },
      warnings,
      photos: photos.map((p) => ({ id: p.id, caption: p.caption || '', hidden: !!p.is_hidden, url: `/api/admin/photos/${p.id}.jpg` })),
      feedbackCount: feedback.n,
    };
  }

  function readCookFields(body, v, { partial }) {
    const out = {};
    if (!partial || body.fullName !== undefined) out.full_name = v.text('fullName', body.fullName, { min: 2, max: 80 });
    if (!partial || body.whatsapp !== undefined) {
      const raw = v.text('whatsapp', body.whatsapp, { min: 6, max: 25 });
      out.whatsapp = raw ? normalizePhone(raw, cfg.defaultCountryCode) : undefined;
      if (raw && !out.whatsapp) v.fail('whatsapp', 'invalid_phone');
    }
    if (!partial || body.areaId !== undefined) {
      const area = areas.get(body.areaId);
      if (!area) v.fail('areaId', body.areaId ? 'invalid' : 'required');
      else out.area = area;
    }
    if (body.lat !== undefined && body.lat !== null && body.lat !== '') out.lat = v.number('lat', body.lat, { min: -90, max: 90 });
    if (body.lng !== undefined && body.lng !== null && body.lng !== '') out.lng = v.number('lng', body.lng, { min: -180, max: 180 });
    if (body.bio !== undefined) out.bio = v.text('bio', body.bio, { max: 300, required: false, multiline: true });
    if (body.adminNotes !== undefined) out.admin_notes = v.text('adminNotes', body.adminNotes, { max: 1000, required: false, multiline: true });
    if (body.photo !== undefined) out.photo = validatePhoto(body.photo, v);
    if (!partial || body.services !== undefined) {
      const s = Array.isArray(body.services) ? [...new Set(body.services)].filter((x) => SERVICE_TYPES.includes(x)) : [];
      if (!s.length) v.fail('services', 'required');
      out.services = s;
    }
    if (!partial || body.servedAreaIds !== undefined) {
      const ids = Array.isArray(body.servedAreaIds) ? [...new Set(body.servedAreaIds.map(Number))].filter((id) => areas.get(id)) : [];
      if (!ids.length) v.fail('servedAreaIds', 'pick_one_area');
      out.servedAreaIds = ids;
    }
    return out;
  }

  /** Column values for the cooks table from validated fields. Moving her village moves her map point unless lat/lng given. */
  function cookColumns(f, current) {
    const cols = {};
    for (const k of ['full_name', 'whatsapp', 'bio', 'photo', 'admin_notes']) if (f[k] !== undefined) cols[k] = f[k];
    if (f.area) {
      cols.area_id = f.area.id;
      cols.area_label = f.area.name_ar;
      if (f.lat === undefined && (!current || current.area_id !== f.area.id)) { cols.lat = f.area.lat; cols.lng = f.area.lng; }
    }
    if (f.lat !== undefined) cols.lat = roundTo(f.lat, 4);
    if (f.lng !== undefined) cols.lng = roundTo(f.lng, 4);
    return cols;
  }

  function readSubFields(body, v, { requirePlan = true } = {}) {
    return {
      plan: v.oneOf('plan', body.plan, PLAN_KEYS, { required: requirePlan }),
      startDate: v.date('startDate', body.startDate, { required: false }),
      expiryDate: v.date('expiryDate', body.expiryDate, { required: false }),
      paymentStatus: v.oneOf('paymentStatus', body.paymentStatus, PAYMENT_STATUSES, { required: false }),
    };
  }
  const subError = (e) => {
    if (e.code === 'expiry_before_start') throw new HttpError(422, 'validation_failed', { fields: { expiryDate: 'expiry_before_start' } });
    throw e;
  };
  const ensureCook = async (id) => { if (!(await db.one('SELECT id FROM cooks WHERE id = $1', [id]))) throw new HttpError(404, 'not_found'); };

  return [
    ['POST', /^\/api\/admin\/login$/, async (req, res) => {
      const r = limiters.login.take('admin:' + clientIp(req, cfg.trustProxy));
      if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
      checkCsrf(req);
      const body = await readJson(req, 4 * 1024);
      const username = String(body.username || '').trim().toLowerCase().replace(/\s+/g, '.');
      const user = await db.one('SELECT id, password_hash FROM admin_users WHERE LOWER(username) = $1', [username]);
      const ok = await verifyPassword(String(body.password || ''), user?.password_hash || DUMMY_HASH);
      if (!user || !ok) throw new HttpError(401, 'invalid_credentials');
      await db.query('UPDATE admin_users SET last_login_at = $1 WHERE id = $2', [new Date().toISOString(), user.id]);
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.create(user.id) });
    }],

    ['POST', /^\/api\/admin\/logout$/, async (req, res) => {
      checkCsrf(req);
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.destroy(req) });
    }],

    ['GET', /^\/api\/admin\/me$/, guard(async (req, res, m, admin) => {
      sendJson(res, 200, { username: admin.username, adminWhatsappConfigured: !!cfg.adminWhatsapp });
    })],

    ['GET', /^\/api\/admin\/stats$/, guard(async (req, res) => {
      const since = new Date(Date.now() - 30 * 86400_000).toISOString();
      const now = new Date().toISOString();
      const s = await db.one(
        `SELECT
          (SELECT CAST(COUNT(*) AS INTEGER) FROM requests WHERE created_at >= $1) AS searches_30d,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM requests) AS searches_total,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events WHERE created_at >= $1) AS whatsapp_clicks_30d,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events) AS whatsapp_clicks_total,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM requests WHERE created_at >= $1 AND results_count = 0) AS empty_searches_30d,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM cooks c WHERE c.status = 'approved' AND EXISTS (SELECT 1 FROM subscriptions s
             WHERE s.cook_id = c.id AND s.status = 'active' AND s.start_date <= $2 AND s.expiry_date > $2)) AS active_cooks,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM cooks WHERE status = 'pending') AS pending_applications,
          (SELECT CAST(COUNT(*) AS INTEGER) FROM feedback WHERE status = 'new') AS new_feedback`, [since, now]);
      sendJson(res, 200, s);
    })],

    ['GET', /^\/api\/admin\/cooks$/, guard(async (req, res) => {
      const url = new URL(req.url, 'http://x');
      const filter = url.searchParams.get('filter') || 'all';
      const q = (url.searchParams.get('q') || '').trim().toLowerCase();
      const rows = await db.query(
        `SELECT c.id, c.full_name, c.whatsapp, c.area_label, c.status, c.created_at, c.requested_plan,
           s.id AS sub_id, s.plan, s.status AS sub_status, s.payment_status, s.start_date, s.expiry_date,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM request_impressions i WHERE i.cook_id = c.id) AS impressions,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM request_contact_events e WHERE e.cook_id = c.id) AS whatsapp_clicks,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM cook_warnings w WHERE w.cook_id = c.id) AS warnings,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM feedback f WHERE f.cook_id = c.id AND f.status = 'new') AS open_feedback
         FROM cooks c LEFT JOIN subscriptions s ON s.id = (SELECT MAX(id) FROM subscriptions WHERE cook_id = c.id)
         ORDER BY c.created_at DESC, c.id DESC`);
      const ratings = await ratingsFor(db, rows.map((r) => r.id));
      const now = new Date();
      const list = rows.map((r) => {
        const sub = r.sub_id ? { status: r.sub_status, start_date: r.start_date, expiry_date: r.expiry_date } : null;
        return {
          id: r.id, fullName: r.full_name, whatsapp: r.whatsapp, area: r.area_label,
          cookStatus: r.status, requestedPlan: r.requested_plan, createdAt: r.created_at,
          plan: r.plan, subscriptionStatus: r.sub_status, paymentStatus: r.payment_status,
          startDate: r.start_date, expiryDate: r.expiry_date,
          effectiveStatus: effectiveStatus(r, sub, now),
          impressions: r.impressions, whatsappClicks: r.whatsapp_clicks, warnings: r.warnings, openFeedback: r.open_feedback,
          rating: ratings.get(r.id),
        };
      }).filter((c) => (filter === 'all' || c.effectiveStatus === filter))
        .filter((c) => !q || c.fullName.toLowerCase().includes(q) || c.whatsapp.includes(q.replace(/\D/g, '') || '§') || (c.area || '').includes(q));
      sendJson(res, 200, { cooks: list });
    })],

    ['GET', /^\/api\/admin\/cooks\/(\d+)$/, guard(async (req, res, m) => {
      sendJson(res, 200, await loadCook(Number(m[1])));
    })],

    ['GET', /^\/api\/admin\/cooks\/(\d+)\/photo$/, guard(async (req, res, m) => {
      sendPhoto(res, (await db.one('SELECT photo FROM cooks WHERE id = $1', [Number(m[1])]))?.photo);
    })],

    ['POST', /^\/api\/admin\/cooks$/, guard(async (req, res, m, admin) => {
      const body = await readJson(req, 256 * 1024);
      const v = new Validator();
      const f = readCookFields(body, v, { partial: false });
      const activate = body.activate ? readSubFields(body.activate, v) : null;
      v.assert();
      const c = cookColumns(f, null);
      const id = await db.tx(async (q) => {
        const row = await q.one(
          `INSERT INTO cooks (full_name, whatsapp, area_id, area_label, lat, lng, service_radius_km, bio, photo, admin_notes, requested_plan, status)
           VALUES ($1,$2,$3,$4,$5,$6,$11,$7,$8,$9,$10,'approved') RETURNING id`,
          [c.full_name, c.whatsapp, c.area_id, c.area_label, c.lat, c.lng, c.bio ?? null, c.photo ?? null, c.admin_notes ?? null, activate?.plan ?? null, 0]);
        await setCookServices(q, row.id, f.services);
        await setServedAreas(q, row.id, f.servedAreaIds);
        return row.id;
      });
      if (activate) await activateSubscription(db, id, { ...activate, paymentStatus: activate.paymentStatus || 'paid' }).catch(subError);
      await logAdminAction(db, admin.id, id, 'create', { activate: !!activate });
      sendJson(res, 201, await loadCook(id));
    })],

    ['PATCH', /^\/api\/admin\/cooks\/(\d+)$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      const current = await loadCook(id);
      const body = await readJson(req, 256 * 1024);
      const v = new Validator();
      const f = readCookFields(body, v, { partial: true });
      v.assert();
      const cols = cookColumns(f, current);
      const keys = Object.keys(cols);
      if (keys.length) {
        await db.query(`UPDATE cooks SET ${keys.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${keys.length + 1} WHERE id = $${keys.length + 2}`,
          [...keys.map((k) => cols[k]), new Date().toISOString(), id]);
      }
      if (f.services) await setCookServices(db, id, f.services);
      if (f.servedAreaIds) await setServedAreas(db, id, f.servedAreaIds);
      await logAdminAction(db, admin.id, id, 'edit', { fields: [...keys, ...(f.services ? ['services'] : []), ...(f.servedAreaIds ? ['servedAreas'] : [])] });
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/(approve|reject)$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      await db.query('UPDATE cooks SET status = $1, updated_at = $2 WHERE id = $3', [m[2] === 'approve' ? 'approved' : 'rejected', new Date().toISOString(), id]);
      await logAdminAction(db, admin.id, id, m[2]);
      sendJson(res, 200, await loadCook(id));
    })],

    // Sets (or generates) the cook's password and returns a ready WhatsApp message with her login details.
    ['POST', /^\/api\/admin\/cooks\/(\d+)\/password$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      const body = await readJson(req, 2 * 1024);
      const password = body.password ? String(body.password) : generatePassword();
      if (password.length < 6 || password.length > 100) throw new HttpError(422, 'validation_failed', { fields: { password: 'password_too_short' } });
      await db.query('UPDATE cooks SET password_hash = $1 WHERE id = $2', [await hashPassword(password), id]);
      await db.query('DELETE FROM cook_sessions WHERE cook_id = $1', [id]);
      const cook = await db.one('SELECT full_name, whatsapp FROM cooks WHERE id = $1', [id]);
      const message = fillTemplate(t('ar', 'wa.cookLogin'), {
        name: cook.full_name, url: publicBaseUrl(req, cfg), phone: cook.whatsapp.replace(/^961/, '0'), password,
      });
      await logAdminAction(db, admin.id, id, 'set_password');
      sendJson(res, 200, { password, whatsappUrl: buildWhatsAppLink(cook.whatsapp, message) });
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/warnings$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      const body = await readJson(req, 8 * 1024);
      const v = new Validator();
      const message = v.text('message', body.message, { min: 3, max: 1500, multiline: true });
      const feedbackId = v.int('feedbackId', body.feedbackId, { min: 1, required: false });
      v.assert();
      await db.query('INSERT INTO cook_warnings (cook_id, admin_id, feedback_id, message) VALUES ($1,$2,$3,$4)', [id, admin.id, feedbackId, message]);
      if (feedbackId) await db.query(`UPDATE feedback SET status = 'resolved', updated_at = $1 WHERE id = $2 AND cook_id = $3`, [new Date().toISOString(), feedbackId, id]);
      const cook = await db.one('SELECT whatsapp FROM cooks WHERE id = $1', [id]);
      await logAdminAction(db, admin.id, id, 'warning', { feedbackId });
      sendJson(res, 201, { whatsappUrl: buildWhatsAppLink(cook.whatsapp, message), cook: await loadCook(id) });
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/subscription\/activate$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      const v = new Validator();
      const s = readSubFields(await readJson(req), v);
      v.assert();
      await activateSubscription(db, id, { ...s, paymentStatus: s.paymentStatus || 'paid' }).catch(subError);
      await logAdminAction(db, admin.id, id, 'activate', s);
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/subscription\/renew$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      const body = await readJson(req);
      const v = new Validator();
      const plan = v.oneOf('plan', body.plan, PLAN_KEYS);
      const paymentStatus = v.oneOf('paymentStatus', body.paymentStatus, PAYMENT_STATUSES, { required: false });
      v.assert();
      await renewSubscription(db, id, { plan, paymentStatus: paymentStatus || 'paid' }).catch(subError);
      await logAdminAction(db, admin.id, id, 'renew', { plan });
      sendJson(res, 200, await loadCook(id));
    })],

    ['POST', /^\/api\/admin\/cooks\/(\d+)\/subscription\/(suspend|expire)$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      if (!(await setSubscriptionStatus(db, id, m[2] === 'suspend' ? 'suspended' : 'expired'))) throw new HttpError(409, 'no_subscription');
      await logAdminAction(db, admin.id, id, m[2]);
      sendJson(res, 200, await loadCook(id));
    })],

    ['PATCH', /^\/api\/admin\/cooks\/(\d+)\/subscription$/, guard(async (req, res, m, admin) => {
      const id = Number(m[1]);
      await ensureCook(id);
      const body = await readJson(req);
      const v = new Validator();
      const s = readSubFields(body, v, { requirePlan: false });
      s.status = v.oneOf('status', body.status, SUBSCRIPTION_STATUSES, { required: false }) ?? undefined;
      v.assert();
      const cur = await latestSubscription(db, id);
      if (!cur) throw new HttpError(409, 'no_subscription');
      const start = s.startDate || (cur.start_date && new Date(cur.start_date));
      const end = s.expiryDate || (cur.expiry_date && new Date(cur.expiry_date));
      if (start && end && end <= start) throw new HttpError(422, 'validation_failed', { fields: { expiryDate: 'expiry_before_start' } });
      await updateSubscriptionFields(db, id, {
        plan: s.plan ?? undefined, paymentStatus: s.paymentStatus ?? undefined,
        startDate: s.startDate ?? undefined, expiryDate: s.expiryDate ?? undefined, status: s.status,
      });
      await logAdminAction(db, admin.id, id, 'edit_subscription', body);
      sendJson(res, 200, await loadCook(id));
    })],

    /* ---------- complaints & notes (admin only) ---------- */
    ['GET', /^\/api\/admin\/feedback$/, guard(async (req, res) => {
      const status = new URL(req.url, 'http://x').searchParams.get('status') || 'new';
      const rows = await db.query(
        `SELECT f.id, f.cook_id, c.full_name AS cook_name, c.whatsapp AS cook_whatsapp, f.kind, f.message, f.customer_name, f.customer_phone,
           f.status, f.admin_note, f.created_at,
           (SELECT CAST(COUNT(*) AS INTEGER) FROM cook_warnings w WHERE w.cook_id = f.cook_id) AS cook_warnings
         FROM feedback f JOIN cooks c ON c.id = f.cook_id
         ${status === 'all' ? '' : 'WHERE f.status = $1'} ORDER BY f.created_at DESC LIMIT 200`, status === 'all' ? [] : [status]);
      sendJson(res, 200, { feedback: rows });
    })],
    ['PATCH', /^\/api\/admin\/feedback\/(\d+)$/, guard(async (req, res, m) => {
      const body = await readJson(req, 4 * 1024);
      const v = new Validator();
      const status = v.oneOf('status', body.status, ['new', 'resolved'], { required: false });
      const note = v.text('adminNote', body.adminNote, { max: 1000, required: false, multiline: true });
      v.assert();
      const cur = await db.one('SELECT status, admin_note FROM feedback WHERE id = $1', [Number(m[1])]);
      if (!cur) throw new HttpError(404, 'not_found');
      await db.query('UPDATE feedback SET status = $1, admin_note = $2, updated_at = $3 WHERE id = $4',
        [status ?? cur.status, body.adminNote !== undefined ? note : cur.admin_note, new Date().toISOString(), Number(m[1])]);
      sendJson(res, 200, { ok: true });
    })],

    /* ---------- photos moderation ---------- */
    ['GET', /^\/api\/admin\/photos\/(\d+)\.jpg$/, guard(async (req, res, m) => {
      sendPhoto(res, (await db.one('SELECT data FROM cook_photos WHERE id = $1', [Number(m[1])]))?.data);
    })],
    ['DELETE', /^\/api\/admin\/photos\/(\d+)$/, guard(async (req, res, m, admin) => {
      const p = await db.one('SELECT cook_id FROM cook_photos WHERE id = $1', [Number(m[1])]);
      if (!p) throw new HttpError(404, 'not_found');
      await db.query('DELETE FROM cook_photos WHERE id = $1', [Number(m[1])]);
      await logAdminAction(db, admin.id, p.cook_id, 'delete_photo');
      sendJson(res, 200, await loadCook(p.cook_id));
    })],

    /* ---------- villages ---------- */
    ['POST', /^\/api\/admin\/areas$/, guard(async (req, res) => {
      const body = await readJson(req);
      const v = new Validator();
      const nameAr = v.text('nameAr', body.nameAr, { min: 2, max: 60 });
      const nameEn = v.text('nameEn', body.nameEn, { max: 60, required: false });
      const district = v.oneOf('district', body.district, Object.keys(DISTRICTS));
      let lat = v.number('lat', body.lat, { min: -90, max: 90, required: false });
      let lng = v.number('lng', body.lng, { min: -180, max: 180, required: false });
      v.assert();
      if (lat == null || lng == null) {
        // No coordinates given: use the district's first village as an approximate centre.
        const ref = areas.inDistrict(district)[0];
        const a = ref && areas.get(ref.id);
        if (!a) throw new HttpError(422, 'validation_failed', { fields: { lat: 'required' } });
        lat = a.lat; lng = a.lng;
      }
      const row = await db.one(
        `INSERT INTO service_areas (slug, name_ar, name_en, name_fr, region, district, lat, lng, sort_order)
         VALUES ($1,$2,$3,$3,$4,$4,$5,$6,1000) RETURNING id`, [`area-${Date.now().toString(36)}`, nameAr, nameEn, district, lat, lng]);
      await areas.load();
      sendJson(res, 201, { id: row.id });
    })],
  ];
}

