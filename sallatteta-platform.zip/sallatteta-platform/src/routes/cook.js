// The cook's own account: login with WhatsApp number + password, see her numbers, manage her page & photos.
// Complaints/notes about her are NEVER exposed here (admin only).
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, validatePhoto, imageBytesOk } from '../lib/validate.js';
import { normalizePhone } from '../lib/whatsapp.js';
import { hashPassword, verifyPassword, clientIp } from '../lib/security.js';
import { sessionManager, checkCsrf } from '../lib/sessions.js';
import { pickLocale } from '../lib/i18n.js';
import {
  cookStats, latestSubscription, effectiveStatus, serviceKeysFor, servedAreaIds, setServedAreas, setCookServices,
} from '../services/cooks.js';
import { isValidLatLng, roundTo } from '../lib/geo.js';
import { SERVICE_TYPES, MAX_PHOTOS_PER_COOK } from '../db/seed-data.js';
import { sendPhoto, redirect } from './public.js';

const DUMMY_HASH = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAA';

export function cookRoutes({ db, cfg, limiters, areas, images }) {
  const sessions = sessionManager({ db, cfg, table: 'cook_sessions', cookie: 'st_cook', ownerColumn: 'cook_id', hours: 24 * 60 });

  const guard = (fn) => async (req, res, m) => {
    const cookId = await sessions.ownerId(req);
    if (!cookId) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const cook = await db.one(`SELECT id, status FROM cooks WHERE id = $1`, [cookId]);
    if (!cook || cook.status === 'rejected') throw new HttpError(401, 'unauthorized');
    return fn(req, res, m, cookId);
  };

  async function me(cookId, locale) {
    const c = await db.one(
      `SELECT id, full_name, whatsapp, area_id, area_label, lat, lng, bio, status, photo_url, is_hidden, CASE WHEN photo IS NULL THEN 0 ELSE 1 END AS has_photo
       FROM cooks WHERE id = $1`, [cookId]);
    const sub = await latestSubscription(db, cookId);
    const photos = await db.query('SELECT id, caption, url, is_hidden, created_at FROM cook_photos WHERE cook_id = $1 ORDER BY created_at DESC, id DESC', [cookId]);
    return {
      id: c.id,
      name: c.full_name,
      whatsapp: c.whatsapp,
      area: { ...(areas.view(areas.get(c.area_id), locale) || {}), name: c.area_label || areas.get(c.area_id)?.name_ar },
      bio: c.bio || '',
      location: { lat: Number(c.lat), lng: Number(c.lng) },
      hidden: !!Number(c.is_hidden),
      photoUrl: c.photo_url || (Number(c.has_photo) ? `/api/cook/photo?ts=${Date.now()}` : null),
      profileUrl: `/c/${c.id}`,
      services: (await serviceKeysFor(db, [c.id])).get(c.id),
      servedAreas: (await servedAreaIds(db, c.id)).map((id) => areas.view(areas.get(id), locale)).filter(Boolean),
      subscription: sub ? { status: effectiveStatus(c, sub), plan: sub.plan, startDate: sub.start_date, expiryDate: sub.expiry_date } : null,
      stats: await cookStats(db, c.id),
      photos: photos.map((p) => ({ id: p.id, url: p.url || `/api/cook/photos/${p.id}.jpg`, caption: p.caption || '', hidden: !!p.is_hidden })),
      maxPhotos: MAX_PHOTOS_PER_COOK,
    };
  }

  return [
    ['POST', /^\/api\/cook\/login$/, async (req, res) => {
      const r = await limiters.login.take('cook:' + clientIp(req, cfg.trustProxy));
      if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
      checkCsrf(req);
      const body = await readJson(req, 2 * 1024);
      const phone = normalizePhone(body.whatsapp, cfg.defaultCountry);
      const cook = phone
        ? await db.one(`SELECT id, password_hash FROM cooks WHERE whatsapp = $1 AND status = 'approved' AND password_hash IS NOT NULL ORDER BY id DESC LIMIT 1`, [phone])
        : null;
      const ok = await verifyPassword(String(body.password || ''), cook?.password_hash || DUMMY_HASH);
      if (!cook || !ok) throw new HttpError(401, 'invalid_cook_credentials');
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.create(cook.id) });
    }],

    ['POST', /^\/api\/cook\/logout$/, async (req, res) => {
      checkCsrf(req);
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.destroy(req) });
    }],

    ['GET', /^\/api\/cook\/me$/, guard(async (req, res, m, cookId) => {
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    ['GET', /^\/api\/cook\/photo$/, guard(async (req, res, m, cookId) => {
      const c = await db.one('SELECT photo, photo_url FROM cooks WHERE id = $1', [cookId]);
      if (c?.photo_url) return redirect(res, c.photo_url);
      sendPhoto(res, c?.photo);
    })],

    // She can edit her description, profile photo, what she cooks and where she delivers.
    // Name and WhatsApp number are changed by the admin only.
    ['PATCH', /^\/api\/cook\/me$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 256 * 1024);
      const v = new Validator();
      const sets = {};
      if (body.bio !== undefined) sets.bio = v.text('bio', body.bio, { max: 300, required: false, multiline: true });
      let newPhoto;
      if (body.photo !== undefined) newPhoto = validatePhoto(body.photo, v) ?? null;
      if (body.lat !== undefined || body.lng !== undefined) {
        const lat = v.number('location', body.lat, { min: -90, max: 90 });
        const lng = v.number('location', body.lng, { min: -180, max: 180 });
        if (lat != null && lng != null && isValidLatLng(lat, lng)) {
          sets.lat = roundTo(lat, 4); sets.lng = roundTo(lng, 4);
          sets.area_id = areas.nearest(lat, lng).id;
        } else v.fail('location', 'invalid');
      }
      if (body.areaLabel !== undefined) sets.area_label = v.text('areaLabel', body.areaLabel, { max: 80, required: false }) || null;
      let services, served;
      if (body.services !== undefined) {
        services = Array.isArray(body.services) ? [...new Set(body.services)].filter((s) => SERVICE_TYPES.includes(s)) : [];
        if (!services.length) v.fail('services', 'required');
      }
      if (body.servedAreaIds !== undefined) {
        served = Array.isArray(body.servedAreaIds) ? [...new Set(body.servedAreaIds.map(Number))].filter((id) => areas.get(id)).slice(0, 300) : [];
        if (!served.length) v.fail('servedAreaIds', 'pick_one_area');
      }
      v.assert();
      if (newPhoto !== undefined) {
        const old = await db.one('SELECT photo_url FROM cooks WHERE id = $1', [cookId]);
        const img = await images.save(`cooks/${cookId}`, newPhoto);
        sets.photo = img.data; sets.photo_url = img.url;
        await images.remove(old?.photo_url);
      }
      const cols = Object.keys(sets);
      if (cols.length) {
        await db.query(`UPDATE cooks SET ${cols.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${cols.length + 1} WHERE id = $${cols.length + 2}`,
          [...cols.map((k) => sets[k]), new Date().toISOString(), cookId]);
      }
      if (services) await setCookServices(db, cookId, services);
      if (served) await setServedAreas(db, cookId, served);
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    ['POST', /^\/api\/cook\/password$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 2 * 1024);
      const row = await db.one('SELECT password_hash FROM cooks WHERE id = $1', [cookId]);
      if (!(await verifyPassword(String(body.current || ''), row.password_hash || DUMMY_HASH))) {
        throw new HttpError(422, 'validation_failed', { fields: { current: 'wrong_password' } });
      }
      const next = String(body.next || '');
      if (next.length < 6 || next.length > 100) throw new HttpError(422, 'validation_failed', { fields: { next: 'password_too_short' } });
      await db.query('UPDATE cooks SET password_hash = $1 WHERE id = $2', [await hashPassword(next), cookId]);
      sendJson(res, 200, { ok: true });
    })],

    ['POST', /^\/api\/cook\/photos$/, guard(async (req, res, m, cookId) => {
      const rl = await limiters.upload.take(`c${cookId}`);
      if (!rl.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: rl.retryAfterSec });
      const body = await readJson(req, 600 * 1024);
      const v = new Validator();
      const caption = v.text('caption', body.caption, { max: 80, required: false });
      const data = String(body.data || '');
      if (!imageBytesOk(data)) v.fail('data', 'invalid');
      else if (data.length > 550_000) v.fail('data', 'too_large');
      // optional small version for lists (made on the phone); only kept when images live on object storage
      const thumb = body.thumb && imageBytesOk(body.thumb) && String(body.thumb).length <= 120_000 ? String(body.thumb) : null;
      v.assert();
      const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM cook_photos WHERE cook_id = $1', [cookId]);
      if (n.n >= MAX_PHOTOS_PER_COOK) throw new HttpError(409, 'too_many_photos');
      const img = await images.save(`dishes/${cookId}`, data);
      const th = images.external && thumb ? await images.save(`dishes/${cookId}/thumbs`, thumb) : { url: null };
      await db.query('INSERT INTO cook_photos (cook_id, data, url, thumb_url, caption) VALUES ($1,$2,$3,$4,$5)', [cookId, img.data || '', img.url, th.url, caption]);
      sendJson(res, 201, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    ['GET', /^\/api\/cook\/photos\/(\d+)\.jpg$/, guard(async (req, res, m, cookId) => {
      const p = await db.one('SELECT data, url FROM cook_photos WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (p?.url) return redirect(res, p.url);
      sendPhoto(res, p?.data);
    })],

    ['DELETE', /^\/api\/cook\/photos\/(\d+)$/, guard(async (req, res, m, cookId) => {
      const p = await db.one('SELECT url, thumb_url FROM cook_photos WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      await db.query('DELETE FROM cook_photos WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      await images.remove(p?.url);
      await images.remove(p?.thumb_url);
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],
  ];
}
