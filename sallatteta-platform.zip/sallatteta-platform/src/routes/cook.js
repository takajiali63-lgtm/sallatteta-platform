// The cook's own account: login with WhatsApp number + password, see her numbers, manage her page & photos.
// Complaints/notes about her are NEVER exposed here (admin only).
import { assertClean } from '../lib/profanity.js';
import { limitsFor } from '../services/catplans.js';
import { readSheet, checkRows, planImport, applyImport, templateCsv, matchPhoto } from '../services/bulkmenu.js';
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, validatePhoto, imageBytesOk } from '../lib/validate.js';
import { normalizePhone } from '../lib/whatsapp.js';
import { hashPassword, verifyPassword, clientIp, hmacHex } from '../lib/security.js';
import { normalizeName } from '../../public/assets/normalize.js';
import { cleanHours } from '../lib/hours.js';
import { sessionManager, checkCsrf } from '../lib/sessions.js';
import { pickLocale } from '../lib/i18n.js';
import {
  cookStats, latestSubscription, effectiveStatus, serviceKeysFor, servedAreaIds, setServedAreas, setCookServices,
} from '../services/cooks.js';
import { isValidLatLng, roundTo } from '../lib/geo.js';
import { getCountry } from '../lib/countries.js';
import { SERVICE_TYPES, MAX_PHOTOS_PER_COOK } from '../db/seed-data.js';
import { sendPhoto, redirect } from './public.js';

const DUMMY_HASH = 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAA';

export function cookRoutes({ db, cfg, limiters, areas, images, geo, settings, cache }) {
  /** Photo limit depends on the kind (restaurants get more), set by the admin. */
  // v8.1: the owner's numbers for this business's CATEGORY (admin → «حدود وأسعار الأقسام»), else the general ones
  const photoLimit = (kind) => limitsFor(settings?.get(), kind || 'cook').photos;
  const menuLimit = (kind) => limitsFor(settings?.get(), kind || 'cook').products;
  const parseSections = (v) => { try { const a = JSON.parse(v || '[]'); return Array.isArray(a) ? a.map(String) : []; } catch { return []; } };
  async function addSection(cookId, name) {
    const cur = parseSections((await db.one('SELECT menu_sections FROM cooks WHERE id = $1', [cookId]))?.menu_sections);
    if (!cur.includes(name) && cur.length < 40) await db.query('UPDATE cooks SET menu_sections = $1 WHERE id = $2', [JSON.stringify([...cur, name]), cookId]);
  }
  // optional product photo (the app shrinks it first): stored with the product, served at /api/menu-photo/<id>
  function productPhoto(v, value) {
    if (value == null || value === '') return null;
    const s = String(value);
    const mm = /^data:(image\/(?:jpeg|png|webp));base64,/.exec(s);
    if (!mm || !imageBytesOk(s) || s.length > 450_000) { v.fail('photo', 'invalid'); return null; }
    return { mime: mm[1], data: s.split(',')[1] };
  }
  // the store's own view of a product (with its quantity and barcode)
  const OWN_BIG = 300;
  const OWN_COLS = 'id, name, description, price, currency, is_available, section, rx, stock, auto_off, barcode, CASE WHEN photo IS NULL AND photo_url IS NULL THEN 0 ELSE 1 END AS has_photo';
  // v8.2 product photos go to the photo storage (Cloudflare R2) when it is set — the database stays light; without it
  // they stay in the database as before. Returns the columns to write.
  async function productPhotoCols(cookId, ph) {
    if (!ph) return { photo: null, photo_mime: null, photo_url: null };
    if (!images?.external) return { photo: ph.data, photo_mime: ph.mime, photo_url: null };
    const { url } = await images.save(`products/${cookId}`, `data:${ph.mime};base64,${ph.data}`);
    return { photo: null, photo_mime: null, photo_url: url };
  }
  const oldPhotoUrl = async (id, cookId) => (await db.one('SELECT photo_url FROM menu_items WHERE id = $1 AND cook_id = $2', [id, cookId]))?.photo_url || null;
  const ownItem = (m) => ({ id: m.id, name: m.name, description: m.description || '', price: m.price == null ? null : Number(m.price), currency: m.currency || null,
    available: !!Number(m.is_available), section: m.section || null, photo: Number(m.has_photo) ? `/api/menu-photo/${m.id}?v=${Date.now() % 1e6}` : null, rx: !!Number(m.rx),
    stock: m.stock == null ? null : Number(m.stock), soldOut: !!Number(m.auto_off), barcode: m.barcode || null });
  // quantity: '' / null = not counted; 0 = ran out (hidden by itself); more = shown again if it had run out
  const stockIn = (v, raw) => (raw === '' || raw == null ? null : v.int('stock', raw, { min: 0, max: 1_000_000 }));
  const barcodeIn = (v, raw) => { if (raw === '' || raw == null) return null; const b = String(raw).trim(); if (!/^[0-9A-Za-z._-]{1,40}$/.test(b)) { v.fail('barcode', 'invalid'); return null; } return b; };
  // product photos count too (the owner's photo number for the category): a supermarket can't fill the database alone
  async function assertProductPhotoRoom(cookId) {
    const c = await db.one('SELECT kind FROM cooks WHERE id = $1', [cookId]);
    const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1 AND (photo IS NOT NULL OR photo_url IS NOT NULL)', [cookId]);
    const max = photoLimit(c?.kind);
    if (Number(n.n) >= max) throw new HttpError(409, 'too_many_photos', { max });
  }
  const sessions = sessionManager({ db, cfg, table: 'cook_sessions', cookie: 'st_cook', ownerColumn: 'cook_id', hours: 24 * 60 });
  // Same admin sessions as /admin — the owner can also sign in from the normal "Log in" page with his admin username.
  const adminSessions = sessionManager({ db, cfg, table: 'admin_sessions', cookie: 'st_admin', ownerColumn: 'admin_id', hours: 12 });

  const guard = (fn) => async (req, res, m) => {
    const cookId = await sessions.ownerId(req);
    if (!cookId) throw new HttpError(401, 'unauthorized');
    if (req.method !== 'GET') checkCsrf(req);
    const cook = await db.one(`SELECT id, status FROM cooks WHERE id = $1`, [cookId]);
    if (!cook || cook.status === 'rejected') throw new HttpError(401, 'unauthorized');
    return fn(req, res, m, cookId);
  };

  async function me(cookId, locale) {
    const c = await db.one(
      `SELECT id, full_name, whatsapp, area_id, area_label, lat, lng, bio, status, photo_url, is_hidden, kind, specialty, allow_directions, hours, booking, CASE WHEN photo IS NULL THEN 0 ELSE 1 END AS has_photo
       FROM cooks WHERE id = $1`, [cookId]);
    const sub = await latestSubscription(db, cookId);
    const photos = await db.query('SELECT id, caption, url, is_hidden, created_at FROM cook_photos WHERE cook_id = $1 ORDER BY created_at DESC, id DESC', [cookId]);
    return {
      id: c.id,
      name: c.full_name,
      whatsapp: c.whatsapp,
      area: { ...(areas.view(areas.get(c.area_id), locale) || {}), name: c.area_label || areas.get(c.area_id)?.name_ar },
      bio: c.bio || '',
      allowDirections: Number(c.allow_directions ?? 1) === 1,
      hours: (() => { try { return c.hours ? JSON.parse(c.hours) : null; } catch { return null; } })(),
      booking: !!Number(c.booking || 0),
      location: c.lat != null && c.lng != null && !(Number(c.lat) === 0 && Number(c.lng) === 0) ? { lat: Number(c.lat), lng: Number(c.lng) } : null,
      hidden: !!Number(c.is_hidden),
      status: c.status,
      photoUrl: c.photo_url || (Number(c.has_photo) ? `/api/cook/photo?ts=${Date.now()}` : null),
      profileUrl: `/c/${c.id}`,
      services: (await serviceKeysFor(db, [c.id])).get(c.id),
      servedAreas: (await servedAreaIds(db, c.id)).map((id) => areas.view(areas.get(id), locale)).filter(Boolean),
      subscription: sub ? { status: effectiveStatus(c, sub), plan: sub.plan, startDate: sub.start_date, expiryDate: sub.expiry_date } : null,
      stats: await cookStats(db, c.id),
      photos: photos.map((p) => ({ id: p.id, url: p.url || `/api/cook/photos/${p.id}.jpg`, caption: p.caption || '', hidden: !!p.is_hidden })),
      maxPhotos: photoLimit(c.kind),
      maxItems: menuLimit(c.kind),
      kind: c.kind || 'cook',
      specialty: c.specialty || '',
      // every category can have a menu. v8.1: a big catalog (supermarket) is not sent whole each time — the products
      // tab loads it by parts (GET /api/cook/menu); menuCount / sectionCounts tell its size.
      ...(await (async () => {
        const counts = await db.query('SELECT section, CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1 GROUP BY section', [c.id]);
        const total = counts.reduce((a, r) => a + Number(r.n), 0);
        if (total > OWN_BIG) return { menu: [], menuBig: true, menuCount: total, sectionCounts: counts.map((r) => ({ name: r.section || null, n: Number(r.n) })) };
        return { menuBig: false, menuCount: total, menu: (await db.query(`SELECT ${OWN_COLS} FROM menu_items WHERE cook_id = $1 ORDER BY sort_order, id`, [c.id])).map(ownItem) };
      })()),
      menuSections: parseSections((await db.one('SELECT menu_sections FROM cooks WHERE id = $1', [c.id]))?.menu_sections),
      // v8.1: the store's money still with drivers (cash orders they delivered and did not hand over yet)
      cashWithDrivers: await (async () => { const r = await db.one(`SELECT COALESCE(SUM(COALESCE(due_cents, CAST(ROUND(amount * 100) AS INTEGER)) - paid_cents), 0) AS c, CAST(COUNT(DISTINCT driver_id) AS INTEGER) AS n
        FROM driver_cash_entries WHERE store_id = $1 AND status IN ('open','in_settlement') AND direction = 'driver_to_store'`, [c.id]); return { total: Math.round(Number(r?.c) || 0) / 100, drivers: Number(r?.n) || 0 }; })(),
      unreadSupport: Number((await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM support_messages WHERE cook_id = $1 AND from_admin = 1 AND read_by_cook = 0', [c.id])).n),
    };
  }

  return [
    ['POST', /^\/api\/cook\/login$/, async (req, res) => {
      const r = await limiters.login.take('cook:' + clientIp(req, cfg.trustProxy));
      if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
      checkCsrf(req);
      const body = await readJson(req, 2 * 1024);
      // Second way into the admin panel: an admin username (has letters) instead of a phone number.
      const login = String(body.whatsapp || '').trim();
      // Letters (any language) = a name: the admin's username, or a shop that signed up without a WhatsApp number.
      const username = login.toLowerCase().replace(/\s+/g, '.');
      const admin = /\p{L}/u.test(login) ? await db.one('SELECT id, password_hash, mfa_required FROM admin_users WHERE LOWER(username) = $1 AND disabled = 0', [username]) : null;
      if (/\p{L}/u.test(login) && !admin) {
        const shop = await db.one(`SELECT id, password_hash FROM cooks WHERE name_norm = $1 AND whatsapp = '' AND status = 'approved' AND password_hash IS NOT NULL ORDER BY id DESC LIMIT 1`,
          [normalizeName(login)]);
        const okShop = await verifyPassword(String(body.password || ''), shop?.password_hash || DUMMY_HASH);
        if (!shop || !okShop) throw new HttpError(401, 'invalid_cook_credentials');
        return sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.create(shop.id) });
      }
      if (admin) {
        const okAdmin = await verifyPassword(String(body.password || ''), admin?.password_hash || DUMMY_HASH);
        const ipHash = hmacHex(cfg.sessionSecret, clientIp(req, cfg.trustProxy)).slice(0, 16);
        await db.query('INSERT INTO admin_logins (admin_id, username, ok, method, ip_hash, user_agent) VALUES ($1,$2,$3,$4,$5,$6)',
          [admin?.id || null, username.slice(0, 60), admin && okAdmin ? 1 : 0, 'account_page', ipHash, String(req.headers['user-agent'] || '').slice(0, 200)]).catch(() => {});
        if (!admin || !okAdmin) throw new HttpError(401, 'invalid_cook_credentials');
        // With a passkey required, finish on the admin page (fingerprint / backup code) — never skip the second step.
        if (Number(admin.mfa_required)) return sendJson(res, 200, { ok: true, admin: true, redirect: '/admin/' });
        await db.query('UPDATE admin_users SET last_login_at = $1 WHERE id = $2', [new Date().toISOString(), admin.id]);
        return sendJson(res, 200, { ok: true, admin: true, redirect: '/admin/' }, { 'Set-Cookie': await adminSessions.create(admin.id) });
      }
      const phone = normalizePhone(body.whatsapp, cfg.defaultCountry);
      const cook = phone
        ? await db.one(`SELECT id, password_hash FROM cooks WHERE whatsapp = $1 AND status = 'approved' AND password_hash IS NOT NULL AND parent_id IS NULL ORDER BY id DESC LIMIT 1`, [phone])
        : null;
      const ok = await verifyPassword(String(body.password || ''), cook?.password_hash || DUMMY_HASH);
      if (!cook || !ok) throw new HttpError(401, 'invalid_cook_credentials');
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.create(cook.id) });
    }],

    ['POST', /^\/api\/cook\/logout$/, async (req, res) => {
      checkCsrf(req);
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.destroy(req) });
    }],

    ['GET', /^\/api\/cook\/me$/, guard(async (req, res, m, cookId) => {
      cache?.clear?.('feed:');
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    ['GET', /^\/api\/cook\/photo$/, guard(async (req, res, m, cookId) => {
      const c = await db.one('SELECT photo, photo_url FROM cooks WHERE id = $1', [cookId]);
      if (c?.photo_url) return redirect(res, c.photo_url);
      sendPhoto(res, c?.photo);
    })],

    // She can edit her description, profile photo, what she cooks and where she delivers.
    // Name and WhatsApp number are changed by the admin only.
    // Google Play requirement: a subscriber can delete their own account from inside the app. Permanent (photos too).
    ['POST', /^\/api\/cook\/me\/delete$/, guard(async (req, res, m, cookId) => {
      await limiters.login?.check?.(clientIp(req, cfg.trustProxy));   // slows down password guessing
      const body = await readJson(req, 4 * 1024);
      const c = await db.one('SELECT id, full_name, password_hash, photo_url FROM cooks WHERE id = $1', [cookId]);
      if (!c) throw new HttpError(404, 'not_found');
      if (!(await verifyPassword(String(body.password || ''), c.password_hash || DUMMY_HASH))) throw new HttpError(401, 'invalid_cook_credentials');
      const photoUrls = [...(await db.query('SELECT url FROM cook_photos WHERE cook_id = $1 AND url IS NOT NULL', [cookId])).map((r) => r.url),
        ...(await db.query('SELECT photo_url AS url FROM menu_items WHERE cook_id = $1 AND photo_url IS NOT NULL', [cookId])).map((r) => r.url)];
      await db.tx(async (q) => { await q.query('DELETE FROM cooks WHERE id = $1', [cookId]); });   // cascades to every related table
      for (const u of [c.photo_url, ...photoUrls]) await images?.remove?.(u);
      cache?.clear?.('feed:');
      sendJson(res, 200, { ok: true }, { 'Set-Cookie': await sessions.destroy(req) });
    })],
    ['PATCH', /^\/api\/cook\/me$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 256 * 1024);
      const v = new Validator();
      const sets = {};
      if (body.bio !== undefined) sets.bio = v.text('bio', body.bio, { max: 300, required: false, multiline: true });
      if (body.allowDirections !== undefined) sets.allow_directions = body.allowDirections ? 1 : 0;
      if (body.booking !== undefined) sets.booking = body.booking ? 1 : 0;   // the add-on can be turned on later (billing by the owner)
      if (body.hours !== undefined) { const h = cleanHours(body.hours); if (h === undefined) v.fail('hours', 'invalid'); else sets.hours = h ? JSON.stringify(h) : null; }   // "directions" button for customers (shops)
      if (body.specialty !== undefined) sets.specialty = v.text('specialty', body.specialty, { min: 2, max: 120 });
      assertClean(HttpError, { bio: sets.bio, specialty: sets.specialty });
      let newPhoto;
      if (body.photo !== undefined) newPhoto = validatePhoto(body.photo, v) ?? null;
      if (body.lat !== undefined || body.lng !== undefined) {
        const lat = v.number('location', body.lat, { min: -90, max: 90 });
        const lng = v.number('location', body.lng, { min: -180, max: 180 });
        if (lat != null && lng != null && isValidLatLng(lat, lng)) {
          const acc = body.accuracy == null ? null : Math.round(Number(body.accuracy));
          if (acc != null && acc > 150) v.fail('location', 'location_inaccurate');
          if (body.locationAt != null && Date.now() - Number(body.locationAt) > 10 * 60_000) v.fail('location', 'location_stale');
          v.assert();
          sets.lat = roundTo(lat, 5); sets.lng = roundTo(lng, 5);
          sets.location_accuracy_m = acc; sets.location_at = new Date().toISOString();
          sets.area_id = areas.nearest(lat, lng).id;
          const place = geo ? await geo.resolve(lat, lng) : { country: null };
          if (place.country) {
            sets.country = place.country;
            sets.region_key = place.regionKey || null; sets.region_name = place.regionName || null;
            sets.region_name_ar = place.regionNameAr || null; sets.region_name_en = place.regionNameEn || null;
            sets.addr_city = place.city || null; sets.addr_district = place.district || null; sets.addr_locality = place.locality || null;
          }
        } else v.fail('location', 'invalid');
      }
      if (body.areaLabel !== undefined) sets.area_label = v.text('areaLabel', body.areaLabel, { max: 80, required: false }) || null;
      let services, served;
      if (body.services !== undefined) {
        services = Array.isArray(body.services) ? [...new Set(body.services)].filter((s) => SERVICE_TYPES.includes(s)) : [];
        // Restaurants have a free-text specialty instead of service types.
        const kindNow = (await db.one('SELECT kind FROM cooks WHERE id = $1', [cookId]))?.kind;
        // service types are optional now (every category describes itself in its description)
      }
      if (body.servedAreaIds !== undefined) {
        served = Array.isArray(body.servedAreaIds) ? [...new Set(body.servedAreaIds.map(Number))].filter((id) => areas.get(id)).slice(0, 300) : [];
        if (!served.length) v.fail('servedAreaIds', 'pick_one_area');
      }
      v.assert();
      if (newPhoto !== undefined) {
        const old = await db.one('SELECT photo_url FROM cooks WHERE id = $1', [cookId]);
        const img = await images.save(`cooks/${cookId}`, newPhoto);
        sets.photo = img.data; sets.photo_url = img.url;
        await images.remove(old?.photo_url);
      }
      const cols = Object.keys(sets);
      if (cols.length) {
        await db.query(`UPDATE cooks SET ${cols.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${cols.length + 1} WHERE id = $${cols.length + 2}`,
          [...cols.map((k) => sets[k]), new Date().toISOString(), cookId]);
      }
      if (services) await setCookServices(db, cookId, services);
      if (served) await setServedAreas(db, cookId, served);
      cache?.clear?.('feed:');
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    ['POST', /^\/api\/cook\/password$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 2 * 1024);
      const row = await db.one('SELECT password_hash FROM cooks WHERE id = $1', [cookId]);
      if (!(await verifyPassword(String(body.current || ''), row.password_hash || DUMMY_HASH))) {
        throw new HttpError(422, 'validation_failed', { fields: { current: 'wrong_password' } });
      }
      const next = String(body.next || '');
      if (next.length < 6 || next.length > 100) throw new HttpError(422, 'validation_failed', { fields: { next: 'password_too_short' } });
      await db.query('UPDATE cooks SET password_hash = $1 WHERE id = $2', [await hashPassword(next), cookId]);
      sendJson(res, 200, { ok: true });
    })],

    ['POST', /^\/api\/cook\/photos$/, guard(async (req, res, m, cookId) => {
      const rl = await limiters.upload.take(`c${cookId}`);
      if (!rl.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: rl.retryAfterSec });
      const body = await readJson(req, 600 * 1024);
      const v = new Validator();
      const caption = v.text('caption', body.caption, { max: 80, required: false });
      const data = String(body.data || '');
      if (!imageBytesOk(data)) v.fail('data', 'invalid');
      else if (data.length > 550_000) v.fail('data', 'too_large');
      // optional small version for lists (made on the phone); only kept when images live on object storage
      const thumb = body.thumb && imageBytesOk(body.thumb) && String(body.thumb).length <= 120_000 ? String(body.thumb) : null;
      v.assert();
      const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM cook_photos WHERE cook_id = $1', [cookId]);
      const k = (await db.one('SELECT kind FROM cooks WHERE id = $1', [cookId]))?.kind;
      if (n.n >= photoLimit(k)) throw new HttpError(409, 'too_many_photos');
      const img = await images.save(`dishes/${cookId}`, data);
      const th = images.external && thumb ? await images.save(`dishes/${cookId}/thumbs`, thumb) : { url: null };
      await db.query('INSERT INTO cook_photos (cook_id, data, url, thumb_url, caption) VALUES ($1,$2,$3,$4,$5)', [cookId, img.data || '', img.url, th.url, caption]);
      cache?.clear?.('feed:');
      sendJson(res, 201, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    ['GET', /^\/api\/cook\/photos\/(\d+)\.jpg$/, guard(async (req, res, m, cookId) => {
      const p = await db.one('SELECT data, url FROM cook_photos WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (p?.url) return redirect(res, p.url);
      sendPhoto(res, p?.data);
    })],

    ['DELETE', /^\/api\/cook\/photos\/(\d+)$/, guard(async (req, res, m, cookId) => {
      const p = await db.one('SELECT url, thumb_url FROM cook_photos WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      await db.query('DELETE FROM cook_photos WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      await images.remove(p?.url);
      await images.remove(p?.thumb_url);
      cache?.clear?.('feed:');
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    /* ---------- product sections (the store's own, in its order) ---------- */
    ['PUT', /^\/api\/cook\/menu-sections$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 8 * 1024);
      const list = Array.isArray(body.sections) ? body.sections : null;
      if (!list || list.length > 40) throw new HttpError(422, 'validation_failed', { fields: { sections: 'invalid' } });
      const clean = [...new Set(list.map((x) => String(x || '').trim().slice(0, 40)).filter(Boolean))];
      const old = parseSections((await db.one('SELECT menu_sections FROM cooks WHERE id = $1', [cookId]))?.menu_sections);
      // renamed: { from, to } pairs move the products along; removed sections leave their products without a section
      for (const r of Array.isArray(body.renamed) ? body.renamed.slice(0, 40) : []) {
        const from = String(r?.from || '').trim(), to = String(r?.to || '').trim().slice(0, 40);
        if (from && to) await db.query('UPDATE menu_items SET section = $1 WHERE cook_id = $2 AND section = $3', [to, cookId, from]);
      }
      for (const gone of old.filter((x) => !clean.includes(x) && !(body.renamed || []).some((r) => r?.from === x))) await db.query('UPDATE menu_items SET section = NULL WHERE cook_id = $1 AND section = $2', [cookId, gone]);
      await db.query('UPDATE cooks SET menu_sections = $1 WHERE id = $2', [JSON.stringify(clean), cookId]);
      cache?.clear?.('feed:');
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    /* ---------- restaurant menu ---------- */
    ['POST', /^\/api\/cook\/menu$/, guard(async (req, res, m, cookId) => {
      const me0 = await db.one('SELECT kind, country FROM cooks WHERE id = $1', [cookId]);
      const body = await readJson(req, 600 * 1024);   // with an optional product photo
      const v = new Validator();
      const name = v.text('name', body.name, { min: 1, max: 80 });
      const description = v.text('description', body.description, { max: 200, required: false });
      const price = body.price === '' || body.price == null ? null : v.number('price', body.price, { min: 0, max: 1000000 });
      const section = v.text('section', body.section, { max: 40, required: false }) || null;
      const photo = productPhoto(v, body.photo);
      const rx = body.rx ? 1 : 0;   // a medicine that needs a prescription
      const stock = stockIn(v, body.stock);
      const barcode = barcodeIn(v, body.barcode);
      v.assert();
      assertClean(HttpError, { name, description, section });
      const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1', [cookId]);
      if (n.n >= menuLimit(me0.kind)) throw new HttpError(409, 'too_many_items');
      if (photo) await assertProductPhotoRoom(cookId);
      const currency = getCountry(me0.country)?.currency || 'USD';
      const pc = await productPhotoCols(cookId, photo);
      await db.query('INSERT INTO menu_items (cook_id, name, description, price, currency, sort_order, section, photo_mime, photo, photo_url, rx, stock, barcode, is_available, auto_off) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)',
        [cookId, name, description, price, currency, n.n, section, pc.photo_mime, pc.photo, pc.photo_url, rx, stock, barcode, stock === 0 ? 0 : 1, stock === 0 ? 1 : 0]);
      if (section) await addSection(cookId, section);
      cache?.clear?.('feed:');
      sendJson(res, 201, await me(cookId, pickLocale(req, cfg.locales)));
    })],
    /* ---------- v8.1 big catalogs: all products from one spreadsheet + their photos by file name ---------- */
    ['GET', /^\/api\/cook\/menu\/template\.csv$/, guard(async (req, res) => {
      const body = Buffer.from(templateCsv(), 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="aklatak-products.csv"', 'Content-Length': body.length, 'Cache-Control': 'no-store' });
      res.end(body);
    })],
    // dryRun: what WOULD happen (new / updated / unchanged / rows with a problem) — the store sees it before saving
    ['POST', /^\/api\/cook\/menu\/import$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 12 * 1024 * 1024);
      const b64 = String(body.data || '').replace(/^data:[^,]*,/, '');
      if (!b64 || b64.length > 11 * 1024 * 1024) throw new HttpError(422, 'validation_failed', { fields: { file: b64 ? 'too_large' : 'required' } });
      let table;
      try { table = readSheet(String(body.fileName || '').slice(0, 120), Buffer.from(b64, 'base64')); }
      catch (e) { throw new HttpError(422, e.code || 'bad_file'); }
      const checked = checkRows(table);
      if (checked.errors[0]?.msg === 'no_name_column') throw new HttpError(422, 'no_name_column');
      if (checked.tooMany) throw new HttpError(422, 'too_many_rows', { max: 20000 });
      const me0 = await db.one('SELECT kind, country FROM cooks WHERE id = $1', [cookId]);
      const existing = await db.query('SELECT id, name, barcode, price, section, description, stock, is_available, auto_off FROM menu_items WHERE cook_id = $1', [cookId]);
      const plan = planImport(existing, checked.rows);
      const errors = [...checked.errors, ...plan.errors].sort((a, b) => a.row - b.row);
      const limit = menuLimit(me0.kind), room = Math.max(0, limit - existing.length);
      const summary = { total: checked.rows.length + checked.errors.length, create: plan.create.length, update: plan.update.length, same: plan.same.length,
        errorCount: errors.length, errors: errors.slice(0, 100), limit, room, overLimit: plan.create.length > room, columns: checked.columns };
      if (body.dryRun) return sendJson(res, 200, { ...summary, applied: false });
      if (summary.overLimit) throw new HttpError(409, 'too_many_items', { limit, room });
      await db.tx((t) => applyImport(t, cookId, plan, { currency: getCountry(me0.country)?.currency || 'USD', startOrder: existing.length }));
      for (const sec of [...new Set(plan.create.map((r) => r.section).filter(Boolean))].slice(0, 40)) await addSection(cookId, sec);
      cache?.clear?.('feed:');
      sendJson(res, 200, { ...summary, applied: true });
    })],
    // one photo of many chosen at once: its file name is the product's barcode or name (the app shrinks it first)
    ['POST', /^\/api\/cook\/menu\/photo$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 600 * 1024);
      const v = new Validator();
      const photo = productPhoto(v, body.photo);
      if (!photo) v.fail('photo', 'required');
      v.assert();
      const existing = await db.query('SELECT id, name, barcode, photo_url, CASE WHEN photo IS NULL AND photo_url IS NULL THEN 0 ELSE 1 END AS has_photo FROM menu_items WHERE cook_id = $1', [cookId]);
      const hit = matchPhoto(existing, body.fileName);
      if (!hit) return sendJson(res, 200, { matched: null });
      if (!Number(hit.has_photo)) await assertProductPhotoRoom(cookId);
      const pc = await productPhotoCols(cookId, photo);
      await db.query('UPDATE menu_items SET photo = $1, photo_mime = $2, photo_url = $3 WHERE id = $4 AND cook_id = $5', [pc.photo, pc.photo_mime, pc.photo_url, hit.id, cookId]);
      if (hit.photo_url && hit.photo_url !== pc.photo_url) await images?.remove?.(hit.photo_url);
      cache?.clear?.('feed:');
      sendJson(res, 200, { matched: { id: hit.id, name: hit.name } });
    })],
    // v8.1: the products tab of a big catalog, by parts: ?section= (empty = «other») / ?q= (name or barcode) / &offset=
    ['GET', /^\/api\/cook\/menu$/, guard(async (req, res, m, cookId) => {
      const p = new URL(req.url, 'http://x').searchParams;
      const params = [cookId];
      let where = 'cook_id = $1';
      const s = String(p.get('q') || '').trim().toLowerCase().slice(0, 60);
      if (s) { params.push(`%${s.replace(/[\\%_]/g, (c) => '\\' + c)}%`, s); where += ` AND (LOWER(name) LIKE $2 ESCAPE '\\' OR barcode = $3)`; }
      else if (p.has('section')) { const sec = p.get('section'); if (sec) { params.push(sec); where += ' AND section = $2'; } else where += ' AND section IS NULL'; }
      if (p.get('soldOut') === '1') where += ' AND auto_off = 1';
      const off = Math.max(Number(p.get('offset')) | 0, 0), lim = 40;
      const rows = await db.query(`SELECT ${OWN_COLS} FROM menu_items WHERE ${where} ORDER BY sort_order, id LIMIT ${lim + 1} OFFSET ${off}`, params);
      sendJson(res, 200, { items: rows.slice(0, lim).map(ownItem), hasMore: rows.length > lim });
    })],
    ['PATCH', /^\/api\/cook\/menu\/(\d+)$/, guard(async (req, res, m, cookId) => {
      const body = await readJson(req, 600 * 1024);
      const v = new Validator();
      const sets = {};
      if (body.name !== undefined) sets.name = v.text('name', body.name, { min: 1, max: 80 });
      if (body.description !== undefined) sets.description = v.text('description', body.description, { max: 200, required: false });
      if (body.price !== undefined) sets.price = body.price === '' || body.price == null ? null : v.number('price', body.price, { min: 0, max: 1000000 });
      if (body.available !== undefined) { sets.is_available = body.available ? 1 : 0; sets.auto_off = 0; }
      if (body.stock !== undefined) {
        sets.stock = stockIn(v, body.stock);
        // ran out → hidden by itself; new stock → back (unless the store also switched it off in the same save)
        if (sets.stock === 0) { sets.is_available = 0; sets.auto_off = 1; }
        else if (body.available === undefined) { sets.auto_off = 0; sets.restock = true; }
      }
      if (body.barcode !== undefined) sets.barcode = barcodeIn(v, body.barcode);
      if (body.rx !== undefined) sets.rx = body.rx ? 1 : 0;
      if (body.section !== undefined) sets.section = v.text('section', body.section, { max: 40, required: false }) || null;
      let newPhoto = undefined;
      if (body.photo === null) newPhoto = null;
      else if (body.photo !== undefined) newPhoto = productPhoto(v, body.photo) || undefined;
      v.assert();
      let oldUrl = null;
      if (newPhoto !== undefined) {
        const had = await db.one('SELECT CASE WHEN photo IS NULL AND photo_url IS NULL THEN 0 ELSE 1 END AS has, photo_url FROM menu_items WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
        if (newPhoto && had && !Number(had.has)) await assertProductPhotoRoom(cookId);
        oldUrl = had?.photo_url || null;
        Object.assign(sets, await productPhotoCols(cookId, newPhoto));
      }
      assertClean(HttpError, { name: sets.name, description: sets.description, section: sets.section });
      if (sets.section) await addSection(cookId, sets.section);
      const restock = sets.restock; delete sets.restock;
      if (restock) await db.query('UPDATE menu_items SET is_available = 1 WHERE id = $1 AND cook_id = $2 AND auto_off = 1', [Number(m[1]), cookId]);
      const keys = Object.keys(sets);
      if (keys.length) {
        await db.query(`UPDATE menu_items SET ${keys.map((k, i) => `${k} = $${i + 1}`).join(', ')} WHERE id = $${keys.length + 1} AND cook_id = $${keys.length + 2}`,
          [...keys.map((k) => sets[k]), Number(m[1]), cookId]);
      }
      if (oldUrl && oldUrl !== sets.photo_url) await images?.remove?.(oldUrl);
      cache?.clear?.('feed:');
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],
    ['DELETE', /^\/api\/cook\/menu\/(\d+)$/, guard(async (req, res, m, cookId) => {
      const gone = await oldPhotoUrl(Number(m[1]), cookId);
      await db.query('DELETE FROM menu_items WHERE id = $1 AND cook_id = $2', [Number(m[1]), cookId]);
      if (gone) await images?.remove?.(gone);
      cache?.clear?.('feed:');
      sendJson(res, 200, await me(cookId, pickLocale(req, cfg.locales)));
    })],

    /* ---------- contact the admin (support thread, shown in the admin panel) ---------- */
    ['GET', /^\/api\/cook\/support$/, guard(async (req, res, m, cookId) => {
      const rows = await db.query('SELECT id, from_admin, body, created_at FROM support_messages WHERE cook_id = $1 ORDER BY created_at, id', [cookId]);
      await db.query('UPDATE support_messages SET read_by_cook = 1 WHERE cook_id = $1 AND from_admin = 1 AND read_by_cook = 0', [cookId]);
      sendJson(res, 200, { messages: rows.map((r) => ({ id: r.id, fromAdmin: !!Number(r.from_admin), body: r.body, createdAt: r.created_at })) });
    })],
    ['POST', /^\/api\/cook\/support$/, guard(async (req, res, m, cookId) => {
      const r = await limiters.feedback.take('support:' + cookId);
      if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
      const body = await readJson(req, 8 * 1024);
      const v = new Validator();
      const text = v.text('body', body.body, { min: 2, max: 2000, multiline: true });
      v.assert();
      await db.query('INSERT INTO support_messages (cook_id, from_admin, body, read_by_cook) VALUES ($1, 0, $2, 1)', [cookId, text]);
      sendJson(res, 201, { ok: true });
    })],
  ];
}
