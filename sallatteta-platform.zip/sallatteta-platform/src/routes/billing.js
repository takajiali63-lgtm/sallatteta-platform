// v8.2 store-app subscriptions: Google Play (Android app) and the App Store (iPhone app, server side ready).
// The phone never activates anything: it hands us a purchase token / signed transaction, we ask Google or check Apple's
// signature ourselves, and only then extend the account (services/billing.js → applyEntitlement).
import { randomUUID, timingSafeEqual, createHash } from 'node:crypto';
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { makeGuards } from '../lib/guards.js';
import { publicBaseUrl } from '../lib/sessions.js';
import { logAdminAction } from '../services/cooks.js';
import {
  STATES, getProducts, saveProducts, cleanProducts, payerOf, payerFor, productsFor, groupOfOwner, assertProductFor, accountIdFor, ownerOfAccountId, billingEnv,
  createGoogleClient, GOOGLE_STATE, trimGoogle, findEntitlement, processEvent, endReplaced, publicEntitlement, PRODUCT_RE,
} from '../services/billing.js';
import { verifyAppleJws, verifyGoogleOidc, googleJwks, BillingAuthError, APPLE_ROOT_G3_SHA256 } from '../services/billingCrypto.js';

const ok = (res, data = {}) => sendJson(res, 200, { ok: true, ...data });
const TOKEN_RE = /^[A-Za-z0-9._:-]{10,4096}$/;
const sameOwner = (a, b) => a && b && a.type === b.type && Number(a.id) === Number(b.id);
const entOwner = (e) => (e?.owner_type ? { type: e.owner_type, id: Number(e.owner_id) } : null);
const sticky = (e) => ['refunded', 'revoked'].includes(e.state) || e.reason === 'replaced';
const isoMs = (v) => (v == null || v === '' ? null : new Date(Number(v)).toISOString());

export function billingRoutes(ctx) {
  const { db, cfg, limiters } = ctx;
  const { store, driver, owner, whoAmI, limit } = makeGuards(ctx);
  // tests inject a fake network and their own local Apple root; production always uses the real ones
  const fetchImpl = cfg.billing?.fetch || globalThis.fetch;
  const appleRoots = !cfg.isProd && Array.isArray(cfg.billing?.appleRootFingerprints) ? cfg.billing.appleRootFingerprints : [APPLE_ROOT_G3_SHA256];
  const google = createGoogleClient({ fetchImpl });
  const jwks = googleJwks(fetchImpl);
  const E = () => billingEnv(cfg);
  const googleReady = (e = E()) => !!(e.package && e.serviceAccount);
  const appleReady = (e = E()) => !!e.appleBundle;
  const needGoogle = () => { const e = E(); if (!googleReady(e)) throw new HttpError(503, 'billing_not_configured'); return e; };
  const needApple = () => { const e = E(); if (!appleReady(e)) throw new HttpError(503, 'billing_not_configured'); return e; };

  /** A logged-in store (main or branch) or driver; customers can't subscribe. Passes the account itself — who pays for
   *  a product is decided per product (payerFor: main plans → the main account; branch plans and AI packs → itself). */
  const subscriber = (fn) => async (req, res, m) => {
    const who = await whoAmI(req);
    const run = (type) => async (rq, rs, mm, id) => fn(rq, rs, mm, { type, id });
    if (who?.type === 'store') return store(run('store'))(req, res, m);
    if (who?.type === 'driver') return driver(run('driver'), { activeOnly: false })(req, res, m);
    throw new HttpError(401, 'unauthorized');
  };
  const throttle = (o) => limit(limiters.lookup, `bill:${o.type}${o.id}`);

  /* ---------------- Google: verify a purchase token and apply it ---------------- */

  /**
   * Ask Google about a token and apply what it says. caller = the account calling verify (null for notifications).
   * forceState/reason: Google's REVOKED notification (the purchase is gone at once, whatever the API shows a moment later).
   */
  async function syncGoogle(token, { hint = null, caller = null, eventId, type, forceState = null, reason = null }) {
    const env = needGoogle();
    const sub = await google.getSubscription(env, token);
    const products = await getProducts(db);
    const items = sub.lineItems || [];
    const line = (hint && items.find((l) => l.productId === hint)) || items.find((l) => products[l.productId]) || items[0];
    if (!line?.productId) throw new HttpError(400, 'invalid_purchase_token');
    if (hint && line.productId !== hint) throw new HttpError(400, 'product_mismatch');
    const obfOwner = await ownerOfAccountId(db, sub.externalAccountIdentifiers?.obfuscatedExternalAccountId);
    if (caller) {
      if (obfOwner && !sameOwner(obfOwner, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
      await assertProductFor(db, caller, products[line.productId]);
    }
    let state = forceState || GOOGLE_STATE[sub.subscriptionState] || 'pending';
    const result = await processEvent(db, {
      platform: 'google', eventId, type, key: { token }, initial: { product_id: line.productId },
      details: { subscriptionState: sub.subscriptionState, orderId: sub.latestOrderId, productId: line.productId },
      update: async (ent, q) => {
        const bound = entOwner(ent);
        if (caller && bound && !sameOwner(bound, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
        if (!bound) {
          let o = caller || obfOwner;
          if (!o && sub.linkedPurchaseToken) o = entOwner(await findEntitlement(q, 'google', { token: sub.linkedPurchaseToken }));
          if (o) { ent.owner_type = o.type; ent.owner_id = o.id; }
        }
        if (sticky(ent) && !forceState) state = ent.state;   // a refunded / replaced purchase never comes back by itself
        ent._newPeriod = !!sub.latestOrderId && sub.latestOrderId !== ent.last_order_id;
        Object.assign(ent, {
          product_id: line.productId, state, expires_at: line.expiryTime ? new Date(line.expiryTime).toISOString() : ent.expires_at || null,
          auto_renew: !!line.autoRenewingPlan?.autoRenewEnabled, linked_token: sub.linkedPurchaseToken || ent.linked_token || null,
          last_order_id: sub.latestOrderId || ent.last_order_id, environment: sub.testPurchase ? 'test' : 'production',
          acknowledged: Number(ent.acknowledged) || sub.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED',
          reason: reason || ent.reason || null, raw: trimGoogle(sub),
        });
      },
      // upgrade / downgrade: the purchase it replaced ends now (its time is taken back, the new one gives its own)
      after: sub.linkedPurchaseToken ? (q, ent, prods) => endReplaced(q, 'google', sub.linkedPurchaseToken, ent, prods) : null,
    });
    if (result.duplicate) return result;
    const ent = result.entitlement;
    // acknowledge only after access was recorded (Google's order), once; a failure is retried at the next verify/notification
    if (ent.owner_type && ['active', 'grace', 'cancelled'].includes(ent.state) && !Number(ent.acknowledged)
      && sub.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_PENDING') {
      const acked = await google.acknowledge(env, line.productId, token).catch(() => false);
      if (acked) { await db.query('UPDATE billing_entitlements SET acknowledged = 1 WHERE id = $1', [ent.id]); ent.acknowledged = 1; }
    }
    return result;
  }

  /**
   * v8.2 the AI pack (Google one-time product): Google confirms it was paid → the budget is added to THIS month of the
   * account, once per purchase (the purchase token is the key), then the purchase is consumed so it can be bought again.
   */
  async function syncGooglePack(token, { hint, caller = null, eventId, type }) {
    const env = needGoogle();
    const products = await getProducts(db);
    const map = products[hint];
    if (!map || map.tier !== 'pack') throw new HttpError(400, 'unknown_product');
    const pr = await google.getProduct(env, hint, token);
    const obfOwner = await ownerOfAccountId(db, pr.obfuscatedExternalAccountId);
    if (caller) {
      if (obfOwner && !sameOwner(obfOwner, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
      await assertProductFor(db, caller, map);
    }
    const paid = Number(pr.purchaseState) === 0;
    const r = await processEvent(db, {
      platform: 'google', eventId, type, key: { token }, initial: { product_id: hint },
      details: { productId: hint, orderId: pr.orderId, purchaseState: pr.purchaseState },
      update: async (ent) => {
        const bound = entOwner(ent);
        if (caller && bound && !sameOwner(bound, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
        if (!bound && (caller || obfOwner)) { const o = caller || obfOwner; ent.owner_type = o.type; ent.owner_id = o.id; }
        if (!sticky(ent)) ent.state = paid ? 'active' : Number(pr.purchaseState) === 1 ? 'expired' : 'pending';
        Object.assign(ent, { product_id: hint, last_order_id: pr.orderId || ent.last_order_id, environment: Number(pr.purchaseType) === 0 ? 'test' : 'production', auto_renew: false,
          acknowledged: Number(ent.acknowledged) || Number(pr.acknowledgementState) === 1, raw: { orderId: pr.orderId, purchaseState: pr.purchaseState, consumptionState: pr.consumptionState } });
      },
      after: (q, ent) => creditPack(q, ent, map),
    });
    if (r.duplicate) return r;
    // consumed only after it was credited (once); a failure is retried at the next verify / notification
    if (r.entitlement?.granted_until && Number(pr.consumptionState) !== 1) await google.consume(env, hint, token).catch(() => false);
    return r;
  }
  /** A paid pack adds its budget to this month's AI budget — once (granted_until marks it). */
  async function creditPack(q, ent, map) {
    if (ent.state !== 'active' || ent.granted_until || !ent.owner_type) return [];
    const month = new Date().toISOString().slice(0, 7);
    const cat = ent.owner_type === 'driver' ? 'drivers' : map.group;
    await q.query(`INSERT INTO ai_usage (owner_type, owner_id, month, category) VALUES ($1,$2,$3,$4) ON CONFLICT (owner_type, owner_id, month) DO NOTHING`, [ent.owner_type, ent.owner_id, month, cat]);
    await q.query('UPDATE ai_usage SET extra_cents = extra_cents + $1, warned = 0 WHERE owner_type = $2 AND owner_id = $3 AND month = $4', [map.cents, ent.owner_type, ent.owner_id, month]);
    ent.granted_until = new Date().toISOString();   // = «the pack was credited» (once)
    ent.base_sub_until = month;                     // which month got it (for a refund)
    await q.query('UPDATE billing_entitlements SET granted_until = $1, base_sub_until = $2 WHERE id = $3', [ent.granted_until, month, ent.id]);
    return [{ field: 'ai_extra_cents', add: map.cents, month }];
  }
  /** A refunded pack takes its budget back from the month it went to (never below 0). */
  async function refundPack(q, ent, products) {
    const map = products[ent.product_id];
    if (map?.tier !== 'pack' || !ent.granted_until || !ent.owner_type) return;
    await q.query('UPDATE ai_usage SET extra_cents = CASE WHEN extra_cents > $1 THEN extra_cents - $1 ELSE 0 END WHERE owner_type = $2 AND owner_id = $3 AND month = $4',
      [map.cents, ent.owner_type, ent.owner_id, ent.base_sub_until || new Date().toISOString().slice(0, 7)]);
    ent.granted_until = null;   // taken back once (a second refund notice changes nothing)
    await q.query('UPDATE billing_entitlements SET granted_until = NULL WHERE id = $1', [ent.id]);
  }

  async function rtdnAuth(req, url, env) {
    const got = Buffer.from(String(url.searchParams.get('token') || ''));
    const want = Buffer.from(env.rtdnToken);
    if (got.length !== want.length || !timingSafeEqual(got, want)) throw new HttpError(401, 'unauthorized');
    if (env.rtdnAudience) {   // optional second lock: the push is signed by Google for our audience
      const bearer = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
      try { await verifyGoogleOidc(bearer, { audience: env.rtdnAudience, jwks }); }
      catch (e) { if (e instanceof BillingAuthError) throw new HttpError(401, 'unauthorized'); throw e; }
    }
  }

  /** Record an event that changes nothing (test notifications, unknown purchases) — once only. */
  async function logOnly(platform, eventId, type, details) {
    const r = await db.one(`INSERT INTO billing_events (platform, event_id, type, details) VALUES ($1,$2,$3,$4) ON CONFLICT (platform, event_id) DO NOTHING RETURNING id`,
      [platform, eventId, type, JSON.stringify(details || {}).slice(0, 2000)]);
    return { duplicate: !r };
  }
  const seen = async (platform, eventId) => !!(await db.one('SELECT id FROM billing_events WHERE platform = $1 AND event_id = $2', [platform, eventId]));

  /* ---------------- Apple ---------------- */

  function appleJws(jws) {
    try { return verifyAppleJws(String(jws || ''), { rootFingerprints: appleRoots }); }
    catch (e) { if (e instanceof BillingAuthError) throw new HttpError(401, 'invalid_signature', { reason: e.code }); throw e; }
  }
  function appleChecks(env, obj) {
    if (obj.bundleId !== env.appleBundle) throw new HttpError(400, 'wrong_bundle');
    // Production also accepts Sandbox: Apple's reviewers buy with sandbox testers (only accounts the owner creates)
    const allowed = env.appleEnv === 'Sandbox' ? ['Sandbox', 'Xcode'] : ['Production', 'Sandbox'];
    if (obj.environment && !allowed.includes(obj.environment)) throw new HttpError(400, 'wrong_environment');
  }
  /** What a notification means for access. Returns null for types that change nothing (TEST, PRICE_INCREASE…). */
  function appleState(type, subtype, tx, renewal) {
    const exp = isoMs(tx?.expiresDate);
    const valid = exp && exp > new Date().toISOString();
    const autoRenew = renewal ? Number(renewal.autoRenewStatus) === 1 : undefined;
    if (tx?.revocationDate && type !== 'REFUND_REVERSED') return { state: tx.revocationReason === 1 || type === 'REFUND' ? 'refunded' : 'revoked', expires: exp, reason: type === 'REVOKE' ? 'family_revoked' : 'refund', autoRenew: false };
    switch (type) {
      case 'verify': case 'SUBSCRIBED': case 'DID_RENEW': case 'OFFER_REDEEMED': case 'RENEWAL_EXTENDED': case 'DID_CHANGE_RENEWAL_PREF': case 'REFUND_REVERSED':
        return { state: valid ? (autoRenew === false ? 'cancelled' : 'active') : 'expired', expires: exp, autoRenew, clearReason: type === 'REFUND_REVERSED' };
      case 'DID_CHANGE_RENEWAL_STATUS':
        return { state: valid ? (subtype === 'AUTO_RENEW_DISABLED' ? 'cancelled' : 'active') : 'expired', expires: exp, autoRenew: subtype === 'AUTO_RENEW_ENABLED' };
      case 'DID_FAIL_TO_RENEW':
        return subtype === 'GRACE_PERIOD'
          ? { state: 'grace', expires: isoMs(renewal?.gracePeriodExpiresDate) || exp, autoRenew }
          : { state: 'on_hold', expires: exp, autoRenew };
      case 'EXPIRED': case 'GRACE_PERIOD_EXPIRED': return { state: 'expired', expires: exp, autoRenew: false };
      case 'REFUND': return { state: 'refunded', expires: exp, reason: 'refund', autoRenew: false };
      case 'REVOKE': return { state: 'revoked', expires: exp, reason: 'family_revoked', autoRenew: false };
      default: return null;
    }
  }
  async function applyApple({ eventId, type, subtype, tx, renewal, caller = null, environment }) {
    const products = await getProducts(db);
    const tokenOwner = await ownerOfAccountId(db, tx.appAccountToken);
    if (caller) {
      if (tokenOwner && !sameOwner(tokenOwner, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
      await assertProductFor(db, caller, products[tx.productId]);
    }
    const pack = products[tx.productId];
    if (pack?.tier === 'pack') return applyApplePack({ eventId, type, tx, caller, tokenOwner, map: pack, environment, products });
    const s = appleState(type, subtype, tx, renewal);
    if (!s) return logOnly('apple', eventId, type, { subtype, productId: tx.productId });
    return processEvent(db, {
      platform: 'apple', eventId, type, key: { otx: String(tx.originalTransactionId) }, initial: { product_id: tx.productId },
      details: { subtype, transactionId: tx.transactionId, productId: tx.productId },
      update: async (ent) => {
        const bound = entOwner(ent);
        if (caller && bound && !sameOwner(bound, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
        if (!bound && (caller || tokenOwner)) { const o = caller || tokenOwner; ent.owner_type = o.type; ent.owner_id = o.id; }
        let state = s.state;
        if (sticky(ent) && !s.clearReason && !['refunded', 'revoked'].includes(state)) state = ent.state;
        ent._newPeriod = !!tx.transactionId && String(tx.transactionId) !== ent.last_order_id && ['SUBSCRIBED', 'DID_RENEW', 'verify'].includes(type);
        Object.assign(ent, {
          product_id: tx.productId, state, expires_at: s.expires || ent.expires_at || null,
          auto_renew: s.autoRenew ?? !!Number(ent.auto_renew), last_order_id: String(tx.transactionId || ent.last_order_id || ''),
          environment: environment || tx.environment || null, acknowledged: 1,
          reason: s.clearReason ? null : (s.reason || ent.reason || null),
          raw: { type, subtype, productId: tx.productId, transactionId: tx.transactionId, expiresDate: tx.expiresDate, revocationDate: tx.revocationDate, autoRenewStatus: renewal?.autoRenewStatus, gracePeriodExpiresDate: renewal?.gracePeriodExpiresDate },
        });
      },
    });
  }

  /** v8.3 the AI pack bought on iPhone (an App Store consumable): the signed transaction is Apple's proof; credited once;
   *  a REFUND / REVOKE notification takes the budget back. */
  async function applyApplePack({ eventId, type, tx, caller, tokenOwner, map, environment, products }) {
    const refunded = !!tx.revocationDate || ['REFUND', 'REVOKE'].includes(type);
    if (!refunded && !['verify', 'ONE_TIME_CHARGE', 'CONSUMPTION_REQUEST', 'REFUND_REVERSED'].includes(type)) return logOnly('apple', eventId, type, { productId: tx.productId });
    if (type === 'CONSUMPTION_REQUEST') return logOnly('apple', eventId, type, { productId: tx.productId });
    return processEvent(db, {
      platform: 'apple', eventId, type, key: { otx: String(tx.transactionId || tx.originalTransactionId) }, initial: { product_id: tx.productId },
      details: { transactionId: tx.transactionId, productId: tx.productId },
      update: async (ent) => {
        const bound = entOwner(ent);
        if (caller && bound && !sameOwner(bound, caller)) throw new HttpError(409, 'purchase_belongs_to_another_account');
        if (!bound && (caller || tokenOwner)) { const o = caller || tokenOwner; ent.owner_type = o.type; ent.owner_id = o.id; }
        if (refunded) { ent.state = 'refunded'; ent.reason = 'refund'; } else if (!sticky(ent)) ent.state = 'active';
        Object.assign(ent, { product_id: tx.productId, last_order_id: String(tx.transactionId || ''), environment: environment || tx.environment || null, auto_renew: false, acknowledged: 1,
          raw: { type, productId: tx.productId, transactionId: tx.transactionId, revocationDate: tx.revocationDate } });
      },
      after: async (q, ent) => {
        if (refunded) { await refundPack(q, ent, products); return []; }
        return creditPack(q, ent, map);
      },
    });
  }

  /** v8.4 the owner hid the AI MANAGER from stores / drivers (admin → prices): its products are not offered there. */
  async function offered(o, list) {
    let hid = {};
    try { const r = await db.one(`SELECT value FROM app_meta WHERE key = 'plans'`); hid = (r ? JSON.parse(r.value) : {}).aiHidden || {}; } catch { hid = {}; }
    if (!(o.type === 'driver' ? hid.drivers : hid.stores)) return list;
    return list.filter((p) => !['ai', 'branch_ai'].includes(p.tier));   // packs stay for those who already have AI
  }
  const view = async (o, products) => {
    const rows = await db.query('SELECT * FROM billing_entitlements WHERE owner_type = $1 AND owner_id = $2 ORDER BY id DESC LIMIT 20', [o.type, o.id]);
    const acct = o.type === 'store' ? await db.one('SELECT ai_until FROM cooks WHERE id = $1', [o.id]) : await db.one('SELECT ai_until, jobs_until FROM drivers WHERE id = $1', [o.id]);
    return { aiUntil: acct?.ai_until || null, ...(o.type === 'driver' ? { jobsUntil: acct?.jobs_until || null } : {}), entitlements: rows.map((r) => publicEntitlement(r, products)) };
  };
  const result = async (res, r, o) => {
    const products = await getProducts(db);
    const e = r.entitlement;
    return ok(res, { entitlement: e ? publicEntitlement(e, products) : null, granted: !!e && ['active', 'grace', 'cancelled'].includes(e.state) && !!e.expires_at && e.expires_at > new Date().toISOString(), ...(await view(o, products)) });
  };

  return [
    /* ----- the app (logged-in store or driver) ----- */
    // The plans this account can buy in the store app (no product id is hard-coded in the app).
    ['GET', /^\/api\/billing\/products$/, subscriber(async (req, res, m, o) => {
      const e = E();
      return ok(res, { google: googleReady(e), apple: appleReady(e), products: await offered(o, await productsFor(db, o, await getProducts(db))) });
    })],
    ['GET', /^\/api\/billing\/me$/, subscriber(async (req, res, m, o) => {
      const products = await getProducts(db);
      const main = await payerOf(db, o);
      const own = await view(o, products);
      if (sameOwner(main, o)) return ok(res, own);
      const root = await view(main, products);   // a branch also sees the main account's plans
      return ok(res, { ...own, entitlements: [...own.entitlements, ...root.entitlements] });
    })],
    // The opaque id to attach to the purchase (Google obfuscatedExternalAccountId / Apple appAccountToken).
    ['GET', /^\/api\/billing\/(google|apple)\/prepare$/, subscriber(async (req, res, m, o) => {
      if (m[1] === 'google') needGoogle(); else needApple();
      await throttle(o);
      const productId = new URL(req.url, 'http://x').searchParams.get('productId') || '';
      if (!PRODUCT_RE.test(productId)) throw new HttpError(422, 'validation_failed', { fields: { productId: 'invalid' } });
      const map = (await getProducts(db))[productId];
      const payer = await payerFor(db, o, map);
      await assertProductFor(db, payer, map);
      if (map && ['ai', 'branch_ai'].includes(map.tier) && !(await offered(payer, [map])).length) throw new HttpError(409, 'ai_not_offered');
      return ok(res, { productId, accountId: await accountIdFor(db, payer) });
    })],
    ['POST', /^\/api\/billing\/google\/verify$/, subscriber(async (req, res, m, o) => {
      needGoogle();
      await throttle(o);
      const b = await readJson(req, 16 * 1024);
      const productId = String(b.productId || ''), token = String(b.purchaseToken || '');
      if (!PRODUCT_RE.test(productId) || !TOKEN_RE.test(token)) throw new HttpError(422, 'validation_failed', { fields: { ...(PRODUCT_RE.test(productId) ? {} : { productId: 'invalid' }), ...(TOKEN_RE.test(token) ? {} : { purchaseToken: 'invalid' }) } });
      const map = (await getProducts(db))[productId];
      const payer = await payerFor(db, o, map);
      const r = map?.tier === 'pack'
        ? await syncGooglePack(token, { hint: productId, caller: payer, eventId: `verify:${randomUUID()}`, type: 'verify' })
        : await syncGoogle(token, { hint: productId, caller: payer, eventId: `verify:${randomUUID()}`, type: 'verify' });
      return result(res, r, payer);
    })],
    ['POST', /^\/api\/billing\/apple\/verify$/, subscriber(async (req, res, m, o) => {
      const env = needApple();
      await throttle(o);
      const b = await readJson(req, 64 * 1024);
      const tx = appleJws(b.signedTransaction);
      appleChecks(env, tx);
      if (!tx.originalTransactionId || !tx.productId) throw new HttpError(400, 'invalid_transaction');
      const payer = await payerFor(db, o, (await getProducts(db))[tx.productId]);
      const r = await applyApple({ eventId: `verify:${randomUUID()}`, type: 'verify', tx, caller: payer, environment: tx.environment });
      return result(res, r, payer);
    })],

    /* ----- Google Real-time Developer Notifications (Pub/Sub push) ----- */
    ['POST', /^\/api\/billing\/google\/rtdn$/, async (req, res) => {
      const env = E();
      if (!googleReady(env) || !env.rtdnToken) throw new HttpError(503, 'billing_not_configured');
      await rtdnAuth(req, new URL(req.url, 'http://x'), env);
      const body = await readJson(req, 64 * 1024);
      const msg = body.message || {};
      const eventId = String(msg.messageId || msg.message_id || '');
      if (!eventId) throw new HttpError(400, 'invalid_message');
      let n;
      try { n = JSON.parse(Buffer.from(String(msg.data || ''), 'base64').toString('utf8')); } catch { throw new HttpError(400, 'invalid_message'); }
      // answers 200 to everything we deliberately ignore, so Pub/Sub stops re-sending it
      if (n.packageName !== env.package) return ok(res, { ignored: 'other_package' });
      if (await seen('google', eventId)) return ok(res, { duplicate: true });
      if (n.testNotification) return ok(res, await logOnly('google', eventId, 'test', {}));
      const vp = n.voidedPurchaseNotification;
      if (vp) {   // refunded / charged back: access is taken back at once
        const ent = vp.purchaseToken && TOKEN_RE.test(vp.purchaseToken) ? await findEntitlement(db, 'google', { token: vp.purchaseToken }) : null;
        if (!ent) return ok(res, await logOnly('google', eventId, 'voided_unknown', { orderId: vp.orderId }));
        const r = await processEvent(db, {
          platform: 'google', eventId, type: 'voided', key: { token: vp.purchaseToken }, details: { orderId: vp.orderId, refundType: vp.refundType },
          update: (e) => { e.state = Number(vp.refundType) === 2 ? 'revoked' : 'refunded'; e.reason = 'voided'; e.auto_renew = false; },
          after: async (q, e, prods) => { await refundPack(q, e, prods); return []; },
        });
        return ok(res, { duplicate: r.duplicate });
      }
      const on = n.oneTimeProductNotification;
      if (on?.purchaseToken && TOKEN_RE.test(on.purchaseToken) && PRODUCT_RE.test(String(on.sku || ''))) {
        if (Number(on.notificationType) !== 1) return ok(res, await logOnly('google', eventId, `otp_${Number(on.notificationType) || 0}`, { sku: on.sku }));
        try { const r = await syncGooglePack(on.purchaseToken, { hint: on.sku, eventId, type: 'otp_purchased' }); return ok(res, { duplicate: r.duplicate }); }
        catch (e) { if (e instanceof HttpError && ['invalid_purchase_token', 'unknown_product'].includes(e.code)) return ok(res, await logOnly('google', eventId, 'otp_gone', {})); throw e; }
      }
      const sn = n.subscriptionNotification;
      if (!sn?.purchaseToken || !TOKEN_RE.test(sn.purchaseToken)) return ok(res, await logOnly('google', eventId, 'other', {}));
      const type = `sub_${Number(sn.notificationType) || 0}`;
      try {
        // never trust the message alone: ask Google for the current state of this purchase
        const r = await syncGoogle(sn.purchaseToken, { eventId, type, ...(Number(sn.notificationType) === 12 ? { forceState: 'revoked', reason: 'revoked' } : {}) });
        return ok(res, { duplicate: r.duplicate });
      } catch (e) {
        if (e instanceof HttpError && e.code === 'invalid_purchase_token') return ok(res, await logOnly('google', eventId, `${type}_gone`, {}));
        throw e;   // Google unreachable → 5xx, Pub/Sub retries later
      }
    }],

    /* ----- App Store Server Notifications V2 ----- */
    ['POST', /^\/api\/billing\/apple\/notify$/, async (req, res) => {
      const env = needApple();
      const body = await readJson(req, 256 * 1024);
      const n = appleJws(body.signedPayload);
      const data = n.data || {};
      appleChecks(env, data);
      const eventId = String(n.notificationUUID || '');
      if (!eventId) throw new HttpError(400, 'invalid_notification');
      if (await seen('apple', eventId)) return ok(res, { duplicate: true });
      const tx = data.signedTransactionInfo ? appleJws(data.signedTransactionInfo) : null;
      const renewal = data.signedRenewalInfo ? appleJws(data.signedRenewalInfo) : null;
      if (!tx) return ok(res, await logOnly('apple', eventId, n.notificationType || 'unknown', { subtype: n.subtype }));
      appleChecks(env, tx);
      const r = await applyApple({ eventId, type: n.notificationType, subtype: n.subtype, tx, renewal, environment: data.environment });
      return ok(res, { duplicate: r.duplicate });
    }],

    /* ----- owner's admin panel ----- */
    ['GET', /^\/api\/admin\/billing\/config$/, owner(async (req, res) => {
      const e = E();
      const raw = cfg.billing?.env || process.env;
      const base = publicBaseUrl(req, cfg);
      return ok(res, {
        products: await getProducts(db),
        // which variables are set — never their values
        env: {
          GOOGLE_PLAY_PACKAGE: !!e.package,
          GOOGLE_PLAY_SERVICE_ACCOUNT_JSON: e.serviceAccount ? 'ok' : (e.serviceAccountSet ? 'invalid' : false),
          GOOGLE_RTDN_TOKEN: !!e.rtdnToken, GOOGLE_RTDN_AUDIENCE: !!e.rtdnAudience,
          APPLE_BUNDLE_ID: !!e.appleBundle, APPLE_ENVIRONMENT: !!raw.APPLE_ENVIRONMENT,
        },
        google: googleReady(e), rtdn: googleReady(e) && !!e.rtdnToken, apple: appleReady(e), appleEnvironment: e.appleEnv,
        googleOnly: ctx.settings?.get?.()?.googleOnly !== false,
        urls: { rtdn: `${base}/api/billing/google/rtdn?token=…`, apple: `${base}/api/billing/apple/notify` },
      });
    })],
    ['PUT', /^\/api\/admin\/billing\/products$/, owner(async (req, res, m, a) => {
      const b = await readJson(req);
      const products = cleanProducts(b.products);
      if (!products) throw new HttpError(422, 'validation_failed', { fields: { products: 'invalid' } });
      await saveProducts(db, products);
      await logAdminAction(db, a.id, null, 'billing_products', { count: Object.keys(products).length, hash: createHash('sha256').update(JSON.stringify(products)).digest('hex').slice(0, 12) });
      return ok(res, { products });
    })],
    ['GET', /^\/api\/admin\/billing\/entitlements$/, owner(async (req, res) => {
      const u = new URL(req.url, 'http://x').searchParams;
      const where = [], params = [];
      const st = u.get('state'), pf = u.get('platform');
      if (st && STATES.includes(st)) { params.push(st); where.push(`e.state = $${params.length}`); }
      if (pf && ['google', 'apple'].includes(pf)) { params.push(pf); where.push(`e.platform = $${params.length}`); }
      const rows = await db.query(`SELECT e.id, e.platform, e.product_id, e.owner_type, e.owner_id, e.state, e.expires_at, e.auto_renew, e.acknowledged, e.environment,
          e.reason, e.last_event_at, e.created_at, COALESCE(c.full_name, d.full_name) AS owner_name
        FROM billing_entitlements e
        LEFT JOIN cooks c ON e.owner_type = 'store' AND c.id = e.owner_id
        LEFT JOIN drivers d ON e.owner_type = 'driver' AND d.id = e.owner_id
        ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY e.id DESC LIMIT 300`, params);
      return ok(res, { entitlements: rows });
    })],
    ['GET', /^\/api\/admin\/billing\/events$/, owner(async (req, res) => {
      const ent = Number(new URL(req.url, 'http://x').searchParams.get('entitlement')) || 0;
      const rows = await db.query(`SELECT id, platform, event_id, type, entitlement_id, owner_type, owner_id, state_before, state_after, details, created_at
        FROM billing_events ${ent ? 'WHERE entitlement_id = $1' : ''} ORDER BY id DESC LIMIT 200`, ent ? [ent] : []);
      return ok(res, { events: rows });
    })],
    // Ask Google again about one purchase (e.g. after fixing the service account) — the owner's manual refresh.
    ['POST', /^\/api\/admin\/billing\/entitlements\/(\d+)\/resync$/, owner(async (req, res, m, a) => {
      const e = await db.one('SELECT id, platform, purchase_token, owner_type, owner_id FROM billing_entitlements WHERE id = $1', [Number(m[1])]);
      if (!e) throw new HttpError(404, 'not_found');
      if (e.platform !== 'google') throw new HttpError(409, 'not_supported');
      const r = await syncGoogle(e.purchase_token, { eventId: `admin:${randomUUID()}`, type: 'admin_resync' });
      await logAdminAction(db, a.id, e.owner_type === 'store' ? e.owner_id : null, 'billing_resync', { entitlement: e.id, state: r.entitlement?.state });
      return ok(res, { state: r.entitlement?.state || null });
    })],
  ];
}
