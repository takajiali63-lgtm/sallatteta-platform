// Sound effects manager routes.
//  Public:  GET /api/sounds/config?role=…   (small, ETag/304)   GET /media/sounds/…  (audio bytes, long cache, nosniff)
//  Owner:   /api/admin/sounds…  (agents and other roles get 403/401). Every change bumps the config version and is audited.
// Nothing here touches orders, money, subscriptions or accounts.
import { createHash } from 'node:crypto';
import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator } from '../lib/validate.js';
import { makeGuards } from '../lib/guards.js';
import {
  ROLES, EVENTS, EVENT_BY_KEY, BUILTIN, CATEGORIES, EXT_MIME, MAX_SOUND_BYTES,
  builtinFiles, builtinUrl, fileUrl, parseSoundUpload, loadState, allEffective, publicConfig,
} from '../services/sounds.js';

const YEAR = 'public, max-age=31536000, immutable';   // URLs carry ?v=<content hash>: a new file = a new URL
const now = () => new Date().toISOString();

/** Audio bytes with ETag and single-range support (Safari/iOS ask for byte ranges before playing). */
function sendAudio(req, res, buf, mime, etag) {
  const base = { 'Content-Type': mime, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': YEAR, ETag: etag, 'Accept-Ranges': 'bytes' };
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, base); return res.end(); }
  const range = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
  if (range && (range[1] || range[2])) {
    let start = range[1] ? Number(range[1]) : Math.max(0, buf.length - Number(range[2]));
    let end = range[1] && range[2] ? Math.min(Number(range[2]), buf.length - 1) : buf.length - 1;
    if (start >= buf.length || start > end) { res.writeHead(416, { ...base, 'Content-Range': `bytes */${buf.length}` }); return res.end(); }
    const part = buf.subarray(start, end + 1);
    res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${buf.length}`, 'Content-Length': part.length });
    return res.end(req.method === 'HEAD' ? undefined : part);
  }
  res.writeHead(200, { ...base, 'Content-Length': buf.length });
  return res.end(req.method === 'HEAD' ? undefined : buf);
}

export function soundsRoutes(ctx) {
  const { db, limiters = {} } = ctx;
  const { owner, limit } = makeGuards(ctx);
  // Per role: the last built config body, reused while the version in the database is unchanged (one tiny query per request).
  const built = new Map();

  async function bump(q, adminId, action, details) {
    await q.query('UPDATE sound_settings SET version = version + 1, updated_at = $1 WHERE id = 1', [now()]);
    await q.query('INSERT INTO admin_actions (admin_id, cook_id, action, details) VALUES ($1,$2,$3,$4)', [adminId, null, action, JSON.stringify(details)]);
  }
  async function adminView() {
    const st = await loadState(db);
    const library = [
      ...Object.entries(BUILTIN).filter(([n]) => builtinFiles()[n]).map(([n, label]) => ({ ref: `default:${n}`, name: label, builtin: true, mime: 'audio/wav', size: builtinFiles()[n].buf.length, url: builtinUrl(n) })),
      ...st.files.map((f) => ({ ref: `file:${f.id}`, id: f.id, name: f.name, builtin: false, mime: f.mime, size: Number(f.size), url: fileUrl(f), createdAt: f.created_at })),
    ];
    return { enabled: st.enabled, version: st.version, roles: ROLES, categories: CATEGORIES, maxBytes: MAX_SOUND_BYTES, events: allEffective(st), library };
  }
  // A sound reference the owner may assign: a built-in name or an existing uploaded file.
  async function soundRefOk(ref) {
    const m = /^(default|file):([a-z_]+|\d+)$/.exec(String(ref || ''));
    if (!m) return false;
    if (m[1] === 'default') return !!BUILTIN[m[2]];
    return !!(await db.one('SELECT id FROM sound_files WHERE id = $1', [Number(m[2])]));
  }
  const uploadErr = (v, field, error) => v.fail(field, error);

  return [
    // ---------- public ----------
    ['GET', /^\/api\/sounds\/config$/, async (req, res) => {
      const role = new URL(req.url, 'http://x').searchParams.get('role');
      if (!ROLES.includes(role)) throw new HttpError(422, 'validation_failed', { fields: { role: 'invalid' } });
      // No per-IP limit on purpose: many phones share one IP behind mobile carriers (CGNAT); a request costs one tiny query.
      const s = await db.one('SELECT enabled, version FROM sound_settings WHERE id = 1');
      const key = `${s?.version}|${s?.enabled}`;
      let b = built.get(role);
      if (!b || b.key !== key) {
        const body = JSON.stringify(publicConfig(await loadState(db), role));
        b = { key, body, etag: `"s${createHash('sha1').update(body).digest('base64url').slice(0, 20)}"` };
        built.set(role, b);
      }
      // no-cache = may be stored, but revalidated each time (a 304 costs a few bytes); offline the app uses its saved copy.
      const h = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache', ETag: b.etag };
      if (req.headers['if-none-match'] === b.etag) { res.writeHead(304, h); return res.end(); }
      res.writeHead(200, { ...h, 'Content-Length': Buffer.byteLength(b.body) });
      return res.end(b.body);
    }],
    ['GET', /^\/media\/sounds\/default\/([a-z_]+)\.wav$/, async (req, res, m) => {
      const f = BUILTIN[m[1]] && builtinFiles()[m[1]];   // whitelist: only the generated names, never a free path
      if (!f) throw new HttpError(404, 'not_found');
      return sendAudio(req, res, f.buf, 'audio/wav', `"${f.sha.slice(0, 20)}"`);
    }],
    ['GET', /^\/media\/sounds\/(\d+)\.([a-z0-9]{3,4})$/, async (req, res, m) => {
      const f = await db.one('SELECT mime, ext, sha256, data FROM sound_files WHERE id = $1', [Number(m[1])]);
      if (!f || f.ext !== m[2] || EXT_MIME[f.ext] !== f.mime) throw new HttpError(404, 'not_found');
      return sendAudio(req, res, Buffer.from(f.data, 'base64'), f.mime, `"${String(f.sha256).slice(0, 20)}"`);
    }],

    // ---------- owner ----------
    ['GET', /^\/api\/admin\/sounds$/, owner(async (req, res) => sendJson(res, 200, await adminView()))],

    ['PUT', /^\/api\/admin\/sounds\/settings$/, owner(async (req, res, m, a) => {
      const body = await readJson(req);
      const v = new Validator();
      if (typeof body.enabled !== 'boolean') v.fail('enabled', 'invalid');
      v.assert();
      await db.tx(async (q) => {
        await q.query('UPDATE sound_settings SET enabled = $1 WHERE id = 1', [body.enabled ? 1 : 0]);
        await bump(q, a.id, 'sounds_global', { enabled: body.enabled });
      });
      sendJson(res, 200, await adminView());
    })],

    ['PUT', /^\/api\/admin\/sounds\/events\/([a-z_]+)$/, owner(async (req, res, m, a) => {
      const ev = EVENT_BY_KEY[m[1]];
      if (!ev) throw new HttpError(404, 'not_found');
      const body = await readJson(req);
      const v = new Validator();
      const cur = allEffective(await loadState(db)).find((x) => x.key === ev.key);
      const next = { enabled: cur.enabled, volume: cur.volume, roles: cur.roles, sound: cur.sound };
      if (body.enabled !== undefined) { if (typeof body.enabled !== 'boolean') v.fail('enabled', 'invalid'); else next.enabled = body.enabled ? 1 : 0; }
      if (body.volume !== undefined) {
        if (!Number.isInteger(body.volume) || body.volume < 0 || body.volume > 100) v.fail('volume', 'invalid');
        else next.volume = body.volume;
      }
      if (body.roles !== undefined) {
        if (!Array.isArray(body.roles) || body.roles.some((r) => !ROLES.includes(r))) v.fail('roles', 'invalid');
        else next.roles = ROLES.filter((r) => body.roles.includes(r));   // de-duplicated, fixed order
      }
      if (body.sound !== undefined && !(await soundRefOk(body.sound))) v.fail('sound', 'invalid');
      else if (body.sound !== undefined) next.sound = body.sound;
      v.assert();
      await db.tx(async (q) => {
        await q.query('DELETE FROM sound_events WHERE event_key = $1', [ev.key]);
        await q.query('INSERT INTO sound_events (event_key, sound, enabled, volume, roles, updated_at) VALUES ($1,$2,$3,$4,$5,$6)',
          [ev.key, next.sound, next.enabled, next.volume, next.roles.join(','), now()]);
        await bump(q, a.id, 'sounds_event', { event: ev.key, ...next });
      });
      sendJson(res, 200, await adminView());
    })],

    ['POST', /^\/api\/admin\/sounds\/files$/, owner(async (req, res, m, a) => {
      await limit(limiters.upload, `snd-up:${a.id}`);
      const body = await readJson(req, 460 * 1024);   // 300 KB as base64 + JSON
      const v = new Validator();
      const name = String(body.name || '').trim().slice(0, 60) || 'صوت';
      const up = parseSoundUpload(body.dataUrl, body.fileName);
      if (up.error) uploadErr(v, 'dataUrl', up.error);
      let assign = null;
      if (body.event !== undefined) { if (!EVENT_BY_KEY[body.event]) v.fail('event', 'invalid'); else assign = body.event; }
      v.assert();
      let id;
      await db.tx(async (q) => {
        id = (await q.query('INSERT INTO sound_files (name, mime, ext, size, sha256, data, created_by, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id',
          [name, up.mime, up.ext, up.size, up.sha256, up.b64, a.id, now()]))[0].id;
        if (assign) {
          // "replace" from an event row: assign the new file to that event, keeping its other settings
          const o = await q.one('SELECT enabled, volume, roles FROM sound_events WHERE event_key = $1', [assign]);
          await q.query('DELETE FROM sound_events WHERE event_key = $1', [assign]);
          await q.query('INSERT INTO sound_events (event_key, sound, enabled, volume, roles, updated_at) VALUES ($1,$2,$3,$4,$5,$6)',
            [assign, `file:${id}`, o ? o.enabled : 1, o ? o.volume : null, o ? o.roles : null, now()]);
        }
        await bump(q, a.id, 'sounds_upload', { id, name, mime: up.mime, size: up.size, sha256: up.sha256, event: assign });
      });
      sendJson(res, 201, { id: Number(id), ...(await adminView()) });
    })],

    ['PUT', /^\/api\/admin\/sounds\/files\/(\d+)$/, owner(async (req, res, m, a) => {
      await limit(limiters.upload, `snd-up:${a.id}`);
      const id = Number(m[1]);
      if (!(await db.one('SELECT id FROM sound_files WHERE id = $1', [id]))) throw new HttpError(404, 'not_found');
      const body = await readJson(req, 460 * 1024);
      const v = new Validator();
      const up = body.dataUrl !== undefined ? parseSoundUpload(body.dataUrl, body.fileName) : null;
      if (up?.error) uploadErr(v, 'dataUrl', up.error);
      const name = body.name !== undefined ? String(body.name).trim().slice(0, 60) : null;
      if (name === '') v.fail('name', 'required');
      v.assert();
      await db.tx(async (q) => {
        if (name) await q.query('UPDATE sound_files SET name = $1, updated_at = $2 WHERE id = $3', [name, now(), id]);
        // new bytes → new sha → new URL (?v=…), so phones never play the old cached file
        if (up) await q.query('UPDATE sound_files SET mime = $1, ext = $2, size = $3, sha256 = $4, data = $5, updated_at = $6 WHERE id = $7', [up.mime, up.ext, up.size, up.sha256, up.b64, now(), id]);
        await bump(q, a.id, 'sounds_replace', { id, name, ...(up ? { mime: up.mime, size: up.size, sha256: up.sha256 } : {}) });
      });
      sendJson(res, 200, await adminView());
    })],

    ['DELETE', /^\/api\/admin\/sounds\/files\/(\d+)$/, owner(async (req, res, m, a) => {
      const id = Number(m[1]);
      if (!(await db.one('SELECT id FROM sound_files WHERE id = $1', [id]))) throw new HttpError(404, 'not_found');
      await db.tx(async (q) => {
        // events that used it go back to their built-in sound (never silence by accident)
        await q.query('UPDATE sound_events SET sound = NULL, updated_at = $1 WHERE sound = $2', [now(), `file:${id}`]);
        await q.query('DELETE FROM sound_files WHERE id = $1', [id]);
        await bump(q, a.id, 'sounds_delete', { id });
      });
      sendJson(res, 200, await adminView());
    })],

    ['POST', /^\/api\/admin\/sounds\/restore$/, owner(async (req, res, m, a) => {
      const body = await readJson(req);
      if (body.confirm !== true) throw new HttpError(422, 'validation_failed', { fields: { confirm: 'required' } });
      await db.tx(async (q) => {
        await q.query('DELETE FROM sound_events');                 // the uploaded library is kept, only assignments reset
        await q.query('UPDATE sound_settings SET enabled = 1 WHERE id = 1');
        await bump(q, a.id, 'sounds_restore', { events: EVENTS.length });
      });
      sendJson(res, 200, await adminView());
    })],
  ];
}
