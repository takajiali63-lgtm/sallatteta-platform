import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, validatePhoto } from '../lib/validate.js';
import { isValidLatLng, roundTo } from '../lib/geo.js';
import { normalizePhone, buildWhatsAppLink, fillTemplate } from '../lib/whatsapp.js';
import { randomToken, hmacHex, clientIp } from '../lib/security.js';
import { t, pickLocale } from '../lib/i18n.js';
import { searchNearbyCooks, isCookVisible, nearestArea, setCookServices, PLAN_KEYS } from '../services/cooks.js';
import { SERVICE_TYPES } from '../db/seed-data.js';

const MIN_FORM_MS = 1500; // a human needs at least this long to fill a form

function antiSpam(body) {
  // Honeypot field "website" is hidden from humans; bots fill it.
  if (body.website) throw new HttpError(400, 'rejected');
  const started = Number(body.startedAt);
  if (Number.isFinite(started) && Date.now() - started < MIN_FORM_MS) throw new HttpError(400, 'too_fast');
}

export function publicRoutes({ db, cfg, limiters }) {
  const limit = (limiter, req) => {
    const r = limiter.take(clientIp(req, cfg.trustProxy));
    if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
  };

  return [
    ['GET', /^\/api\/config$/, async (req, res) => {
      const locale = pickLocale(req, cfg.locales);
      const col = { en: 'name_en', fr: 'name_fr' }[locale] || 'name_ar';
      const areas = await db.query(
        `SELECT id, slug, region, COALESCE(${col}, name_ar) AS name FROM service_areas WHERE is_active = 1 ORDER BY sort_order, id`);
      const types = await db.query('SELECT key FROM service_types ORDER BY sort_order');
      sendJson(res, 200, {
        locales: cfg.locales,
        areas,
        serviceTypes: types.map((x) => x.key),
        plans: PLAN_KEYS,
        radiusOptionsKm: [2, 3, 5, 8, 10, 15, 20, 30],
        adminContactConfigured: !!cfg.adminWhatsapp,
      });
    }],

    // Customer search: stores the request, returns nearby active cooks (no phone numbers).
    ['POST', /^\/api\/search$/, async (req, res) => {
      limit(limiters.search, req);
      const body = await readJson(req, 16 * 1024);
      antiSpam(body);
      const locale = pickLocale(req, cfg.locales);
      const v = new Validator();
      const text = v.text('text', body.text, { min: 5, max: 1000, multiline: true });
      const serviceType = v.oneOf('serviceType', body.serviceType, SERVICE_TYPES, { required: false });
      const loc = body.location || {};
      let lat, lng, areaLabel, source;
      if (loc.type === 'gps') {
        lat = v.number('location', loc.lat, { min: -90, max: 90 });
        lng = v.number('location', loc.lng, { min: -180, max: 180 });
        source = 'gps';
      } else if (loc.type === 'area') {
        const areaId = v.int('location', loc.areaId, { min: 1 });
        if (areaId) {
          const col = { en: 'name_en', fr: 'name_fr' }[locale] || 'name_ar';
          const area = await db.one(`SELECT lat, lng, COALESCE(${col}, name_ar) AS name FROM service_areas WHERE id = $1 AND is_active = 1`, [areaId]);
          if (!area) v.fail('location', 'invalid');
          else { lat = area.lat; lng = area.lng; areaLabel = area.name; }
        }
        source = 'area';
      } else {
        v.fail('location', 'required');
      }
      v.assert();
      // Privacy: we only work with an approximate position (~100 m) and store it at ~1 km.
      lat = roundTo(lat, 3); lng = roundTo(lng, 3);
      if (!isValidLatLng(lat, lng)) throw new HttpError(422, 'validation_failed', { fields: { location: 'invalid' } });
      if (!areaLabel) areaLabel = (await nearestArea(db, lat, lng, locale))?.name || null;

      const cooks = await searchNearbyCooks(db, {
        lat, lng, serviceType, locale, maxRadiusKm: cfg.maxServiceRadiusKm, limit: cfg.searchResultLimit,
      });
      const publicId = randomToken(12);
      const saved = await db.one(
        `INSERT INTO requests (public_id, body, area_label, approx_lat, approx_lng, location_source, service_type_key, results_count, locale, ip_hash)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
        [publicId, text, areaLabel, roundTo(lat, 2), roundTo(lng, 2), source, serviceType, cooks.length, locale,
          hmacHex(cfg.sessionSecret, clientIp(req, cfg.trustProxy))]);
      for (const [i, c] of cooks.entries()) {
        await db.query('INSERT INTO request_impressions (request_id, cook_id, distance_km, position) VALUES ($1,$2,$3,$4)',
          [saved.id, c.id, c.distanceKm, i + 1]);
      }
      sendJson(res, 200, { requestId: publicId, areaLabel, cooks });
    }],

    // Customer taps "send via WhatsApp": returns the wa.me link for that one cook only.
    ['POST', /^\/api\/contact$/, async (req, res) => {
      limit(limiters.contact, req);
      const body = await readJson(req, 4 * 1024);
      const v = new Validator();
      const requestId = v.text('requestId', body.requestId, { min: 8, max: 40 });
      const cookId = v.int('cookId', body.cookId, { min: 1 });
      v.assert();
      const request = await db.one('SELECT id, body, area_label, locale, created_at FROM requests WHERE public_id = $1', [requestId]);
      if (!request) throw new HttpError(404, 'request_not_found');
      if (Date.now() - new Date(request.created_at).getTime() > 48 * 3600_000) throw new HttpError(410, 'request_expired');
      const shown = await db.one('SELECT 1 AS ok FROM request_impressions WHERE request_id = $1 AND cook_id = $2', [request.id, cookId]);
      if (!shown) throw new HttpError(404, 'cook_not_available');
      if (!(await isCookVisible(db, cookId))) throw new HttpError(404, 'cook_not_available');
      const cook = await db.one('SELECT whatsapp FROM cooks WHERE id = $1', [cookId]);
      const lang = request.locale || 'ar';
      const message = fillTemplate(t(lang, 'wa.customerMessage'), {
        request: request.body,
        area: request.area_label || '-',
      });
      await db.query('INSERT INTO request_contact_events (request_id, cook_id, channel) VALUES ($1,$2,$3)', [request.id, cookId, 'whatsapp']);
      sendJson(res, 200, { whatsappUrl: buildWhatsAppLink(cook.whatsapp, message) });
    }],

    // Cook applies to join. Saved as pending; a WhatsApp link to the admin is returned.
    ['POST', /^\/api\/cook-applications$/, async (req, res) => {
      limit(limiters.apply, req);
      const body = await readJson(req, 256 * 1024);
      antiSpam(body);
      const v = new Validator();
      const fullName = v.text('fullName', body.fullName, { min: 2, max: 80 });
      const rawPhone = v.text('whatsapp', body.whatsapp, { min: 6, max: 25 });
      const whatsapp = rawPhone ? normalizePhone(rawPhone, cfg.defaultCountryCode) : null;
      if (rawPhone && !whatsapp) v.fail('whatsapp', 'invalid_phone');
      const areaId = v.int('areaId', body.areaId, { min: 1 });
      const radiusKm = v.number('radiusKm', body.radiusKm, { min: 1, max: cfg.maxServiceRadiusKm });
      const services = Array.isArray(body.services) ? [...new Set(body.services)].filter((s) => SERVICE_TYPES.includes(s)) : [];
      if (!services.length) v.fail('services', 'required');
      const bio = v.text('bio', body.bio, { max: 300, required: false, multiline: true });
      const plan = v.oneOf('plan', body.plan, PLAN_KEYS);
      const photo = validatePhoto(body.photo, v);
      let lat = null, lng = null;
      if (body.lat != null && body.lng != null && body.lat !== '' && body.lng !== '') {
        lat = v.number('location', body.lat, { min: -90, max: 90 });
        lng = v.number('location', body.lng, { min: -180, max: 180 });
      }
      const area = areaId ? await db.one('SELECT id, name_ar, lat, lng FROM service_areas WHERE id = $1', [areaId]) : null;
      if (areaId && !area) v.fail('areaId', 'invalid');
      v.assert();
      const dup = await db.one(`SELECT id FROM cooks WHERE whatsapp = $1 AND status = 'pending'`, [whatsapp]);
      if (dup) throw new HttpError(409, 'application_exists');

      const cookId = await db.tx(async (q) => {
        const row = await q.one(
          `INSERT INTO cooks (full_name, whatsapp, area_id, area_label, lat, lng, service_radius_km, bio, photo, requested_plan, status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'pending') RETURNING id`,
          [fullName, whatsapp, area.id, area.name_ar, roundTo(lat ?? area.lat, 3), roundTo(lng ?? area.lng, 3), radiusKm, bio, photo ?? null, plan]);
        await setCookServices(q, row.id, services);
        await q.query(`INSERT INTO subscriptions (cook_id, plan, status, payment_status) VALUES ($1,$2,'pending','unpaid')`, [row.id, plan]);
        return row.id;
      });

      const lang = 'ar'; // admin messages are always in the admin's language
      const message = fillTemplate(t(lang, 'wa.adminApplication'), {
        id: cookId,
        name: fullName,
        whatsapp: '+' + whatsapp,
        area: area.name_ar,
        radius: radiusKm,
        services: services.map((s) => t(lang, `services.${s}`)).join('، '),
        plan: t(lang, `plans.${plan}`),
      });
      sendJson(res, 201, {
        applicationId: cookId,
        whatsappUrl: cfg.adminWhatsapp ? buildWhatsAppLink(cfg.adminWhatsapp, message) : null,
      });
    }],

    // Cook photo — only for cooks currently visible to customers.
    ['GET', /^\/media\/cooks\/(\d+)\.jpg$/, async (req, res, m) => {
      const id = Number(m[1]);
      if (!(await isCookVisible(db, id))) throw new HttpError(404, 'not_found');
      sendPhoto(res, (await db.one('SELECT photo FROM cooks WHERE id = $1', [id]))?.photo);
    }],

    ['GET', /^\/healthz$/, async (req, res) => {
      await db.one('SELECT 1 AS ok');
      sendJson(res, 200, { ok: true });
    }],
  ];
}

export function sendPhoto(res, dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(dataUrl || '');
  if (!m) throw new HttpError(404, 'not_found');
  const buf = Buffer.from(m[2], 'base64');
  res.writeHead(200, { 'Content-Type': m[1], 'Content-Length': buf.length, 'Cache-Control': 'private, max-age=300' });
  res.end(buf);
}
