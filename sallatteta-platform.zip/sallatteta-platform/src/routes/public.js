import { HttpError, readJson, sendJson } from '../lib/http.js';
import { Validator, validatePhoto } from '../lib/validate.js';
import { isValidLatLng, roundTo, haversineKm } from '../lib/geo.js';
import { normalizePhone, buildWhatsAppLink, fillTemplate } from '../lib/whatsapp.js';
import { randomToken, hmacHex, clientIp } from '../lib/security.js';
import { t, pickLocale } from '../lib/i18n.js';
import {
  searchCooksForArea, searchCooksByName, homeFeed, publicProfile, isCookVisible,
  setCookServices, setServedAreas, PLAN_KEYS,
} from '../services/cooks.js';
import { ensurePlacesAround } from '../services/osm.js';
import { normalizeName } from '../../public/assets/normalize.js';
import { SERVICE_TYPES, MAX_PHOTOS_PER_COOK } from '../db/seed-data.js';

const MIN_FORM_MS = 1500;
const REVIEW_WINDOW_DAYS = 60;

function antiSpam(body) {
  if (body.website) throw new HttpError(400, 'rejected'); // honeypot
  const started = Number(body.startedAt);
  if (Number.isFinite(started) && Date.now() - started < MIN_FORM_MS) throw new HttpError(400, 'too_fast');
}

export function publicRoutes({ db, cfg, limiters, areas, images, cache }) {
  const ip = (req) => clientIp(req, cfg.trustProxy);
  const limit = (limiter, req) => {
    const r = limiter.take(ip(req));
    if (!r.ok) throw new HttpError(429, 'rate_limited', { retryAfterSec: r.retryAfterSec });
  };
  const viewerHash = (id) => {
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(String(id || ''))) throw new HttpError(422, 'validation_failed', { fields: { viewerId: 'invalid' } });
    return hmacHex(cfg.sessionSecret, `viewer:${id}`);
  };
  const cookIdFrom = (m) => Number(m[1]);
  const placesOpts = { fetcher: cfg.placesFetcher, log: cfg.quiet ? {} : console };
  const withPlaces = (lat, lng) => ensurePlacesAround(db, areas, lat, lng, { km: 15, ...(placesOpts.fetcher ? { fetcher: placesOpts.fetcher } : {}), log: placesOpts.log });

  /** Saves a customer request and the cooks shown for it; returns its public id. */
  async function saveRequest(req, { text, area, point, source, serviceType, locale, cooks }) {
    const publicId = randomToken(12);
    const saved = await db.one(
      `INSERT INTO requests (public_id, body, area_label, approx_lat, approx_lng, location_source, service_type_key, results_count, locale, ip_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [publicId, text, area.name_ar, roundTo(point.lat, 2), roundTo(point.lng, 2), source, serviceType, cooks.length, locale,
        hmacHex(cfg.sessionSecret, ip(req))]);
    for (const [i, c] of cooks.entries()) {
      await db.query('INSERT INTO request_impressions (request_id, cook_id, distance_km, position) VALUES ($1,$2,$3,$4)',
        [saved.id, c.id, c.distanceKm ?? 0, i + 1]);
    }
    return publicId;
  }

  return [
    ['GET', /^\/api\/config$/, async (req, res) => {
      const locale = pickLocale(req, cfg.locales);
      sendJson(res, 200, await cache.get(`config:${locale}`, 5 * 60_000, async () => ({
        locales: cfg.locales,
        serviceTypes: (await db.query('SELECT key FROM service_types ORDER BY sort_order')).map((x) => x.key),
        plans: PLAN_KEYS,
        districts: areas.districts(locale),
        maxPhotos: MAX_PHOTOS_PER_COOK,
        adminContactConfigured: !!cfg.adminWhatsapp,
      })));
    }],

    /* ---------- villages ---------- */
    ['GET', /^\/api\/areas\/search$/, async (req, res) => {
      limit(limiters.lookup, req);
      const url = new URL(req.url, 'http://x');
      sendJson(res, 200, { areas: areas.search(url.searchParams.get('q') || '', { locale: pickLocale(req, cfg.locales) }) });
    }],
    ['GET', /^\/api\/areas\/nearby$/, async (req, res) => {
      const url = new URL(req.url, 'http://x');
      const km = Math.min(30, Math.max(1, Number(url.searchParams.get('km')) || 15));
      sendJson(res, 200, { areas: areas.nearby(url.searchParams.get('areaId'), { km, locale: pickLocale(req, cfg.locales) }) });
    }],
    // Villages & areas around the cook's GPS position (from OpenStreetMap, saved locally).
    ['GET', /^\/api\/areas\/around$/, async (req, res) => {
      limit(limiters.places, req);
      const url = new URL(req.url, 'http://x');
      const lat = Number(url.searchParams.get('lat')), lng = Number(url.searchParams.get('lng'));
      if (!isValidLatLng(lat, lng)) throw new HttpError(422, 'validation_failed', { fields: { location: 'invalid' } });
      const r = await withPlaces(lat, lng);
      const locale = pickLocale(req, cfg.locales);
      const near = areas.nearest(lat, lng);
      sendJson(res, 200, {
        source: r.source,
        nearest: near ? areas.view(near, locale, { distanceKm: roundTo(haversineKm(lat, lng, near.lat, near.lng), 1) }) : null,
        areas: areas.around(lat, lng, { km: 15, locale }),
      });
    }],
    ['GET', /^\/api\/areas\/nearest$/, async (req, res) => {
      const url = new URL(req.url, 'http://x');
      const lat = Number(url.searchParams.get('lat')), lng = Number(url.searchParams.get('lng'));
      if (!isValidLatLng(lat, lng)) throw new HttpError(422, 'validation_failed', { fields: { location: 'invalid' } });
      sendJson(res, 200, { area: areas.view(areas.nearest(lat, lng), pickLocale(req, cfg.locales)) });
    }],
    ['GET', /^\/api\/areas\/district$/, async (req, res) => {
      const url = new URL(req.url, 'http://x');
      sendJson(res, 200, { areas: areas.inDistrict(url.searchParams.get('key') || '', pickLocale(req, cfg.locales)) });
    }],

    /* ---------- customer search & contact ---------- */
    ['POST', /^\/api\/search$/, async (req, res) => {
      limit(limiters.search, req);
      const body = await readJson(req, 16 * 1024);
      antiSpam(body);
      const locale = pickLocale(req, cfg.locales);
      const v = new Validator();
      const text = v.text('text', body.text, { min: 5, max: 1000, multiline: true });
      const serviceType = v.oneOf('serviceType', body.serviceType, SERVICE_TYPES, { required: false });
      const loc = body.location || (body.areaId ? { type: 'area', areaId: body.areaId } : {});
      let area = null, point = null, source = null;
      if (loc.type === 'gps') {
        const lat = v.number('location', loc.lat, { min: -90, max: 90 });
        const lng = v.number('location', loc.lng, { min: -180, max: 180 });
        if (isValidLatLng(lat, lng)) {
          point = { lat: roundTo(lat, 3), lng: roundTo(lng, 3) };
          withPlaces(point.lat, point.lng).catch(() => {}); // learn the villages around the customer in the background
          area = areas.nearest(point.lat, point.lng);
          source = 'gps';
        }
      } else if (loc.type === 'area') {
        area = areas.get(loc.areaId);
        if (!area) v.fail('location', 'invalid');
        else { point = { lat: area.lat, lng: area.lng }; source = 'area'; }
      } else {
        v.fail('location', 'required');
      }
      v.assert();
      // GPS: the nearest village + any place within 1.5 km (small villages sit next to each other). Typed village: exactly that one.
      const areaIds = source === 'gps' ? areas.idsNear(point.lat, point.lng, 1.5) : [area.id];
      const cooks = await searchCooksForArea(db, areas, { areaIds, point, serviceType, locale, limit: cfg.searchResultLimit });
      const requestId = await saveRequest(req, { text, area, point, source, serviceType, locale, cooks });
      const areaView = areas.view(area, locale, { distanceKm: roundTo(haversineKm(point.lat, point.lng, area.lat, area.lng), 1) });
      sendJson(res, 200, { requestId, area: areaView, areaLabel: areaView.name, cooks });
    }],

    // Order straight from a cook's page (the customer already knows her).
    ['POST', /^\/api\/cooks\/(\d+)\/request$/, async (req, res, m) => {
      limit(limiters.search, req);
      const body = await readJson(req, 16 * 1024);
      antiSpam(body);
      const locale = pickLocale(req, cfg.locales);
      const v = new Validator();
      const text = v.text('text', body.text, { min: 5, max: 1000, multiline: true });
      // The customer's GPS position (the website requires it); a village id is still accepted for API clients.
      let area = null, point = null;
      if (body.lat != null && body.lng != null) {
        const lat = v.number('location', body.lat, { min: -90, max: 90 });
        const lng = v.number('location', body.lng, { min: -180, max: 180 });
        if (lat != null && lng != null && isValidLatLng(lat, lng)) {
          point = { lat: roundTo(lat, 3), lng: roundTo(lng, 3) };
          withPlaces(point.lat, point.lng).catch(() => {});
          area = areas.nearest(point.lat, point.lng);
        } else v.fail('location', 'invalid');
      } else if (body.areaId) {
        area = areas.get(body.areaId);
        if (!area) v.fail('location', 'invalid'); else point = { lat: area.lat, lng: area.lng };
      } else v.fail('location', 'location_required');
      v.assert();
      const cookId = cookIdFrom(m);
      if (!(await isCookVisible(db, cookId))) throw new HttpError(404, 'cook_not_available');
      const cookRow = await db.one('SELECT lat, lng FROM cooks WHERE id = $1', [cookId]);
      const requestId = await saveRequest(req, {
        text, area, point, source: 'profile', serviceType: null, locale,
        cooks: [{ id: cookId, distanceKm: roundTo(haversineKm(point.lat, point.lng, cookRow.lat, cookRow.lng), 1) }],
      });
      sendJson(res, 200, { requestId });
    }],

    // wa.me link for that one cook only, plus a private token that lets this customer rate her later.
    ['POST', /^\/api\/contact$/, async (req, res) => {
      limit(limiters.contact, req);
      const body = await readJson(req, 4 * 1024);
      const v = new Validator();
      const requestId = v.text('requestId', body.requestId, { min: 8, max: 40 });
      const cookId = v.int('cookId', body.cookId, { min: 1 });
      v.assert();
      const request = await db.one('SELECT id, body, area_label, locale, created_at FROM requests WHERE public_id = $1', [requestId]);
      if (!request) throw new HttpError(404, 'request_not_found');
      if (Date.now() - new Date(request.created_at).getTime() > 48 * 3600_000) throw new HttpError(410, 'request_expired');
      const shown = await db.one('SELECT 1 AS ok FROM request_impressions WHERE request_id = $1 AND cook_id = $2', [request.id, cookId]);
      if (!shown || !(await isCookVisible(db, cookId))) throw new HttpError(404, 'cook_not_available');
      const cook = await db.one('SELECT full_name, whatsapp FROM cooks WHERE id = $1', [cookId]);
      const message = fillTemplate(t(request.locale || 'ar', 'wa.customerMessage'), { request: request.body, area: request.area_label || '-' });
      const reviewToken = randomToken(18);
      await db.query('INSERT INTO request_contact_events (request_id, cook_id, channel, review_token) VALUES ($1,$2,$3,$4)',
        [request.id, cookId, 'whatsapp', reviewToken]);
      sendJson(res, 200, { whatsappUrl: buildWhatsAppLink(cook.whatsapp, message), reviewToken, cook: { id: cookId, name: cook.full_name } });
    }],

    /* ---------- discovery ---------- */
    ['GET', /^\/api\/feed$/, async (req, res) => {
      const locale = pickLocale(req, cfg.locales);
      sendJson(res, 200, await cache.get(`feed:${locale}`, 60_000, () => homeFeed(db, areas, { locale })));
    }],
    ['GET', /^\/api\/cooks\/search$/, async (req, res) => {
      limit(limiters.lookup, req);
      const q = new URL(req.url, 'http://x').searchParams.get('q') || '';
      sendJson(res, 200, { cooks: await searchCooksByName(db, areas, q, { locale: pickLocale(req, cfg.locales) }) });
    }],
    ['GET', /^\/api\/cooks\/(\d+)$/, async (req, res, m) => {
      const profile = await publicProfile(db, areas, cookIdFrom(m), { locale: pickLocale(req, cfg.locales) });
      if (!profile) throw new HttpError(404, 'cook_not_available');
      const viewer = new URL(req.url, 'http://x').searchParams.get('viewerId');
      if (viewer) {
        profile.likedByMe = !!(await db.one('SELECT 1 AS ok FROM cook_likes WHERE cook_id = $1 AND viewer_hash = $2', [profile.id, viewerHash(viewer)]));
      }
      sendJson(res, 200, profile);
    }],
    // A visit to her page (counted once per visitor per 12 hours).
    ['POST', /^\/api\/cooks\/(\d+)\/view$/, async (req, res, m) => {
      limit(limiters.lookup, req);
      const body = await readJson(req, 1024);
      const cookId = cookIdFrom(m);
      const vh = viewerHash(body.viewerId);
      if (!(await isCookVisible(db, cookId))) throw new HttpError(404, 'cook_not_available');
      const since = new Date(Date.now() - 12 * 3600_000).toISOString();
      const recent = await db.one('SELECT 1 AS ok FROM cook_page_views WHERE cook_id = $1 AND viewer_hash = $2 AND created_at >= $3', [cookId, vh, since]);
      if (!recent) await db.query('INSERT INTO cook_page_views (cook_id, viewer_hash) VALUES ($1,$2)', [cookId, vh]);
      sendJson(res, 200, { ok: true });
    }],
    ['POST', /^\/api\/cooks\/(\d+)\/like$/, async (req, res, m) => {
      limit(limiters.lookup, req);
      const body = await readJson(req, 1024);
      const cookId = cookIdFrom(m);
      const vh = viewerHash(body.viewerId);
      if (!(await isCookVisible(db, cookId))) throw new HttpError(404, 'cook_not_available');
      if (body.like === false) await db.query('DELETE FROM cook_likes WHERE cook_id = $1 AND viewer_hash = $2', [cookId, vh]);
      else await db.query('INSERT INTO cook_likes (cook_id, viewer_hash) VALUES ($1,$2) ON CONFLICT DO NOTHING', [cookId, vh]);
      const n = await db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM cook_likes WHERE cook_id = $1', [cookId]);
      sendJson(res, 200, { likes: n.n, likedByMe: body.like !== false });
    }],

    /* ---------- ratings (public average) & complaints (admin only) ---------- */
    ['POST', /^\/api\/reviews$/, async (req, res) => {
      limit(limiters.contact, req);
      const body = await readJson(req, 2 * 1024);
      const v = new Validator();
      const token = v.text('token', body.token, { min: 10, max: 60 });
      const rating = v.int('rating', body.rating, { min: 1, max: 5 });
      v.assert();
      const ev = await db.one('SELECT id, cook_id, created_at FROM request_contact_events WHERE review_token = $1', [token]);
      if (!ev) throw new HttpError(404, 'review_not_allowed');
      if (Date.now() - new Date(ev.created_at).getTime() > REVIEW_WINDOW_DAYS * 86400_000) throw new HttpError(410, 'review_expired');
      const existing = await db.one('SELECT id FROM reviews WHERE contact_event_id = $1', [ev.id]);
      if (existing) await db.query('UPDATE reviews SET rating = $1, updated_at = $2 WHERE id = $3', [rating, new Date().toISOString(), existing.id]);
      else await db.query('INSERT INTO reviews (cook_id, contact_event_id, rating) VALUES ($1,$2,$3)', [ev.cook_id, ev.id, rating]);
      sendJson(res, 200, { ok: true, cookId: ev.cook_id, rating });
    }],

    ['POST', /^\/api\/feedback$/, async (req, res) => {
      limit(limiters.feedback, req);
      const body = await readJson(req, 8 * 1024);
      antiSpam(body);
      const v = new Validator();
      const cookId = v.int('cookId', body.cookId, { min: 1 });
      const kind = v.oneOf('kind', body.kind, ['complaint', 'note']);
      const message = v.text('message', body.message, { min: 5, max: 1500, multiline: true });
      const name = v.text('name', body.name, { max: 60, required: false });
      const rawPhone = v.text('phone', body.phone, { max: 25, required: false });
      const phone = rawPhone ? normalizePhone(rawPhone, cfg.defaultCountryCode) : null;
      if (rawPhone && !phone) v.fail('phone', 'invalid_phone');
      v.assert();
      const cook = await db.one(`SELECT id FROM cooks WHERE id = $1 AND status <> 'rejected'`, [cookId]);
      if (!cook) throw new HttpError(404, 'not_found');
      await db.query(
        'INSERT INTO feedback (cook_id, kind, message, customer_name, customer_phone, ip_hash) VALUES ($1,$2,$3,$4,$5,$6)',
        [cookId, kind, message, name, phone, hmacHex(cfg.sessionSecret, ip(req))]);
      sendJson(res, 201, { ok: true });
    }],

    /* ---------- cook application ---------- */
    ['POST', /^\/api\/cook-applications$/, async (req, res) => {
      limit(limiters.apply, req);
      const body = await readJson(req, 256 * 1024);
      antiSpam(body);
      const v = new Validator();
      const fullName = v.text('fullName', body.fullName, { min: 2, max: 80 });
      const rawPhone = v.text('whatsapp', body.whatsapp, { min: 6, max: 25 });
      const whatsapp = rawPhone ? normalizePhone(rawPhone, cfg.defaultCountryCode) : null;
      if (rawPhone && !whatsapp) v.fail('whatsapp', 'invalid_phone');
      const served = Array.isArray(body.servedAreaIds) ? [...new Set(body.servedAreaIds.map(Number))].filter((id) => areas.get(id)).slice(0, 300) : [];
      if (!served.length) v.fail('servedAreaIds', 'pick_one_area');
      const services = Array.isArray(body.services) ? [...new Set(body.services)].filter((s) => SERVICE_TYPES.includes(s)) : [];
      if (!services.length) v.fail('services', 'required');
      const bio = v.text('bio', body.bio, { max: 300, required: false, multiline: true });
      const areaLabel = v.text('areaLabel', body.areaLabel, { max: 80, required: false }); // optional, for information
      const plan = v.oneOf('plan', body.plan, PLAN_KEYS);
      const photo = validatePhoto(body.photo, v);
      // GPS location is mandatory: it's how we find the villages around her.
      let lat = null, lng = null;
      if (body.lat == null || body.lng == null || body.lat === '' || body.lng === '') v.fail('location', 'location_required');
      else {
        lat = v.number('location', body.lat, { min: -90, max: 90 });
        lng = v.number('location', body.lng, { min: -180, max: 180 });
        if (lat != null && lng != null && !isValidLatLng(lat, lng)) v.fail('location', 'invalid');
      }
      v.assert();
      const picked = areas.get(body.areaId);
      const home = picked || areas.nearest(lat, lng);
      const homeLabel = areaLabel || home.name_ar;
      if (await db.one(`SELECT id FROM cooks WHERE whatsapp = $1 AND status = 'pending'`, [whatsapp])) throw new HttpError(409, 'application_exists');

      const img = await images.save('cooks', photo);
      const cookId = await db.tx(async (q) => {
        const row = await q.one(
          `INSERT INTO cooks (full_name, whatsapp, area_id, area_label, lat, lng, service_radius_km, bio, photo, requested_plan, admin_notes, status, photo_url, name_norm)
           VALUES ($1,$2,$3,$4,$5,$6,$11,$7,$8,$9,$10,'pending',$12,$13) RETURNING id`,
          [fullName, whatsapp, home.id, homeLabel, roundTo(lat, 4), roundTo(lng, 4), bio, img.data, plan, null, 0, img.url, normalizeName(fullName)]);
        await setCookServices(q, row.id, services);
        await setServedAreas(q, row.id, served);
        await q.query(`INSERT INTO subscriptions (cook_id, plan, status, payment_status) VALUES ($1,$2,'pending','unpaid')`, [row.id, plan]);
        return row.id;
      });

      const lang = 'ar';
      const servedNames = served.map((id) => areas.get(id).name_ar);
      const message = fillTemplate(t(lang, 'wa.adminApplication'), {
        id: cookId,
        name: fullName,
        whatsapp: '+' + whatsapp,
        area: homeLabel,
        map: `https://maps.google.com/?q=${roundTo(lat, 4)},${roundTo(lng, 4)}`,
        served: servedNames.length > 8 ? `${servedNames.slice(0, 8).join('، ')} و${servedNames.length - 8} بلدات أخرى` : servedNames.join('، '),
        services: services.map((s) => t(lang, `services.${s}`)).join('، '),
        plan: t(lang, `plans.${plan}`),
      });
      sendJson(res, 201, { applicationId: cookId, whatsappUrl: cfg.adminWhatsapp ? buildWhatsAppLink(cfg.adminWhatsapp, message) : null });
    }],

    /* ---------- media ---------- */
    ['GET', /^\/media\/cooks\/(\d+)\.jpg$/, async (req, res, m) => {
      const id = cookIdFrom(m);
      if (!(await isCookVisible(db, id))) throw new HttpError(404, 'not_found');
      const c = await db.one('SELECT photo, photo_url FROM cooks WHERE id = $1', [id]);
      if (c?.photo_url) return redirect(res, c.photo_url);
      sendPhoto(res, c?.photo);
    }],
    ['GET', /^\/media\/photos\/(\d+)\.jpg$/, async (req, res, m) => {
      const p = await db.one('SELECT cook_id, data, url, is_hidden FROM cook_photos WHERE id = $1', [Number(m[1])]);
      if (!p || p.is_hidden || !(await isCookVisible(db, p.cook_id))) throw new HttpError(404, 'not_found');
      if (p.url) return redirect(res, p.url);
      sendPhoto(res, p.data, 'public, max-age=86400');
    }],

    ['GET', /^\/healthz$/, async (req, res) => {
      await db.one('SELECT 1 AS ok');
      sendJson(res, 200, { ok: true });
    }],
  ];
}

export function redirect(res, url) {
  res.writeHead(302, { Location: url, 'Cache-Control': 'public, max-age=3600' });
  res.end();
}

export function sendPhoto(res, dataUrl, cache = 'private, max-age=300') {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(dataUrl || '');
  if (!m) throw new HttpError(404, 'not_found');
  const buf = Buffer.from(m[2], 'base64');
  res.writeHead(200, { 'Content-Type': m[1], 'Content-Length': buf.length, 'Cache-Control': cache });
  res.end(buf);
}
