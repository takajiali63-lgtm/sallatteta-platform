-- Written for PostgreSQL. The SQLite dev adapter translates the few type differences automatically.

CREATE TABLE IF NOT EXISTS admin_users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS admin_sessions (
  id SERIAL PRIMARY KEY,
  admin_id INTEGER NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL
);

-- Reserved for optional customer accounts in a later phase (registration is not required in v1).
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  display_name TEXT,
  phone TEXT UNIQUE,
  locale TEXT NOT NULL DEFAULT 'ar',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Towns / regions customers and cooks pick from (approximate centre coordinates).
CREATE TABLE IF NOT EXISTS service_areas (
  id SERIAL PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  name_fr TEXT,
  region TEXT,
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- Kinds of requests a cook can take (labels live in /locales/*.json under "services").
CREATE TABLE IF NOT EXISTS service_types (
  id SERIAL PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cooks (
  id SERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  area_id INTEGER REFERENCES service_areas(id) ON DELETE SET NULL,
  area_label TEXT NOT NULL,
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  service_radius_km DOUBLE PRECISION NOT NULL,
  bio TEXT,
  photo TEXT,
  requested_plan TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cooks_geo_idx ON cooks (lat, lng);
CREATE INDEX IF NOT EXISTS cooks_status_idx ON cooks (status);

CREATE TABLE IF NOT EXISTS cook_service_types (
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  service_type_id INTEGER NOT NULL REFERENCES service_types(id) ON DELETE CASCADE,
  PRIMARY KEY (cook_id, service_type_id)
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id SERIAL PRIMARY KEY,
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  plan TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','expired','suspended')),
  payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','paid','waived')),
  start_date TIMESTAMPTZ,
  expiry_date TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS subscriptions_cook_idx ON subscriptions (cook_id, status, expiry_date);

-- One row per customer search. Stores only the request text and a rounded (~1 km) location.
CREATE TABLE IF NOT EXISTS requests (
  id SERIAL PRIMARY KEY,
  public_id TEXT NOT NULL UNIQUE,
  body TEXT NOT NULL,
  area_label TEXT,
  approx_lat DOUBLE PRECISION,
  approx_lng DOUBLE PRECISION,
  location_source TEXT,
  service_type_key TEXT,
  results_count INTEGER NOT NULL DEFAULT 0,
  locale TEXT NOT NULL DEFAULT 'ar',
  ip_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS requests_created_idx ON requests (created_at);

-- Which cooks were shown for a request (analytics; only shown cooks can be contacted).
CREATE TABLE IF NOT EXISTS request_impressions (
  request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  distance_km DOUBLE PRECISION NOT NULL,
  position INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (request_id, cook_id)
);
CREATE INDEX IF NOT EXISTS impressions_cook_idx ON request_impressions (cook_id);

CREATE TABLE IF NOT EXISTS request_contact_events (
  id SERIAL PRIMARY KEY,
  request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  channel TEXT NOT NULL DEFAULT 'whatsapp',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS contact_events_cook_idx ON request_contact_events (cook_id, created_at);

CREATE TABLE IF NOT EXISTS admin_actions (
  id SERIAL PRIMARY KEY,
  admin_id INTEGER REFERENCES admin_users(id) ON DELETE SET NULL,
  cook_id INTEGER REFERENCES cooks(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  details TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
