// Tiny database adapter: PostgreSQL in production, SQLite (node:sqlite) for local dev/tests.
// All SQL in the app is written once, PostgreSQL-style ($1, $2 …), and kept portable.
import { readFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

export async function openDb(cfg) {
  const url = cfg.databaseUrl;
  if (url.startsWith('sqlite:')) return openSqlite(url.slice('sqlite:'.length));
  if (/^postgres(ql)?:\/\//.test(url)) return openPg(url, cfg.databaseSsl);
  throw new Error('DATABASE_URL must start with postgres:// or sqlite:');
}

async function openPg(url, ssl) {
  const { default: pg } = await import('pg');
  pg.types.setTypeParser(701, (v) => parseFloat(v)); // DOUBLE PRECISION → number
  const pool = new pg.Pool({
    connectionString: url,
    ssl: ssl ? { rejectUnauthorized: false } : undefined,
    max: 10,
  });
  const wrap = (client) => {
    const query = async (sql, params = []) => (await client.query(sql, params)).rows;
    return { query, one: async (sql, params) => (await query(sql, params))[0] || null };
  };
  return {
    kind: 'pg',
    ...wrap(pool),
    async exec(sqlText) { await pool.query(sqlText); },
    async tx(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const out = await fn(wrap(client));
        await client.query('COMMIT');
        return out;
      } catch (e) {
        await client.query('ROLLBACK');
        throw e;
      } finally {
        client.release();
      }
    },
    async close() { await pool.end(); },
  };
}

async function openSqlite(file) {
  const { DatabaseSync } = await import('node:sqlite');
  if (file !== ':memory:') await mkdir(dirname(resolve(file)), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  if (file !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
  const cache = new Map();
  const norm = (v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v instanceof Date ? v.toISOString() : v);
  const query = async (sql, params = []) => {
    let st = cache.get(sql);
    if (!st) { st = db.prepare(sql.replace(/\$(\d+)/g, '?$1')); cache.set(sql, st); }
    return st.all(...params.map(norm)).map((r) => ({ ...r }));
  };
  const one = async (sql, params) => (await query(sql, params))[0] || null;
  return {
    kind: 'sqlite',
    query,
    one,
    async exec(sqlText) { db.exec(sqlitify(sqlText)); },
    async tx(fn) {
      db.exec('BEGIN');
      try { const out = await fn({ query, one }); db.exec('COMMIT'); return out; }
      catch (e) { db.exec('ROLLBACK'); throw e; }
    },
    async close() { db.close(); },
  };
}

function sqlitify(sql) {
  return sql
    .replace(/SERIAL PRIMARY KEY/g, 'INTEGER PRIMARY KEY AUTOINCREMENT')
    .replace(/TIMESTAMPTZ/g, 'TEXT')
    .replace(/DOUBLE PRECISION/g, 'REAL')
    .replace(/DEFAULT now\(\)/g, "DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))");
}

// Idempotent: safe to run on every boot.
export async function migrate(db) {
  const schema = await readFile(resolve(here, 'schema.sql'), 'utf8');
  await db.exec(schema);
  const { SERVICE_TYPES, AREAS } = await import('./seed-data.js');
  for (const [i, key] of SERVICE_TYPES.entries()) {
    await db.query('INSERT INTO service_types (key, sort_order) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING', [key, i]);
  }
  for (const [i, a] of AREAS.entries()) {
    await db.query(
      `INSERT INTO service_areas (slug, name_ar, name_en, name_fr, region, lat, lng, sort_order)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (slug) DO NOTHING`,
      [a.slug, a.ar, a.en, a.fr || a.en, a.region, a.lat, a.lng, i],
    );
  }
}
