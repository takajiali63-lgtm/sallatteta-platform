-- v8.4 catalog: product options/extras, promotions, craftspeople's quotes, independent drivers' services and quotes.
-- Money in integer CENTS. Times compared in code are ISO text (portable between PostgreSQL and SQLite).

-- Option groups of a product ("Size": choose 1, required · "Extras": choose up to 3). min_select 0 = optional.
CREATE TABLE IF NOT EXISTS item_option_groups (
  id SERIAL PRIMARY KEY,
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  min_select INTEGER NOT NULL DEFAULT 0 CHECK (min_select >= 0),
  max_select INTEGER NOT NULL DEFAULT 1 CHECK (max_select >= 1),
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS item_option_groups_item_idx ON item_option_groups (item_id, sort_order);
CREATE INDEX IF NOT EXISTS item_option_groups_cook_idx ON item_option_groups (cook_id);

-- One choice inside a group, with the price it adds (cents, never negative).
CREATE TABLE IF NOT EXISTS item_options (
  id SERIAL PRIMARY KEY,
  group_id INTEGER NOT NULL REFERENCES item_option_groups(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price_cents INTEGER NOT NULL DEFAULT 0 CHECK (price_cents >= 0),
  is_available INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS item_options_group_idx ON item_options (group_id, sort_order);

-- What the customer chose, copied at order time (names + prices): later edits never change an old order.
CREATE TABLE IF NOT EXISTS order_item_options (
  id SERIAL PRIMARY KEY,
  order_item_id INTEGER NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
  option_id INTEGER,
  group_name TEXT NOT NULL,
  name TEXT NOT NULL,
  price_cents INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS order_item_options_idx ON order_item_options (order_item_id);

-- A store's offer: % or fixed discount on ONE product or a whole section, between two dates, with an optional badge.
CREATE TABLE IF NOT EXISTS promotions (
  id SERIAL PRIMARY KEY,
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  item_id INTEGER REFERENCES menu_items(id) ON DELETE CASCADE,
  section TEXT,
  kind TEXT NOT NULL CHECK (kind IN ('percent','fixed')),
  value INTEGER NOT NULL CHECK (value > 0),          -- percent (1–90) or cents off
  badge TEXT,
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS promotions_cook_idx ON promotions (cook_id, active);
CREATE INDEX IF NOT EXISTS promotions_live_idx ON promotions (active, ends_at);

-- A craftsperson's price for a "come to me" request. Only ONE quote of a visit can ever be accepted.
CREATE TABLE IF NOT EXISTS visit_quotes (
  id SERIAL PRIMARY KEY,
  visit_id INTEGER NOT NULL REFERENCES visit_requests(id) ON DELETE CASCADE,
  cook_id INTEGER NOT NULL REFERENCES cooks(id) ON DELETE CASCADE,
  price_cents INTEGER NOT NULL CHECK (price_cents > 0),
  note TEXT,
  valid_until TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('sent','accepted','rejected','withdrawn')),
  decided_at TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS visit_quotes_visit_idx ON visit_quotes (visit_id, status);

-- What an independent driver offers (deliver an item, buy & bring …). Types come from the owner's allowed list.
CREATE TABLE IF NOT EXISTS driver_services (
  id SERIAL PRIMARY KEY,
  driver_id INTEGER NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  description TEXT NOT NULL,
  price_mode TEXT NOT NULL DEFAULT 'quote' CHECK (price_mode IN ('fixed','quote')),
  price_cents INTEGER,
  area_mode TEXT NOT NULL DEFAULT 'radius' CHECK (area_mode IN ('radius','areas')),
  center_lat DOUBLE PRECISION,
  center_lng DOUBLE PRECISION,
  radius_km DOUBLE PRECISION,
  area_ids TEXT,                 -- JSON list of service_areas ids (area_mode = 'areas')
  hours TEXT,                    -- JSON weekly hours {"open":"08:00","close":"20:00","closed":[5]} (null = any time)
  min_notice_min INTEGER NOT NULL DEFAULT 0,   -- booking preference: how long before he can start
  booking_note TEXT,             -- booking preference shown to customers ("send a photo of the item" …)
  active INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS driver_services_driver_idx ON driver_services (driver_id, active);

-- Drivers' prices for a customer's request (open to nearby drivers, or sent to one driver). The customer picks one.
CREATE TABLE IF NOT EXISTS errand_quotes (
  id SERIAL PRIMARY KEY,
  errand_id INTEGER NOT NULL REFERENCES errands(id) ON DELETE CASCADE,
  driver_id INTEGER NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
  price_cents INTEGER NOT NULL CHECK (price_cents > 0),
  note TEXT,
  status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('sent','accepted','closed','withdrawn')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at TEXT,
  UNIQUE (errand_id, driver_id)
);
CREATE INDEX IF NOT EXISTS errand_quotes_errand_idx ON errand_quotes (errand_id, status);
CREATE INDEX IF NOT EXISTS errand_quotes_driver_idx ON errand_quotes (driver_id, status);
