-- v8.3 AI Operations Manager. Every row is scoped to ONE subscriber (owner_type 'store' = cooks.id, 'driver' = drivers.id):
-- the AI of one subscriber never reads another's rows. Times compared in code are ISO text (portable PostgreSQL / SQLite).

-- The owner's global switches, monthly limits, unit costs and channel flags (one JSON value per key).
CREATE TABLE IF NOT EXISTS ai_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Each subscriber's own settings: a master switch + one level per permission (JSON {key: level}).
CREATE TABLE IF NOT EXISTS ai_settings (
  owner_type TEXT NOT NULL CHECK (owner_type IN ('store','driver')),
  owner_id INTEGER NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  perms TEXT NOT NULL DEFAULT '{}',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (owner_type, owner_id)
);

-- Who changed which permission, when, from what to what (changes never touch the subscription price).
CREATE TABLE IF NOT EXISTS ai_settings_audit (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  actor TEXT NOT NULL,
  perm_key TEXT NOT NULL,
  old_level TEXT,
  new_level TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_settings_audit_owner_idx ON ai_settings_audit (owner_type, owner_id, id);

-- Every AI action: executed, queued for approval, blocked by a permission, refused, failed.
CREATE TABLE IF NOT EXISTS ai_actions (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  actor TEXT NOT NULL,                 -- subscriber | customer | workflow
  tool TEXT NOT NULL,
  risk TEXT,
  args_summary TEXT,
  result_summary TEXT,
  decision TEXT NOT NULL,              -- executed | queued | blocked | denied | invalid | failed | approved | rejected | answered
  approval_id INTEGER,
  cost_cents INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_actions_owner_idx ON ai_actions (owner_type, owner_id, id);

-- Actions waiting for the subscriber's explicit "approve" (executed at most once).
CREATE TABLE IF NOT EXISTS ai_approvals (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  tool TEXT NOT NULL,
  args TEXT NOT NULL,
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','executed','failed','rejected')),
  result TEXT,
  decided_at TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_approvals_owner_idx ON ai_approvals (owner_type, owner_id, status);

-- Monthly metering (messages, tool calls, tokens, voice seconds, cost) against the owner's limits.
CREATE TABLE IF NOT EXISTS ai_usage (
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  month TEXT NOT NULL,
  category TEXT NOT NULL,
  messages INTEGER NOT NULL DEFAULT 0,
  tool_calls INTEGER NOT NULL DEFAULT 0,
  tokens_in INTEGER NOT NULL DEFAULT 0,
  tokens_out INTEGER NOT NULL DEFAULT 0,
  voice_seconds INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (owner_type, owner_id, month)
);

-- In-app voice sessions (speech is recognised on the phone; only the seconds are counted here).
CREATE TABLE IF NOT EXISTS ai_voice_sessions (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','ended','stopped')),
  seconds INTEGER NOT NULL DEFAULT 0,
  last_beat_at TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_voice_owner_idx ON ai_voice_sessions (owner_type, owner_id);

-- Durable jobs and the subscriber's "talk to a human" tasks. task_key is unique → the same operation never runs twice.
CREATE TABLE IF NOT EXISTS ai_tasks (
  id SERIAL PRIMARY KEY,
  task_key TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  ref TEXT,
  status TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running','done','failed','escalated','open','closed')),
  attempts INTEGER NOT NULL DEFAULT 1,
  next_at TEXT,
  last_error TEXT,
  result TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS ai_tasks_owner_idx ON ai_tasks (owner_type, owner_id, kind, status);
CREATE INDEX IF NOT EXISTS ai_tasks_retry_idx ON ai_tasks (status, next_at);

-- Daily / weekly reports saved by the workflows.
CREATE TABLE IF NOT EXISTS ai_reports (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  period TEXT NOT NULL CHECK (period IN ('daily','weekly')),
  period_key TEXT NOT NULL,
  data TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ai_reports_uq ON ai_reports (owner_type, owner_id, period, period_key);

-- Approved drafts kept for the subscriber (promotions, marketing texts) — nothing is published or priced from here.
CREATE TABLE IF NOT EXISTS ai_drafts (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_drafts_owner_idx ON ai_drafts (owner_type, owner_id);

-- ===== CRM preparation (future, tenant-isolated) =====
-- Contacts come ONLY from real customers who ordered / booked / used this subscriber (created automatically from orders).
-- No scraping and no importing of bought lists: there is deliberately no import endpoint.
CREATE TABLE IF NOT EXISTS crm_contacts (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL CHECK (owner_type IN ('store','driver')),
  owner_id INTEGER NOT NULL,
  customer_id INTEGER NOT NULL,
  name TEXT,
  source TEXT NOT NULL,                 -- order | appointment | visit | errand
  orders_count INTEGER NOT NULL DEFAULT 0,
  first_at TEXT,
  last_at TEXT,
  op_consent INTEGER NOT NULL DEFAULT 1,  -- operational messages about his own orders (needed to serve him)
  mkt_consent INTEGER NOT NULL DEFAULT 0, -- marketing: off until the customer agrees
  opted_out INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS crm_contacts_uq ON crm_contacts (owner_type, owner_id, customer_id);

CREATE TABLE IF NOT EXISTS crm_events (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  customer_id INTEGER,
  kind TEXT NOT NULL,
  details TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_events_owner_idx ON crm_events (owner_type, owner_id);

-- The customer's choices per subscriber; they survive the contact being deleted and re-created by a new order.
CREATE TABLE IF NOT EXISTS crm_consents (
  id SERIAL PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  customer_id INTEGER NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('operational','marketing')),
  granted INTEGER NOT NULL,
  source TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_consents_idx ON crm_consents (owner_type, owner_id, customer_id, kind);
