-- v8.2 in-app subscriptions bought in the store apps (Google Play now, Apple App Store later).
-- Nothing here is ever written because the phone says "paid": only after the server checked with Google / Apple.

-- The opaque id we give an account before it buys (Google obfuscatedExternalAccountId / Apple appAccountToken),
-- so a notification about a purchase we have never seen can still be tied to the right account.
CREATE TABLE IF NOT EXISTS billing_accounts (
  account_id TEXT PRIMARY KEY,
  owner_type TEXT NOT NULL CHECK (owner_type IN ('store','driver')),
  owner_id INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS billing_accounts_owner_idx ON billing_accounts (owner_type, owner_id);

-- One row per store-app subscription (a Google purchase token / an Apple original transaction).
CREATE TABLE IF NOT EXISTS billing_entitlements (
  id SERIAL PRIMARY KEY,
  platform TEXT NOT NULL CHECK (platform IN ('google','apple')),
  product_id TEXT NOT NULL,
  owner_type TEXT CHECK (owner_type IN ('store','driver')),     -- NULL while nobody has claimed it yet
  owner_id INTEGER,
  purchase_token TEXT,                                          -- Google
  original_transaction_id TEXT,                                 -- Apple
  state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('active','grace','on_hold','paused','cancelled','expired','refunded','revoked','pending')),
  expires_at TEXT,
  auto_renew INTEGER NOT NULL DEFAULT 0,
  acknowledged INTEGER NOT NULL DEFAULT 0,
  linked_token TEXT,                                            -- Google upgrade/downgrade: the purchase it replaced
  last_order_id TEXT,                                           -- last paid period seen (one referral commission per period)
  environment TEXT,
  granted_until TEXT,                                           -- the end this purchase gave the account (a refund takes it back)
  base_sub_until TEXT,                                          -- the account's own paid ends BEFORE this purchase (kept on refund)
  base_ai_until TEXT,
  reason TEXT,                                                  -- why it ended early: refund, voided, replaced…
  last_event_at TEXT,
  raw TEXT,                                                     -- trimmed copy of what Google / Apple said
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS billing_ent_token_idx ON billing_entitlements (platform, purchase_token) WHERE purchase_token IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS billing_ent_otx_idx ON billing_entitlements (platform, original_transaction_id) WHERE original_transaction_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS billing_ent_owner_idx ON billing_entitlements (owner_type, owner_id);
CREATE INDEX IF NOT EXISTS billing_ent_state_idx ON billing_entitlements (state, platform);

-- Every notification / verification, once: the same Pub/Sub message or Apple notificationUUID is processed one time only.
CREATE TABLE IF NOT EXISTS billing_events (
  id SERIAL PRIMARY KEY,
  platform TEXT NOT NULL,
  event_id TEXT NOT NULL,
  type TEXT NOT NULL,
  entitlement_id INTEGER,
  owner_type TEXT,
  owner_id INTEGER,
  state_before TEXT,
  state_after TEXT,
  details TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS billing_events_uniq ON billing_events (platform, event_id);
CREATE INDEX IF NOT EXISTS billing_events_created_idx ON billing_events (created_at);
CREATE INDEX IF NOT EXISTS billing_events_ent_idx ON billing_events (entitlement_id);
