// Initial reference data. Coordinates are approximate town centres; the admin can add more later.
export const SERVICE_TYPES = ['home_cooking', 'pastries', 'sweets', 'mouneh', 'mezze', 'feasts'];

// plan key → months
export const PLANS = { monthly: 1, quarterly: 3, semiannual: 6, yearly: 12 };

export const AREAS = [
  // Beqaa
  { slug: 'zahle', ar: 'زحلة', en: 'Zahle', region: 'beqaa', lat: 33.8463, lng: 35.9020 },
  { slug: 'chtaura', ar: 'شتورا', en: 'Chtaura', region: 'beqaa', lat: 33.8156, lng: 35.8531 },
  { slug: 'bar-elias', ar: 'برالياس', en: 'Bar Elias', region: 'beqaa', lat: 33.7750, lng: 35.9000 },
  { slug: 'anjar', ar: 'عنجر', en: 'Anjar', region: 'beqaa', lat: 33.7300, lng: 35.9300 },
  { slug: 'riyaq', ar: 'رياق', en: 'Riyaq', region: 'beqaa', lat: 33.8500, lng: 36.0100 },
  { slug: 'baalbek', ar: 'بعلبك', en: 'Baalbek', region: 'beqaa', lat: 34.0047, lng: 36.2110 },
  { slug: 'hermel', ar: 'الهرمل', en: 'Hermel', region: 'beqaa', lat: 34.3943, lng: 36.3848 },
  { slug: 'joub-jannine', ar: 'جب جنين', en: 'Joub Jannine', region: 'beqaa', lat: 33.6300, lng: 35.7800 },
  { slug: 'rashaya', ar: 'راشيا', en: 'Rashaya', region: 'beqaa', lat: 33.5000, lng: 35.8430 },
  // Beirut & Mount Lebanon
  { slug: 'beirut', ar: 'بيروت', en: 'Beirut', region: 'beirut', lat: 33.8938, lng: 35.5018 },
  { slug: 'achrafieh', ar: 'الأشرفية', en: 'Achrafieh', region: 'beirut', lat: 33.8886, lng: 35.5200 },
  { slug: 'hamra', ar: 'الحمرا', en: 'Hamra', region: 'beirut', lat: 33.8959, lng: 35.4824 },
  { slug: 'dahieh', ar: 'الضاحية', en: 'Dahieh', region: 'mount', lat: 33.8530, lng: 35.5130 },
  { slug: 'baabda', ar: 'بعبدا', en: 'Baabda', region: 'mount', lat: 33.8339, lng: 35.5442 },
  { slug: 'aley', ar: 'عاليه', en: 'Aley', region: 'mount', lat: 33.8100, lng: 35.6000 },
  { slug: 'damour', ar: 'الدامور', en: 'Damour', region: 'mount', lat: 33.7300, lng: 35.4600 },
  { slug: 'beiteddine', ar: 'بيت الدين (الشوف)', en: 'Beiteddine (Chouf)', region: 'mount', lat: 33.6950, lng: 35.5800 },
  { slug: 'antelias', ar: 'أنطلياس', en: 'Antelias', region: 'mount', lat: 33.9150, lng: 35.5900 },
  { slug: 'broummana', ar: 'برمانا', en: 'Broummana', region: 'mount', lat: 33.8800, lng: 35.6300 },
  { slug: 'bikfaya', ar: 'بكفيا', en: 'Bikfaya', region: 'mount', lat: 33.9200, lng: 35.6800 },
  { slug: 'zouk-mosbeh', ar: 'ذوق مصبح', en: 'Zouk Mosbeh', region: 'mount', lat: 33.9500, lng: 35.6100 },
  { slug: 'jounieh', ar: 'جونية', en: 'Jounieh', region: 'mount', lat: 33.9808, lng: 35.6178 },
  { slug: 'faraya', ar: 'فاريا (كسروان)', en: 'Faraya (Keserwan)', region: 'mount', lat: 34.0100, lng: 35.8200 },
  { slug: 'jbeil', ar: 'جبيل', en: 'Byblos', region: 'mount', lat: 34.1230, lng: 35.6519 },
  // North
  { slug: 'batroun', ar: 'البترون', en: 'Batroun', region: 'north', lat: 34.2553, lng: 35.6581 },
  { slug: 'amioun', ar: 'أميون (الكورة)', en: 'Amioun (Koura)', region: 'north', lat: 34.3000, lng: 35.8100 },
  { slug: 'tripoli', ar: 'طرابلس', en: 'Tripoli', region: 'north', lat: 34.4367, lng: 35.8497 },
  { slug: 'zgharta', ar: 'زغرتا', en: 'Zgharta', region: 'north', lat: 34.3980, lng: 35.8950 },
  { slug: 'ehden', ar: 'إهدن', en: 'Ehden', region: 'north', lat: 34.2922, lng: 35.9711 },
  { slug: 'bcharre', ar: 'بشري', en: 'Bcharre', region: 'north', lat: 34.2511, lng: 36.0117 },
  { slug: 'halba', ar: 'حلبا (عكار)', en: 'Halba (Akkar)', region: 'north', lat: 34.5428, lng: 36.0797 },
  // South
  { slug: 'saida', ar: 'صيدا', en: 'Saida', region: 'south', lat: 33.5571, lng: 35.3729 },
  { slug: 'jezzine', ar: 'جزين', en: 'Jezzine', region: 'south', lat: 33.5439, lng: 35.5847 },
  { slug: 'nabatieh', ar: 'النبطية', en: 'Nabatieh', region: 'south', lat: 33.3789, lng: 35.4839 },
  { slug: 'tyre', ar: 'صور', en: 'Tyre', region: 'south', lat: 33.2704, lng: 35.2038 },
  { slug: 'marjayoun', ar: 'مرجعيون', en: 'Marjayoun', region: 'south', lat: 33.3600, lng: 35.5900 },
  { slug: 'hasbaya', ar: 'حاصبيا', en: 'Hasbaya', region: 'south', lat: 33.3978, lng: 35.6853 },
  { slug: 'bint-jbeil', ar: 'بنت جبيل', en: 'Bint Jbeil', region: 'south', lat: 33.1203, lng: 35.4333 },
];
