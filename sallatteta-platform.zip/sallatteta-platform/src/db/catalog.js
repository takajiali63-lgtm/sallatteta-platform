// v8.4 catalog migration: new tables (catalog.sql) + new columns on existing tables. Idempotent (runs on every boot).
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

export async function migrateCatalog(db, addColumn) {
  await db.exec(await readFile(resolve(here, 'catalog.sql'), 'utf8'));
  // products: an optional daily "available from–to" window (store's local time, 'HH:MM')
  await addColumn(db, 'menu_items', 'avail_from', 'TEXT');
  await addColumn(db, 'menu_items', 'avail_to', 'TEXT');
  // order line snapshot: price before the discount (base + options), the discount, which offer
  await addColumn(db, 'order_items', 'unit_cents', 'INTEGER');
  await addColumn(db, 'order_items', 'discount_cents', 'INTEGER NOT NULL DEFAULT 0');
  await addColumn(db, 'order_items', 'promo_id', 'INTEGER');
  await addColumn(db, 'order_items', 'promo_label', 'TEXT');
  // preparation: minutes promised when accepting, and "ready for pickup"
  await addColumn(db, 'orders', 'prep_minutes', 'INTEGER');
  await addColumn(db, 'orders', 'ready_at', 'TEXT');
  // craftspeople's jobs after a quote is accepted: scheduled → in_progress → completed → confirmed (by the customer)
  await addColumn(db, 'visit_requests', 'job_status', 'TEXT');
  await addColumn(db, 'visit_requests', 'price_cents', 'INTEGER');
  await addColumn(db, 'visit_requests', 'job_at', 'TEXT');
  await addColumn(db, 'visit_requests', 'completed_at', 'TEXT');
  await addColumn(db, 'visit_requests', 'confirmed_at', 'TEXT');
  // independent drivers: public switch + public profile photo (never the private ID selfie)
  await addColumn(db, 'drivers', 'services_on', 'INTEGER NOT NULL DEFAULT 0');
  await addColumn(db, 'drivers', 'profile_mime', 'TEXT');
  await addColumn(db, 'drivers', 'profile_photo', 'TEXT');
  // errands: a request to ONE driver (from his services) and/or priced by drivers' quotes instead of the customer
  await addColumn(db, 'errands', 'target_driver_id', 'INTEGER');
  await addColumn(db, 'errands', 'service_id', 'INTEGER');
  await addColumn(db, 'errands', 'quote_mode', 'INTEGER NOT NULL DEFAULT 0');
  await addColumn(db, 'errands', 'rating', 'INTEGER');
  await db.exec('CREATE INDEX IF NOT EXISTS errands_target_idx ON errands (target_driver_id, status)');
}
