-- v8.1 sound effects manager: an uploaded sound library, per-event overrides (no row = built-in default), one settings row.
-- Nothing here touches orders, money, subscriptions or accounts.

-- Uploaded sounds live in the database (small: ≤ 300 KB each) so every server instance serves the same bytes.
CREATE TABLE IF NOT EXISTS sound_files (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  mime TEXT NOT NULL,
  ext TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  data TEXT NOT NULL,              -- base64 (no data: prefix)
  created_by INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TEXT
);

-- Only events the owner changed have a row; "restore defaults" simply deletes them.
CREATE TABLE IF NOT EXISTS sound_events (
  event_key TEXT PRIMARY KEY,
  sound TEXT,                      -- 'default:<name>' | 'file:<id>' | NULL = the event's built-in sound
  enabled INTEGER NOT NULL DEFAULT 1,
  volume INTEGER,                  -- 0..100, NULL = default
  roles TEXT,                      -- 'customer,store,driver' subset, NULL = default
  updated_at TEXT
);

-- One row: the global switch and a version that every change bumps (clients refetch, audio URLs change).
CREATE TABLE IF NOT EXISTS sound_settings (
  id INTEGER PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT
);
INSERT INTO sound_settings (id, enabled, version) VALUES (1, 1, 1) ON CONFLICT (id) DO NOTHING;
