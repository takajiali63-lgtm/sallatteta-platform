// Central configuration — every secret/setting comes from environment variables.
export function loadConfig(env = process.env) {
  const isProd = env.NODE_ENV === 'production';
  const cfg = {
    isProd,
    port: Number(env.PORT || 3000),
    databaseUrl: env.DATABASE_URL || 'sqlite:./data/dev.sqlite',
    databaseSsl: String(env.DATABASE_SSL).toLowerCase() === 'true',
    adminWhatsapp: (env.ADMIN_WHATSAPP_NUMBER || '').replace(/\D/g, ''),
    defaultCountryCode: (env.DEFAULT_COUNTRY_CODE || '961').replace(/\D/g, ''),
    sessionSecret: env.SESSION_SECRET || '',
    adminPath: normalizeAdminPath(env.ADMIN_PATH || '/admin'),
    trustProxy: ['1', 'true'].includes(String(env.TRUST_PROXY).toLowerCase()),
    defaultLocale: 'ar',
    locales: ['ar', 'en', 'fr'],
    bootstrapAdmin: {
      username: (env.ADMIN_BOOTSTRAP_USERNAME || '').trim(),
      password: env.ADMIN_BOOTSTRAP_PASSWORD || '',
    },
    publicBaseUrl: (env.PUBLIC_BASE_URL || '').replace(/\/+$/, ''),
    maxServiceRadiusKm: 50,
    searchResultLimit: 30,
  };
  if (isProd && cfg.sessionSecret.length < 32) {
    throw new Error('SESSION_SECRET must be set (at least 32 characters) in production');
  }
  if (!cfg.sessionSecret) cfg.sessionSecret = 'dev-only-secret-not-for-production-use-0000';
  return cfg;
}

function normalizeAdminPath(p) {
  const path = '/' + String(p).trim().replace(/^\/+|\/+$/g, '');
  const reserved = ['/api', '/assets', '/locales', '/media', '/join', '/healthz'];
  if (!/^\/[A-Za-z0-9_\-/]{2,64}$/.test(path) || reserved.some((r) => path === r || path.startsWith(r + '/'))) {
    throw new Error('ADMIN_PATH is invalid (use letters, digits, - _ /; not a reserved path)');
  }
  return path;
}
