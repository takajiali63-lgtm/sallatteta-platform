// Adds 4 demo cooks around Zahle (3 active + 1 expired) — for local testing only.
import { loadConfig } from '../src/config.js';
import { openDb, migrate } from '../src/db/index.js';
import { setCookServices, activateSubscription, addMonths } from '../src/services/cooks.js';

const cfg = loadConfig();
if (cfg.isProd && !process.argv.includes('--force')) { console.error('Refusing to seed demo data in production (use --force).'); process.exit(1); }
const db = await openDb(cfg);
await migrate(db);
const zahle = await db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`);
const demo = [
  { name: 'أم علي', phone: '96170000001', lat: 33.8500, lng: 35.9050, r: 5, s: ['home_cooking', 'pastries', 'sweets'], bio: 'كبة، ورق عنب ومعجنات على الطريقة البقاعية.' },
  { name: 'رنا', phone: '96170000002', lat: 33.8560, lng: 35.8930, r: 5, s: ['home_cooking', 'mouneh'], bio: 'طبخ بيتي يومي ومونة موسمية.' },
  { name: 'سعاد', phone: '96170000003', lat: 33.8310, lng: 35.8900, r: 6, s: ['home_cooking', 'sweets'], bio: 'حلويات عربية وطبخات للعزايم.' },
  { name: 'نهى (اشتراك منتهي)', phone: '96170000004', lat: 33.8470, lng: 35.9030, r: 5, s: ['home_cooking'], bio: '', expired: true },
];
for (const d of demo) {
  if (await db.one('SELECT id FROM cooks WHERE whatsapp = $1', [d.phone])) continue;
  const row = await db.one(
    `INSERT INTO cooks (full_name, whatsapp, area_id, area_label, lat, lng, service_radius_km, bio, status)
     VALUES ($1,$2,$3,'زحلة',$4,$5,$6,$7,'approved') RETURNING id`, [d.name, d.phone, zahle.id, d.lat, d.lng, d.r, d.bio]);
  await setCookServices(db, row.id, d.s);
  const start = d.expired ? addMonths(new Date(), -2) : new Date(Date.now() - 60_000);
  await activateSubscription(db, row.id, { plan: 'monthly', startDate: start, paymentStatus: 'paid' });
}
await db.query(`UPDATE subscriptions SET status='expired' WHERE expiry_date <= $1 AND status='active'`, [new Date().toISOString()]);
console.log('Demo cooks ready.');
await db.close();
