// v8 load test — the marketplace's real traffic mix (browse without GPS, browse nearby, store pages, offers, orders,
// stores' order screens, drivers' GPS updates and offers, invoices, the owner's overview).
//   Local (own server + demo data):   node scripts/load-test-v8.js --seconds 30 --concurrency 50 [--db postgres://…]
//   Against staging (NEVER production): node scripts/load-test-v8.js --url https://staging.example.com …
// The numbers are what THIS machine measured (server and load generator share it) — not a capacity promise.
import { parseArgs } from 'node:util';

const { values: o } = parseArgs({ options: {
  url: { type: 'string' }, seconds: { type: 'string', default: '30' }, concurrency: { type: 'string', default: '50' },
  stores: { type: 'string', default: '400' }, drivers: { type: 'string', default: '60' }, db: { type: 'string', default: 'sqlite::memory:' },
} });
const SECONDS = Number(o.seconds), CONC = Number(o.concurrency);
let base = o.url, app = null;
const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const ADMIN_PW = `lt-${Math.random().toString(36).slice(2)}-${Date.now()}`;
const rand = (a, b) => a + Math.random() * (b - a);
const pick = (a) => a[Math.floor(Math.random() * a.length)];

async function http(method, path, { body, cookie } = {}) {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', 'Accept-Encoding': 'gzip', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('json') ? await r.json().catch(() => null) : await r.arrayBuffer();
  return { status: r.status, data, cookie: r.headers.get('set-cookie')?.split(';')[0] };
}

const stores = [], drivers = [], customers = [];
if (!base) {
  const { createApp } = await import('../src/server.js');
  app = await createApp({ databaseUrl: o.db, sessionSecret: 'x'.repeat(40), quiet: true, rateLimitScale: 100_000, placesFetcher: async () => [], adminWhatsapp: '96170000000',
    bootstrapAdmin: { username: 'admin', password: ADMIN_PW }, searchLimit: 1e6, applyLimit: 1e6, loginLimit: 1e6, lookupLimit: 1e6, uploadLimit: 1e6, adminLimit: 1e6 });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  const t0 = Date.now();
  const admin = (await http('POST', '/api/admin/login', { body: { username: 'admin', password: ADMIN_PW } })).cookie;
  const areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  await http('PUT', '/api/admin/delivery/settings', { cookie: admin, body: { driverService: 1, claimWindowSec: 0 } });
  for (let i = 0; i < Number(o.stores); i += 1) {
    const lat = rand(33.3, 34.4), lng = rand(35.4, 36.2);
    const wa = `+9617${String(1000000 + i).slice(-7)}`;
    const r = await http('POST', '/api/admin/cooks', { cookie: admin, body: { fullName: `متجر ${i}`, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: pick(['restaurant', 'pharmacy', 'supermarket']), lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } } });
    if (r.status !== 201) continue;
    for (let k = 0; k < 6; k += 1) await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency, section) VALUES ($1,$2,$3,'USD',$4)`, [r.data.id, `منتج ${k}`, 2 + k, k < 3 ? 'أطباق' : 'مشروبات']);
    if (i < 40) {
      await http('POST', `/api/admin/stores/${r.data.id}/delivery`, { cookie: admin, body: { mode: 'delivery' } });
      const pw = (await http('POST', `/api/admin/cooks/${r.data.id}/password`, { cookie: admin, body: {} })).data.password;
      const cookie = (await http('POST', '/api/cook/login', { body: { whatsapp: wa, password: pw } })).cookie;
      const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1 ORDER BY id', [r.data.id])).id;
      stores.push({ id: r.data.id, cookie, lat, lng, item });
    }
  }
  for (let i = 0; i < Number(o.drivers); i += 1) {
    const phone = `7199${String(10000 + i).slice(-4)}`;
    const docs = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
    const r = await http('POST', '/api/driver/apply', { body: { fullName: `سائق ${i}`, phone, password: 'pass123', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs } });
    if (r.status !== 201) continue;
    await http('POST', `/api/admin/drivers/${r.data.id}/status`, { cookie: admin, body: { status: 'active' } });
    const cookie = (await http('POST', '/api/driver/login', { body: { phone, password: 'pass123' } })).cookie;
    drivers.push({ id: r.data.id, cookie, lat: rand(33.3, 34.4), lng: rand(35.4, 36.2) });
  }
  for (let i = 0; i < 40; i += 1) customers.push((await http('POST', '/api/customer/login', { body: { name: `زبون ${i}`, phone: `03${String(100000 + i)}`, acceptTerms: true } })).cookie);
  globalThis.ADMIN = admin;
  console.log(`seeded ${o.stores} stores (${stores.length} with logins), ${drivers.length} drivers, ${customers.length} customers in ${Date.now() - t0} ms (db: ${app.db.kind})`);
}

const stats = new Map();
const record = (name, ms, ok, code = 0) => { let s = stats.get(name); if (!s) { s = { lat: [], errors: 0, codes: {} }; stats.set(name, s); } s.lat.push(ms); s.codes[code] = (s.codes[code] || 0) + 1; if (!ok) s.errors += 1; };
async function call(name, method, path, opts = {}) {
  const t = performance.now();
  try { const r = await http(method, path, opts); record(name, performance.now() - t, r.status < 500 && r.status !== 429, r.status); return r; } catch { record(name, performance.now() - t, false); return { status: 0 }; }
}

async function step() {
  const r = Math.random();
  if (r < 0.18) return call('home (no GPS)', 'GET', `/api/delivery/stores?country=LB&page=${Math.floor(rand(0, 5))}`);
  if (r < 0.33) return call('home nearby', 'GET', `/api/delivery/stores?country=LB&lat=${rand(33.3, 34.4)}&lng=${rand(35.4, 36.2)}`);
  if (r < 0.43) return call('store page', 'GET', `/api/delivery/stores/${pick(stores)?.id || 1}?country=LB`);
  if (r < 0.48) return call('offers', 'GET', '/api/delivery/offers?country=LB');
  if (r < 0.52) return call('design.css', 'GET', '/design.css?p=app');
  if (r < 0.60 && stores.length && customers.length) {
    const st = pick(stores);
    return call('create order', 'POST', '/api/orders', { cookie: pick(customers), body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: st.lat + 0.004, lng: st.lng, paymentMethod: 'cash' } });
  }
  if (r < 0.70 && stores.length) return call('store orders', 'GET', '/api/store/orders', { cookie: pick(stores).cookie });
  if (r < 0.80 && drivers.length) { const d = pick(drivers); return call('driver GPS', 'POST', '/api/driver/availability', { cookie: d.cookie, body: { available: true, lat: d.lat + rand(-0.001, 0.001), lng: d.lng + rand(-0.001, 0.001) } }); }
  if (r < 0.88 && drivers.length) return call('driver offers', 'GET', '/api/driver/offers', { cookie: pick(drivers).cookie });
  if (r < 0.93 && drivers.length) return call('invoices', 'GET', '/api/driver/invoices', { cookie: pick(drivers).cookie });
  if (r < 0.95 && globalThis.ADMIN) return call('admin overview', 'GET', '/api/admin/platform', { cookie: globalThis.ADMIN });
  return call('home page', 'GET', '/');
}

const cpu0 = process.cpuUsage(); const wall0 = performance.now();
const deadline = Date.now() + SECONDS * 1000;
await Promise.all(Array.from({ length: CONC }, async () => { while (Date.now() < deadline) await step(); }));
const wall = (performance.now() - wall0) / 1000;
const cpu = process.cpuUsage(cpu0);
const pct = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a.length ? a[Math.min(a.length - 1, Math.floor(p * a.length))] : 0; };
let total = 0, errs = 0; const all = [];
console.log(`\n${SECONDS}s, ${CONC} concurrent virtual users → ${base}${app ? ` (local, ${app.db.kind})` : ''}\n`);
console.log('scenario'.padEnd(16), 'requests'.padStart(9), 'rps'.padStart(8), 'p50 ms'.padStart(8), 'p95 ms'.padStart(8), 'p99 ms'.padStart(8), 'errors'.padStart(7));
for (const [name, s] of stats) {
  total += s.lat.length; errs += s.errors; all.push(...s.lat);
  console.log(name.padEnd(16), String(s.lat.length).padStart(9), (s.lat.length / wall).toFixed(1).padStart(8), pct(s.lat, 0.5).toFixed(1).padStart(8), pct(s.lat, 0.95).toFixed(1).padStart(8), pct(s.lat, 0.99).toFixed(1).padStart(8), String(s.errors).padStart(7));
}
for (const [name, s] of stats) if (Object.keys(s.codes).some((c) => c !== '200')) console.log(`  ${name}: ${Object.entries(s.codes).map(([c, n]) => `${c}×${n}`).join(' ')}`);
console.log('TOTAL'.padEnd(16), String(total).padStart(9), (total / wall).toFixed(1).padStart(8), pct(all, 0.5).toFixed(1).padStart(8), pct(all, 0.95).toFixed(1).padStart(8), pct(all, 0.99).toFixed(1).padStart(8), String(errs).padStart(7));
console.log(`\nerror rate ${(100 * errs / Math.max(1, total)).toFixed(2)}% · process CPU ${((cpu.user + cpu.system) / 1e6 / wall * 100).toFixed(0)}% of one core (server + load generator) · memory ${(process.memoryUsage().rss / 1048576).toFixed(0)} MB`);
if (app) await app.close();
process.exit(0);
