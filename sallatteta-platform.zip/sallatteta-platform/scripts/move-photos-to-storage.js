// Moves images stored inside the database to S3-compatible storage (Cloudflare R2 / AWS S3).
// Run once after setting the S3_* environment variables:  node scripts/move-photos-to-storage.js
// Safe to re-run: only images still in the database are moved.
import { loadConfig } from '../src/config.js';
import { openDb, migrate } from '../src/db/index.js';
import { createStorage } from '../src/services/storage.js';

const cfg = loadConfig();
const storage = createStorage(cfg);
if (!storage.enabled) { console.error('S3_* variables are not set — nothing to do.'); process.exit(1); }
const db = await openDb(cfg);
await migrate(db);

let moved = 0;
for (;;) {
  const batch = await db.query(`SELECT id, cook_id, data FROM cook_photos WHERE url IS NULL AND data <> '' ORDER BY id LIMIT 50`);
  if (!batch.length) break;
  for (const p of batch) {
    const url = await storage.putDataUrl(`dishes/${p.cook_id}`, p.data);
    await db.query(`UPDATE cook_photos SET url = $1, data = '' WHERE id = $2`, [url, p.id]);
    moved++;
  }
  console.log(`dish photos moved: ${moved}`);
}
let avatars = 0;
for (;;) {
  const batch = await db.query('SELECT id, photo FROM cooks WHERE photo IS NOT NULL AND photo_url IS NULL ORDER BY id LIMIT 50');
  if (!batch.length) break;
  for (const c of batch) {
    const url = await storage.putDataUrl(`cooks/${c.id}`, c.photo);
    await db.query('UPDATE cooks SET photo_url = $1, photo = NULL WHERE id = $2', [url, c.id]);
    avatars++;
  }
}
console.log(`Done: ${moved} dish photos and ${avatars} profile photos now served from storage.`);
await db.close();
