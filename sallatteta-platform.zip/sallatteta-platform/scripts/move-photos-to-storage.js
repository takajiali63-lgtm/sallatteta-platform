// Moves images stored inside the database to S3-compatible storage (Cloudflare R2 / AWS S3).
// Run once after setting the S3_* environment variables:  node scripts/move-photos-to-storage.js
// Safe to re-run: only images still in the database are moved.
import { loadConfig } from '../src/config.js';
import { openDb, migrate } from '../src/db/index.js';
import { createStorage } from '../src/services/storage.js';

const cfg = loadConfig();
const storage = createStorage(cfg);
if (!storage.enabled) { console.error('S3_* variables are not set — nothing to do.'); process.exit(1); }
const db = await openDb(cfg);
await migrate(db);

// Only drop the database copy once the uploaded file is really served by the storage/CDN.
async function verified(url) {
  for (let i = 0; i < 3; i++) {
    const r = await fetch(url, { method: 'HEAD' }).catch(() => null);
    if (r && r.ok) return true;
    await new Promise((res) => setTimeout(res, 1000 * (i + 1)));
  }
  return false;
}

let moved = 0, skipped = 0, lastId = 0;
for (;;) {
  const batch = await db.query(`SELECT id, cook_id, data FROM cook_photos WHERE url IS NULL AND data <> '' AND id > $1 ORDER BY id LIMIT 50`, [lastId]);
  if (!batch.length) break;
  for (const p of batch) {
    lastId = p.id;
    const url = await storage.putDataUrl(`dishes/${p.cook_id}`, p.data);
    if (!(await verified(url))) { skipped++; console.warn(`photo ${p.id}: uploaded but not reachable at ${url} — kept in database`); continue; }
    await db.query(`UPDATE cook_photos SET url = $1, data = '' WHERE id = $2`, [url, p.id]);
    moved++;
  }
  console.log(`dish photos moved: ${moved}`);
}
let avatars = 0, lastCook = 0;
for (;;) {
  const batch = await db.query('SELECT id, photo FROM cooks WHERE photo IS NOT NULL AND photo_url IS NULL AND id > $1 ORDER BY id LIMIT 50', [lastCook]);
  if (!batch.length) break;
  for (const c of batch) {
    lastCook = c.id;
    const url = await storage.putDataUrl(`cooks/${c.id}`, c.photo);
    if (!(await verified(url))) { skipped++; continue; }
    await db.query('UPDATE cooks SET photo_url = $1, photo = NULL WHERE id = $2', [url, c.id]);
    avatars++;
  }
}
console.log(`Done: ${moved} dish photos and ${avatars} profile photos now served from storage; ${skipped} kept in the database (retry later).`);
await db.close();
