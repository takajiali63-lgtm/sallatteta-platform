// Generates the built-in sound library (public/assets/sounds/*.wav) from simple synthesized tones.
// Why synthesized: no licences to worry about, tiny files (16-bit mono 22 kHz), deterministic (same bytes every run),
// and they work with no admin action at all. Kept quiet on purpose (peak ≈ 0.35–0.55 of full scale).
// Run: node scripts/gen-sounds.mjs
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const RATE = 22050;
const OUT = resolve(dirname(fileURLToPath(import.meta.url)), '../public/assets/sounds');

// note names → Hz (equal temperament, A4 = 440)
const N = (name) => {
  const m = /^([A-G])(#?)(\d)$/.exec(name);
  const semi = { C: -9, D: -7, E: -5, F: -4, G: -2, A: 0, B: 2 }[m[1]] + (m[2] ? 1 : 0) + (Number(m[3]) - 4) * 12;
  return 440 * 2 ** (semi / 12);
};

/** One voice: frequency (optionally gliding to `to`), soft attack + exponential decay, a little harmonic for warmth. */
function voice(buf, { f, to = f, at = 0, dur = 0.15, gain = 1, wave = 'sine', attack = 0.006, bell = false }) {
  const start = Math.round(at * RATE), len = Math.round(dur * RATE);
  let phase = 0;
  for (let i = 0; i < len && start + i < buf.length; i++) {
    const t = i / RATE, p = i / len;
    const freq = f + (to - f) * p;
    phase += (2 * Math.PI * freq) / RATE;
    let s = wave === 'tri' ? (2 / Math.PI) * Math.asin(Math.sin(phase)) : Math.sin(phase);
    if (bell) s = 0.7 * s + 0.2 * Math.sin(phase * 2.01) + 0.1 * Math.sin(phase * 3.02);
    else s = 0.88 * s + 0.12 * Math.sin(phase * 2);
    const env = Math.min(1, t / attack) * Math.exp(-4.2 * p) * (1 - p ** 8); // ends at exactly 0 → no click
    buf[start + i] += s * env * gain;
  }
}

function render(total, voices, peak) {
  const buf = new Float64Array(Math.round(total * RATE));
  for (const v of voices) voice(buf, v);
  const max = buf.reduce((m, x) => Math.max(m, Math.abs(x)), 0) || 1;
  const pcm = Buffer.alloc(44 + buf.length * 2);
  pcm.write('RIFF', 0); pcm.writeUInt32LE(36 + buf.length * 2, 4); pcm.write('WAVE', 8);
  pcm.write('fmt ', 12); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(RATE, 24); pcm.writeUInt32LE(RATE * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write('data', 36); pcm.writeUInt32LE(buf.length * 2, 40);
  for (let i = 0; i < buf.length; i++) pcm.writeInt16LE(Math.round((buf[i] / max) * peak * 32767), 44 + i * 2);
  return pcm;
}

// seq: quick helper for a melody of [note, at, dur]
const seq = (notes, extra = {}) => notes.map(([n, at, dur]) => ({ f: typeof n === 'number' ? n : N(n), at, dur, ...extra }));
const SOFT = 0.35, MID = 0.45, LOUD = 0.55;   // peaks: interface sounds stay soft, operational alerts a bit clearer

export const SOUNDS = {
  pop:         [0.10, [{ f: 880, to: 1320, dur: 0.09 }], SOFT],
  drop:        [0.14, [{ f: 700, to: 340, dur: 0.13 }], SOFT],
  confirm:     [0.36, seq([['C5', 0, 0.12], ['E5', 0.1, 0.12], ['G5', 0.2, 0.16]]), MID],
  accept:      [0.26, seq([['E5', 0, 0.12], ['A5', 0.11, 0.15]]), MID],
  reject:      [0.30, seq([['A4', 0, 0.14], ['F4', 0.13, 0.17]], { wave: 'tri' }), SOFT],
  complete:    [0.50, seq([['C5', 0, 0.12], ['E5', 0.09, 0.12], ['G5', 0.18, 0.12], ['C6', 0.27, 0.23]], { bell: true }), MID],
  message:     [0.26, seq([['G5', 0, 0.1], ['D6', 0.11, 0.15]]), SOFT],
  coin:        [0.30, seq([['B5', 0, 0.08], ['E6', 0.07, 0.23]], { bell: true }), MID],
  fail:        [0.36, seq([[220, 0, 0.15], [196, 0.17, 0.19]], { wave: 'tri' }), SOFT],
  error:       [0.25, [{ f: 330, to: 262, dur: 0.24, wave: 'tri' }], SOFT],
  new_order:   [0.56, seq([['A5', 0, 0.12], ['A5', 0.16, 0.12], ['E6', 0.32, 0.24]], { bell: true }), LOUD],
  urgent:      [0.60, seq([[988, 0, 0.13], [740, 0.15, 0.13], [988, 0.3, 0.13], [740, 0.45, 0.15]], { wave: 'tri' }), LOUD],
  request:     [0.50, seq([['D5', 0, 0.1], ['F#5', 0.09, 0.1], ['A5', 0.18, 0.1], ['D6', 0.27, 0.23]]), LOUD],
  delayed:     [0.50, seq([['E5', 0, 0.22], ['C5', 0.22, 0.28]], { bell: true }), LOUD],
  reminder:    [0.50, [{ f: N('C6'), dur: 0.5, bell: true }], MID],
  booking:     [0.40, seq([['G5', 0, 0.12], ['B5', 0.11, 0.12], ['D6', 0.22, 0.18]], { bell: true }), MID],
  ai_start:    [0.30, [{ f: 400, to: 800, dur: 0.3, attack: 0.04 }], SOFT],
  ai_listen:   [0.10, [{ f: 1200, dur: 0.08 }], SOFT],
  ai_process:  [0.20, seq([[900, 0, 0.07], [1100, 0.1, 0.09]]), SOFT],
  ai_ready:    [0.36, seq([['C6', 0, 0.1], ['E6', 0.08, 0.1], ['G6', 0.16, 0.2]], { bell: true }), SOFT],
  ai_approval: [0.30, seq([['E5', 0, 0.13], ['B5', 0.13, 0.17]]), MID],
  ai_fail:     [0.30, [{ f: 600, to: 400, dur: 0.3, wave: 'tri' }], SOFT],
  success:     [0.26, seq([['C6', 0, 0.1], ['G6', 0.09, 0.17]], { bell: true }), SOFT],
  warning:     [0.32, seq([['D5', 0, 0.13], ['D5', 0.16, 0.16]], { wave: 'tri' }), MID],
  important:   [0.46, seq([['A5', 0, 0.2], ['D6', 0.18, 0.28]], { bell: true }), MID],
  ring:        [0.60, seq([[660, 0, 0.13], [880, 0.15, 0.13], [660, 0.3, 0.13], [880, 0.45, 0.15]]), MID],
  announce:    [0.56, seq([['G4', 0, 0.16], ['C5', 0.14, 0.16], ['E5', 0.28, 0.28]], { bell: true }), MID],
};

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  mkdirSync(OUT, { recursive: true });
  let total = 0;
  for (const [name, [dur, voices, peak]] of Object.entries(SOUNDS)) {
    const wav = render(dur, voices, peak);
    writeFileSync(resolve(OUT, `${name}.wav`), wav);
    total += wav.length;
  }
  console.log(`${Object.keys(SOUNDS).length} sounds → ${OUT} (${Math.round(total / 1024)} KB)`);
}
