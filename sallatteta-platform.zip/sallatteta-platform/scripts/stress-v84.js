// v8.4 stress + integrity test — thousands of customers and drivers at the same moment, and checks that NOTHING is
// mixed up: an order never gets two drivers, a driver never carries two orders, stock never goes below zero, one tap
// twice never makes two orders, a request never goes to two drivers, nobody sees another's orders, searches stay fast.
//   node scripts/stress-v84.js --db postgres://… --customers 2000 --drivers 500 --stores 150
//   (default: SQLite in memory, smaller numbers). Runs its OWN server — never against production.
// Exported runStress() is used by test/v93-stress.test.js with small numbers.
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';
import { randomToken, sha256 } from '../src/lib/security.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const rand = (a, b) => a + Math.random() * (b - a);
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const pct = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a.length ? a[Math.min(a.length - 1, Math.floor(p * a.length))] : 0; };

export async function runStress({ db: dbUrl = 'sqlite::memory:', customers: NC = 300, drivers: ND = 120, stores: NS = 40, seconds = 10, concurrency = 80, log = console.log } = {}) {
  const { createApp } = await import('../src/server.js');
  const ADMIN_PW = `st-${Math.random().toString(36).slice(2)}-${Date.now()}`;
  const app = await createApp({ databaseUrl: dbUrl, sessionSecret: 'x'.repeat(40), quiet: true, runJobs: false, rateLimitScale: 1e6, placesFetcher: async () => [], adminWhatsapp: '96170000000',
    bootstrapAdmin: { username: 'admin', password: ADMIN_PW }, searchLimit: 1e7, applyLimit: 1e7, loginLimit: 1e7, lookupLimit: 1e7, uploadLimit: 1e7, adminLimit: 1e7, feedbackLimit: 1e7, placesLimit: 1e7 });
  await new Promise((r) => app.server.listen(0, r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const db = app.db;
  const results = [];
  const check = (name, ok, detail = '') => { results.push({ name, ok: !!ok, detail }); log(`${ok ? '✅' : '❌'} ${name}${detail ? ` — ${detail}` : ''}`); };
  const fivexx = [];
  async function http(method, path, { body, cookie } = {}) {
    const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const ct = r.headers.get('content-type') || '';
    const data = ct.includes('json') ? await r.json().catch(() => null) : null;
    if (r.status >= 500) fivexx.push(`${r.status} ${method} ${path} ${JSON.stringify(data)?.slice(0, 120)}`);
    return { status: r.status, data, cookie: r.headers.get('set-cookie')?.split(';')[0] };
  }
  const iso = () => new Date().toISOString();
  const later = new Date(Date.now() + 30 * 864e5).toISOString();
  async function session(table, col, id, cookie) {
    const token = randomToken(32);
    await db.query(`INSERT INTO ${table} (${col}, token_hash, expires_at) VALUES ($1,$2,$3)`, [id, sha256(token), later]);
    return `${cookie}=${token}`;
  }

  /* ---------------- seed ---------------- */
  const t0 = Date.now();
  const admin = (await http('POST', '/api/admin/login', { body: { username: 'admin', password: ADMIN_PW } })).cookie;
  const areaId = (await db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  await http('PUT', '/api/admin/delivery/settings', { cookie: admin, body: { driverService: 1, claimWindowSec: 0, dispatchRadiusKm: 30, errandRadiusKm: 30, offerBatch: 50, cashLimit: 100000, storesRadiusKm: 60 } });
  await http('PUT', '/api/admin/settings', { cookie: admin, body: { googleOnly: false } });
  const C0 = { lat: 33.85, lng: 35.90 };
  const stores = [];
  for (let i = 0; i < NS; i += 1) {
    const lat = C0.lat + rand(-0.05, 0.05), lng = C0.lng + rand(-0.05, 0.05);
    const wa = `+9617${String(2000000 + i).slice(-7)}`;
    const r = await http('POST', '/api/admin/cooks', { cookie: admin, body: { fullName: `متجر ضغط ${i}`, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: pick(['restaurant', 'pharmacy', 'supermarket']), lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } } });
    if (r.status !== 201) { log('store seed failed', r.status, JSON.stringify(r.data)); continue; }
    const id = r.data.id;
    await http('POST', `/api/admin/stores/${id}/delivery`, { cookie: admin, body: { mode: 'delivery' } });
    await db.query(`UPDATE cooks SET delivery_fee = 2, delivery_radius_km = 60, accepting_orders = 1, hours = NULL WHERE id = $1`, [id]);
    for (let k = 0; k < 8; k += 1) await db.query(`INSERT INTO menu_items (cook_id, name, price, currency, section) VALUES ($1,$2,$3,'USD',$4)`, [id, `منتج ${k}`, 2 + k, k < 4 ? 'أطباق' : 'مشروبات']);
    const item = (await db.one('SELECT id FROM menu_items WHERE cook_id = $1 ORDER BY id', [id])).id;
    stores.push({ id, lat, lng, item, cookie: await session('cook_sessions', 'cook_id', id, 'st_cook') });
  }
  const custs = [];
  for (let i = 0; i < NC; i += 1) {
    const r = await db.one(`INSERT INTO customers (name, phone, country) VALUES ($1,$2,'LB') RETURNING id`, [`زبون ${i}`, `+9613${String(5000000 + i).slice(-7)}`]);
    custs.push({ id: r.id, cookie: await session('customer_sessions', 'customer_id', r.id, 'st_cust') });
  }
  const drvs = [];
  for (let i = 0; i < ND; i += 1) {
    const lat = C0.lat + rand(-0.05, 0.05), lng = C0.lng + rand(-0.05, 0.05);
    const r = await db.one(`INSERT INTO drivers (full_name, phone, password_hash, vehicle, status, available, lat, lng, loc_at, country, jobs_until) VALUES ($1,$2,'x','moto','active',1,$3,$4,$5,'LB',$6) RETURNING id`,
      [`سائق ${i}`, `+9617${String(6000000 + i).slice(-7)}`, lat, lng, iso(), later]);
    drvs.push({ id: r.id, lat, lng, cookie: await session('driver_sessions', 'driver_id', r.id, 'st_driver') });
  }
  log(`seeded ${stores.length} stores, ${custs.length} customers, ${drvs.length} drivers in ${Date.now() - t0} ms (${db.kind})`);
  const keepFresh = setInterval(() => { db.query('UPDATE drivers SET loc_at = $1 WHERE available = 1', [iso()]).catch(() => {}); }, 20_000);

  /* ---------------- 1) stock: 30 pieces, 10× more buyers at once ---------------- */
  {
    const st = stores[0];
    await db.query('UPDATE menu_items SET stock = 30, auto_off = 0, is_available = 1 WHERE id = $1', [st.item]);
    const buyers = custs.slice(0, Math.min(custs.length, 300));
    const res = await Promise.all(buyers.map((c) => http('POST', '/api/orders', { cookie: c.cookie, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: st.lat + 0.002, lng: st.lng, paymentMethod: 'cash' } })));
    const okN = res.filter((r) => r.status === 201).length;
    const left = Number((await db.one('SELECT stock FROM menu_items WHERE id = $1', [st.item])).stock);
    const sold = Number((await db.one(`SELECT COALESCE(SUM(i.qty),0) AS n FROM order_items i JOIN orders o ON o.id = i.order_id WHERE i.menu_item_id = $1 AND o.status NOT IN ('cancelled','rejected')`, [st.item])).n);
    check('stock: never oversold', okN <= 30 && left >= 0 && sold + left === 30, `${buyers.length} buyers → ${okN} orders, ${left} left, sold ${sold}`);
    check('stock: the others got a clear «sold out»', res.filter((r) => r.status !== 201).every((r) => r.status === 409), [...new Set(res.map((r) => r.status))].join(','));
  }

  /* ---------------- 2) one tap sent 6 times at once → ONE order ---------------- */
  {
    const st = stores[1], c = custs[custs.length - 1];
    const idem = `tap-${Date.now()}`;
    const res = await Promise.all(Array.from({ length: 6 }, () => http('POST', '/api/orders', { cookie: c.cookie, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: st.lat, lng: st.lng, paymentMethod: 'cash', idem } })));
    const ids = new Set(res.filter((r) => r.status === 201 || r.status === 200).map((r) => r.data?.id));
    const n = Number((await db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM orders WHERE customer_id = $1 AND cook_id = $2`, [c.id, st.id])).n);
    check('double tap: one order only', n === 1 && ids.size === 1, `${n} order(s), statuses ${res.map((r) => r.status).join(',')}`);
  }

  /* ---------------- 3) store taps «accept» twice at once ---------------- */
  {
    const st = stores[2];
    const o = await http('POST', '/api/orders', { cookie: custs[1].cookie, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: st.lat, lng: st.lng, paymentMethod: 'cash' } });
    const res = await Promise.all([1, 2, 3].map(() => http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} })));
    check('store double accept: one wins', res.filter((r) => r.status === 200).length === 1, res.map((r) => r.status).join(','));
  }

  /* ---------------- 4) many orders, all drivers grab at the same moment ---------------- */
  {
    const n = Math.min(stores.length - 3, 60);
    const orders = [];
    for (let i = 3; i < 3 + n; i += 1) {
      const st = stores[i], c = custs[(i * 7) % custs.length];
      const o = await http('POST', '/api/orders', { cookie: c.cookie, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: st.lat + 0.003, lng: st.lng, paymentMethod: 'cash' } });
      if (o.status !== 201) { log('order failed', o.status, JSON.stringify(o.data)); continue; }
      await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
      const s = await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: {} });
      if (s.status !== 200) log('search failed', s.status, JSON.stringify(s.data));
      orders.push(o.data.id);
    }
    // every driver looks at his offers and tries to take ALL of them at once
    const t1 = performance.now();
    await Promise.all(drvs.map(async (d) => {
      const off = await http('GET', '/api/driver/offers', { cookie: d.cookie });
      const mine = (off.data?.offers || []).filter((x) => x.type === 'store');
      await Promise.all(mine.slice(0, 5).map((x) => http('POST', `/api/driver/offers/${x.id}/accept`, { cookie: d.cookie, body: {} })));
    }));
    const took = Math.round(performance.now() - t1);
    const rows = await db.query(`SELECT id, driver_id, status FROM orders WHERE id IN (${orders.map((_, i) => `$${i + 1}`).join(',')})`, orders);
    const assigned = rows.filter((r) => r.driver_id);
    const perDriver = new Map();
    for (const r of await db.query(`SELECT driver_id, CAST(COUNT(*) AS INTEGER) AS n FROM orders WHERE status IN ('assigned','picked_up') AND driver_id IS NOT NULL GROUP BY driver_id`)) perDriver.set(r.driver_id, Number(r.n));
    const doubles = [...perDriver.values()].filter((x) => x > 1).length;
    const offersWon = await db.query(`SELECT order_id, CAST(COUNT(*) AS INTEGER) AS n FROM order_offers WHERE status = 'won' GROUP BY order_id HAVING COUNT(*) > 1`);
    check('dispatch: every order got a driver', assigned.length === orders.length, `${assigned.length}/${orders.length} in ${took} ms (${drvs.length} drivers grabbing)`);
    check('dispatch: no order has two winners', offersWon.length === 0, `${offersWon.length} conflicts`);
    check('dispatch: no driver carries two orders', doubles === 0, `${doubles} drivers with 2+`);
  }

  /* ---------------- 5) customers' requests priced by drivers: quotes + double accept ---------------- */
  {
    const errs = [];
    for (let i = 0; i < 15; i += 1) {
      const c = custs[100 + i];
      const e = await http('POST', '/api/errands', { cookie: c.cookie, body: { kind: 'deliver', description: `توصيل غرض رقم ${i}`, from: { lat: C0.lat + rand(-0.02, 0.02), lng: C0.lng + rand(-0.02, 0.02) }, to: { lat: C0.lat + 0.03, lng: C0.lng } } });
      if (e.status === 201) errs.push({ id: e.data.id, c });
      else log('errand failed', e.status, JSON.stringify(e.data));
    }
    const free = drvs.filter((d) => true);
    await Promise.all(free.map(async (d) => {
      const off = await http('GET', '/api/driver/offers', { cookie: d.cookie });
      for (const x of (off.data?.offers || []).filter((y) => y.type === 'errand').slice(0, 3)) await http('POST', `/api/driver/errands/${x.errandId}/quote`, { cookie: d.cookie, body: { price: Math.round(rand(2, 9) * 2) / 2 } });
    }));
    let doubleWin = 0, assignedN = 0;
    await Promise.all(errs.map(async ({ id, c }) => {
      const qs = (await http('GET', `/api/customer/errands/${id}/quotes`, { cookie: c.cookie })).data?.quotes || [];
      if (!qs.length) return;
      // two phones accept two different quotes at the same moment + a «better price» tap
      const res = await Promise.all([...qs.slice(0, 2).map((q) => http('POST', `/api/customer/errands/${id}/quotes/${q.id}/accept`, { cookie: c.cookie, body: {} })), http('POST', `/api/customer/errands/${id}/quotes/${qs[0].id}/improve`, { cookie: c.cookie, body: {} })]);
      if (res.slice(0, 2).filter((r) => r.status === 200).length > 1) doubleWin += 1;
      const e = await db.one('SELECT driver_id, status FROM errands WHERE id = $1', [id]);
      if (e.driver_id) assignedN += 1;
    }));
    const busy = await db.query(`SELECT d.id FROM drivers d WHERE (SELECT COUNT(*) FROM orders o WHERE o.driver_id = d.id AND o.status IN ('assigned','picked_up')) + (SELECT COUNT(*) FROM errands e WHERE e.driver_id = d.id AND e.status IN ('assigned','picked_up')) > 1`);
    check('requests: one driver per request', doubleWin === 0, `${assignedN}/${errs.length} assigned`);
    check('requests: no driver booked twice (orders + requests)', busy.length === 0, `${busy.length} drivers`);
  }

  /* ---------------- 6) nobody sees another's orders ---------------- */
  {
    const someOrder = await db.one(`SELECT id, customer_id, cook_id FROM orders ORDER BY id DESC LIMIT 1`);
    const otherCust = custs.find((c) => c.id !== someOrder.customer_id);
    const otherStore = stores.find((s) => s.id !== someOrder.cook_id);
    const a = await http('GET', `/api/customer/orders/${someOrder.id}`, { cookie: otherCust.cookie });
    const b = await http('POST', `/api/store/orders/${someOrder.id}/accept`, { cookie: otherStore.cookie, body: {} });
    check('isolation: another customer / store can\'t open or touch an order', [403, 404].includes(a.status) && [403, 404].includes(b.status), `${a.status}, ${b.status}`);
  }

  /* ---------------- 7) the crowd: browsing, searching, store pages, GPS, offers ---------------- */
  {
    const lat = [];
    const stats = new Map();
    const rec = (k, ms, s) => { let x = stats.get(k); if (!x) { x = { lat: [], bad: 0 }; stats.set(k, x); } x.lat.push(ms); if (s >= 500 || s === 0) x.bad += 1; };
    const deadline = Date.now() + seconds * 1000;
    async function one() {
      const r = Math.random(), t = performance.now();
      let k, res;
      try {
        if (r < 0.25) { k = 'nearby stores'; res = await http('GET', `/api/delivery/stores?country=LB&lat=${C0.lat + rand(-0.05, 0.05)}&lng=${C0.lng + rand(-0.05, 0.05)}`); }
        else if (r < 0.40) { k = 'search'; res = await http('GET', `/api/delivery/stores?country=LB&q=${encodeURIComponent(pick(['متجر', 'منتج', 'صيدلية', 'ضغط']))}`); }
        else if (r < 0.55) { k = 'store page'; res = await http('GET', `/api/delivery/stores/${pick(stores).id}?country=LB`); }
        else if (r < 0.62) { k = 'offers'; res = await http('GET', '/api/delivery/offers?country=LB'); }
        else if (r < 0.75) { const d = pick(drvs); k = 'driver GPS'; res = await http('POST', '/api/driver/availability', { cookie: d.cookie, body: { available: true, lat: d.lat + rand(-0.001, 0.001), lng: d.lng + rand(-0.001, 0.001) } }); }
        else if (r < 0.85) { k = 'driver offers'; res = await http('GET', '/api/driver/offers', { cookie: pick(drvs).cookie }); }
        else if (r < 0.92) { k = 'store orders'; res = await http('GET', '/api/store/orders', { cookie: pick(stores).cookie }); }
        else { k = 'my orders'; res = await http('GET', '/api/customer/orders', { cookie: pick(custs).cookie }); }
      } catch { res = { status: 0 }; }
      const ms = performance.now() - t; lat.push(ms); rec(k, ms, res.status);
    }
    await Promise.all(Array.from({ length: concurrency }, async () => { while (Date.now() < deadline) await one(); }));
    const bad = [...stats.values()].reduce((a, x) => a + x.bad, 0);
    for (const [k, x] of stats) log(`   ${k.padEnd(14)} ${String(x.lat.length).padStart(6)} req  p50 ${pct(x.lat, 0.5).toFixed(0).padStart(5)} ms  p95 ${pct(x.lat, 0.95).toFixed(0).padStart(5)} ms  errors ${x.bad}`);
    check('crowd: no server errors', bad === 0, `${lat.length} requests by ${concurrency} at once in ${seconds}s, p95 ${pct(lat, 0.95).toFixed(0)} ms`);
  }

  check('no 5xx anywhere', fivexx.length === 0, fivexx.slice(0, 5).join(' | '));
  clearInterval(keepFresh);
  await app.close();
  return results;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const { values: o } = parseArgs({ options: { db: { type: 'string', default: 'sqlite::memory:' }, customers: { type: 'string', default: '2000' }, drivers: { type: 'string', default: '500' }, stores: { type: 'string', default: '150' }, seconds: { type: 'string', default: '30' }, concurrency: { type: 'string', default: '200' } } });
  const r = await runStress({ db: o.db, customers: Number(o.customers), drivers: Number(o.drivers), stores: Number(o.stores), seconds: Number(o.seconds), concurrency: Number(o.concurrency) });
  const bad = r.filter((x) => !x.ok);
  console.log(bad.length ? `\n${bad.length} check(s) FAILED` : '\nALL CHECKS PASSED');
  process.exit(bad.length ? 1 : 0);
}
