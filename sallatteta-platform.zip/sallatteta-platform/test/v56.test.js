// v5.6: craftspeople (group "crafts"): private location, call + "come to me", own tab and "everything near me", description required.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { mergeSettings, DEFAULT_SETTINGS } from '../src/services/settings.js';

let app, base, ck, z;
const call = async (m, p, body, cookie = ck) => {
  const r = await fetch(base + p, { method: m, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, data: await r.json().catch(() => null) };
};
before(async () => {
  app = await createApp({ databaseUrl: 'sqlite::memory:', sessionSecret: 'x'.repeat(40), quiet: true, adminWhatsapp: '96170999999',
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' }, applyLimit: 1e4, searchLimit: 1e4, lookupLimit: 1e4, placesFetcher: async () => [],
    geoFetcher: async () => ({ country: 'LB', locality: 'زحلة' }) });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  const l = await fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify({ username: 'admin', password: 'correct-horse-battery' }) });
  ck = l.headers.get('set-cookie').split(';')[0];
  z = (await call('GET', `/api/areas/search?q=${encodeURIComponent('زحلة')}`)).data.areas[0].id;
});
after(async () => { await app.close(); });

test('default crafts exist (group "crafts"); a site saved before gets them once; a deleted craft stays deleted', async () => {
  const cats = (await call('GET', '/api/admin/settings')).data.categories;
  assert.ok(['electrician', 'plumber', 'mechanic'].every((k) => cats.find((c) => c.key === k)?.group === 'crafts'));
  const old = cats.filter((c) => c.group !== 'crafts').map(({ group, ...c }) => c);
  assert.ok(mergeSettings(DEFAULT_SETTINGS, { categories: old }).categories.some((c) => c.key === 'electrician'), 'added once for old sites');
  const del = cats.map((c) => (c.key === 'painter' ? { ...c, deleted: true } : c));
  assert.equal((await call('PUT', '/api/admin/settings', { categories: del })).status, 200);
  assert.equal((await call('GET', '/api/admin/settings')).data.categories.find((c) => c.key === 'painter').deleted, true);
});

test('a craftsperson must describe the services; then: no directions (private), a call button, own tab for "everything near me"', async () => {
  const body = { acceptTerms: true, password: 'elec-12345', kind: 'electrician', fullName: 'محمد الكهربائي', whatsapp: '71 888 001', lat: 33.8466, lng: 35.9031, servedAreaIds: [z], plan: 'monthly', startedAt: Date.now() - 5000 };
  assert.equal((await call('POST', '/api/cook-applications', { ...body, bio: 'قصير' }, null)).data.fields?.bio, 'describe_services');
  const r = await call('POST', '/api/cook-applications', { ...body, bio: 'تمديدات كهربائية، تصليح أعطال، تركيب إنارة وقواطع.' }, null);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await call('POST', `/api/admin/cooks/${r.data.applicationId}/approve`, {});
  await call('POST', `/api/admin/cooks/${r.data.applicationId}/subscription/activate`, { plan: 'monthly', startDate: new Date(Date.now() - 60000).toISOString() });
  await call('POST', '/api/admin/cooks', { kind: 'bakery', fullName: 'فرن', whatsapp: '+96171888002', areaId: z, lat: 33.847, lng: 35.903, servedAreaIds: [z], activate: { plan: 'monthly', startDate: new Date(Date.now() - 60000).toISOString() } });
  const prof = (await call('GET', `/api/cooks/${r.data.applicationId}`, null, null)).data;
  assert.equal(prof.nav, null, 'a craftsperson\'s location is never shown');
  assert.equal(prof.callPhone, '96171888001');
  const crafts = (await call('GET', '/api/cooks/nearby?lat=33.8466&lng=35.9031&type=all&group=crafts', null, null)).data.cooks;
  const shops = (await call('GET', '/api/cooks/nearby?lat=33.8466&lng=35.9031&type=all', null, null)).data.cooks;
  assert.deepEqual(crafts.map((c) => c.name), ['محمد الكهربائي']);
  assert.ok(shops.some((c) => c.name === 'فرن') && !shops.some((c) => c.name === 'محمد الكهربائي'));
  assert.deepEqual((await call('POST', '/api/route/distances', { lat: 33.8466, lng: 35.9031, ids: [r.data.applicationId] }, null)).data.distances, [], 'no route to a craftsperson\'s home');
});
