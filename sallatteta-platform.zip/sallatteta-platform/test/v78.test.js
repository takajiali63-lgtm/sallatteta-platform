// v7.8: DIRECT money (default — the platform never touches money: the driver hands stores their money, stores confirm),
// the owner's switch to hide drivers from stores, reminders, the driver's fast screen data, Google Play readiness
// (offensive words, reports, blocking, prescriptions, account deletion), and fixes (distance without location, records).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { createPayments } from '../src/services/payments.js';
import { runReminders, isQuiet } from '../src/services/reminders.js';
import { localize } from '../src/services/push.js';
import { hasProfanity } from '../src/lib/profanity.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
const PAY_ENV = { PAY_CHECKOUT_URL: 'https://pay.example/create', PAY_API_KEY: 'k', PAY_WEBHOOK_SECRET: 'whsec' };
const fakePay = async (url, opts) => ({ ok: true, status: 200, json: async () => ({ url: `https://pay.example/c/${JSON.parse(opts.body).reference}` }) });
let app, base, admin, areaId, cust;
const pushed = [];
const fakePush = { notify: (type, id, msg) => pushed.push({ type, id, ...msg }), notifyAdmins: () => {}, subscribe: async () => {}, publicKey: async () => 'k' };

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let n = 0;
async function makeDriver(lat, lng, extra = {}) {
  const phone = `7190${String(1000 + n++).padStart(4, '0')}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ' + phone.slice(-3), phone, password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: `7166${phone.slice(-4)}`, acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, ...extra } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  const cookie = await login('/api/driver/login', { phone, password: 'pass123' });
  await http('POST', '/api/driver/availability', { body: { available: true, lat, lng }, cookie });
  return { id: r.data.id, cookie, phone };
}
let sn = 0;
async function makeStore(lat, lng, { kind = 'restaurant', price = 10, pay = 'both' } = {}) {
  const wa = `+9617170${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل ' + sn, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'delivery' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency) VALUES ($1,'طبق',$2,'USD')`, [r.data.id, price]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  await http('POST', '/api/store/settings', { cookie, body: { deliveryFee: 2, payMethods: pay } });
  return { id: r.data.id, cookie, item, lat, lng, pw, wa };
}
async function deliver(d, st, qty = 1) {
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty }], lat: st.lat + 0.004, lng: st.lng, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
  const s = await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: {} });
  assert.equal(s.status, 200, JSON.stringify(s.data));
  const off = (await http('GET', '/api/driver/offers', { cookie: d.cookie })).data.offers.find((x) => x.orderId === o.data.id);
  assert.ok(off, 'offered');
  assert.equal((await http('POST', `/api/driver/offers/${off.id}/accept`, { cookie: d.cookie, body: {} })).status, 200);
  await http('POST', `/api/driver/orders/${o.data.id}/delivered`, { cookie: d.cookie, body: {} });
  await http('POST', `/api/customer/orders/${o.data.id}/confirm`, { cookie: cust, body: {} });
  return o.data.id;
}
const fin = async (d) => (await http('GET', '/api/driver/finance', { cookie: d.cookie })).data.finance;

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [], push: fakePush,
    payments: createPayments({ env: PAY_ENV, fetchImpl: fakePay, log: {} }),
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03999666', acceptTerms: true });
  await A('PUT', '/api/admin/delivery/settings', { claimWindowSec: 0, offerBatch: 5, cashLimit: 200, driverService: 1 });
});
after(() => app?.close?.());

test('direct money is the default: no card even when a gateway exists; no settlements through the platform', async () => {
  const st = await makeStore(35.00, 35.50, { pay: 'both' });
  const s = (await http('GET', `/api/delivery/stores/${st.id}`)).data.store;
  assert.deepEqual(s.payMethods, ['cash']);
  const card = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: 35.004, lng: 35.50, paymentMethod: 'card' } });
  assert.equal(card.status, 422);
  const ss = (await http('GET', '/api/store/settings', { cookie: st.cookie })).data;
  assert.deepEqual([ss.payMethods, ss.cardAvailable, ss.flags.platformMoney], ['cash', false, false]);
  const d = await makeDriver(35.001, 35.501);
  await deliver(d, st, 3);
  for (const p of ['/api/driver/settlements', '/api/driver/settlements/online']) {
    const r = await http('POST', p, { cookie: d.cookie, body: { amount: 30, method: 'whish', reference: 'WH-1', gateway: 'whish' } });
    assert.deepEqual([r.status, r.data.error], [409, 'direct_money']);
  }
  assert.equal((await http('GET', '/api/store/wallet', { cookie: st.cookie })).data.flags.platformMoney, false);
});

test('the driver hands each store its money; the store confirms (or not); reminders; admin sees who owes whom', async () => {
  const A1 = await makeStore(35.10, 35.50, { price: 10 }), B1 = await makeStore(35.102, 35.50, { price: 15 });
  const d = await makeDriver(35.101, 35.501);
  await deliver(d, A1, 2); await deliver(d, A1, 1); await deliver(d, B1, 2);   // A: 20 + 10, B: 30
  let f = await fin(d);
  assert.deepEqual(f.owed.map((x) => [x.storeId, x.amount, x.orders]), [[A1.id, 30, 2], [B1.id, 30, 1]].sort((a, b) => (a[0] === A1.id ? -1 : 1)));
  assert.ok(f.owed.every((x) => x.phone && x.since));
  // the store sees the driver (photo route works for it), with phone and since when
  const sf = (await http('GET', '/api/store/finance', { cookie: A1.cookie })).data.finance;
  assert.deepEqual(sf.drivers.map((x) => [x.driverId, x.owes, x.orders]), [[d.id, 30, 2]]);
  assert.ok(sf.drivers[0].phone && sf.drivers[0].since);
  assert.notEqual((await fetch(`${base}/api/store/driver-photo/${d.id}`, { headers: { Cookie: A1.cookie } })).status, 404);
  // the driver says "I handed it" → the store must confirm; the store says "not received" → recorded, the driver is told
  pushed.length = 0;
  const h1 = await http('POST', '/api/driver/handover', { cookie: d.cookie, body: { storeId: A1.id } });
  assert.deepEqual([h1.status, h1.data.amount], [200, 30]);
  assert.ok(pushed.some((p) => p.type === 'store' && p.id === A1.id && p.key === 'store_handover_claim'));
  const claim = (await http('GET', '/api/store/finance', { cookie: A1.cookie })).data.finance.drivers[0].claim;
  assert.equal(claim.amount, 30);
  assert.equal((await http('POST', `/api/store/handovers/${claim.id}/deny`, { cookie: A1.cookie, body: { note: 'ما وصلني شي' } })).status, 200);
  assert.ok((await app.db.query(`SELECT id FROM security_events WHERE kind = 'handover_denied' AND driver_id = $1`, [d.id])).length);
  assert.equal((await fin(d)).owed.find((x) => x.storeId === A1.id).claim.status, 'denied');
  // the store reminds him (once an hour at most)
  assert.equal((await http('POST', `/api/store/finance/drivers/${d.id}/remind`, { cookie: A1.cookie, body: {} })).status, 200);
  assert.equal((await http('POST', `/api/store/finance/drivers/${d.id}/remind`, { cookie: A1.cookie, body: {} })).status, 429);
  // the owner sees everyone who owes, oldest first, and reminds one driver / all of them
  const dues = (await A('GET', '/api/admin/finance/dues')).data;
  const mine = dues.drivers.find((x) => x.driverId === d.id);
  assert.deepEqual([mine.total, mine.stores.length], [60, 2]);
  assert.ok(dues.handovers.some((h) => h.driver_id === d.id && h.status === 'denied'));
  assert.equal((await A('POST', '/api/admin/finance/dues/remind', { driverId: d.id })).data.reminded, 1);
  assert.ok((await A('POST', '/api/admin/finance/dues/remind', {})).data.reminded >= 1);
  assert.ok((await http('GET', '/api/driver/me', { cookie: d.cookie })).data.duesReminder);
  // only one order received from B, then everything from A and the rest of B
  const bOrders = (await http('GET', `/api/store/finance/drivers/${d.id}`, { cookie: B1.cookie })).data.orders;
  const one = await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: B1.cookie, body: { orderIds: [bOrders[0].orderId] } });
  assert.deepEqual([one.status, one.data.status, one.data.amount], [200, 'pending', 30], 'v8: the store said it — the driver must say the same');
  assert.ok(pushed.some((p) => p.type === 'driver' && p.id === d.id && p.key === 'drv_store_says_received'));
  const both = await http('POST', '/api/driver/handover', { cookie: d.cookie, body: { storeId: B1.id, amount: 30 } });
  assert.deepEqual([both.status, both.data.status, both.data.amount, both.data.left], [200, 'confirmed', 30, 0]);
  assert.equal((await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: B1.cookie, body: {} })).status, 409, 'nothing left: never twice');
  await http('POST', '/api/driver/handover', { cookie: d.cookie, body: { storeId: A1.id } });
  const all = await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: A1.cookie, body: {} });
  assert.equal(all.data.amount, 30);
  f = await fin(d);
  assert.deepEqual([f.restaurantCash, f.owed.length, f.cashOrders], [0, 0, true]);
  assert.equal((await http('GET', '/api/driver/me', { cookie: d.cookie })).data.duesReminder, null, 'reminder cleared once he owes nothing');
  assert.equal((await http('GET', '/api/store/finance', { cookie: A1.cookie })).data.finance.settled, 30);
  assert.equal((await A('GET', '/api/admin/finance/dues')).data.drivers.some((x) => x.driverId === d.id), false);
  // another store can't confirm or deny for someone else
  assert.equal((await http('POST', `/api/store/handovers/${claim.id}/deny`, { cookie: B1.cookie, body: {} })).status, 409);
});

test('the cash limit still protects stores in direct mode: at 200 $ unconfirmed, no new cash orders until BOTH confirm', async () => {
  const st = await makeStore(35.20, 35.50, { price: 100 });
  const d = await makeDriver(35.201, 35.501);
  await deliver(d, st, 2);   // 200 $
  assert.equal((await fin(d)).cashOrders, false);
  await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: st.cookie, body: {} });
  assert.equal((await fin(d)).cashOrders, false, 'v8: one side is not enough');
  await http('POST', '/api/driver/handover', { cookie: d.cookie, body: { storeId: st.id } });
  assert.equal((await fin(d)).cashOrders, true);
});

test('owner switch: drivers hidden from stores — plans, store panel, search; customers keep requests; drivers\' plan compulsory', async () => {
  const st = await makeStore(35.30, 35.50);
  await A('PUT', '/api/admin/delivery/settings', { driverService: 0 });
  const plans = (await http('GET', '/api/plans')).data;
  assert.deepEqual([plans.store.delivery, plans.jobsRequired, plans.flags.driverService], [{}, true, false]);
  assert.equal((await http('GET', '/api/store/wallet', { cookie: st.cookie })).data.deliveryMode, 'self');
  const sub = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.deepEqual(sub.options.map((o) => o.kind), ['basic']);
  assert.equal((await http('GET', `/api/delivery/stores/${st.id}`)).data.store.ownDelivery, true);
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: 35.304, lng: 35.50 } });
  assert.equal(o.status, 201, 'customers still order; the store delivers itself');
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
  const s = await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: {} });
  assert.deepEqual([s.status, s.data.error], [409, 'driver_service_off']);
  assert.equal((await http('POST', `/api/store/orders/${o.data.id}/self-dispatch`, { cookie: st.cookie, body: {} })).status, 200);
  // a driver must choose the customer-requests plan
  const noPlan = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق بلا خطة', phone: '71955501', password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: '71955501', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS } });
  assert.equal(noPlan.status, 422);
  const withPlan = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق بخطة', phone: '71955502', password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: '71955502', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(withPlan.status, 201, JSON.stringify(withPlan.data));
  // the renewal with drivers can't be asked for
  assert.equal((await http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'delivery', months: 1, method: 'whish', receipt: JPG } })).status, 422);
  await A('PUT', '/api/admin/delivery/settings', { driverService: 1 });
  assert.equal((await http('GET', '/api/store/wallet', { cookie: st.cookie })).data.deliveryMode, 'delivery', 'switched back: everything returns');
  assert.ok(Object.keys((await http('GET', '/api/plans')).data.store.delivery).length);
});

test('driver sign-up: the plate is asked for cars only', async () => {
  const base1 = { password: 'pass123', walletProvider: 'whish', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS };
  assert.equal((await http('POST', '/api/driver/apply', { body: { ...base1, fullName: 'سائق موتو', phone: '71955601', walletNumber: '71955601', vehicle: 'moto' } })).status, 201);
  assert.equal((await http('POST', '/api/driver/apply', { body: { ...base1, fullName: 'سائق سيارة', phone: '71955602', walletNumber: '71955602', vehicle: 'car' } })).status, 422);
  assert.equal((await http('POST', '/api/driver/apply', { body: { ...base1, fullName: 'سائق سيارة', phone: '71955603', walletNumber: '71955603', vehicle: 'car', plate: 'B 99' } })).status, 201);
});

test('fixes: no distance for a store without a location; any finished order can leave the records (money stays recorded)', async () => {
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل بلا موقع', whatsapp: '+96171755999', areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: 'restaurant', activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201);
  await app.db.query('UPDATE cooks SET lat = 0, lng = 0 WHERE id = $1', [r.data.id]);   // a place never set
  const v = (await http('GET', `/api/delivery/stores/${r.data.id}?lat=33.89&lng=35.50`)).data.store;
  assert.equal(v.distanceM, null, 'was ~5,300 km (measured to 0,0)');
  // the real cause: a customer without a location (search by name) was measured from 0,0 — now no distance at all
  const st0 = await makeStore(35.45, 35.50);
  assert.equal((await http('GET', `/api/delivery/stores/${st0.id}`)).data.store.distanceM, null);
  assert.ok((await http('GET', `/api/delivery/stores?q=${encodeURIComponent('محل')}&country=LB`)).data.stores.every((x) => x.distanceM == null));
  assert.ok((await http('GET', `/api/delivery/stores/${st0.id}?lat=35.46&lng=35.50`)).data.store.distanceM < 2000);
  const st = await makeStore(35.40, 35.50);
  const d = await makeDriver(35.401, 35.501);
  const id = await deliver(d, st, 2);
  assert.equal((await http('POST', `/api/store/orders/${id}/hide`, { cookie: st.cookie, body: {} })).status, 200);
  assert.equal((await http('GET', '/api/store/finance', { cookie: st.cookie })).data.finance.outstandingWithDrivers, 20);
});

test('Google Play: offensive words refused everywhere others can read; reports; blocking a store', async () => {
  assert.equal(hasProfanity('شاورما دجاج'), false);
  const st = await makeStore(35.50, 35.50);
  const bad = await http('POST', '/api/cook/menu', { cookie: st.cookie, body: { name: 'يا شرموطة', price: 1 } });
  assert.deepEqual([bad.status, bad.data.error], [422, 'inappropriate_words']);
  assert.equal((await http('POST', '/api/cook/menu', { cookie: st.cookie, body: { name: 'كسكسي', price: 1 } })).status, 201);
  assert.equal((await http('PATCH', '/api/cook/me', { cookie: st.cookie, body: { bio: 'fuck this' } })).status, 422);
  const d = await makeDriver(35.501, 35.501);
  const id = await deliver(d, st, 1);
  assert.equal((await http('POST', `/api/customer/orders/${id}/rate`, { cookie: cust, body: { stars: 1, note: 'كس امك' } })).status, 422);
  assert.equal((await http('POST', `/api/customer/orders/${id}/rate`, { cookie: cust, body: { stars: 4, note: 'طيب كتير' } })).status, 200);
  // report a store (pictures, words, a medicine without prescription…)
  assert.equal((await http('POST', '/api/report', { body: { cookId: st.id, reason: 'image', note: 'صورة غير لائقة' } })).status, 201);
  assert.ok((await app.db.query(`SELECT id FROM site_messages WHERE contact LIKE $1`, [`#${st.id} %`])).length);
  // block it: it disappears from this customer's lists
  const list = async () => (await http('GET', `/api/delivery/stores?lat=35.50&lng=35.50&country=LB`, { cookie: cust })).data.stores.map((x) => x.id);
  assert.ok((await list()).includes(st.id));
  assert.equal((await http('POST', `/api/customer/blocked/${st.id}`, { cookie: cust, body: { on: true } })).status, 200);
  assert.ok(!(await list()).includes(st.id));
  assert.deepEqual((await http('GET', '/api/customer/me', { cookie: cust })).data.blocked, [st.id]);
  await http('POST', `/api/customer/blocked/${st.id}`, { cookie: cust, body: { on: false } });
  assert.ok((await list()).includes(st.id));
});

test('Google Play: a medicine that needs a prescription is ordered only with the prescription photo, seen by that pharmacy only', async () => {
  const ph = await makeStore(35.60, 35.50, { kind: 'pharmacy' });
  const add = await http('POST', '/api/cook/menu', { cookie: ph.cookie, body: { name: 'مضاد حيوي', price: 8, rx: true } });
  assert.equal(add.status, 201);
  const rxItem = add.data.menu.find((m) => m.name === 'مضاد حيوي');
  assert.equal(rxItem.rx, true);
  assert.equal((await http('GET', `/api/delivery/stores/${ph.id}`)).data.menu.find((m) => m.id === rxItem.id).rx, true);
  const body = { storeId: ph.id, items: [{ id: rxItem.id, qty: 1 }], lat: 35.604, lng: 35.50 };
  const no = await http('POST', '/api/orders', { cookie: cust, body });
  assert.deepEqual([no.status, no.data.error], [422, 'prescription_required']);
  const yes = await http('POST', '/api/orders', { cookie: cust, body: { ...body, prescription: JPG } });
  assert.equal(yes.status, 201);
  const ord = (await http('GET', '/api/store/orders', { cookie: ph.cookie })).data.orders.find((o) => o.id === yes.data.id);
  assert.equal(ord.prescription, true);
  assert.equal((await fetch(`${base}/api/store/orders/${yes.data.id}/prescription`, { headers: { Cookie: ph.cookie } })).status, 200);
  const other = await makeStore(35.70, 35.50);
  assert.equal((await fetch(`${base}/api/store/orders/${yes.data.id}/prescription`, { headers: { Cookie: other.cookie } })).status, 404);
  // ordinary items need nothing
  assert.equal((await http('POST', '/api/orders', { cookie: cust, body: { storeId: ph.id, items: [{ id: ph.item, qty: 1 }], lat: 35.604, lng: 35.50 } })).status, 201);
});

test('Google Play: drivers and stores delete their own account from inside the app', async () => {
  const st = await makeStore(35.80, 35.50);
  const d = await makeDriver(35.801, 35.501);
  await deliver(d, st, 1);
  assert.equal((await http('POST', '/api/driver/me/delete', { cookie: d.cookie, body: { password: 'wrong' } })).status, 401);
  const owes = await http('POST', '/api/driver/me/delete', { cookie: d.cookie, body: { password: 'pass123' } });
  assert.deepEqual([owes.status, owes.data.error], [409, 'dues_first']);
  await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: st.cookie, body: {} });
  await http('POST', '/api/driver/handover', { cookie: d.cookie, body: { storeId: st.id } });   // v8: both sides
  assert.equal((await http('POST', '/api/driver/me/delete', { cookie: d.cookie, body: { password: 'pass123' } })).status, 200);
  assert.equal((await http('POST', '/api/driver/login', { body: { phone: d.phone, password: 'pass123' } })).status, 401);
  assert.equal((await app.db.query('SELECT id FROM driver_documents WHERE driver_id = $1', [d.id])).length, 0);
  assert.equal((await http('POST', '/api/cook/me/delete', { cookie: st.cookie, body: { password: st.pw } })).status, 200);
});

test('automatic reminders: limited steps, quiet at night, each once; texts in the phone\'s language', async () => {
  const s = { remindStoreMin: 2, remindConfirmMin: 15, confirmAfterMin: 120, cashLimit: 200 };
  const st = await makeStore(35.90, 35.50);
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: 35.904, lng: 35.50 } });
  const day = new Date('2026-10-07T09:00:00Z');   // 12:00 in Beirut
  assert.equal(isQuiet(day), false);
  assert.equal(isQuiet(new Date('2026-10-07T22:00:00Z')), true);   // 01:00 in Beirut
  await app.db.query('UPDATE orders SET created_at = $1 WHERE id = $2', [new Date(day.getTime() - 3 * 60_000).toISOString(), o.data.id]);
  const msgs = [];
  const p = { notify: (type, id, m) => msgs.push({ type, id, ...m }) };
  await runReminders(app.db, p, s, { now: day });
  await runReminders(app.db, p, s, { now: day });
  assert.equal(msgs.filter((m) => m.key === 'store_pending_remind' && m.id === st.id).length, 1, 'once per step');
  await runReminders(app.db, p, s, { now: new Date(day.getTime() + 3 * 60_000) });
  assert.equal(msgs.filter((m) => m.key === 'store_pending_remind' && m.id === st.id).length, 2, 'second (last) step');
  await runReminders(app.db, p, s, { now: new Date(day.getTime() + 30 * 60_000) });
  assert.equal(msgs.filter((m) => m.key === 'store_pending_remind' && m.id === st.id).length, 2, 'never more');
  // delivered, not confirmed: 15 / 45 / 90 minutes
  const d = await makeDriver(35.901, 35.501);
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
  await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: {} });
  const off = (await http('GET', '/api/driver/offers', { cookie: d.cookie })).data.offers.find((x) => x.orderId === o.data.id);
  await http('POST', `/api/driver/offers/${off.id}/accept`, { cookie: d.cookie, body: {} });
  await http('POST', `/api/driver/orders/${o.data.id}/delivered`, { cookie: d.cookie, body: {} });
  const at = (min) => new Date(day.getTime() + min * 60_000);
  await app.db.query('UPDATE orders SET delivered_at = $1 WHERE id = $2', [day.toISOString(), o.data.id]);
  for (const m of [5, 16, 20, 46, 91, 100]) await runReminders(app.db, p, s, { now: at(m) });
  assert.equal(msgs.filter((m) => m.key === 'cust_confirm_remind').length, 3);
  // at night nothing that can wait
  const before = msgs.length;
  await app.db.query('UPDATE orders SET delivered_at = $1 WHERE id = $2', [new Date('2026-10-07T21:30:00Z').toISOString(), o.data.id]);
  await app.db.query(`DELETE FROM notif_log WHERE kind = 'cust_confirm'`);
  await runReminders(app.db, p, s, { now: new Date('2026-10-07T22:00:00Z') });
  assert.equal(msgs.length, before);
  // the phone's language
  assert.equal(localize({ key: 'store_pending_remind', vars: { ref: 'AKL9' }, body: 'x' }, 'fr').body, '⏰ La commande AKL9 attend votre confirmation');
  assert.equal(localize({ key: 'store_pending_remind', vars: { ref: 'AKL9' }, body: 'x' }, null).body, '⏰ الطلب AKL9 بانتظار تأكيدك');
  assert.equal(localize({ body: 'plain' }, 'en').body, 'plain');
});

test('direct money: drivers sign up without a wallet number (the platform pays nobody)', async () => {
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق بلا محفظة', phone: '71955701', password: 'pass123', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
});
