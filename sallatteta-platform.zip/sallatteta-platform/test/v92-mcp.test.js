// v8.3 the owner's Claude connector (/mcp): a secret key from the admin panel, a fixed list of safe tools,
// every change previewed (before → after) and applied only with confirm=true, everything in the admin log as Claude,
// revoked keys stop at once, and no tool can delete, move money or touch passwords.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { TOOL_DEFS } from '../src/routes/mcp.js';

let app, base, admin, key, keyId, areaId, storeId;
async function http(method, path, { body, cookie, headers = {} } = {}) {
  const res = await fetch(base + path, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let rid = 0;
const mcp = (method, params, k = key) => fetch(base + '/mcp', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json, text/event-stream', ...(k ? { Authorization: `Bearer ${k}` } : {}) }, body: JSON.stringify({ jsonrpc: '2.0', id: ++rid, method, params }) })
  .then(async (r) => ({ status: r.status, data: r.status === 202 ? null : await r.json() }));
const tool = async (name, args = {}) => (await mcp('tools/call', { name, arguments: args })).data.result;

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 's'.repeat(40), quiet: true, runJobs: false,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' }, loginLimit: 1e4, adminLimit: 1e5, placesFetcher: async () => [],
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  const res = await fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify({ username: 'admin', password: 'correct-horse-battery' }) });
  admin = res.headers.get('set-cookie').split(';')[0];
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'مطعم الضيعة', whatsapp: '+96171901234', areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: 'restaurant', lat: 33.85, lng: 35.9, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  storeId = r.data.id;
});
after(async () => { await app.close(); });

test('no key → 401; the owner makes a key (shown once, kept as a hash)', async () => {
  assert.equal((await mcp('tools/list', {}, null)).status, 401);
  assert.equal((await mcp('tools/list', {}, 'akl_wrongwrongwrongwrongwrongwrong')).status, 401);
  assert.equal((await http('POST', '/api/admin/mcp/tokens', { body: { label: 'x' } })).status, 401);   // not logged in
  const r = await A('POST', '/api/admin/mcp/tokens', { label: 'Claude — هاتفي' });
  assert.equal(r.status, 201);
  key = r.data.token; keyId = r.data.key.id;
  assert.match(key, /^akl_/);
  const stored = (await app.db.one(`SELECT value FROM app_meta WHERE key = 'mcp_tokens'`)).value;
  assert.ok(!stored.includes(key), 'the key itself is never stored');
  const list = await A('GET', '/api/admin/mcp');
  assert.equal(list.data.tokens.length, 1);
  assert.equal(list.data.tokens[0].hash, undefined);
});

test('MCP handshake: initialize, initialized (202), ping, tools/list', async () => {
  const i = await mcp('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'claude', version: '1' } });
  assert.equal(i.status, 200);
  assert.equal(i.data.result.protocolVersion, '2025-06-18');
  assert.ok(i.data.result.capabilities.tools);
  const n = await fetch(base + '/mcp', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` }, body: JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) });
  assert.equal(n.status, 202);
  assert.deepEqual((await mcp('ping')).data.result, {});
  assert.equal((await fetch(base + '/mcp', { headers: { Authorization: `Bearer ${key}` } })).status, 405);
  const t = (await mcp('tools/list')).data.result.tools;
  assert.equal(t.length, TOOL_DEFS.length);
  for (const x of t) assert.ok(x.inputSchema && x.description, x.name);
  assert.equal((await mcp('nope/nothing')).data.error.code, -32601);
});

test('no dangerous tool exists (delete / money / password / payment numbers)', async () => {
  const names = (await mcp('tools/list')).data.result.tools.map((x) => x.name).join(' ').toLowerCase();
  for (const bad of ['delete', 'password', 'withdraw', 'payout', 'transfer', 'payto', 'refund', 'wipe']) assert.ok(!names.includes(bad), bad);
  const r = await mcp('tools/call', { name: 'delete_account', arguments: { id: 1 } });
  assert.ok(r.data.error);
  // the money switches of the delivery settings are refused
  const m = await tool('set_delivery_settings', { settings: { platformMoney: 1 }, confirm: true });
  assert.equal(m.isError, true);
  assert.match(m.content[0].text, /admin panel/);
});

test('read tools: overview, prices, stores, AI, pending', async () => {
  const o = await tool('overview');
  assert.ok(!o.isError, o.content[0].text);
  assert.ok('ordersToday' in o.structuredContent && 'ai' in o.structuredContent);
  const p = (await tool('get_prices')).structuredContent;
  assert.equal(p.currency, 'USD');
  assert.ok(p.store.basic['1'] > 0);
  assert.equal(p.payTo, undefined);
  const s = (await tool('list_stores', { q: 'الضيعة' })).structuredContent;
  assert.equal(s.stores[0].id, storeId);
  assert.ok((await tool('get_ai_config')).structuredContent.budgetsUsd.shops > 0);
  assert.ok(Array.isArray((await tool('list_pending')).structuredContent.renewals));
  assert.ok((await tool('get_delivery_settings')).structuredContent.storesRadiusKm > 0);
});

test('set_prices: preview shows before → after and saves NOTHING; confirm applies; all logged as Claude', async () => {
  const before = (await A('GET', '/api/admin/plans')).data.plans;
  const pv = await tool('set_prices', { store: { basic: { 1: 19 } }, ai: { shops: 35 } });
  assert.match(pv.content[0].text, /PREVIEW ONLY/);
  assert.equal(pv.structuredContent.preview, true);
  const ch = Object.fromEntries(pv.structuredContent.changes.map((c) => [c.field, c]));
  assert.equal(ch['store.basic.1'].before, before.store.basic['1'].price);
  assert.equal(ch['store.basic.1'].after, 19);
  assert.equal(ch['aiMonthly.shops'].after, 35);
  assert.deepEqual((await A('GET', '/api/admin/plans')).data.plans, before, 'preview saved nothing');
  const ok = await tool('set_prices', { store: { basic: { 1: 19 } }, ai: { shops: 35 }, confirm: true });
  assert.ok(!ok.isError, ok.content[0].text);
  const now = (await A('GET', '/api/admin/plans')).data.plans;
  assert.equal(now.store.basic['1'].price, 19);
  assert.equal(now.ai.shops['1'].price, 35);
  assert.equal(now.ai.shops['3'].price, 105, 'AI: no discount (monthly × 3)');
  const log = (await A('GET', '/api/admin/mcp')).data.log;
  assert.ok(log.some((l) => l.tool === 'set_prices' && l.applied));
  assert.ok(log.some((l) => l.tool === 'set_prices' && !l.applied));
  const row = await app.db.one(`SELECT details FROM admin_actions WHERE action = 'mcp_call' ORDER BY id DESC LIMIT 1`);
  assert.equal(JSON.parse(row.details).by, 'Claude');
  // wrong values are refused by the same checks as the panel
  assert.equal((await tool('set_prices', { store: { basic: { 2: 10 } }, confirm: true })).isError, true);
  assert.equal((await tool('set_prices', { store: { basic: { 1: -5 } }, confirm: true })).isError, true);
});

test('category plan, AI config (USD), delivery settings: preview then apply', async () => {
  const pv = await tool('set_category_plan', { kind: 'restaurant', products: 400, ai: { 1: 25 } });
  assert.equal(pv.structuredContent.preview, true);
  assert.equal((await A('GET', '/api/admin/settings')).data.catPlans?.restaurant, undefined);
  await tool('set_category_plan', { kind: 'restaurant', products: 400, ai: { 1: 25 }, confirm: true });
  assert.equal((await A('GET', '/api/admin/settings')).data.catPlans.restaurant.products, 400);

  const a = await tool('set_ai_config', { budgetsUsd: { shops: 10 }, monthlyCapUsd: 150, balanceUsd: 25 });
  assert.equal(a.structuredContent.preview, true);
  assert.equal(a.structuredContent.changes.find((c) => c.field === 'budgetsUsd.shops').before, 8);
  await tool('set_ai_config', { budgetsUsd: { shops: 10 }, monthlyCapUsd: 150, balanceUsd: 25, confirm: true });
  const cfg = (await A('GET', '/api/admin/ai/config')).data.config;
  assert.equal(cfg.budgets.shops, 1000);
  assert.equal(cfg.protect.monthlyCapCents, 15000);
  assert.equal(cfg.balance.cents, 2500);

  await tool('set_delivery_settings', { settings: { storesRadiusKm: 33 }, confirm: true });
  assert.equal((await A('GET', '/api/admin/delivery/settings')).data.settings.storesRadiusKm, 33);
  assert.equal((await tool('set_delivery_settings', { settings: { storesRadiusKm: 0 }, confirm: true })).isError, true, 'same range checks');
});

test('store AI, suspend, broadcast: preview first, then apply; nothing deleted', async () => {
  const pv = await tool('store_ai', { storeId, months: 2 });
  assert.equal(pv.structuredContent.preview, true);
  assert.equal((await app.db.one('SELECT ai_until FROM cooks WHERE id = $1', [storeId])).ai_until, null);
  await tool('store_ai', { storeId, months: 2, confirm: true });
  assert.ok(Date.parse((await app.db.one('SELECT ai_until FROM cooks WHERE id = $1', [storeId])).ai_until) > Date.now() + 50 * 864e5);

  await tool('suspend_account', { type: 'store', id: storeId, action: 'suspend', confirm: true });
  assert.equal(Number((await app.db.one('SELECT suspended FROM cooks WHERE id = $1', [storeId])).suspended), 1);
  await tool('suspend_account', { type: 'store', id: storeId, action: 'activate', confirm: true });
  assert.equal(Number((await app.db.one('SELECT suspended FROM cooks WHERE id = $1', [storeId])).suspended), 0);

  const b0 = (await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM broadcasts')).n;
  await tool('broadcast', { audience: 'stores', body: 'تحديث جديد بالتطبيق', days: 3 });
  assert.equal((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM broadcasts')).n, b0, 'preview sends nothing');
  await tool('broadcast', { audience: 'stores', body: 'تحديث جديد بالتطبيق', days: 3, confirm: true });
  assert.equal((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM broadcasts')).n, b0 + 1);
  // the short-lived admin sessions are gone after each call
  assert.equal((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM admin_sessions')).n, 1, 'only the owner\'s own login remains');
});

test('a revoked key stops at once', async () => {
  assert.equal((await A('DELETE', `/api/admin/mcp/tokens/${keyId}`)).status, 200);
  assert.equal((await mcp('tools/list')).status, 401);
  assert.equal((await A('GET', '/api/admin/mcp')).data.tokens.length, 0);
});
