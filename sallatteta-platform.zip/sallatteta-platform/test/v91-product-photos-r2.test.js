// v8.2 product photos on the photo storage (Cloudflare R2): a supermarket's thousands of photos no longer fill the
// database. New photos go straight to storage; the ones already in the database are moved (checked reachable first);
// the address the apps use (/api/menu-photo/<id>) keeps working — it now points to the storage.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/server.js';
import { migratePhotos, storageCounts } from '../src/services/photoMigration.js';
import { createStorage } from '../src/services/storage.js';

const IMG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
let r2, r2Base, app, base, admin, store, storeId;
const objects = new Map();
const call = async (m, p, body, cookie) => {
  const r = await fetch(base + p, { method: m, redirect: 'manual', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await r.text(); let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: r.status, data, headers: r.headers };
};
const S3 = () => ({ endpoint: r2Base, bucket: 'photos-bucket', accessKeyId: 'AKIDEXAMPLE', secretAccessKey: 'secret', publicUrl: `${r2Base}/pub`, region: 'auto' });

before(async () => {
  r2 = http.createServer((req, res) => {
    const chunks = []; req.on('data', (c) => chunks.push(c)); req.on('end', () => {
      if (req.method === 'PUT') { objects.set(req.url.replace(/^\/photos-bucket\//, '/'), Buffer.concat(chunks)); res.writeHead(200); return res.end(); }
      if (req.method === 'DELETE') { objects.delete(req.url.replace(/^\/photos-bucket\//, '/')); res.writeHead(204); return res.end(); }
      const key = req.url.replace(/^\/pub/, '');
      if (objects.has(key)) { res.writeHead(200, { 'Content-Type': 'image/jpeg' }); return res.end(req.method === 'HEAD' ? undefined : objects.get(key)); }
      res.writeHead(404); res.end();
    });
  });
  await new Promise((r) => r2.listen(0, r));
  r2Base = `http://127.0.0.1:${r2.address().port}`;
  // 1) photos saved in the database (no storage yet)
  app = await createApp({ databaseUrl: `sqlite:/tmp/r2p-${Date.now()}.db`, sessionSecret: 'p'.repeat(40), quiet: true, adminWhatsapp: '96170999999',
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' }, placesFetcher: async () => [] });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  admin = (await call('POST', '/api/admin/login', { username: 'admin', password: 'correct-horse-battery' })).headers.get('set-cookie').split(';')[0];
  const z = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  const c = (await call('POST', '/api/admin/cooks', { kind: 'supermarket', fullName: 'سوبرماركت الصور', whatsapp: '+96171777099', areaId: z, servedAreaIds: [z], lat: 33.85, lng: 35.9,
    activate: { plan: 'monthly', startDate: new Date(Date.now() - 60000).toISOString() } }, admin)).data;
  storeId = c.id;
  const pw = (await call('POST', `/api/admin/cooks/${c.id}/password`, {}, admin)).data.password;
  const login = async () => (await call('POST', '/api/cook/login', { whatsapp: '+96171777099', password: pw })).headers.get('set-cookie').split(';')[0];
  store = await login();
  for (const n of ['حليب', 'خبز']) assert.equal((await call('POST', '/api/cook/menu', { name: n, price: 1, photo: IMG }, store)).status, 201);
  const dbFile = app.cfg.databaseUrl;
  await app.close();
  // 2) then R2 is configured
  app = await createApp({ databaseUrl: dbFile, sessionSecret: 'p'.repeat(40), quiet: true, adminWhatsapp: '96170999999', placesFetcher: async () => [], s3: S3() });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  store = await login();
});
after(async () => { await app.close(); r2.close(); });

test('product photos already in the database are moved to storage; the same address now points there', async () => {
  const before = await storageCounts(app.db);
  assert.equal(before.productsInDb, 2);
  const r = await migratePhotos({ db: app.db, storage: createStorage(app.cfg) });
  assert.equal(r.products, 2);
  const after = await storageCounts(app.db);
  assert.deepEqual([after.productsInDb, after.productsInStorage], [0, 2]);
  const item = await app.db.one(`SELECT id, photo, photo_url FROM menu_items WHERE cook_id = $1 ORDER BY id LIMIT 1`, [storeId]);
  assert.equal(item.photo, null, 'the database copy is gone');
  const res = await call('GET', `/api/menu-photo/${item.id}`);
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), item.photo_url);
  assert.equal((await fetch(item.photo_url)).status, 200, 'really reachable');
});

test('a new product photo goes straight to storage; replacing / deleting removes the old file; the page shows it', async () => {
  const n0 = objects.size;
  const me = (await call('POST', '/api/cook/menu', { name: 'رز', price: 2, photo: IMG }, store)).data;
  const it = me.menu.find((x) => x.name === 'رز');
  assert.ok(it.photo, 'the app gets a photo address');
  const row = await app.db.one('SELECT photo, photo_url FROM menu_items WHERE id = $1', [it.id]);
  assert.equal(row.photo, null); assert.ok(row.photo_url.startsWith(r2Base));
  assert.equal(objects.size, n0 + 1);
  // replace → the old file is deleted from storage
  await call('PATCH', `/api/cook/menu/${it.id}`, { photo: IMG }, store);
  const row2 = await app.db.one('SELECT photo_url FROM menu_items WHERE id = $1', [it.id]);
  assert.notEqual(row2.photo_url, row.photo_url);
  assert.equal(objects.size, n0 + 1, 'old one removed, new one added');
  // remove the photo → no file left for it
  await call('PATCH', `/api/cook/menu/${it.id}`, { photo: null }, store);
  assert.equal((await app.db.one('SELECT photo_url FROM menu_items WHERE id = $1', [it.id])).photo_url, null);
  assert.equal(objects.size, n0);
  // the customer's store page still lists the photos of the moved products
  const page = (await call('GET', `/api/delivery/stores/${storeId}`)).data;
  assert.ok(page.menu.filter((x) => x.photo).length >= 2);
  // the photo number of the category counts storage photos too
  const cnt = await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1 AND (photo IS NOT NULL OR photo_url IS NOT NULL)', [storeId]);
  assert.equal(Number(cnt.n), 2);
});
