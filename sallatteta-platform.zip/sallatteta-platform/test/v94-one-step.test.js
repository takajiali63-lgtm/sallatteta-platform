// v8.5 one-step orders (owner's request): with «find a driver» hidden from the stores' plans, the store only accepts or
// refuses; the customer closes the order («I received it»), reminds the store (every 10 min at most) or asks on WhatsApp
// with a ready message; nothing closes by itself; an open order can be closed and removed by the customer.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
let app, base, admin, areaId, cust, cust2;
const pushed = [];
const fakePush = { notify: (type, id, msg) => pushed.push({ type, id, ...msg }), notifyAdmins: () => {}, subscribe: async () => {}, publicKey: async () => 'k' };

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let n = 0;
async function makeDriver(lat, lng, { jobs = true } = {}) {
  const phone = `7184${String(1000 + n++).padStart(4, '0')}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ' + phone.slice(-3) + ' الكنية', phone, password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: `7166${phone.slice(-4)}`, acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  if (jobs) await A('POST', `/api/admin/drivers/${r.data.id}/jobs`, { months: 1 });
  const cookie = await login('/api/driver/login', { phone, password: 'pass123' });
  await http('POST', '/api/driver/availability', { body: { available: true, lat, lng }, cookie });
  return { id: r.data.id, cookie, phone };
}
let sn = 0;
async function makeStore(lat, lng, { kind = 'restaurant', price = 10 } = {}) {
  const wa = `+9617184${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل ' + sn, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'delivery' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency, section) VALUES ($1,'بيتزا',$2,'USD','بيتزا')`, [r.data.id, price]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  return { id: r.data.id, cookie, item, lat, lng };
}
const order = (st, items, cookie = cust) => http('POST', '/api/orders', { cookie, body: { storeId: st.id, items, lat: st.lat + 0.004, lng: st.lng, paymentMethod: 'cash' } });
const S = (st, m, p, b) => http(m, p, { body: b, cookie: st.cookie });
const setS = (b) => A('PUT', '/api/admin/delivery/settings', b);
const C = (m, p, b, cookie = cust) => http(m, p, { body: b, cookie });

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true, runJobs: false,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [], push: fakePush,
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03185777', acceptTerms: true });
  cust2 = await login('/api/customer/login', { name: 'زبون آخر', phone: '03185778', acceptTerms: true });
  await setS({ driverService: 0 });   // the owner hid «find a driver» from the stores' plans
});
after(() => app?.close?.());

async function accepted(st) {
  const o = await order(st, [{ id: st.item, qty: 2 }]);
  assert.equal(o.status, 201, JSON.stringify(o.data));
  assert.equal((await S(st, 'POST', `/api/store/orders/${o.data.id}/accept`, {})).status, 200);
  return o.data.id;
}

test('store: only accept; customer: «I received it» closes it; no other button needed', async () => {
  const st = await makeStore(33.85, 35.90);
  const id = await accepted(st);
  const so = (await S(st, 'GET', '/api/store/orders')).data.orders.find((x) => x.id === id);
  assert.deepEqual([so.status, so.oneStep], ['preparing', true]);
  const v = (await C('GET', `/api/customer/orders/${id}`)).data.order;
  assert.deepEqual([v.oneStep, v.canReceive, v.canRemind, v.hasWhatsapp], [true, true, true, true]);
  assert.equal((await C('POST', `/api/customer/orders/${id}/confirm`, {}, cust2)).status, 404, 'another customer');
  const r = await C('POST', `/api/customer/orders/${id}/confirm`, {});
  assert.deepEqual([r.status, r.data.closed], [200, true]);
  const row = await app.db.one('SELECT status, confirmed_at, delivered_at, self_delivery, customer_hidden FROM orders WHERE id = $1', [id]);
  assert.deepEqual([row.status, !!row.confirmed_at, !!row.delivered_at, Number(row.self_delivery), Number(row.customer_hidden)], ['delivered', true, true, 1, 1]);
  assert.ok(pushed.some((p) => p.type === 'store' && p.id === st.id && p.key === 'store_order_received'));
  const again = await C('POST', `/api/customer/orders/${id}/confirm`, {});
  assert.deepEqual([again.status, again.data.closed, again.data.feePaid], [200, undefined, false], 'a second tap changes nothing');
  assert.equal((await C('POST', `/api/customer/orders/${id}/rate`, { stars: 5 })).status, 200, 'then he can rate it');
  assert.ok(!(await S(st, 'GET', '/api/store/orders')).data.orders.some((x) => x.id === id), 'gone from the store\'s active list');
});

test('remind the store: push + mark on the order, at most every 10 minutes; not on a closed order', async () => {
  const st = await makeStore(33.86, 35.91);
  const o = await order(st, [{ id: st.item, qty: 1 }]);
  const id = o.data.id;
  const r1 = await C('POST', `/api/customer/orders/${id}/remind`, {});
  assert.equal(r1.status, 200, 'even before acceptance');
  assert.ok(pushed.some((p) => p.type === 'store' && p.id === st.id && p.key === 'store_customer_reminder'));
  const r2 = await C('POST', `/api/customer/orders/${id}/remind`, {});
  assert.deepEqual([r2.status, r2.data.error], [429, 'remind_wait']);
  assert.ok(r2.data.retryAfterSec > 500);
  assert.equal((await C('POST', `/api/customer/orders/${id}/remind`, {}, cust2)).status, 404);
  const so = (await S(st, 'GET', '/api/store/orders')).data.orders.find((x) => x.id === id);
  assert.equal(so.reminders, 1);
  assert.ok(so.remindedAt);
  // 10 minutes later he may remind again
  await app.db.query('UPDATE orders SET reminded_at = $1 WHERE id = $2', [new Date(Date.now() - 11 * 60_000).toISOString(), id]);
  assert.equal((await C('POST', `/api/customer/orders/${id}/remind`, {})).status, 200);
  assert.equal((await S(st, 'GET', '/api/store/orders')).data.orders.find((x) => x.id === id).reminders, 2);
  await S(st, 'POST', `/api/store/orders/${id}/reject`, {});
  assert.equal((await C('POST', `/api/customer/orders/${id}/remind`, {})).status, 409);
});

test('ask on WhatsApp: a ready message with the order number, items, total, time and status — to this store only; editable from the admin', async () => {
  const st = await makeStore(33.87, 35.92);
  const id = await accepted(st);
  const r = await C('GET', `/api/customer/orders/${id}/whatsapp`);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const wa = (await app.db.one('SELECT whatsapp FROM cooks WHERE id = $1', [st.id])).whatsapp.replace(/\D/g, '');
  assert.ok(r.data.url.startsWith(`https://wa.me/${wa}?text=`));
  const text = decodeURIComponent(r.data.url.split('?text=')[1]);
  for (const part of [`AKL${id}`, '2 × بيتزا', '22$', 'قَبِل المتجر طلبك', 'أكلتك']) assert.ok(text.includes(part), `${part} in:\n${text}`);
  assert.equal((await C('GET', `/api/customer/orders/${id}/whatsapp`, undefined, cust2)).status, 404, 'not another customer');
  // the owner edits the message (admin → WhatsApp messages)
  assert.equal((await A('PUT', '/api/admin/texts', { lang: 'ar', key: 'wa.orderInquiry', value: 'سؤال عن {ref} — {total}', translate: false })).status, 200);
  const r2 = await C('GET', `/api/customer/orders/${id}/whatsapp`);
  assert.equal(decodeURIComponent(r2.data.url.split('?text=')[1]), `سؤال عن AKL${id} — 22$`);
  // a store without a WhatsApp number: no button, no link
  await app.db.query(`UPDATE cooks SET whatsapp = '' WHERE id = $1`, [st.id]);
  assert.equal((await C('GET', `/api/customer/orders/${id}`)).data.order.hasWhatsapp, false);
  assert.equal((await C('GET', `/api/customer/orders/${id}/whatsapp`)).data.error, 'no_whatsapp');
});

test('nothing closes by itself: an accepted order stays open for days; the customer may close and remove it', async () => {
  const st = await makeStore(33.88, 35.93);
  const id = await accepted(st);
  const old = new Date(Date.now() - 5 * 864e5).toISOString();
  await app.db.query('UPDATE orders SET accepted_at = $1, created_at = $2 WHERE id = $3', [old, old, id]);
  await app.jobs.runNow('settle-deliveries').catch(() => {});
  await app.jobs.runNow('reminders').catch(() => {});
  assert.equal((await app.db.one('SELECT status FROM orders WHERE id = $1', [id])).status, 'preparing');
  const list = (await C('GET', '/api/customer/orders')).data.orders.find((x) => x.id === id);
  assert.equal(list.closable, true);
  assert.equal((await C('POST', `/api/customer/orders/${id}/hide`, {})).status, 200);
  const row = await app.db.one('SELECT status, close_reason, customer_hidden, confirmed_at FROM orders WHERE id = $1', [id]);
  assert.deepEqual([row.status, row.close_reason, Number(row.customer_hidden), !!row.confirmed_at], ['delivered', 'customer_closed', 1, true]);
  assert.ok(pushed.some((p) => p.type === 'store' && p.id === st.id && p.key === 'store_order_closed'));
  // a pending order can't be «removed» this way (he cancels it instead)
  const p2 = (await order(st, [{ id: st.item, qty: 1 }])).data.id;
  assert.equal((await C('POST', `/api/customer/orders/${p2}/hide`, {})).status, 409);
});

test('with «find a driver» shown again: the full flow is back (no «I received it» on an accepted order)', async () => {
  await setS({ driverService: 1 });
  try {
    const st = await makeStore(33.89, 35.94);
    const id = await accepted(st);
    const v = (await C('GET', `/api/customer/orders/${id}`)).data.order;
    assert.deepEqual([v.oneStep, v.canReceive, v.canRemind], [false, false, true]);
    assert.equal((await S(st, 'GET', '/api/store/orders')).data.orders.find((x) => x.id === id).oneStep, false);
    assert.equal((await C('POST', `/api/customer/orders/${id}/confirm`, {})).status, 409);
    assert.equal((await C('GET', '/api/customer/orders')).data.orders.find((x) => x.id === id).closable, false);
  } finally { await setS({ driverService: 0 }); }
});

test('sales count from «accept»: in the store\'s records, report and the AI sales report at once; the customer removing it changes nothing; refused orders never count', async () => {
  const { salesReport } = await import('../src/services/ai/tools.js');
  const st = await makeStore(33.90, 35.95, { price: 7 });
  const rep = async () => (await S(st, 'GET', '/api/store/report?period=day')).data.report;
  const hist = async () => (await S(st, 'GET', '/api/store/orders?view=history')).data.orders;
  const id = await accepted(st);   // 2 × 7$
  let r = await rep();
  assert.deepEqual([r.delivered, r.sales, r.topItems[0]?.qty], [1, 14, 2]);
  const h = (await hist()).find((x) => x.id === id);
  assert.deepEqual([h?.status, h?.oneStep], ['preparing', true], 'in the records while still open');
  const ai = await salesReport(app.db, { type: 'store', id: st.id }, 'day');
  assert.deepEqual([ai.delivered, ai.revenue], [1, 14]);
  // the customer removes it from his list: still in the store's records and sales
  assert.equal((await C('POST', `/api/customer/orders/${id}/hide`, {})).status, 200);
  r = await rep();
  assert.deepEqual([r.delivered, r.sales], [1, 14]);
  assert.ok((await hist()).some((x) => x.id === id));
  // refused / not yet accepted: not counted
  const p = (await order(st, [{ id: st.item, qty: 1 }])).data.id;
  assert.equal((await rep()).sales, 14, 'a pending order is not a sale');
  await S(st, 'POST', `/api/store/orders/${p}/reject`, {});
  r = await rep();
  assert.deepEqual([r.sales, r.rejected], [14, 1]);
  // with «find a driver» on again, an accepted order counts only when delivered (as before)
  await setS({ driverService: 1 });
  try {
    const st2 = await makeStore(33.91, 35.96, { price: 5 });
    await accepted(st2);
    assert.equal((await S(st2, 'GET', '/api/store/report?period=day')).data.report.sales, 0);
    assert.equal((await salesReport(app.db, { type: 'store', id: st2.id }, 'day')).revenue, 0);
  } finally { await setS({ driverService: 0 }); }
});
