// v8.6 security sweep: EVERY API route of the platform is called without a login, as a customer, and without the CSRF
// header; plus one account touching another account's data, injection strings, forged prices, fake images, path tricks,
// security headers, cookie flags and login brute force. Routes are read from the source, so a new route is covered
// automatically (a new PUBLIC route must be added to the allow-list below on purpose).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createApp } from '../src/server.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
const OPTS = { adminWhatsapp: '96170999999', sessionSecret: 's'.repeat(40), quiet: true, placesFetcher: async () => [] };
let app, base, admin, cust, cust2, areaId;

async function http(method, path, { body, cookie, csrf = true, headers = {} } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { 'Content-Type': 'application/json', ...(csrf ? { 'X-Requested-With': 'fetch' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: method === 'GET' || method === 'HEAD' ? undefined : JSON.stringify(body ?? {}) });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return { cookie: res.headers.get('set-cookie')?.split(';')[0], raw: res.headers.get('set-cookie') };
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let sn = 0;
async function makeStore() {
  const wa = `+9617160${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: `متجر ${sn}`, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: 'restaurant', lat: 33.85, lng: 35.9, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'self' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency, section) VALUES ($1, 'صحن', 5, 'USD', 'أطباق')`, [r.data.id]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  return { id: r.data.id, item, cookie: (await login('/api/cook/login', { whatsapp: wa, password: pw })).cookie };
}
async function makeDriver(i) {
  const phone = `7188${String(1000 + i)}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: `سائق ${i}`, phone, password: 'pass123', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  return { id: r.data.id, cookie: (await login('/api/driver/login', { phone, password: 'pass123' })).cookie };
}

// ---- every route, from the source ----
function routes() {
  const out = [];
  for (const f of fs.readdirSync(new URL('../src/routes/', import.meta.url))) {
    const s = fs.readFileSync(new URL(`../src/routes/${f}`, import.meta.url), 'utf8');
    for (const m of s.matchAll(/\['(GET|POST|PUT|PATCH|DELETE)', \/(\^.*?\$)\/([a-z]*)\s*[,\]]/g)) out.push({ method: m[1], re: new RegExp(m[2], m[3]), src: m[2] });
  }
  return out;
}
function sample(src) {
  let p = src.slice(1, -1);
  for (let i = 0; i < 6; i += 1) p = p.replace(/\(([^()]*)\)\?/g, '');
  return p.replace(/\(\\d\+\)/g, '1').replace(/\(\[A-Za-z\]\{2\}\)/g, 'LB').replace(/\(\[a-z\]\[a-z0-9_\]\{1,30\}\)/g, 'abc')
    .replace(/\(\[[^\]]*\]\+\)/g, 'x').replace(/\(\?:([^()|]*)[^()]*\)/g, '$1').replace(/\(([^()|]*)(\|[^()]*)?\)/g, '$1')
    .replace(/\[[^\]]*\]\+/g, 'x').replace(/\\d\+/g, '1').replace(/\\\//g, '/').replace(/\\\./g, '.').replace(/\\-/g, '-');
}
// open to everyone ON PURPOSE (browsing, sign-up, logins/logouts, signed webhooks, the customer's privacy requests)
const PUBLIC = [
  /^\/api\/(config|plans|feed|dishes|banners|areas\/|cooks\/|stats\/|push\/key|customer\/config|delivery\/(stores|offers|service-types|drivers|quote))/,
  /^\/api\/(admin|cook|customer|driver)\/logout$/, /^\/api\/(visit|search|contact|contact-admin|feedback|reviews|cook-applications|booking|report|ads|route\/distances)$/,
  /^\/api\/ai\/store\/\d+\/assistant$/, /^\/api\/billing\/(google\/rtdn|apple\/notify)$/, /^\/api\/pay\/webhook/, /^\/(theme|design)\.css$/, /^\/healthz$/,
];
const isPublic = (p) => PUBLIC.some((r) => r.test(p));

before(async () => {
  app = await createApp({ databaseUrl: 'sqlite::memory:', ...OPTS, bootstrapAdmin: { username: 'admin', password: 'sweep-admin-pass-1' },
    searchLimit: 1e6, applyLimit: 1e6, loginLimit: 1e6, lookupLimit: 1e6, placesLimit: 1e6, feedbackLimit: 1e6, uploadLimit: 1e6, adminLimit: 1e6 });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = (await login('/api/admin/login', { username: 'admin', password: 'sweep-admin-pass-1' })).cookie;
  cust = (await login('/api/customer/login', { name: 'زبون أول', phone: '03111222', acceptTerms: true })).cookie;
  cust2 = (await login('/api/customer/login', { name: 'زبون ثان', phone: '03111333', acceptTerms: true })).cookie;
});
after(() => app?.close?.());

test('every protected route refuses a visitor without login (401/403), and nothing answers 500', async () => {
  const leaks = [], crashes = [];
  const all = routes();
  assert.ok(all.length > 350, `routes found: ${all.length}`);
  for (const r of all) {
    const p = sample(r.src);
    if (!r.re.test(p)) continue;
    const s = (await http(r.method, p)).status;
    if (s >= 500 && s !== 503) crashes.push(`${s} ${r.method} ${p}`);
    if (!isPublic(p) && s < 400) leaks.push(`${s} ${r.method} ${p}`);
  }
  assert.deepEqual(crashes, []);
  assert.deepEqual(leaks, []);
});

test('a customer cannot reach any admin / store / driver / AI-owner route', async () => {
  const leaks = [];
  for (const r of routes()) {
    const p = sample(r.src);
    if (!r.re.test(p) || isPublic(p) || !/^\/api\/(admin|store|driver|cook|ai\/(?!crm\/(opt-out|forget)$))/.test(p)) continue;
    const s = (await http(r.method, p, { cookie: cust })).status;
    if (s < 400) leaks.push(`${s} ${r.method} ${p}`);
  }
  assert.deepEqual(leaks, []);
});

test('a store or a driver cannot reach the owner panel', async () => {
  const st = await makeStore(), dr = await makeDriver(1);
  const leaks = [];
  for (const r of routes()) {
    const p = sample(r.src);
    if (!r.re.test(p) || !/^\/api\/admin\//.test(p) || /logout$/.test(p)) continue;
    for (const c of [st.cookie, dr.cookie]) { const s = (await http(r.method, p, { cookie: c })).status; if (s < 400) leaks.push(`${s} ${r.method} ${p}`); }
  }
  assert.deepEqual(leaks, []);
});

test('CSRF: a logged-in owner without the app header (a forged page) is refused on every change', async () => {
  const passed = [];
  for (const r of routes()) {
    const p = sample(r.src);
    if (r.method === 'GET' || !r.re.test(p) || !/^\/api\/admin\//.test(p) || /\/login$/.test(p)) continue;
    const s = (await http(r.method, p, { cookie: admin, csrf: false })).status;
    if (s !== 403) passed.push(`${s} ${r.method} ${p}`);
  }
  assert.deepEqual(passed, []);
  // and from another site (Origin of a different host) even with the header
  assert.equal((await http('PUT', '/api/admin/plans', { cookie: admin, body: {}, headers: { Origin: 'https://evil.example' } })).status, 403);
});

test('one account cannot see or change another account\'s data (orders, invoices, addresses)', async () => {
  const a = await makeStore(), b = await makeStore();
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: a.id, items: [{ id: a.item, qty: 1 }], lat: 33.851, lng: 35.9, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  const id = o.data.id;
  // the other customer
  assert.equal((await http('GET', `/api/customer/orders/${id}`, { cookie: cust2 })).status, 404);
  assert.ok([403, 404, 409].includes((await http('POST', `/api/customer/orders/${id}/cancel`, { cookie: cust2 })).status));
  // the other store
  const list = (await http('GET', '/api/store/orders', { cookie: b.cookie })).data.orders;
  assert.ok(!list.some((x) => x.id === id));
  for (const act of ['accept', 'cancel', 'search', 'send-location', 'self-dispatch', 'paid', 'hide', 'ready']) {
    const s = (await http('POST', `/api/store/orders/${id}/${act}`, { cookie: b.cookie, body: { minutes: 10 } })).status;
    assert.ok([403, 404, 409, 422].includes(s), `${act} → ${s}`);
  }
  assert.equal((await app.db.one('SELECT status FROM orders WHERE id = $1', [id])).status, 'pending');
  // the real store still can
  assert.equal((await http('POST', `/api/store/orders/${id}/accept`, { cookie: a.cookie, body: { minutes: 10 } })).status, 200);
  // addresses
  const ad = await http('POST', '/api/customer/addresses', { cookie: cust, body: { label: 'البيت', lat: 33.85, lng: 35.9 } });
  if (ad.status === 201 || ad.status === 200) {
    const aid = ad.data.id ?? ad.data.address?.id;
    if (aid) { await http('DELETE', `/api/customer/addresses/${aid}`, { cookie: cust2 }); assert.equal((await app.db.one('SELECT COUNT(*) AS n FROM customer_addresses WHERE id = $1', [aid])).n * 1, 1); }
  }
  // a driver cannot take an offer that was never sent to him, nor another driver's invoice
  const d = await makeDriver(2);
  assert.ok([403, 404, 409].includes((await http('POST', '/api/driver/offers/999999/accept', { cookie: d.cookie })).status));
  assert.ok([403, 404, 409, 422].includes((await http('POST', '/api/driver/dues/999999/remind', { cookie: d.cookie })).status));
});

test('the price is the server\'s: a forged price or total in the order is ignored', async () => {
  const a = await makeStore();
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: a.id, items: [{ id: a.item, qty: 2, price: 0.01 }], total: 0.01, lat: 33.851, lng: 35.9, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  assert.equal(Number((await app.db.one('SELECT total FROM orders WHERE id = $1', [o.data.id])).total), 10);
  // negative or absurd quantities are refused
  const neg = await http('POST', '/api/orders', { cookie: cust, body: { storeId: a.id, items: [{ id: a.item, qty: -3 }], lat: 33.851, lng: 35.9 } });
  assert.ok(neg.status >= 400 && neg.status < 500, String(neg.status));
});

test('injection strings are treated as text (no crash, no data leak); a forged login fails', async () => {
  const bad = ["' OR 1=1 --", "'; DROP TABLE cooks; --", '" OR ""="', '%27%20OR%201=1', '<script>alert(1)</script>', '../../etc/passwd'];
  for (const s of bad) {
    for (const p of [`/api/delivery/stores?country=LB&q=${encodeURIComponent(s)}`, `/api/cooks/search?q=${encodeURIComponent(s)}`, `/api/areas/search?q=${encodeURIComponent(s)}`]) {
      const r = await http('GET', p);
      assert.ok(r.status < 500, `${p} → ${r.status}`);
    }
    assert.ok([400, 401, 422].includes((await http('POST', '/api/admin/login', { body: { username: s, password: s } })).status));
    assert.ok([400, 401, 422].includes((await http('POST', '/api/cook/login', { body: { whatsapp: s, password: s } })).status));
  }
  assert.ok((await app.db.one('SELECT COUNT(*) AS n FROM cooks')).n * 1 > 0);   // the table is still there
});

test('a file that only claims to be an image is refused', async () => {
  const fake = 'data:image/jpeg;base64,' + Buffer.from('<?php system($_GET[1]); ?>').toString('base64');
  const st = await makeStore();
  const r = await http('POST', '/api/cook/photos', { cookie: st.cookie, body: { data: fake } });
  assert.ok(r.status >= 400 && r.status < 500, String(r.status));
  const dr = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق مزيف', phone: '71889999', password: 'pass123', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: { ...DOCS, selfie: fake } } });
  assert.ok(dr.status >= 400 && dr.status < 500, String(dr.status));
});

test('no secret file can be read through the web address (path tricks)', async () => {
  for (const p of ['/../.env', '/%2e%2e/.env', '/..%2f..%2fpackage.json', '/assets/../../src/server.js', '/.git/config', '/src/server.js', '/package.json', '/data/app.db', '/media/sounds/../../../.env']) {
    const res = await fetch(base + p, { redirect: 'manual' });
    const body = await res.text();
    assert.ok(res.status >= 300 || !/SESSION_SECRET|"dependencies"|createServer|\[core\]/.test(body), `${p} → ${res.status}`);
    assert.ok(!/SESSION_SECRET|"dependencies"|\[core\]/.test(body), p);
  }
});

test('security headers on pages and API; the session cookie is HttpOnly + SameSite=Strict', async () => {
  for (const p of ['/', '/store', '/driver', '/admin/', '/api/config']) {
    const h = (await fetch(base + p, { redirect: 'manual' })).headers;
    const csp = h.get('content-security-policy') || '';
    assert.ok(csp, `CSP on ${p}`);
    const script = (csp.match(/script-src[^;]*/) || [''])[0];
    assert.ok(!/unsafe-inline|unsafe-eval/.test(script), `no inline/eval scripts on ${p}: ${script}`);
    assert.ok(/frame-ancestors 'none'|frame-ancestors 'self'/.test(csp) || /DENY|SAMEORIGIN/i.test(h.get('x-frame-options') || ''), `no framing on ${p}`);
    assert.equal(h.get('x-content-type-options'), 'nosniff', p);
    assert.ok(h.get('referrer-policy'), p);
  }
  const { raw } = await login('/api/customer/login', { name: 'زبون ثالث', phone: '03111444', acceptTerms: true });
  assert.match(raw, /HttpOnly/i); assert.match(raw, /SameSite=Strict/i);
});

test('login brute force is slowed down (429) with the real limits', async () => {
  const app2 = await createApp({ databaseUrl: 'sqlite::memory:', ...OPTS, bootstrapAdmin: { username: 'admin', password: 'real-limits-pass-1' } });
  await new Promise((r) => app2.server.listen(0, r));
  const b2 = `http://127.0.0.1:${app2.server.address().port}`;
  const codes = [];
  for (let i = 0; i < 40; i += 1) {
    const r = await fetch(b2 + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify({ username: 'admin', password: `wrong-${i}` }) });
    codes.push(r.status); await r.arrayBuffer();
  }
  await app2.close();
  assert.ok(codes.includes(429), `codes: ${[...new Set(codes)]}`);
  assert.ok(!codes.includes(200));
});

test('subscriptions cannot be self-granted: a BASIC store is refused by the AI manager, and a fake store purchase grants nothing', async () => {
  const st = await makeStore();
  assert.equal((await http('GET', '/api/ai/settings?as=store', { cookie: st.cookie })).status, 403);
  const v = await http('POST', '/api/billing/google/verify', { cookie: st.cookie, body: { productId: 'aklatak.shop.ai.monthly', purchaseToken: 'fake-token-123456789' } });
  assert.ok(v.status >= 400, String(v.status));
  const row = await app.db.one('SELECT ai_until FROM cooks WHERE id = $1', [st.id]);
  assert.ok(!row.ai_until);
});
