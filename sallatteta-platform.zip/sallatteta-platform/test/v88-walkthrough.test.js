// v8.0.7 — problems found by using the app as a real store, customer and driver (12 Oct 2026), kept fixed:
// a shop that signs up by itself must receive orders when stores deliver themselves; the customer of such a shop sees
// no driver steps; the driver's own customer requests count in his deliveries and earnings; light designs keep light
// form controls; distances keep their limits.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
let app, base, admin, areaId;

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });

before(async () => {
  app = await createApp({ databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'w'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'walkthrough-pass-1' }, placesFetcher: async () => [],
    searchLimit: 1e6, applyLimit: 1e6, loginLimit: 1e6, lookupLimit: 1e6, placesLimit: 1e6, feedbackLimit: 1e6, uploadLimit: 1e6, adminLimit: 1e6 });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'walkthrough-pass-1' });
  await A('PUT', '/api/admin/delivery/settings', { claimWindowSec: 0 });   // the first driver who accepts gets it (no 5-second contest)
});
after(() => app?.close?.());

test('a shop that signs up by itself receives orders (delivers itself) — customers can order, it has delivery settings, no driver wording', async () => {
  await new Promise((r) => setTimeout(r, 1600));   // the form's anti-bot minimum time
  const r = await http('POST', '/api/cook-applications', { body: { acceptTerms: true, password: 'karam123', kind: 'restaurant', fullName: 'مشاوي الكرم', whatsapp: '71555444', lat: 33.847, lng: 35.904, servedAreaIds: [areaId], plan: 'monthly', startedAt: Date.now() - 5000 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const id = r.data.applicationId;
  assert.equal((await app.db.one('SELECT delivery_mode FROM cooks WHERE id = $1', [id])).delivery_mode, 'self');
  await A('POST', `/api/admin/cooks/${id}/approve`, {});
  await A('POST', `/api/admin/cooks/${id}/subscription/activate`, { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() });
  const store = await login('/api/cook/login', { whatsapp: '71555444', password: 'karam123' });
  assert.ok(store);
  // the store has its delivery settings (fee, radius)
  assert.equal((await http('POST', '/api/store/settings', { cookie: store, body: { deliveryFee: 2, deliveryRadiusKm: 10 } })).status, 200);
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency) VALUES ($1, 'شيش طاووق', 4, 'USD')`, [id]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [id])).id;
  const cust = await login('/api/customer/login', { name: 'علي حسن', phone: '03456789', acceptTerms: true });
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: id, items: [{ id: item, qty: 2 }], lat: 33.848, lng: 35.904, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  // from the very first moment the customer sees the store's own delivery (no «driver on the way to the store» step)
  assert.equal((await http('GET', `/api/customer/orders/${o.data.id}`, { cookie: cust })).data.order.selfDelivery, true);
  // the store delivers it itself
  assert.equal((await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: store, body: { minutes: 20 } })).status, 200);
  assert.equal((await http('POST', `/api/store/orders/${o.data.id}/self-dispatch`, { cookie: store, body: {} })).status, 200);
  assert.equal((await http('POST', `/api/store/orders/${o.data.id}/self-delivered`, { cookie: store, body: {} })).status, 200);
  const done = (await http('GET', `/api/customer/orders/${o.data.id}`, { cookie: cust })).data.order;
  assert.equal(done.selfDelivery, true); assert.equal(done.awaitingConfirm, true);
});

test('a craftsperson who signs up keeps «no delivery» (they come to the customer)', async () => {
  await new Promise((r) => setTimeout(r, 1600));
  const r = await http('POST', '/api/cook-applications', { body: { acceptTerms: true, password: 'elec1234', kind: 'electrician', fullName: 'كهربائي البقاع', whatsapp: '71555445', bio: 'تمديدات كهربائية وصيانة وتركيب إنارة للمنازل والمحلات', lat: 33.847, lng: 35.904, servedAreaIds: [areaId], plan: 'monthly', startedAt: Date.now() - 5000 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal((await app.db.one('SELECT delivery_mode FROM cooks WHERE id = $1', [r.data.applicationId])).delivery_mode, 'none');
});

test("the driver's customer requests («ask a driver») appear in his deliveries and count in his earnings and km", async () => {
  const phone = '71222333';
  const ap = await http('POST', '/api/driver/apply', { body: { fullName: 'خالد يوسف', phone, password: 'khaled1', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1995-05-20', docs: DOCS, jobsMonths: 1 } });
  assert.equal(ap.status, 201, JSON.stringify(ap.data));
  await A('POST', `/api/admin/drivers/${ap.data.id}/status`, { status: 'active' });
  await A('POST', `/api/admin/drivers/${ap.data.id}/jobs`, { months: 1 });
  const drv = await login('/api/driver/login', { phone, password: 'khaled1' });
  await http('POST', '/api/driver/availability', { cookie: drv, body: { available: true, lat: 33.844, lng: 35.9 } });
  const cust = await login('/api/customer/login', { name: 'زبون', phone: '03456780', acceptTerms: true });
  const e = await http('POST', '/api/errands', { cookie: cust, body: { kind: 'deliver', description: 'ظرف أوراق', price: 3, from: { lat: 33.847, lng: 35.904, details: 'البيت' }, to: { lat: 33.824, lng: 35.885, details: 'الصيدلية' } } });
  assert.ok([200, 201].includes(e.status), JSON.stringify(e.data));
  const eid = e.data.id ?? e.data.errand?.id ?? e.data.errandId;
  assert.ok(eid, JSON.stringify(e.data));
  const off = (await http('GET', '/api/driver/offers', { cookie: drv })).data;
  const eo = (off.errands || off.errandOffers || off.offers || []).find((x) => (x.errandId ?? x.errand?.id ?? x.id) === eid) || (off.errands || [])[0];
  assert.ok(eo, JSON.stringify(off).slice(0, 300));
  const acc = await http('POST', `/api/driver/errand-offers/${eo.id}/accept`, { cookie: drv, body: {} });
  assert.equal(acc.status, 200, JSON.stringify(acc.data));
  assert.equal((await http('POST', `/api/driver/errands/${eid}/picked`, { cookie: drv, body: {} })).status, 200);
  assert.equal((await http('POST', `/api/driver/errands/${eid}/delivered`, { cookie: drv, body: {} })).status, 200);
  const h = (await http('GET', '/api/driver/history', { cookie: drv })).data;
  assert.equal(h.errands.length, 1); assert.equal(h.errands[0].price, 3);
  const rep = (await http('GET', '/api/driver/report?period=month', { cookie: drv })).data.report;
  assert.equal(rep.errands, 1); assert.equal(rep.errandEarnings, 3); assert.ok(rep.earnings >= 3); assert.ok(rep.km > 0);
});

test('light ready designs give light form controls (no black checkboxes on the sign-up page); dark ones dark', async () => {
  for (const [key, scheme] of [['signature', 'light'], ['glass', 'dark'], ['emerald', 'light']]) {
    await A('PUT', '/api/admin/designs', { key });
    const css = await (await fetch(`${base}/theme.css`)).text();
    assert.match(css, new RegExp(`color-scheme:only ${scheme}`), key);
  }
  await A('PUT', '/api/admin/designs', { key: 'signature' });
});
