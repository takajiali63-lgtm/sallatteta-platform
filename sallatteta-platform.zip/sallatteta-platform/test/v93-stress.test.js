// v8.4 the stress + integrity checks (scripts/stress-v84.js) with small numbers, on every test run: many customers,
// drivers and stores at the same moment, and nothing may be mixed up (stock, double taps, double accepts, two drivers on
// one order, a driver on two jobs, another person's order, server errors under a crowd).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runStress } from '../scripts/stress-v84.js';

test('stress: hundreds at once, every integrity check holds', { timeout: 240_000 }, async () => {
  const out = await runStress({ customers: 250, drivers: 100, stores: 30, seconds: 5, concurrency: 50, log: () => {} });
  const bad = out.filter((x) => !x.ok);
  assert.equal(bad.length, 0, bad.map((x) => `${x.name}: ${x.detail}`).join('\n'));
  assert.ok(out.length >= 12);
});
