// v8.5.1 «start a fresh account» (owner's request): a store can make its records and reports count from a chosen moment,
// like a new notebook. Nothing is deleted: the CSV keeps every order, money with drivers is untouched, and «show all» undoes it.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { salesReport } from '../src/services/ai/tools.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
let app, base, admin, areaId, cust, cust2;
const pushed = [];
const fakePush = { notify: (type, id, msg) => pushed.push({ type, id, ...msg }), notifyAdmins: () => {}, subscribe: async () => {}, publicKey: async () => 'k' };

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let n = 0;
async function makeDriver(lat, lng, { jobs = true } = {}) {
  const phone = `7194${String(1000 + n++).padStart(4, '0')}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ' + phone.slice(-3) + ' الكنية', phone, password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: `7166${phone.slice(-4)}`, acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  if (jobs) await A('POST', `/api/admin/drivers/${r.data.id}/jobs`, { months: 1 });
  const cookie = await login('/api/driver/login', { phone, password: 'pass123' });
  await http('POST', '/api/driver/availability', { body: { available: true, lat, lng }, cookie });
  return { id: r.data.id, cookie, phone };
}
let sn = 0;
async function makeStore(lat, lng, { kind = 'restaurant', price = 10 } = {}) {
  const wa = `+9617194${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل ' + sn, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'delivery' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency, section) VALUES ($1,'بيتزا',$2,'USD','بيتزا')`, [r.data.id, price]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  return { id: r.data.id, cookie, item, lat, lng };
}
const order = (st, items, cookie = cust) => http('POST', '/api/orders', { cookie, body: { storeId: st.id, items, lat: st.lat + 0.004, lng: st.lng, paymentMethod: 'cash' } });
const S = (st, m, p, b) => http(m, p, { body: b, cookie: st.cookie });
const setS = (b) => A('PUT', '/api/admin/delivery/settings', b);
const C = (m, p, b, cookie = cust) => http(m, p, { body: b, cookie });

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true, runJobs: false,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [], push: fakePush,
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03195777', acceptTerms: true });
  cust2 = await login('/api/customer/login', { name: 'زبون آخر', phone: '03195778', acceptTerms: true });
  await setS({ driverService: 0 });   // the owner hid «find a driver» from the stores' plans
});
after(() => app?.close?.());

async function accepted(st) {
  const o = await order(st, [{ id: st.item, qty: 2 }]);
  assert.equal(o.status, 201, JSON.stringify(o.data));
  assert.equal((await S(st, 'POST', `/api/store/orders/${o.data.id}/accept`, {})).status, 200);
  return o.data.id;
}
const hist = async (st) => (await S(st, 'GET', '/api/store/orders?view=history')).data;
const rep = async (st) => (await S(st, 'GET', '/api/store/report?period=month')).data.report;
const csvRows = async (st) => {
  const res = await fetch(base + '/api/store/orders.csv', { headers: { Cookie: st.cookie } });
  return (await res.text()).trim().split('\n').length - 1;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('fresh account: records, report and smart-manager report start from the reset; nothing is deleted; undo brings all back', async () => {
  const st = await makeStore(33.85, 35.90);
  const old = await accepted(st);
  assert.ok((await hist(st)).orders.some((o) => o.id === old));
  assert.equal((await rep(st)).delivered, 1);
  assert.equal((await hist(st)).records.from, null);

  await sleep(5);
  const r = await S(st, 'POST', '/api/store/records/reset', {});
  assert.equal(r.status, 200);
  assert.ok(r.data.recordsFrom);
  await sleep(5);
  let h = await hist(st);
  assert.equal(h.records.from, r.data.recordsFrom);
  assert.equal(h.orders.length, 0);
  let rp = await rep(st);
  assert.equal(rp.orders, 0); assert.equal(rp.delivered, 0); assert.equal(rp.sales, 0);
  assert.equal(rp.recordsFrom, r.data.recordsFrom);
  const ai = await salesReport(app.db, { type: 'store', id: st.id }, 'month');
  assert.equal(ai.orders, 0);
  // the order itself is untouched and still downloadable
  assert.equal(await csvRows(st), 1);
  assert.equal((await app.db.one('SELECT status, store_hidden FROM orders WHERE id = $1', [old])).store_hidden, 0);

  const fresh = await accepted(st);
  h = await hist(st);
  assert.deepEqual(h.orders.map((o) => o.id), [fresh]);
  rp = await rep(st);
  assert.equal(rp.delivered, 1); assert.equal(rp.sales, 20);
  assert.equal((await salesReport(app.db, { type: 'store', id: st.id }, 'month')).delivered, 1);

  // undo: everything is back
  const u = await S(st, 'POST', '/api/store/records/reset', { undo: true });
  assert.equal(u.status, 200); assert.equal(u.data.recordsFrom, null);
  h = await hist(st);
  assert.deepEqual(h.orders.map((o) => o.id).sort(), [old, fresh].sort());
  assert.equal((await rep(st)).delivered, 2);
});

test('fresh account: only the store itself; another store and customers are not affected; the active orders stay', async () => {
  const a = await makeStore(33.86, 35.91);
  const b = await makeStore(33.87, 35.92);
  const ob = await accepted(b);
  const pend = (await order(a, [{ id: a.item, qty: 1 }])).data.id;   // still waiting for «accept»
  await sleep(5);
  assert.equal((await S(a, 'POST', '/api/store/records/reset', {})).status, 200);
  assert.ok((await hist(b)).orders.some((o) => o.id === ob));
  assert.equal((await rep(b)).delivered, 1);
  assert.ok((await S(a, 'GET', '/api/store/orders')).data.orders.some((o) => o.id === pend));
  // a customer / driver / no session cannot call it
  assert.notEqual((await C('POST', '/api/store/records/reset', {})).status, 200);
  assert.notEqual((await http('POST', '/api/store/records/reset', { body: {} })).status, 200);
  // the customer still sees his orders
  assert.ok((await C('GET', '/api/customer/orders')).data.orders.some((o) => o.id === ob));
});

test('fresh account for a driver: his list, report and smart-manager report start from the reset; money owed untouched; undo', async () => {
  const st = await makeStore(33.88, 35.93);
  const d = await makeDriver(33.88, 35.93);
  const D = (m, p, b) => http(m, p, { body: b, cookie: d.cookie });
  // a delivered store order carried by this driver (set up directly: the one-step mode here has no driver flow)
  const id = await accepted(st);
  const past = new Date(Date.now() - 3600e3).toISOString();
  await app.db.query(`UPDATE orders SET driver_id = $1, status = 'delivered', delivered_at = $2, delivery_fee = 3 WHERE id = $3`, [d.id, past, id]);
  let h = (await D('GET', '/api/driver/history')).data;
  assert.equal(h.recordsFrom, null);
  assert.ok(h.orders.some((o) => o.id === id));
  assert.equal((await D('GET', '/api/driver/report?period=month')).data.report.deliveries, 1);
  const fin0 = (await D('GET', '/api/driver/finance')).data;

  const r = await D('POST', '/api/driver/records/reset', {});
  assert.equal(r.status, 200); assert.ok(r.data.recordsFrom);
  h = (await D('GET', '/api/driver/history')).data;
  assert.equal(h.recordsFrom, r.data.recordsFrom);
  assert.equal(h.orders.length, 0);
  const rp = (await D('GET', '/api/driver/report?period=month')).data.report;
  assert.equal(rp.deliveries, 0); assert.equal(rp.earnings, 0); assert.equal(rp.recordsFrom, r.data.recordsFrom);
  assert.equal((await salesReport(app.db, { type: 'driver', id: d.id }, 'month')).storeDeliveries, 0);
  // the money pages are exactly the same
  assert.deepEqual((await D('GET', '/api/driver/finance')).data, fin0);
  // the store's own records are not touched by the driver's reset
  assert.ok((await hist(st)).orders.some((o) => o.id === id));
  // a store cannot call the driver's route
  assert.notEqual((await S(st, 'POST', '/api/driver/records/reset', {})).status, 200);

  const u = await D('POST', '/api/driver/records/reset', { undo: true });
  assert.equal(u.data.recordsFrom, null);
  assert.ok((await D('GET', '/api/driver/history')).data.orders.some((o) => o.id === id));
  assert.equal((await D('GET', '/api/driver/report?period=month')).data.report.deliveries, 1);
});
