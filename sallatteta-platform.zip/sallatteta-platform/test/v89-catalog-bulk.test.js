// v8.1 big catalogs (supermarkets with thousands of products) — from the owner's request of 12 Oct 2026:
// per-CATEGORY product / photo limits and subscription prices set in the admin panel and applied to every subscriber of
// that category; the whole catalog uploaded from one spreadsheet (CSV / Excel) and updated by barcode or name; photos
// matched by file name; quantities that go down with orders, hide a product that ran out and bring it back when
// restocked; big catalogs loaded by parts (no heavy page for the customer or the store).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { createZip } from '../src/lib/zip.js';
import { parseCsv, parseXlsx, checkRows, planImport, matchPhoto } from '../src/services/bulkmenu.js';
import { cleanCatPlans, limitsFor, plansFor } from '../src/services/catplans.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
let app, base, admin, areaId;

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let sn = 0;
async function makeStore(kind = 'supermarket') {
  const wa = `+9617160${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: `سوبرماركت ${sn}`, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat: 33.847, lng: 35.904, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await app.db.query(`UPDATE cooks SET delivery_mode = 'self', hours = NULL WHERE id = $1`, [r.data.id]);
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  await http('POST', '/api/store/settings', { cookie, body: { deliveryFee: 1, deliveryRadiusKm: 20 } });
  return { id: r.data.id, cookie };
}
const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
const importFile = (st, fileName, content, dryRun) => http('POST', '/api/cook/menu/import', { cookie: st.cookie, body: { fileName, data: Buffer.isBuffer(content) ? content.toString('base64') : b64(content), dryRun } });

/** A real minimal .xlsx (shared strings + inline string + numbers), like Excel / Google Sheets save it. */
function xlsx(rows) {
  const shared = [];
  const si = (s) => { let i = shared.indexOf(s); if (i < 0) { shared.push(s); i = shared.length - 1; } return i; };
  const col = (i) => String.fromCharCode(65 + i);
  const sheet = `<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${rows.map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => v === '' ? '' : typeof v === 'number' ? `<c r="${col(ci)}${ri + 1}"><v>${v}</v></c>` : ci === 3 ? `<c r="${col(ci)}${ri + 1}" t="inlineStr"><is><t>${v.replace(/&/g, '&amp;')}</t></is></c>` : `<c r="${col(ci)}${ri + 1}" t="s"><v>${si(v)}</v></c>`).join('')}</row>`).join('')}</sheetData></worksheet>`;
  const sst = `<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${shared.map((s) => `<si><t>${s.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</t></si>`).join('')}</sst>`;
  const wb = '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>';
  const rels = '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
  return createZip([
    { name: 'xl/workbook.xml', data: Buffer.from(wb) }, { name: 'xl/_rels/workbook.xml.rels', data: Buffer.from(rels) },
    { name: 'xl/sharedStrings.xml', data: Buffer.from(sst) }, { name: 'xl/worksheets/sheet1.xml', data: Buffer.from(sheet) },
  ]);
}

before(async () => {
  app = await createApp({ databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'c'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'catalog-pass-1' }, placesFetcher: async () => [],
    searchLimit: 1e6, applyLimit: 1e6, loginLimit: 1e6, lookupLimit: 1e6, placesLimit: 1e6, feedbackLimit: 1e6, uploadLimit: 1e6, adminLimit: 1e6 });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'catalog-pass-1' });
  // these tests also cover the receipt (Whish / OMT) way, kept for the owner; v8.2 closes it by default (Google Play only)
  await A('PUT', '/api/admin/settings', { googleOnly: false });
});
after(() => app?.close?.());

/* ---------------- per-category limits and prices ---------------- */

test('category settings: only clean values are kept; empty = the general numbers', () => {
  assert.deepEqual(cleanCatPlans({ supermarket: { products: '6000', photos: '', basic: { 1: '25', 3: '' } } }), { supermarket: { products: 6000, basic: { 1: 25 } } });
  for (const bad of [{ supermarket: { products: 0 } }, { supermarket: { products: 60_000 } }, { supermarket: { basic: { 1: -5 } } }, { 'Bad Key': {} }, [], null]) assert.equal(cleanCatPlans(bad), null, JSON.stringify(bad));
  const s = { limits: { menuItems: 300, restaurantPhotos: 300, cookPhotos: 100 }, catPlans: { supermarket: { products: 6000, photos: 2000 } } };
  assert.deepEqual(limitsFor(s, 'supermarket'), { products: 6000, photos: 2000 });
  assert.deepEqual(limitsFor(s, 'pharmacy'), { products: 300, photos: 300 });
  assert.deepEqual(limitsFor(s, 'cook'), { products: 300, photos: 100 });
  const plans = { store: { basic: { 1: { price: 10 } }, delivery: { 1: { price: 20 } } }, ai: { shops: { 1: { price: 30 } }, crafts: { 1: { price: 8 } }, online: { 1: { price: 12 } } } };
  const p = plansFor(plans, { catPlans: { supermarket: { basic: { 1: 25 }, ai: { 1: 45 } } } }, 'supermarket');
  assert.equal(p.store.basic[1].price, 25); assert.equal(p.ai.shops[1].price, 45); assert.equal(p.store.delivery[1].price, 20);
  assert.equal(plans.store.basic[1].price, 10, 'the general plans are not changed');
});

test('admin sets a category\'s limits and prices; every subscriber of that category gets them (plans page, my plan, renewal, sign-up)', async () => {
  const bad = await A('PUT', '/api/admin/settings', { catPlans: { supermarket: { products: -1 } } });
  assert.equal(bad.status, 422);
  assert.equal((await http('PUT', '/api/admin/settings', { body: { catPlans: {} } })).status, 401);
  const r = await A('PUT', '/api/admin/settings', { catPlans: { supermarket: { products: 6000, photos: 3, basic: { 1: 25, 12: 250 }, ai: { 1: 45 } } } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  // the public prices of the category
  const p = (await http('GET', '/api/plans?kind=supermarket')).data;
  assert.equal(p.store.basic['1'], 25); assert.equal(p.store.basic['12'], 250); assert.equal(p.ai.shops['1'], 45);
  assert.equal((await http('GET', '/api/plans?kind=pharmacy')).data.store.basic['1'], 10, 'other categories keep the general price');
  // a supermarket's «my plan» and its renewal
  const st = await makeStore();
  const sub = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.equal(sub.options.find((o) => o.kind === 'basic').months.find((x) => x.months === 1).price, 25);
  assert.equal(sub.aiOptions.find((x) => x.months === 1).price, 45);
  const ren = await http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'basic', months: 1, tier: 'basic', amount: 1, method: 'whish', reference: 'S1', receipt: JPG } });
  assert.equal(ren.status, 201, JSON.stringify(ren.data));
  assert.equal(ren.data.amount, 25, 'priced by the server with the category price');
  // its products limit
  assert.equal((await http('GET', '/api/cook/me', { cookie: st.cookie })).data.maxItems, 6000);
  // a new supermarket signing up pays the category price
  await new Promise((res) => setTimeout(res, 1600));
  const su = await http('POST', '/api/cook-applications', { body: { acceptTerms: true, password: 'market123', kind: 'supermarket', fullName: 'سوبرماركت الجديد', whatsapp: '71666777', lat: 33.847, lng: 35.904, servedAreaIds: [areaId], plan: 'monthly', startedAt: Date.now() - 5000 } });
  assert.equal(su.status, 201, JSON.stringify(su.data));
  assert.equal(Number((await app.db.one('SELECT amount FROM subscriptions WHERE cook_id = $1', [su.data.applicationId])).amount), 25);
});

/* ---------------- spreadsheet import ---------------- */

test('reading files: CSV (comma / semicolon, quotes, BOM, Arabic digits) and a real .xlsx', () => {
  assert.deepEqual(parseCsv('\uFEFFالاسم;السعر\n"خبز; كبير";"1,5"\r\nماء;٢'), [['الاسم', 'السعر'], ['خبز; كبير', '1,5'], ['ماء', '٢']]);
  const c = checkRows(parseCsv('\uFEFFالاسم;السعر\n"خبز; كبير";"1,5"\r\nماء;٢'));
  assert.equal(c.rows[0].price, 1.5); assert.equal(c.rows[1].price, 2);
  const rows = parseXlsx(xlsx([['Name', 'Price', 'Category', 'Description', 'Barcode', 'Qty'], ['Milk 1L', 1.25, 'Dairy', 'Fresh & cold', '629100', 12], ['Bread', 0.9, '', '', '', '']]));
  assert.deepEqual(rows[1], ['Milk 1L', '1.25', 'Dairy', 'Fresh & cold', '629100', '12']);
  const x = checkRows(rows);
  assert.deepEqual(x.columns.sort(), ['barcode', 'description', 'name', 'price', 'section', 'stock']);
  assert.equal(x.rows[0].stock, 12); assert.equal(x.rows[1].has.stock, undefined);
});

test('row problems are listed with their row number; the rest are imported', () => {
  const c = checkRows(parseCsv(['الاسم,السعر,الباركود,الكمية', ',2,,', 'جبنة,abc,,', 'لبنة,3,6.29E+12,', 'زيت,5,,-2', 'رز,2,,10', '', 'سكر,1,,'].join('\n')));
  assert.deepEqual(c.errors.map((e) => [e.row, e.msg]), [[2, 'name_missing'], [3, 'price_invalid'], [4, 'barcode_as_number'], [5, 'stock_invalid']]);
  assert.deepEqual(c.rows.map((r) => r.name), ['رز', 'سكر']);
  assert.equal(checkRows([['price'], ['1']]).errors[0].msg, 'no_name_column');
});

test('an existing product is updated by barcode, else by name; same name with another barcode is a new product', () => {
  const existing = [{ id: 1, name: 'حليب', barcode: '111', price: 1, section: 'ألبان', description: 'طازج', stock: 5, is_available: 1, auto_off: 0 },
    { id: 2, name: 'الخبز العربي', barcode: null, price: 1, section: null, description: null, stock: null, is_available: 1, auto_off: 0 },
    { id: 3, name: 'عصير', barcode: '333', price: 2, section: null, description: null, stock: 0, is_available: 0, auto_off: 1 }];
  const { rows } = checkRows(parseCsv(['الاسم,السعر,الباركود,الكمية', 'حليب كامل,1.2,111,', 'خبز عربي,1.1,,', 'عصير,2,334,', 'عصير,2,333,8', 'حليب كامل,1.3,111,'].join('\n')));
  const plan = planImport(existing, rows);
  assert.deepEqual(plan.update.map((u) => [u.id, u.name, u.price]), [[1, 'حليب كامل', 1.2], [2, 'خبز عربي', 1.1], [3, 'عصير', 2]]);
  assert.equal(plan.update[0].description, 'طازج', 'a column not in the file is kept');
  assert.equal(plan.update[0].stock, 5, 'an empty quantity cell keeps the quantity');
  assert.deepEqual([plan.update[2].stock, plan.update[2].is_available, plan.update[2].auto_off], [8, 1, 0], 'restocked → back in the store');
  assert.deepEqual(plan.create.map((r) => r.barcode), ['334']);
  assert.deepEqual(plan.errors.map((e) => e.row), [6]);
});

test('5000 products from one file in seconds; preview first; re-import updates prices and quantities; the category limit holds', async () => {
  await A('PUT', '/api/admin/settings', { catPlans: { supermarket: { products: 6000, photos: 3, basic: { 1: 25 } } } });
  const st = await makeStore();
  const lines = ['الاسم,السعر,القسم,الوصف,الباركود,الكمية'];
  for (let i = 1; i <= 5000; i++) lines.push(`منتج رقم ${i},${(i % 50) + 0.5},قسم ${i % 20},,${100000 + i},${i % 7 === 0 ? 0 : 10}`);
  const preview = await importFile(st, 'products.csv', lines.join('\n'), true);
  assert.equal(preview.status, 200, JSON.stringify(preview.data));
  assert.deepEqual([preview.data.create, preview.data.update, preview.data.errorCount, preview.data.applied], [5000, 0, 0, false]);
  assert.equal(Number((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1', [st.id])).n), 0, 'the preview saves nothing');
  const t0 = Date.now();
  const r = await importFile(st, 'products.csv', lines.join('\n'), false);
  const ms = Date.now() - t0;
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.create, 5000);
  assert.ok(ms < 15000, `took ${ms} ms`);
  const cnt = await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n, CAST(SUM(CASE WHEN auto_off = 1 THEN 1 ELSE 0 END) AS INTEGER) AS off FROM menu_items WHERE cook_id = $1', [st.id]);
  assert.equal(Number(cnt.n), 5000); assert.equal(Number(cnt.off), 714, 'quantity 0 → hidden by itself');
  // the store's page doesn't send 5000 products at once
  const me = (await http('GET', '/api/cook/me', { cookie: st.cookie })).data;
  assert.equal(me.menuBig, true); assert.equal(me.menu.length, 0); assert.equal(me.menuCount, 5000);
  assert.equal(me.sectionCounts.length, 20);
  // update prices / quantities by barcode (names changed a bit)
  const upd = ['الباركود,الاسم,السعر,الكمية', '100001,منتج رقم 1 (جديد),9.99,', '100007,منتج رقم 7,1,4'].join('\n');
  const u = await importFile(st, 'update.csv', upd, false);
  assert.deepEqual([u.data.create, u.data.update], [0, 2]);
  const p1 = await app.db.one('SELECT name, price, stock, section FROM menu_items WHERE cook_id = $1 AND barcode = $2', [st.id, '100001']);
  assert.deepEqual([p1.name, Number(p1.price), Number(p1.stock), p1.section], ['منتج رقم 1 (جديد)', 9.99, 10, 'قسم 1']);
  const p7 = await app.db.one('SELECT stock, is_available, auto_off FROM menu_items WHERE cook_id = $1 AND barcode = $2', [st.id, '100007']);
  assert.deepEqual([Number(p7.stock), Number(p7.is_available), Number(p7.auto_off)], [4, 1, 0]);
  // over the category's limit: refused whole, nothing half-saved
  const more = ['الاسم,السعر'];
  for (let i = 0; i < 1001; i++) more.push(`إضافي ${i},1`);
  const pre = await importFile(st, 'more.csv', more.join('\n'), true);
  assert.equal(pre.data.overLimit, true); assert.equal(pre.data.room, 1000);
  assert.equal((await importFile(st, 'more.csv', more.join('\n'), false)).status, 409);
  assert.equal(Number((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM menu_items WHERE cook_id = $1', [st.id])).n), 5000);
  // wrong files
  const noName = await importFile(st, 'x.csv', 'price\n1', true);
  assert.deepEqual([noName.status, noName.data.error], [422, 'no_name_column']);
  assert.equal((await importFile(st, 'old.xls', Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 1, 2, 3, 4]), true)).status, 422);
  // another store can't touch these
  const other = await makeStore();
  const o = await importFile(other, 'update.csv', upd, false);
  assert.deepEqual([o.data.create, o.data.update], [2, 0]);
});

test('Excel file import + template download', async () => {
  const st = await makeStore('minimarket');
  const t = await fetch(`${base}/api/cook/menu/template.csv`, { headers: { Cookie: st.cookie } });
  assert.equal(t.status, 200);
  assert.match(t.headers.get('content-disposition'), /attachment/);
  const tpl = Buffer.from(await t.arrayBuffer());
  assert.deepEqual([...tpl.subarray(0, 3)], [0xef, 0xbb, 0xbf], 'UTF-8 mark: Excel shows the Arabic letters');
  assert.ok(tpl.toString('utf8').slice(1).startsWith('الاسم,السعر,القسم'), 'Arabic titles');
  const r = await importFile(st, 'list.xlsx', xlsx([['الاسم', 'السعر', 'القسم', 'الوصف', 'الباركود', 'الكمية'], ['شاي', 3, 'مشروبات', 'علبة 100 كيس', '7001', 6], ['قهوة', 7.5, 'مشروبات', '', '7002', '']]), false);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.create, 2);
  const tea = await app.db.one('SELECT description, stock, section FROM menu_items WHERE cook_id = $1 AND barcode = $2', [st.id, '7001']);
  assert.deepEqual([tea.description, Number(tea.stock), tea.section], ['علبة 100 كيس', 6, 'مشروبات']);
  assert.ok((await http('GET', '/api/cook/me', { cookie: st.cookie })).data.menuSections.includes('مشروبات'));
});

test('photos chosen at once find their product by file name (barcode or name); the category photo number holds', async () => {
  assert.equal(matchPhoto([{ id: 1, name: 'خبز عربي', barcode: '55' }], 'IMG/55.jpg').id, 1);
  assert.equal(matchPhoto([{ id: 1, name: 'الخبز العربي', barcode: null }], 'خبز عربي.JPEG').id, 1);
  assert.equal(matchPhoto([{ id: 1, name: 'خبز', barcode: null }], 'random.png'), null);
  const st = await makeStore();   // supermarket: 3 photos (set above)
  await importFile(st, 'p.csv', ['الاسم,السعر,الباركود', 'أ,1,901', 'ب,1,902', 'ج,1,903', 'د,1,904'].join('\n'), false);
  for (const code of ['901', '902', '903']) {
    const r = await http('POST', '/api/cook/menu/photo', { cookie: st.cookie, body: { fileName: `${code}.jpg`, photo: JPG } });
    assert.equal(r.status, 200, JSON.stringify(r.data)); assert.ok(r.data.matched);
  }
  assert.equal((await http('POST', '/api/cook/menu/photo', { cookie: st.cookie, body: { fileName: 'nothing.jpg', photo: JPG } })).data.matched, null);
  assert.equal((await http('POST', '/api/cook/menu/photo', { cookie: st.cookie, body: { fileName: '904.jpg', photo: JPG } })).status, 409, 'over the photo number');
  assert.equal((await http('POST', '/api/cook/menu/photo', { cookie: st.cookie, body: { fileName: '901.jpg', photo: JPG } })).status, 200, 'replacing a photo is always fine');
  assert.equal((await http('POST', '/api/cook/menu/photo', { body: { fileName: '901.jpg', photo: JPG } })).status, 401);
});

/* ---------------- quantities ---------------- */

test('quantities: an order takes them, the last piece hides the product, a rejected / cancelled order gives them back', async () => {
  const st = await makeStore();
  const add = await http('POST', '/api/cook/menu', { cookie: st.cookie, body: { name: 'بطيخ', price: 3, stock: 3 } });
  assert.equal(add.status, 201, JSON.stringify(add.data));
  const item = add.data.menu.find((m) => m.name === 'بطيخ');
  assert.equal(item.stock, 3);
  const cust = await login('/api/customer/login', { name: 'زبون', phone: '03456111', acceptTerms: true });
  const order = (qty) => http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: item.id, qty }], lat: 33.848, lng: 35.904, paymentMethod: 'cash' } });
  // more than left → refused with what is left
  const over = await order(4);
  assert.equal(over.status, 409, JSON.stringify(over.data));
  assert.deepEqual([over.data.error, over.data.left], ['item_unavailable', 3], 'tells how many are left');
  const o1 = await order(2);
  assert.equal(o1.status, 201, JSON.stringify(o1.data));
  assert.equal(Number((await app.db.one('SELECT stock FROM menu_items WHERE id = $1', [item.id])).stock), 1);
  const o2 = await order(1);
  assert.equal(o2.status, 201);
  let row = await app.db.one('SELECT stock, is_available, auto_off FROM menu_items WHERE id = $1', [item.id]);
  assert.deepEqual([Number(row.stock), Number(row.is_available), Number(row.auto_off)], [0, 0, 1], 'ran out → hidden by itself');
  let page = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.ok(!page.menu.some((m) => m.id === item.id), 'the customer does not see it');
  assert.equal((await order(1)).status, 409);
  // the store rejects the 2nd order → the piece comes back, and the product too
  assert.equal((await http('POST', `/api/store/orders/${o2.data.id}/reject`, { cookie: st.cookie, body: {} })).status, 200);
  row = await app.db.one('SELECT stock, is_available, auto_off FROM menu_items WHERE id = $1', [item.id]);
  assert.deepEqual([Number(row.stock), Number(row.is_available), Number(row.auto_off)], [1, 1, 0]);
  page = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.ok(page.menu.some((m) => m.id === item.id));
  // the customer cancels the 1st → 2 more back (once only, even if asked twice)
  const c1 = await http('POST', `/api/customer/orders/${o1.data.id}/cancel`, { cookie: cust, body: {} });
  assert.equal(c1.status, 200, JSON.stringify(c1.data));
  await http('POST', `/api/customer/orders/${o1.data.id}/cancel`, { cookie: cust, body: {} });
  assert.equal(Number((await app.db.one('SELECT stock FROM menu_items WHERE id = $1', [item.id])).stock), 3);
  // the store edits the quantity: 0 hides, more shows again; switching it by hand keeps working
  let me = (await http('PATCH', `/api/cook/menu/${item.id}`, { cookie: st.cookie, body: { stock: 0 } })).data;
  assert.deepEqual([me.menu.find((m) => m.id === item.id).available, me.menu.find((m) => m.id === item.id).soldOut], [false, true]);
  me = (await http('PATCH', `/api/cook/menu/${item.id}`, { cookie: st.cookie, body: { stock: 20 } })).data;
  assert.deepEqual([me.menu.find((m) => m.id === item.id).available, me.menu.find((m) => m.id === item.id).soldOut, me.menu.find((m) => m.id === item.id).stock], [true, false, 20]);
  me = (await http('PATCH', `/api/cook/menu/${item.id}`, { cookie: st.cookie, body: { stock: '' } })).data;
  assert.equal(me.menu.find((m) => m.id === item.id).stock, null, 'not counted any more');
  assert.equal((await order(30)).status, 201, 'a product without a quantity is never limited');
  assert.equal((await http('PATCH', `/api/cook/menu/${item.id}`, { cookie: st.cookie, body: { stock: -1 } })).status, 422);
});

test('two customers buying the last piece at the same moment: one gets it, the other is told it ran out', async () => {
  const st = await makeStore();
  const item = (await http('POST', '/api/cook/menu', { cookie: st.cookie, body: { name: 'آخر قطعة', price: 5, stock: 1 } })).data.menu.find((m) => m.name === 'آخر قطعة');
  const custs = await Promise.all(['03456201', '03456202', '03456203'].map((phone) => login('/api/customer/login', { name: 'زبون', phone, acceptTerms: true })));
  const res = await Promise.all(custs.map((cookie) => http('POST', '/api/orders', { cookie, body: { storeId: st.id, items: [{ id: item.id, qty: 1 }], lat: 33.848, lng: 35.904, paymentMethod: 'cash' } })));
  assert.deepEqual(res.map((r) => r.status).sort(), [201, 409, 409]);
  assert.equal(Number((await app.db.one('SELECT stock FROM menu_items WHERE id = $1', [item.id])).stock), 0);
});

/* ---------------- big catalogs by parts ---------------- */

test('a big store\'s page: first products of each section + real counts, «more» by parts, search in the whole catalog (also by barcode)', async () => {
  const st = await makeStore();
  const lines = ['الاسم,السعر,القسم,الباركود'];
  for (let i = 1; i <= 400; i++) lines.push(`صنف ${i},1,${i <= 100 ? 'خضار' : 'معلبات'},${500000 + i}`);
  lines.push('زعتر بلدي,4,,777777');
  const imp = await importFile(st, 'big.csv', lines.join('\n'), false);
  assert.equal(imp.status, 200, JSON.stringify(imp.data));
  const r = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.ok(r.menuBig, JSON.stringify(r).slice(0, 300));
  assert.ok(r.menuBig); assert.equal(r.menuBig.total, 401);
  assert.equal(r.menu.length, 25, '12 + 12 + 1 (three sections)');
  assert.deepEqual(r.menuBig.sections.map((s) => [s.name, s.n]).sort(), [[null, 1], ['خضار', 100], ['معلبات', 300]].sort());
  const more = (await http('GET', `/api/delivery/stores/${st.id}/menu?section=${encodeURIComponent('معلبات')}&offset=12`)).data;
  assert.equal(more.items.length, 24); assert.equal(more.hasMore, true); assert.equal(more.items[0].name, 'صنف 113');
  const other = (await http('GET', `/api/delivery/stores/${st.id}/menu?section=`)).data;
  assert.deepEqual(other.items.map((x) => x.name), ['زعتر بلدي']);
  assert.deepEqual((await http('GET', `/api/delivery/stores/${st.id}/menu?q=${encodeURIComponent('زعتر')}`)).data.items.map((x) => x.name), ['زعتر بلدي']);
  assert.deepEqual((await http('GET', `/api/delivery/stores/${st.id}/menu?q=777777`)).data.items.map((x) => x.name), ['زعتر بلدي']);
  assert.equal((await http('GET', `/api/delivery/stores/${st.id}/menu?q=${encodeURIComponent('%')}`)).data.items.length, 0, '% is a letter, not «everything»');
  // the cart page can ask for the store only
  assert.equal((await http('GET', `/api/delivery/stores/${st.id}?menu=0`)).data.menu.length, 0);
  // the store's own list by parts + search
  const own = (await http('GET', `/api/cook/menu?section=${encodeURIComponent('خضار')}`, { cookie: st.cookie })).data;
  assert.equal(own.items.length, 40); assert.equal(own.hasMore, true); assert.ok('stock' in own.items[0] && 'barcode' in own.items[0]);
  assert.equal((await http('GET', '/api/cook/menu?q=500001', { cookie: st.cookie })).data.items[0].name, 'صنف 1');
  assert.equal((await http('GET', '/api/cook/menu')).status, 401);
  // a small store stays exactly as before (whole menu at once)
  const small = await makeStore('pharmacy');
  await http('POST', '/api/cook/menu', { cookie: small.cookie, body: { name: 'بنادول', price: 2 } });
  const sp = (await http('GET', `/api/delivery/stores/${small.id}`)).data;
  assert.equal(sp.menuBig, null); assert.equal(sp.menu.length, 1);
  assert.equal((await http('GET', '/api/cook/me', { cookie: small.cookie })).data.menuBig, false);
});

/* ---------------- AI MANAGER per branch, no discount (owner, 12 Oct 2026) ---------------- */

test('AI MANAGER: monthly price × months × each chosen branch (no discount); other branches pay the normal share; only chosen branches get it', async () => {
  await A('PUT', '/api/admin/plans', { ai: { shops: { 1: { price: 30 }, 3: { price: 50 } } }, branchPercent: 50 });
  const pub = (await http('GET', '/api/plans')).data;
  assert.deepEqual([pub.ai.shops['1'], pub.ai.shops['3'], pub.ai.shops['12']], [30, 90, 360], 'no discount on months');
  const st = await makeStore('pharmacy');   // general prices: basic 10 / month
  const b1 = (await http('POST', '/api/store/branches', { cookie: st.cookie, body: { name: 'فرع زحلة', lat: 33.85, lng: 35.9 } })).data.id;
  const b2 = (await http('POST', '/api/store/branches', { cookie: st.cookie, body: { name: 'فرع شتورة', lat: 33.82, lng: 35.85 } })).data.id;
  for (const b of [b1, b2]) await A('POST', `/api/admin/stores/${b}/branch-status`, { status: 'approved' });
  const sub = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.equal(sub.aiOptions.find((x) => x.months === 1).price, 90, '3 branches × 30');
  assert.equal(sub.aiOptions.find((x) => x.months === 3).price, 270, '3 branches × 30 × 3');
  assert.equal(sub.options[0].months.find((x) => x.months === 1).price, 20, 'the subscription keeps its branch discount (10 + 5 + 5)');
  assert.equal(sub.aiBranchList.length, 3); assert.equal(sub.aiBranchList[0].main, true);
  const send = (body) => http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'basic', method: 'whish', receipt: JPG, ...body } });
  // two branches (main + زحلة) for 1 month: 2 × 30 + شتورة as a normal extra branch (10 × 50%) = 65
  const r = await send({ months: 1, tier: 'ai', aiBranches: [st.id, b1], amount: 1 });
  assert.equal(r.status, 201, JSON.stringify(r.data)); assert.equal(r.data.amount, 65);
  // only شتورة, without the main one: 30 + the main one's normal price 10 + زحلة as an extra branch 5 = 45
  const r2 = await send({ months: 1, tier: 'ai', aiBranches: [b2] });
  assert.equal(r2.data.amount, 45);
  // a branch of another store, or nothing chosen → refused
  const other = await makeStore('pharmacy');
  assert.equal((await http('POST', '/api/store/renewals', { cookie: other.cookie, body: { kind: 'basic', months: 1, tier: 'ai', aiBranches: [b1], method: 'whish', receipt: JPG } })).status, 422);
  // the admin sees which branches; approving gives the AI to those branches only
  const row = (await A('GET', '/api/admin/renewals?status=pending')).data.renewals.find((x) => x.id === r.data.id);
  assert.deepEqual(row.aiBranches.sort(), [(await app.db.one('SELECT full_name FROM cooks WHERE id = $1', [st.id])).full_name, 'فرع زحلة'].sort());
  assert.equal((await A('POST', `/api/admin/renewals/${r.data.id}/approve`, {})).status, 200);
  const ai = Object.fromEntries((await app.db.query('SELECT id, ai_until FROM cooks WHERE id IN ($1,$2,$3)', [st.id, b1, b2])).map((x) => [x.id, x.ai_until]));
  assert.ok(ai[st.id] && ai[b1], 'the chosen branches have it'); assert.equal(ai[b2], null, 'the other branch does not');
  // a new AI sign-up pays monthly × months
  await new Promise((res) => setTimeout(res, 1600));
  const su = await http('POST', '/api/cook-applications', { body: { acceptTerms: true, password: 'aiyear123', kind: 'restaurant', fullName: 'مطعم السنة', whatsapp: '71666888', lat: 33.847, lng: 35.904, servedAreaIds: [areaId], plan: 'yearly', tier: 'ai', startedAt: Date.now() - 5000 } });
  assert.equal(su.status, 201, JSON.stringify(su.data));
  assert.equal(Number((await app.db.one('SELECT amount FROM subscriptions WHERE cook_id = $1', [su.data.applicationId])).amount), 360);
  await A('PUT', '/api/admin/plans', { ai: { shops: { 3: { price: 90 } } } });
});

/* ---------------- the stores' money with drivers (owner, 12 Oct 2026) ---------------- */

test('money with drivers: store sees the driver\'s phone + vehicle / ID photos only while he holds its money; clear boxes for store, driver and admin', async () => {
  const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
  const ap = await http('POST', '/api/driver/apply', { body: { fullName: 'سامر الحاج', phone: '71333444', password: 'samer11', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1994-03-02', docs: DOCS, jobsMonths: 1 } });
  assert.equal(ap.status, 201, JSON.stringify(ap.data));
  const did = ap.data.id;
  await A('POST', `/api/admin/drivers/${did}/status`, { status: 'active' });
  const drv = await login('/api/driver/login', { phone: '71333444', password: 'samer11' });
  const st = await makeStore('restaurant');
  const other = await makeStore('restaurant');
  // a cash order he delivered and still holds: 25 $
  await app.db.query(`INSERT INTO driver_cash_entries (order_id, driver_id, store_id, amount, due_cents) VALUES ($1,$2,$3,$4,$5)`, [900001, did, st.id, 25, 2500]);
  // the store: a clear box + the driver's phone + his photos
  assert.deepEqual((await http('GET', '/api/cook/me', { cookie: st.cookie })).data.cashWithDrivers, { total: 25, drivers: 1 });
  const fin = (await http('GET', '/api/store/finance', { cookie: st.cookie })).data.finance;
  assert.equal(fin.drivers[0].phone.replace(/\D/g, '').endsWith('71333444'), true);
  for (const k of ['vehicle', 'id']) {
    const r = await fetch(`${base}/api/store/driver-doc/${did}/${k}`, { headers: { Cookie: st.cookie } });
    assert.equal(r.status, 200, k); assert.match(r.headers.get('content-type'), /^image\//); assert.match(r.headers.get('cache-control'), /no-store/);
  }
  assert.equal((await fetch(`${base}/api/store/driver-doc/${did}/vehicle`, { headers: { Cookie: other.cookie } })).status, 404, 'another store: nothing');
  assert.equal((await fetch(`${base}/api/store/driver-doc/${did}/vehicle`)).status, 401);
  // the driver: a clear box too
  assert.deepEqual((await http('GET', '/api/driver/me', { cookie: drv })).data.storeCash, { total: 25, stores: 1 });
  // the admin: total on the overview, by driver and by store
  assert.ok((await A('GET', '/api/admin/delivery/overview')).data.cashForStores >= 25);
  const dues = (await A('GET', '/api/admin/finance/dues')).data;
  const byStore = dues.stores.find((x) => x.storeId === st.id);
  assert.equal(byStore.total, 25); assert.equal(byStore.drivers[0].driverId, did);
  // he hands it over, the store confirms → the photos are gone for the store, the boxes are empty
  const h = await http('POST', '/api/driver/dues/pay', { cookie: drv, body: { storeId: st.id, amount: 25 } });
  assert.ok([200, 201].includes(h.status), JSON.stringify(h.data));
  assert.equal((await A('GET', '/api/admin/finance/dues')).data.stores.find((x) => x.storeId === st.id).drivers[0].claimed.amount, 25, 'admin sees «he says he handed it»');
  const rc = await http('POST', `/api/store/finance/drivers/${did}/received`, { cookie: st.cookie, body: { amount: 25 } });
  assert.ok([200, 201].includes(rc.status), JSON.stringify(rc.data));
  assert.equal((await fetch(`${base}/api/store/driver-doc/${did}/id`, { headers: { Cookie: st.cookie } })).status, 404, 'paid → no more photos');
  assert.deepEqual((await http('GET', '/api/cook/me', { cookie: st.cookie })).data.cashWithDrivers, { total: 0, drivers: 0 });
  assert.deepEqual((await http('GET', '/api/driver/me', { cookie: drv })).data.storeCash, { total: 0, stores: 0 });
});
