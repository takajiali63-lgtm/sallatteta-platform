// v8.5 integration: BASIC vs AI MANAGER chosen before paying (stores, sign-up, drivers) and the AI entitlement set only by
// the server; the signature design served from the owner's choice; browsing without GPS (paged, never "nearest");
// the owner's one-page overview; the customer hiding a finished order (from the owner's own version of the app).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
let app, base, admin, areaId, cust;

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let sn = 0;
async function makeStore({ kind = 'restaurant', lat = 33.85, lng = 35.9, pinned = false } = {}) {
  const wa = `+9617150${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: `متجر ${sn}`, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  if (pinned) await app.db.query('UPDATE cooks SET pinned = 1 WHERE id = $1', [r.data.id]);
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  return { id: r.data.id, cookie: await login('/api/cook/login', { whatsapp: wa, password: pw }) };
}

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [],
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03999111', acceptTerms: true });
});
after(() => app?.close?.());

test('plans: AI MANAGER prices per category (30 / 10 / 12 / 8 $ a month), editable by the owner only', async () => {
  const p = (await http('GET', '/api/plans')).data;
  assert.equal(p.ai.shops['1'], 30); assert.equal(p.ai.drivers['1'], 10); assert.equal(p.ai.online['1'], 12); assert.equal(p.ai.crafts['1'], 8);
  assert.equal((await A('PUT', '/api/admin/plans', { ai: { crafts: { 1: { price: 9 } } } })).status, 200);
  assert.equal((await http('GET', '/api/plans')).data.ai.crafts['1'], 9);
  assert.equal((await http('PUT', '/api/admin/plans', { body: { ai: { shops: { 1: { price: 1 } } } } })).status, 401);
  await A('PUT', '/api/admin/plans', { ai: { crafts: { 1: { price: 8 } } } });
});

test('store renewal: AI MANAGER chosen before paying, priced by the server; approval gives the AI entitlement; BASIC never reaches AI', async () => {
  const st = await makeStore();
  assert.equal((await http('GET', '/api/ai/settings?as=store', { cookie: st.cookie })).status, 403);   // BASIC
  const sub = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.equal(sub.aiActive, false);
  assert.equal(sub.aiOptions.find((x) => x.months === 1).price, 30);
  // the price sent by the phone is ignored: the server computes 30 $
  const r = await http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'basic', months: 1, tier: 'ai', amount: 1, method: 'whish', reference: 'R1', receipt: JPG } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(r.data.amount, 30);
  assert.equal((await http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'basic', months: 1, tier: 'gold', method: 'whish', receipt: JPG } })).status, 422);
  const row = (await A('GET', '/api/admin/renewals?status=pending')).data.renewals.find((x) => x.id === r.data.id);
  assert.equal(row.tier, 'ai');
  assert.equal((await A('POST', `/api/admin/renewals/${r.data.id}/approve`, {})).status, 200);
  const after = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.equal(after.aiActive, true);
  assert.ok(Date.parse(after.aiUntil) > Date.now() + 25 * 86_400_000);
  assert.equal((await http('GET', '/api/ai/settings?as=store', { cookie: st.cookie })).status, 200);
  // a BASIC renewal later keeps AI only until the date already paid (downgrade happens by itself)
  const r2 = await http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'basic', months: 1, tier: 'basic', method: 'whish', receipt: JPG } });
  assert.equal(r2.data.amount, 10);
  await A('POST', `/api/admin/renewals/${r2.data.id}/approve`, {});
  const later = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.equal(later.aiUntil, after.aiUntil);
  assert.ok(Date.parse(later.expiry) > Date.parse(after.aiUntil));
});

test('sign-up: the chosen tier is kept on the pending subscription and becomes the AI entitlement when the owner activates', async () => {
  await new Promise((r) => setTimeout(r, 1600));   // the form's anti-bot minimum time
  const body = { acceptTerms: true, password: 'pass12345', kind: 'restaurant', fullName: 'مطعم الذكاء', whatsapp: '71555123', lat: 33.85, lng: 35.9, servedAreaIds: [areaId], plan: 'monthly', tier: 'ai', startedAt: Date.now() - 5000 };
  const r = await http('POST', '/api/cook-applications', { body });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const id = r.data.applicationId;
  const sub = await app.db.one('SELECT tier, amount FROM subscriptions WHERE cook_id = $1', [id]);
  assert.equal(sub.tier, 'ai');
  assert.equal(Number(sub.amount), 30);
  assert.equal((await app.db.one('SELECT ai_until FROM cooks WHERE id = $1', [id])).ai_until, null, 'nothing before the owner activates');
  const act = await A('POST', `/api/admin/cooks/${id}/subscription/activate`, { plan: 'monthly' });
  assert.equal(act.status, 200, JSON.stringify(act.data));
  const c = await app.db.one('SELECT ai_until FROM cooks WHERE id = $1', [id]);
  assert.ok(c.ai_until && Date.parse(c.ai_until) > Date.now() + 25 * 86_400_000, 'AI until the paid end');
});

test('drivers: AI MANAGER chosen at sign-up; the owner activates it with the plan; 0 months stops both', async () => {
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ذكي', phone: '71555999', password: 'pass123', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1, jobsTier: 'ai' } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const d = (await A('GET', `/api/admin/drivers/${r.data.id}`)).data.driver;
  assert.equal(d.jobs_request_tier, 'ai');
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  const j = await A('POST', `/api/admin/drivers/${r.data.id}/jobs`, { months: 1, tier: 'ai' });
  assert.equal(j.data.ai, true);
  const cookie = await login('/api/driver/login', { phone: '71555999', password: 'pass123' });
  assert.equal((await http('GET', '/api/ai/settings?as=driver', { cookie })).status, 200);
  await A('POST', `/api/admin/drivers/${r.data.id}/jobs`, { months: 0 });
  assert.equal((await http('GET', '/api/ai/settings?as=driver', { cookie })).status, 403);
});

test('design: the signature layer follows the owner\'s choice (look, switching), classic designs get none', async () => {
  let css = await (await fetch(`${base}/design.css?p=app`)).text();
  assert.match(css, /--ak-signature:1/);
  assert.match(css, /--ak-default-variant:modern/);
  assert.match(css, /--ak-allow-switch:1/);
  await app.settings.save({ designVariant: 'luxury', designSwitch: false });
  css = await (await fetch(`${base}/design.css?p=panel`)).text();
  assert.match(css, /--ak-default-variant:luxury/);
  assert.match(css, /--ak-allow-switch:0/);
  assert.equal((await A('PUT', '/api/admin/designs', { key: 'midnight' })).status, 200);
  css = await (await fetch(`${base}/design.css?p=app`)).text();
  assert.ok(!/--ak-signature/.test(css));
  await A('PUT', '/api/admin/designs', { key: 'signature' });
  await app.settings.save({ designVariant: 'modern', designSwitch: true });
  // every page links it, and the icons + theme scripts load from the same origin (CSP)
  for (const p of ['/', '/store', '/driver']) {
    const html = await (await fetch(base + p)).text();
    assert.match(html, /\/design\.css\?p=/);
    assert.match(html, /aklatak-all-icons\.js/);
    assert.ok(!/ style="/.test(html), `no inline style attributes on ${p}`);
  }
});

test('browsing without GPS: every shop of the country, paged, featured first then newest, never sorted as "nearest"', async () => {
  const pinned = await makeStore({ pinned: true, lat: 34.4, lng: 35.8 });
  const many = [];
  for (let i = 0; i < 4; i += 1) many.push(await makeStore({ lat: 33.2 + i * 0.3, lng: 35.4 }));
  const r = (await http('GET', '/api/delivery/stores?country=LB&limit=3')).data;
  assert.equal(r.sorted, 'featured_new');
  assert.equal(r.stores.length, 3);
  assert.equal(r.hasMore, true);
  assert.equal(r.stores[0].id, pinned.id);
  assert.ok(r.stores.every((s) => s.distanceM === null), 'no distance without a location');
  const p2 = (await http('GET', '/api/delivery/stores?country=LB&limit=3&page=1')).data;
  assert.ok(p2.stores.every((s) => !r.stores.some((x) => x.id === s.id)), 'next page = other shops');
  const feat = (await http('GET', '/api/delivery/stores?country=LB&section=featured')).data.stores;
  assert.deepEqual(feat.map((s) => s.id), [pinned.id]);
  const fresh = (await http('GET', '/api/delivery/stores?country=LB&section=new')).data.stores;
  assert.ok(fresh.length >= 5 && fresh.every((s) => s.isNew));
  // with a location: only what is around (box + exact 25 km), nearest first
  const near = (await http('GET', `/api/delivery/stores?country=LB&lat=33.2&lng=35.4`)).data;
  assert.equal(near.sorted, 'distance');
  assert.ok(near.stores.every((s) => s.distanceM != null && s.distanceM <= 25_000));
  assert.ok(near.stores.some((s) => s.id === many[0].id));
});

test('the owner\'s overview: switches, numbers, server health — owner only', async () => {
  const r = await A('GET', '/api/admin/platform');
  assert.equal(r.status, 200);
  assert.equal(r.data.flags.driverService, false);   // restaurants manage their own delivery by default
  assert.equal(typeof r.data.numbers.storesActive, 'number');
  assert.ok(r.data.server.memoryMb > 0);
  assert.equal((await http('GET', '/api/admin/platform')).status, 401);
});

test('customer hides a finished order from his list; live orders cannot be hidden; nobody else\'s', async () => {
  const st = await makeStore({ lat: 33.85, lng: 35.9 });
  await A('POST', `/api/admin/stores/${st.id}/delivery`, { mode: 'self' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency) VALUES ($1,'طبق',5,'USD')`, [st.id]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [st.id])).id;
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: item, qty: 1 }], lat: 33.853, lng: 35.9, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  assert.equal((await http('POST', `/api/customer/orders/${o.data.id}/hide`, { cookie: cust, body: {} })).status, 409);   // still live
  await http('POST', `/api/store/orders/${o.data.id}/reject`, { cookie: st.cookie, body: {} });
  const other = await login('/api/customer/login', { name: 'آخر', phone: '03999222', acceptTerms: true });
  assert.equal((await http('POST', `/api/customer/orders/${o.data.id}/hide`, { cookie: other, body: {} })).status, 409);
  assert.equal((await http('POST', `/api/customer/orders/${o.data.id}/hide`, { cookie: cust, body: {} })).status, 200);
  assert.ok(!(await http('GET', '/api/customer/orders', { cookie: cust })).data.orders.some((x) => x.id === o.data.id));
  assert.ok(await app.db.one('SELECT id FROM orders WHERE id = $1', [o.data.id]), 'the record stays for the store');
});

test('design preset: ANY earlier ready design (old default or «glass») becomes the signature design once; a later classic choice stays', async () => {
  const { mergeSettings } = await import('../src/services/settings.js');
  const saved = mergeSettings({ ...(await app.settings.get()) }, {});
  assert.equal(saved.designV, 3);
  // a live site saved by v8.0.2 on «glass» (designV 2) → signature after the update, once
  const row = await app.db.one(`SELECT value FROM app_meta WHERE key = 'site_settings'`);
  const old = { ...JSON.parse(row.value), designPreset: 'glass', designV: 2 };
  await app.db.query(`UPDATE app_meta SET value = $1 WHERE key = 'site_settings'`, [JSON.stringify(old)]);
  await app.settings.load();
  assert.equal(app.settings.get().designPreset, 'signature');
  assert.match((await http('GET', '/design.css?p=app')).data, /ak-hero/);
  // the owner may still go back to «glass»: it stays across restarts
  await A('PUT', '/api/admin/designs', { key: 'glass' });
  await app.settings.load();
  assert.equal(app.settings.get().designPreset, 'glass');
  await A('PUT', '/api/admin/designs', { key: 'emerald' });
  await app.settings.load();
  assert.equal(app.settings.get().designPreset, 'emerald');
  await A('PUT', '/api/admin/designs', { key: 'signature' });
});
