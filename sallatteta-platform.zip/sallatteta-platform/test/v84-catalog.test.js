// v8.4 catalog: product options priced by the server, availability, promotions + the «offers» list, preparation status,
// craftspeople's quotes and jobs, independent drivers' services (listing, booking) and drivers' quotes on requests.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
let app, base, admin, areaId, cust, cust2;
const pushed = [];
const fakePush = { notify: (type, id, msg) => pushed.push({ type, id, ...msg }), notifyAdmins: () => {}, subscribe: async () => {}, publicKey: async () => 'k' };

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let n = 0;
async function makeDriver(lat, lng, { jobs = true } = {}) {
  const phone = `7184${String(1000 + n++).padStart(4, '0')}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ' + phone.slice(-3) + ' الكنية', phone, password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: `7166${phone.slice(-4)}`, acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  if (jobs) await A('POST', `/api/admin/drivers/${r.data.id}/jobs`, { months: 1 });
  const cookie = await login('/api/driver/login', { phone, password: 'pass123' });
  await http('POST', '/api/driver/availability', { body: { available: true, lat, lng }, cookie });
  return { id: r.data.id, cookie, phone };
}
let sn = 0;
async function makeStore(lat, lng, { kind = 'restaurant', price = 10 } = {}) {
  const wa = `+9617184${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل ' + sn, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'delivery' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency, section) VALUES ($1,'بيتزا',$2,'USD','بيتزا')`, [r.data.id, price]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  return { id: r.data.id, cookie, item, lat, lng };
}
const order = (st, items, cookie = cust) => http('POST', '/api/orders', { cookie, body: { storeId: st.id, items, lat: st.lat + 0.004, lng: st.lng, paymentMethod: 'cash' } });
const S = (st, m, p, b) => http(m, p, { body: b, cookie: st.cookie });
const EXTRAS = { groups: [
  { name: 'الحجم', min: 1, max: 1, options: [{ name: 'وسط', price: 0 }, { name: 'كبير', price: 2 }] },
  { name: 'إضافات', min: 0, max: 2, options: [{ name: 'جبنة', price: 1 }, { name: 'صلصة', price: 0.5 }, { name: 'زيتون', price: 0.5 }] },
] };
async function withExtras(st) {
  const r = await S(st, 'PUT', `/api/store/menu/${st.item}/extras`, EXTRAS);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const g = r.data.groups;
  return { medium: g[0].options[0].id, large: g[0].options[1].id, cheese: g[1].options[0].id, sauce: g[1].options[1].id, olives: g[1].options[2].id };
}
const setS = (b) => A('PUT', '/api/admin/delivery/settings', b);
const offerFor = async (d, errandId) => (await http('GET', '/api/driver/offers', { cookie: d.cookie })).data.offers.find((o) => o.type === 'errand' && o.errandId === errandId);
const newErrand = (body, cookie = cust) => http('POST', '/api/errands', { cookie, body: { kind: 'deliver', description: 'طرد صغير', from: { lat: 34.30, lng: 35.80 }, to: { lat: 34.31, lng: 35.81 }, ...body } });

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [], push: fakePush,
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03184777', acceptTerms: true });
  cust2 = await login('/api/customer/login', { name: 'زبون آخر', phone: '03184778', acceptTerms: true });
  await setS({ claimWindowSec: 0, offerBatch: 5 });
});
after(() => app?.close?.());

test('options are priced by the server: a tampered client price is ignored; required option → 422; max extras enforced', async () => {
  const st = await makeStore(33.80, 35.60, { price: 10 });
  const o = await withExtras(st);
  // the phone claims 0.01 $ — the server uses the database: 10 + large 2 + cheese 1 + sauce 0.5 = 13.5 × 2
  const r = await order(st, [{ id: st.item, qty: 2, price: 0.01, options: [o.large, o.cheese, o.sauce] }]);
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(r.data.total, 27);
  const line = (await app.db.one('SELECT price, unit_cents FROM order_items WHERE order_id = $1', [r.data.id]));
  assert.deepEqual([line.price, line.unit_cents], [13.5, 1350]);
  const det = (await http('GET', `/api/customer/orders/${r.data.id}`, { cookie: cust })).data.order;
  assert.deepEqual(det.items[0].options.map((x) => x.name), ['كبير', 'جبنة', 'صلصة']);
  // required "size" missing
  const miss = await order(st, [{ id: st.item, qty: 1, options: [o.cheese] }]);
  assert.deepEqual([miss.status, miss.data.error, miss.data.itemId], [422, 'option_required', st.item]);
  // three extras where 2 are allowed
  const many = await order(st, [{ id: st.item, qty: 1, options: [o.medium, o.cheese, o.sauce, o.olives] }]);
  assert.deepEqual([many.status, many.data.error], [422, 'too_many_options']);
  // two sizes in a "choose one" group, an option of another product, a repeated option
  assert.equal((await order(st, [{ id: st.item, qty: 1, options: [o.medium, o.large] }])).data.error, 'too_many_options');
  const other = await makeStore(33.81, 35.61);
  const oo = await withExtras(other);
  assert.equal((await order(st, [{ id: st.item, qty: 1, options: [oo.medium] }])).data.error, 'option_invalid');
  assert.equal((await order(st, [{ id: st.item, qty: 1, options: [o.medium, o.medium] }])).status, 422);
  // the cart's price check says the same, and saves nothing
  const chk = await http('POST', '/api/delivery/cart/price', { body: { storeId: st.id, items: [{ id: st.item, qty: 1, options: [o.medium, o.olives] }] } });
  assert.deepEqual([chk.status, chk.data.total, chk.data.lines[0].options.length], [200, 10.5, 2]);
  // the store page shows the groups to the customer
  const page = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.deepEqual(page.menu[0].options.map((g) => [g.name, g.min, g.max, g.options.length]), [['الحجم', 1, 1, 2], ['إضافات', 0, 2, 3]]);
  // invalid set-ups are refused (max above the number of options, min > max)
  const bad = await S(st, 'PUT', `/api/store/menu/${st.item}/extras`, { groups: [{ name: 'x', min: 2, max: 1, options: [{ name: 'a' }, { name: 'b' }] }] });
  assert.equal(bad.status, 422);
});

test('unavailable products are refused (switched off, or outside their hours) and shown greyed', async () => {
  const st = await makeStore(33.82, 35.62);
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency) VALUES ($1,'سلطة',4,'USD')`, [st.id]);
  const salad = (await app.db.one(`SELECT id FROM menu_items WHERE cook_id = $1 AND name = 'سلطة'`, [st.id])).id;
  await S(st, 'PATCH', `/api/cook/menu/${salad}`, { available: false });
  const r = await order(st, [{ id: st.item, qty: 1 }, { id: salad, qty: 1 }]);
  assert.deepEqual([r.status, r.data.error, r.data.itemId], [409, 'item_unavailable', salad]);
  let page = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.equal(page.menu.find((m) => m.id === salad).available, false, 'listed, greyed — not hidden');
  // a window that does not include "now" (Beirut time): 3 hours from now, for one hour
  const hh = Number(new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Beirut', hour: '2-digit', hourCycle: 'h23' }).format(new Date()));
  const f = `${String((hh + 3) % 24).padStart(2, '0')}:00`, t = `${String((hh + 4) % 24).padStart(2, '0')}:00`;
  assert.equal((await S(st, 'PUT', `/api/store/menu/${st.item}/extras`, { groups: [], availFrom: f, availTo: t })).status, 200);
  assert.equal((await order(st, [{ id: st.item, qty: 1 }])).data.error, 'item_unavailable');
  page = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.deepEqual([page.menu.find((m) => m.id === st.item).available, page.menu.find((m) => m.id === st.item).availFrom], [false, f]);
  // a window around now → available again
  const f2 = `${String((hh + 23) % 24).padStart(2, '0')}:00`, t2 = `${String((hh + 2) % 24).padStart(2, '0')}:00`;
  await S(st, 'PUT', `/api/store/menu/${st.item}/extras`, { groups: [], availFrom: f2, availTo: t2 });
  assert.equal((await order(st, [{ id: st.item, qty: 1 }])).status, 201);
  // a deleted product → same clear answer for the cart
  await S(st, 'DELETE', `/api/cook/menu/${salad}`);
  assert.deepEqual([(await order(st, [{ id: salad, qty: 1 }])).data.error], ['item_unavailable']);
});

test('a price change before confirming uses the new price; older orders keep their snapshot (names and prices)', async () => {
  const st = await makeStore(33.83, 35.63, { price: 10 });
  const o = await withExtras(st);
  const first = await order(st, [{ id: st.item, qty: 1, options: [o.medium, o.cheese] }]);
  assert.equal(first.data.total, 11);
  await S(st, 'PATCH', `/api/cook/menu/${st.item}`, { price: 12, name: 'بيتزا جديدة' });
  const g = (await S(st, 'GET', `/api/store/menu/${st.item}/extras`)).data.groups;
  g[1].options[0].name = 'جبنة إضافية'; g[1].options[0].price = 3;
  await S(st, 'PUT', `/api/store/menu/${st.item}/extras`, { groups: g });
  const ids = (await S(st, 'GET', `/api/store/menu/${st.item}/extras`)).data.groups;
  const second = await order(st, [{ id: st.item, qty: 1, options: [ids[0].options[0].id, ids[1].options[0].id] }]);
  assert.equal(second.data.total, 15, 'the price at order time');
  const old = (await http('GET', `/api/customer/orders/${first.data.id}`, { cookie: cust })).data.order;
  assert.deepEqual([old.total, old.items[0].name, old.items[0].price, old.items[0].options[1].name, old.items[0].options[1].price], [11, 'بيتزا', 11, 'جبنة', 1]);
  // the old option ids no longer exist → the cart gets a clear error to remove the line
  const stale = await order(st, [{ id: st.item, qty: 1, options: [o.medium] }]);
  assert.equal(stale.status, 422);
});

test('promotions: applied at order time with a snapshot; section offers; expire; shown on the item', async () => {
  const st = await makeStore(33.84, 35.64, { price: 20 });
  const ends = new Date(Date.now() + 864e5).toISOString();
  const p = await S(st, 'POST', '/api/store/promotions', { itemId: st.item, kind: 'percent', value: 25, badge: 'عرض', endsAt: ends });
  assert.equal(p.status, 201, JSON.stringify(p.data));
  const page = (await http('GET', `/api/delivery/stores/${st.id}`)).data;
  assert.deepEqual([page.menu[0].promo.price, page.menu[0].promo.label], [15, 'عرض']);
  const r = await order(st, [{ id: st.item, qty: 2 }]);
  assert.equal(r.data.total, 30);
  const line = await app.db.one('SELECT price, unit_cents, discount_cents, promo_label FROM order_items WHERE order_id = $1', [r.data.id]);
  assert.deepEqual([line.price, line.unit_cents, line.discount_cents, line.promo_label], [15, 2000, 500, 'عرض']);
  // the offer ends → full price; the old order keeps its discount
  await app.db.query('UPDATE promotions SET ends_at = $1 WHERE id = $2', [new Date(Date.now() - 1000).toISOString(), p.data.id]);
  assert.equal((await order(st, [{ id: st.item, qty: 1 }])).data.total, 20);
  assert.equal((await http('GET', `/api/customer/orders/${r.data.id}`, { cookie: cust })).data.order.total, 30);
  // a fixed discount on a whole section; the best offer wins; never below zero
  await S(st, 'POST', '/api/store/promotions', { section: 'بيتزا', kind: 'fixed', value: 3, endsAt: ends });
  assert.equal((await order(st, [{ id: st.item, qty: 1 }])).data.total, 17);
  await S(st, 'POST', '/api/store/promotions', { itemId: st.item, kind: 'fixed', value: 500, endsAt: ends });
  assert.equal((await order(st, [{ id: st.item, qty: 1 }])).data.total, 0);
  // validation: 95 % refused, end before start refused, unknown section refused
  assert.equal((await S(st, 'POST', '/api/store/promotions', { itemId: st.item, kind: 'percent', value: 95, endsAt: ends })).status, 422);
  assert.equal((await S(st, 'POST', '/api/store/promotions', { itemId: st.item, kind: 'percent', value: 10, startsAt: ends, endsAt: new Date(Date.now() + 3600e3).toISOString() })).status, 422);
  assert.equal((await S(st, 'POST', '/api/store/promotions', { section: 'لا يوجد', kind: 'percent', value: 10, endsAt: ends })).status, 422);
});

test('GET /api/delivery/offers works without a location, is paged and never says "nearest"; country separate', async () => {
  const ends = new Date(Date.now() + 864e5).toISOString();
  const st = await makeStore(33.85, 35.65, { price: 8 });
  await app.db.query('UPDATE promotions SET active = 0');   // only this test's offers
  for (const v of [10, 20, 30]) assert.equal((await S(st, 'POST', '/api/store/promotions', { itemId: st.item, kind: 'percent', value: v, endsAt: ends })).status, 201);
  const p0 = await http('GET', '/api/delivery/offers?country=LB&limit=2');
  assert.deepEqual([p0.status, p0.data.offers.length, p0.data.hasMore, p0.data.sorted, p0.data.offers[0].distanceM], [200, 2, true, 'newest', null]);
  assert.equal(p0.data.offers[0].item.newPrice, 5.6);
  const p1 = await http('GET', '/api/delivery/offers?country=LB&limit=2&page=1');
  assert.deepEqual([p1.data.offers.length, p1.data.hasMore], [1, false]);
  const near = await http('GET', `/api/delivery/offers?country=LB&lat=${st.lat + 0.01}&lng=${st.lng}`);
  assert.deepEqual([near.data.sorted, near.data.offers.length > 0, near.data.offers[0].distanceM > 0], ['distance', true, true]);
  const far = await http('GET', '/api/delivery/offers?country=LB&lat=36.5&lng=36.9');
  assert.equal(far.data.offers.length, 0);
  assert.equal((await http('GET', '/api/delivery/offers?country=JO')).data.offers.length, 0, 'every country is separate');
  // an offer on a product switched off disappears from the list
  await S(st, 'PATCH', `/api/cook/menu/${st.item}`, { available: false });
  assert.equal((await http('GET', '/api/delivery/offers?country=LB')).data.offers.length, 0);
});

test('preparation: time promised at accept, "ready for pickup" by the store only, seen in tracking; late flag', async () => {
  const st = await makeStore(33.86, 35.66);
  const other = await makeStore(33.87, 35.67);
  const r = await order(st, [{ id: st.item, qty: 1 }]);
  assert.equal((await S(st, 'POST', `/api/store/orders/${r.data.id}/ready`, {})).status, 409, 'not before accepting');
  assert.equal((await S(st, 'POST', `/api/store/orders/${r.data.id}/accept`, { prepMinutes: 999 })).status, 422);
  assert.equal((await S(st, 'POST', `/api/store/orders/${r.data.id}/accept`, { prepMinutes: 20 })).status, 200);
  let tr = (await http('GET', `/api/customer/orders/${r.data.id}`, { cookie: cust })).data.order;
  assert.deepEqual([tr.prepMinutes, !!tr.readyBy, tr.readyAt], [20, true, null]);
  assert.equal((await S(other, 'POST', `/api/store/orders/${r.data.id}/ready`, {})).status, 404, 'another store cannot mark it');
  // late: the promised time passed and it is not ready
  await app.db.query('UPDATE orders SET accepted_at = $1 WHERE id = $2', [new Date(Date.now() - 30 * 60_000).toISOString(), r.data.id]);
  let so = (await S(st, 'GET', '/api/store/orders')).data.orders.find((x) => x.id === r.data.id);
  assert.deepEqual([so.prepLate, so.prepMinutes], [true, 20]);
  assert.equal((await S(st, 'POST', `/api/store/orders/${r.data.id}/ready`, {})).status, 200);
  assert.equal((await S(st, 'POST', `/api/store/orders/${r.data.id}/ready`, {})).status, 409, 'once');
  so = (await S(st, 'GET', '/api/store/orders')).data.orders.find((x) => x.id === r.data.id);
  assert.deepEqual([so.prepLate, !!so.readyAt], [false, true]);
  tr = (await http('GET', `/api/customer/orders/${r.data.id}`, { cookie: cust })).data.order;
  assert.ok(tr.readyAt);
  assert.ok(pushed.some((p) => p.type === 'customer' && p.key === 'cust_order_ready'));
  // the store's own delivery continues as before after "ready"
  assert.equal((await S(st, 'POST', `/api/store/orders/${r.data.id}/self-dispatch`, {})).status, 200);
  // accept without a time still works (old phones)
  const r2 = await order(st, [{ id: st.item, qty: 1 }]);
  assert.equal((await S(st, 'POST', `/api/store/orders/${r2.data.id}/accept`, {})).status, 200);
});

test('craftsperson: quote → accepted once (double accept → one) → in progress → completed → confirmed by the customer', async () => {
  const cr = await makeStore(33.88, 35.68, { kind: 'electrician' });
  const other = await makeStore(33.89, 35.69, { kind: 'plumber' });
  const v = await http('POST', '/api/visits', { cookie: cust, body: { craftId: cr.id, description: 'تصليح كهرباء المطبخ', lat: 33.881, lng: 35.681 } });
  assert.equal(v.status, 201, JSON.stringify(v.data));
  assert.equal((await S(other, 'POST', `/api/store/visits/${v.data.id}/quote`, { price: 30 })).status, 404, 'not his request');
  const q1 = await S(cr, 'POST', `/api/store/visits/${v.data.id}/quote`, { price: 30, note: 'يشمل القطع', validHours: 24 });
  assert.equal(q1.status, 201, JSON.stringify(q1.data));
  // a new price replaces the old one
  const q2 = await S(cr, 'POST', `/api/store/visits/${v.data.id}/quote`, { price: 25 });
  let mine = (await http('GET', '/api/customer/visits', { cookie: cust })).data.visits.find((x) => x.id === v.data.id);
  assert.deepEqual([mine.quote.id, mine.quote.price, mine.quote.status, mine.phone], [q2.data.id, 25, 'sent', null]);
  assert.equal((await http('POST', `/api/customer/visits/${v.data.id}/quotes/${q1.data.id}/accept`, { cookie: cust, body: {} })).status, 409, 'withdrawn quote');
  assert.equal((await http('POST', `/api/customer/visits/${v.data.id}/quotes/${q2.data.id}/accept`, { cookie: cust2, body: {} })).status, 404, 'another customer');
  const [a, b] = await Promise.all([1, 2].map(() => http('POST', `/api/customer/visits/${v.data.id}/quotes/${q2.data.id}/accept`, { cookie: cust, body: {} })));
  assert.deepEqual([a.status, b.status].sort(), [200, 409], 'accepted exactly once');
  mine = (await http('GET', '/api/customer/visits', { cookie: cust })).data.visits.find((x) => x.id === v.data.id);
  assert.deepEqual([mine.status, mine.jobStatus, mine.price, !!mine.phone], ['accepted', 'scheduled', 25, true]);
  assert.equal((await S(cr, 'POST', `/api/store/visits/${v.data.id}/quote`, { price: 99 })).status, 409, 'no new price after acceptance');
  assert.equal((await http('POST', `/api/customer/visits/${v.data.id}/confirm`, { cookie: cust, body: {} })).status, 409, 'not completed yet');
  assert.equal((await S(other, 'POST', `/api/store/visits/${v.data.id}/job/start`, {})).status, 404);
  assert.equal((await S(cr, 'POST', `/api/store/visits/${v.data.id}/job/start`, {})).status, 200);
  assert.equal((await S(cr, 'POST', `/api/store/visits/${v.data.id}/job/start`, {})).status, 409);
  assert.equal((await S(cr, 'POST', `/api/store/visits/${v.data.id}/job/complete`, {})).status, 200);
  assert.equal((await http('POST', `/api/customer/visits/${v.data.id}/confirm`, { cookie: cust, body: {} })).status, 200);
  const sv = (await S(cr, 'GET', '/api/store/visits')).data.visits.find((x) => x.id === v.data.id);
  assert.deepEqual([sv.status, sv.jobStatus, sv.price], ['done', 'confirmed', 25]);
  // an expired quote can't be accepted; a refused one neither
  const v2 = await http('POST', '/api/visits', { cookie: cust, body: { craftId: cr.id, description: 'تركيب ثريا جديدة', lat: 33.881, lng: 35.681 } });
  const q3 = await S(cr, 'POST', `/api/store/visits/${v2.data.id}/quote`, { price: 15, validHours: 1 });
  await app.db.query('UPDATE visit_quotes SET valid_until = $1 WHERE id = $2', [new Date(Date.now() - 1000).toISOString(), q3.data.id]);
  assert.equal((await http('POST', `/api/customer/visits/${v2.data.id}/quotes/${q3.data.id}/accept`, { cookie: cust, body: {} })).data.error, 'quote_expired');
  const q4 = await S(cr, 'POST', `/api/store/visits/${v2.data.id}/quote`, { price: 16 });
  assert.equal((await http('POST', `/api/customer/visits/${v2.data.id}/quotes/${q4.data.id}/reject`, { cookie: cust, body: {} })).status, 200);
  assert.equal((await http('POST', `/api/customer/visits/${v2.data.id}/quotes/${q4.data.id}/accept`, { cookie: cust, body: {} })).status, 409);
});

const SVC = { type: 'deliver', description: 'أوصل الطرود الصغيرة داخل المدينة', priceMode: 'fixed', price: 3, areaMode: 'radius', center: { lat: 34.30, lng: 35.80 }, radiusKm: 8 };
test('driver services: CRUD with validation (forbidden types and passengers refused), tenant isolation, public listing without location', async () => {
  const d = await makeDriver(34.30, 35.80);
  const d2 = await makeDriver(34.30, 35.80);
  assert.equal((await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, type: 'taxi' } })).status, 422, 'type not in the owner\'s list');
  assert.equal((await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, description: 'توصيل ركاب إلى المطار' } })).data.error, 'forbidden_service');
  assert.equal((await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, description: 'I drive passengers anywhere' } })).data.error, 'forbidden_service');
  assert.equal((await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, radiusKm: 500 } })).status, 422);
  assert.equal((await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, hours: { open: '25:00', close: '10:00' } } })).status, 422);
  // the owner can't add a passenger type either
  assert.equal((await A('PUT', '/api/admin/catalog/service-types', { types: [{ key: 'passenger_ride', names: { ar: 'نقل ركاب' } }] })).data.error, 'forbidden_service');
  const s1 = await http('POST', '/api/driver/services', { cookie: d.cookie, body: SVC });
  assert.equal(s1.status, 201, JSON.stringify(s1.data));
  const s2 = await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, type: 'buy', description: 'أشتري لك من الصيدلية أو السوبرماركت', priceMode: 'quote', areaMode: 'areas', areaIds: [areaId] } });
  assert.equal(s2.status, 201, JSON.stringify(s2.data));
  // another driver can't edit or delete them
  assert.equal((await http('PUT', `/api/driver/services/${s1.data.id}`, { cookie: d2.cookie, body: SVC })).status, 404);
  assert.equal((await http('DELETE', `/api/driver/services/${s1.data.id}`, { cookie: d2.cookie })).status, 404);
  assert.equal((await http('PUT', `/api/driver/services/${s1.data.id}`, { cookie: d.cookie, body: { ...SVC, price: 4 } })).status, 200);
  const mine = (await http('GET', '/api/driver/services', { cookie: d.cookie })).data;
  assert.deepEqual([mine.services.length, mine.services[0].price, mine.on], [2, 4, false]);
  // listed only after the public switch is on
  let list = (await http('GET', '/api/delivery/drivers?country=LB')).data;
  assert.ok(!list.drivers.some((x) => x.id === d.id));
  await http('POST', '/api/driver/services-switch', { cookie: d.cookie, body: { on: true } });
  list = (await http('GET', '/api/delivery/drivers?country=LB')).data;
  const pub = list.drivers.find((x) => x.id === d.id);
  assert.ok(pub, 'listed');
  assert.deepEqual([pub.distanceM, pub.name, list.sorted], [null, 'سائق', 'rating'], 'no distance without a location, first name only');
  const raw = JSON.stringify(list);
  assert.ok(!/"lat"|"lng"|phone|center/.test(raw), 'never an exact place or phone');
  // with a location: distance rounded to the km; outside every service area → not listed
  const near = (await http('GET', '/api/delivery/drivers?country=LB&lat=34.33&lng=35.80')).data.drivers.find((x) => x.id === d.id);
  assert.equal(near.distanceM % 1000, 0);
  assert.ok(!(await http('GET', '/api/delivery/drivers?country=LB&lat=33.0&lng=35.2')).data.drivers.some((x) => x.id === d.id));
  // filter by type; profile page
  assert.ok((await http('GET', '/api/delivery/drivers?country=LB&type=buy')).data.drivers.find((x) => x.id === d.id).services.every((s) => s.type === 'buy'));
  const prof = (await http('GET', `/api/delivery/drivers/${d.id}`)).data.driver;
  assert.deepEqual(prof.services.map((s) => s.type), ['deliver', 'buy']);
  assert.ok(!/"lat"|"lng"|phone/.test(JSON.stringify(prof)));
  // the public photo is only the one he chose (the ID selfie stays private)
  assert.equal((await http('GET', `/api/delivery/drivers/${d.id}/photo`)).status, 404);
  assert.equal((await http('POST', '/api/driver/profile-photo', { cookie: d.cookie, body: { photo: JPG } })).status, 200);
  assert.equal((await fetch(`${base}/api/delivery/drivers/${d.id}/photo`)).status, 200);
  // a driver without the "customer requests" plan is never listed
  const nojobs = await makeDriver(34.30, 35.80, { jobs: false });
  await http('POST', '/api/driver/services', { cookie: nojobs.cookie, body: SVC });
  await http('POST', '/api/driver/services-switch', { cookie: nojobs.cookie, body: { on: true } });
  assert.ok(!(await http('GET', '/api/delivery/drivers?country=LB')).data.drivers.some((x) => x.id === nojobs.id));
  await http('DELETE', `/api/driver/services/${s2.data.id}`, { cookie: d.cookie });
  assert.equal((await http('GET', '/api/driver/services', { cookie: d.cookie })).data.services.length, 1);
});

test('booking a specific driver: a request to him only; his fixed price is his quote; accepting assigns him', async () => {
  const d = await makeDriver(34.40, 35.90);
  const bystander = await makeDriver(34.40, 35.90);
  const s = await http('POST', '/api/driver/services', { cookie: d.cookie, body: { ...SVC, center: { lat: 34.40, lng: 35.90 } } });
  await http('POST', '/api/driver/services-switch', { cookie: d.cookie, body: { on: true } });
  const body = { serviceId: s.data.id, description: 'وثيقة إلى البلدية', from: { lat: 34.41, lng: 35.90 }, to: { lat: 34.42, lng: 35.91 } };
  assert.equal((await http('POST', `/api/delivery/drivers/${d.id}/book`, { cookie: cust, body: { ...body, from: { lat: 33.0, lng: 35.2 } } })).data.error, 'outside_service_area');
  const b = await http('POST', `/api/delivery/drivers/${d.id}/book`, { cookie: cust, body });
  assert.equal(b.status, 201, JSON.stringify(b.data));
  assert.ok(await offerFor(d, b.data.id), 'he sees it');
  assert.equal(await offerFor(bystander, b.data.id), undefined, 'nobody else');
  const quotes = (await http('GET', `/api/customer/errands/${b.data.id}/quotes`, { cookie: cust })).data.quotes;
  assert.deepEqual(quotes.map((x) => [x.driver.id, x.price]), [[d.id, 3]]);
  assert.equal((await http('GET', `/api/customer/errands/${b.data.id}/quotes`, { cookie: cust2 })).status, 404);
  const acc = await http('POST', `/api/customer/errands/${b.data.id}/quotes/${quotes[0].id}/accept`, { cookie: cust, body: {} });
  assert.equal(acc.status, 200, JSON.stringify(acc.data));
  const e = (await http('GET', `/api/customer/errands/${b.data.id}`, { cookie: cust })).data.errand;
  assert.deepEqual([e.status, e.driver.id, e.price, e.quoteMode, e.targetDriverId], ['assigned', d.id, 3, true, d.id]);
  // never a restaurant order through this path: no order rows were created
  assert.equal((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM orders WHERE driver_id = $1', [d.id])).n, 0);
  await http('POST', `/api/driver/errands/${b.data.id}/delivered`, { cookie: d.cookie, body: {} });
  assert.equal((await http('POST', `/api/customer/errands/${b.data.id}/rate`, { cookie: cust, body: { stars: 5 } })).status, 200);
  assert.deepEqual((await http('GET', `/api/delivery/drivers/${d.id}`)).data.driver.rating, { count: 1, avg: 5 });
});

test('open request priced by drivers: quotes, a blocked driver can\'t quote, two simultaneous accepts → one winner', async () => {
  const d1 = await makeDriver(34.30, 35.80);
  const d2 = await makeDriver(34.301, 35.801);
  const d3 = await makeDriver(34.302, 35.802);
  const e = await newErrand({});
  assert.equal(e.status, 201, JSON.stringify(e.data));
  assert.equal(e.data.quoteMode, true);
  const o1 = await offerFor(d1, e.data.id);
  assert.ok(o1?.quoteMode, 'nearby drivers get it, marked "send your price"');
  // taking it without a price is refused
  assert.equal((await http('POST', `/api/driver/errand-offers/${o1.id}/accept`, { cookie: d1.cookie, body: {} })).data.error, 'quote_required');
  // a driver who owes the platform can't offer
  await app.db.query('INSERT INTO admin_debt_ledger (driver_id, cents, note) VALUES ($1, 500, $2)', [d3.id, 'test']);
  const blocked = await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d3.cookie, body: { price: 4 } });
  assert.deepEqual([blocked.status, blocked.data.error], [409, 'admin_debt_block']);
  await app.db.query('DELETE FROM admin_debt_ledger WHERE driver_id = $1', [d3.id]);
  assert.equal((await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d1.cookie, body: { price: 5, note: 'خلال ربع ساعة' } })).status, 201);
  assert.equal((await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d2.cookie, body: { price: 4 } })).status, 201);
  assert.equal((await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d2.cookie, body: { price: 4.5 } })).status, 200, 'he can change his price');
  assert.equal((await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d1.cookie, body: { price: 0 } })).status, 422);
  const quotes = (await http('GET', `/api/customer/errands/${e.data.id}/quotes`, { cookie: cust })).data.quotes;
  assert.deepEqual(quotes.map((x) => x.price), [4.5, 5], 'cheapest first');
  // two tabs accept two different quotes at the same moment
  const res = await Promise.all(quotes.map((x) => http('POST', `/api/customer/errands/${e.data.id}/quotes/${x.id}/accept`, { cookie: cust, body: {} })));
  assert.deepEqual(res.map((x) => x.status).sort(), [200, 409]);
  const winner = res.find((x) => x.status === 200).data;
  const er = (await http('GET', `/api/customer/errands/${e.data.id}`, { cookie: cust })).data.errand;
  assert.deepEqual([er.status, er.driver.id, er.price], ['assigned', winner.driverId, winner.price]);
  const rows = await app.db.query('SELECT driver_id, status FROM errand_quotes WHERE errand_id = $1 ORDER BY id', [e.data.id]);
  assert.deepEqual(rows.map((r) => r.status).sort(), ['accepted', 'closed']);
  assert.ok(pushed.some((p) => p.type === 'driver' && p.id === winner.driverId && p.key === 'drv_quote_won'));
  // too late for the others: the request is no longer offered to them
  assert.equal((await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d3.cookie, body: { price: 3 } })).status, 404);
  assert.ok([undefined, 'reserved'].includes((await offerFor(d3, e.data.id))?.state), 'shown as "reserved" for a moment, then gone');
  await http('POST', `/api/customer/errands/${e.data.id}/cancel`, { cookie: cust, body: {} });
});

test('negotiation: «a better price please» (once), the driver must go lower; «no thanks» stops that driver; others unaffected', async () => {
  const d1 = await makeDriver(34.60, 35.90);
  const d2 = await makeDriver(34.601, 35.901);
  const e = await newErrand({ from: { lat: 34.60, lng: 35.90 }, to: { lat: 34.61, lng: 35.91 } }, cust2);
  assert.equal(e.status, 201, JSON.stringify(e.data));
  const id = e.data.id;
  const Q = (d, price) => http('POST', `/api/driver/errands/${id}/quote`, { cookie: d.cookie, body: { price } });
  assert.equal((await Q(d1, 8)).status, 201);
  assert.equal((await Q(d2, 7)).status, 201);
  const qs = async () => (await http('GET', `/api/customer/errands/${id}/quotes`, { cookie: cust2 })).data.quotes;
  const q1 = (await qs()).find((x) => x.driver.id === d1.id);
  const C = (q, act, who = cust2) => http('POST', `/api/customer/errands/${id}/quotes/${q.id}/${act}`, { cookie: who, body: {} });
  assert.equal((await C(q1, 'improve', cust)).status, 404, 'only the customer of the request');
  assert.equal((await C(q1, 'improve')).status, 200);
  assert.equal((await C(q1, 'improve')).data.error, 'already_asked');
  assert.ok(pushed.some((p) => p.type === 'driver' && p.id === d1.id && p.key === 'drv_quote_improve'));
  const off = await offerFor(d1, id);
  assert.deepEqual([off.improveAsked, off.myQuote], [true, 8]);
  // the driver must go lower than his refused price
  assert.deepEqual([(await Q(d1, 8)).status, (await Q(d1, 9)).data.error], [422, 'price_not_better']);
  const better = await Q(d1, 6.5);
  assert.deepEqual([better.status, better.data.improved], [200, true]);
  const q1b = (await qs()).find((x) => x.driver.id === d1.id);
  assert.deepEqual([q1b.price, q1b.previous, q1b.improveAsked], [6.5, 8, false]);
  assert.ok(pushed.some((p) => p.type === 'customer' && p.key === 'cust_errand_quote_better'));
  // «no thanks» to the other driver: he can't send another price; his offer disappears for him
  const q2 = (await qs()).find((x) => x.driver.id === d2.id);
  assert.equal((await C(q2, 'reject')).status, 200);
  assert.equal((await Q(d2, 5)).data.error, 'quote_rejected');
  assert.equal(await offerFor(d2, id), undefined);
  assert.deepEqual((await qs()).map((x) => x.driver.id), [d1.id]);
  assert.equal((await C(q2, 'accept')).status, 409, 'a refused offer can\'t be accepted');
  // a simultaneous «improve» and «accept»: the request still goes to one driver at one price
  const [acc] = await Promise.all([C(q1b, 'accept'), C(q1b, 'improve')]);
  assert.equal(acc.status, 200);
  const er = (await http('GET', `/api/customer/errands/${id}`, { cookie: cust2 })).data.errand;
  assert.deepEqual([er.status, er.driver.id, er.price], ['assigned', d1.id, 6.5]);
  assert.equal((await Q(d1, 5)).status, 404, 'no new price after acceptance');
  await http('POST', `/api/customer/errands/${id}/cancel`, { cookie: cust2, body: {} });
});

test('old customer-priced requests still work as before (first driver takes it at the customer\'s price)', async () => {
  const d = await makeDriver(34.50, 36.00);
  const e = await newErrand({ price: 6, from: { lat: 34.50, lng: 36.00 }, to: { lat: 34.51, lng: 36.01 } }, cust2);
  assert.deepEqual([e.status, e.data.quoteMode], [201, false]);
  const off = await offerFor(d, e.data.id);
  assert.deepEqual([off.quoteMode, off.fee], [false, 6]);
  assert.equal((await http('POST', `/api/driver/errands/${e.data.id}/quote`, { cookie: d.cookie, body: { price: 9 } })).status, 409, 'no quotes on a priced request');
  const acc = await http('POST', `/api/driver/errand-offers/${off.id}/accept`, { cookie: d.cookie, body: {} });
  assert.equal(acc.data.won, true, JSON.stringify(acc.data));
  const er = (await http('GET', `/api/customer/errands/${e.data.id}`, { cookie: cust2 })).data.errand;
  assert.deepEqual([er.status, er.price, er.driver.id], ['assigned', 6, d.id]);
});

test('a store cannot touch another store\'s catalog, offers, photos or orders', async () => {
  const a = await makeStore(33.90, 35.70);
  const b = await makeStore(33.91, 35.71);
  assert.equal((await S(b, 'GET', `/api/store/menu/${a.item}/extras`)).status, 404);
  assert.equal((await S(b, 'PUT', `/api/store/menu/${a.item}/extras`, EXTRAS)).status, 404);
  assert.equal((await S(b, 'POST', '/api/store/promotions', { itemId: a.item, kind: 'percent', value: 10, endsAt: new Date(Date.now() + 864e5).toISOString() })).status, 404);
  const p = await S(a, 'POST', '/api/store/promotions', { itemId: a.item, kind: 'percent', value: 10, endsAt: new Date(Date.now() + 864e5).toISOString() });
  assert.equal((await S(b, 'PATCH', `/api/store/promotions/${p.data.id}`, { active: false })).status, 404);
  assert.equal((await S(b, 'DELETE', `/api/store/promotions/${p.data.id}`)).status, 404);
  assert.ok(!(await S(b, 'GET', '/api/store/promotions')).data.promotions.some((x) => x.id === p.data.id));
  await app.db.query(`INSERT INTO cook_photos (cook_id, data, caption) VALUES ($1,'x','قديم')`, [a.id]);
  const ph = (await app.db.one('SELECT id FROM cook_photos WHERE cook_id = $1', [a.id])).id;
  assert.equal((await S(b, 'PATCH', `/api/store/photos/${ph}`, { caption: 'لي' })).status, 404);
  assert.equal((await S(a, 'PATCH', `/api/store/photos/${ph}`, { caption: 'مطبخ بعد التجديد' })).status, 200);
  // the business page: shareable address, gallery with captions, towns served
  const page = (await http('GET', `/api/delivery/stores/${a.id}`)).data.store;
  assert.equal(page.shareUrl, `/c/${a.id}`);
  assert.deepEqual(page.gallery.map((g) => g.caption), ['مطبخ بعد التجديد']);
  assert.ok(page.areas.length >= 1);
  const html = await fetch(`${base}/c/${a.id}`);
  assert.equal(html.status, 200, '/c/<id> opens the app (then #/s/<id>)');
  // without signing in: nothing
  assert.equal((await http('GET', '/api/store/promotions')).status, 401);
  assert.equal((await http('GET', '/api/driver/services')).status, 401);
});
