// v8.7 every country is a separate world: stores, offers, store pages, orders, drivers (offers, listing, booking),
// errands and the owner's per-country views — Lebanon and Egypt side by side, nothing crosses the border.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
const ZAHLE = { lat: 33.8466, lng: 35.9031 }, CAIRO = { lat: 30.0444, lng: 31.2357 };
let app, base, admin, areaId, lb, eg, custLB, custEG, drvLB, drvEG;

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let sn = 0;
async function makeStore(where, country, name) {
  const wa = `+9617180${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: name, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: 'restaurant', lat: where.lat, lng: where.lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await app.db.query('UPDATE cooks SET country = $1, lat = $2, lng = $3, pinned = 1 WHERE id = $4', [country, where.lat, where.lng, r.data.id]);   // pinned: also in «featured»
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'delivery' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency) VALUES ($1, $2, 5, 'USD')`, [r.data.id, `${name} طبق`]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  await http('POST', '/api/store/settings', { cookie, body: { deliveryFee: 2 } });
  const ends = new Date(Date.now() + 7 * 864e5).toISOString();
  assert.ok([200, 201].includes((await http('POST', '/api/store/promotions', { cookie, body: { itemId: item, kind: 'percent', value: 10, badge: 'عرض', endsAt: ends } })).status));
  return { id: r.data.id, cookie, item, ...where, name };
}
async function makeDriver(where, country, i) {
  const phone = `7191${String(1000 + i)}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: `سائق ${country}`, phone, password: 'pass123', vehicle: 'moto', acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await app.db.query('UPDATE drivers SET country = $1 WHERE id = $2', [country, r.data.id]);
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  await A('POST', `/api/admin/drivers/${r.data.id}/jobs`, { months: 1 });
  const cookie = await login('/api/driver/login', { phone, password: 'pass123' });
  await http('POST', '/api/driver/availability', { cookie, body: { available: true, lat: where.lat + 0.002, lng: where.lng } });
  return { id: r.data.id, cookie };
}

before(async () => {
  app = await createApp({ databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'c'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'countries-pass-1' }, placesFetcher: async () => [],
    searchLimit: 1e6, applyLimit: 1e6, loginLimit: 1e6, lookupLimit: 1e6, placesLimit: 1e6, feedbackLimit: 1e6, uploadLimit: 1e6, adminLimit: 1e6 });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'countries-pass-1' });
  await A('PUT', '/api/admin/delivery/settings', { driverService: 1, claimWindowSec: 0 });
  lb = await makeStore(ZAHLE, 'LB', 'مطعم زحلة');
  eg = await makeStore(CAIRO, 'EG', 'مطعم القاهرة');
  custLB = await login('/api/customer/login', { name: 'زبون لبنان', phone: '03222111', country: 'LB', acceptTerms: true });
  custEG = await login('/api/customer/login', { name: 'زبون مصر', phone: '01012345678', country: 'EG', acceptTerms: true });
  assert.ok(custLB && custEG);
  drvLB = await makeDriver(ZAHLE, 'LB', 1);
  drvEG = await makeDriver(CAIRO, 'EG', 2);
});
after(() => app?.close?.());

const names = (r) => JSON.stringify(r.data);

test('store lists: each country sees only its own stores — with or without location, every page, search, and even without a country', async () => {
  for (const qs of ['', 'LOC', '&page=0', '&section=featured', '&section=new', '&q=' + encodeURIComponent('مطعم')]) {
    const L = await http('GET', `/api/delivery/stores?country=LB${qs === 'LOC' ? `&lat=${ZAHLE.lat}&lng=${ZAHLE.lng}` : qs}`);
    const E = await http('GET', `/api/delivery/stores?country=EG${qs === 'LOC' ? `&lat=${CAIRO.lat}&lng=${CAIRO.lng}` : qs}`);
    assert.ok(names(L).includes('مطعم زحلة') && !names(L).includes('مطعم القاهرة'), `LB ${qs}`);
    assert.ok(names(E).includes('مطعم القاهرة') && !names(E).includes('مطعم زحلة'), `EG ${qs}`);
  }
  // even a Lebanese location asked "as Egypt" never mixes, and no country never means "all countries"
  assert.ok(!names(await http('GET', '/api/delivery/stores?country=EG&lat=33.85&lng=35.9')).includes('مطعم زحلة'));
  const none = await http('GET', '/api/delivery/stores');
  assert.ok(!names(none).includes('مطعم القاهرة'));
});

test('offers and store pages stay inside their country', async () => {
  const oL = names(await http('GET', '/api/delivery/offers?country=LB'));
  const oE = names(await http('GET', '/api/delivery/offers?country=EG'));
  assert.ok(oL.includes('مطعم زحلة') && !oL.includes('مطعم القاهرة'));
  assert.ok(oE.includes('مطعم القاهرة') && !oE.includes('مطعم زحلة'));
  assert.ok(!names(await http('GET', '/api/delivery/offers')).includes('مطعم القاهرة'));
  assert.equal((await http('GET', `/api/delivery/stores/${eg.id}?country=EG`)).status, 200);
  assert.equal((await http('GET', `/api/delivery/stores/${eg.id}?country=LB`)).status, 404);
});

test('orders never cross a border; drivers only get offers from their own country', async () => {
  // a customer of one country cannot order from a store in another
  assert.equal((await http('POST', '/api/orders', { cookie: custLB, body: { storeId: eg.id, items: [{ id: eg.item, qty: 1 }], lat: CAIRO.lat + 0.004, lng: CAIRO.lng, paymentMethod: 'cash' } })).status, 404);
  assert.equal((await http('POST', '/api/orders', { cookie: custEG, body: { storeId: lb.id, items: [{ id: lb.item, qty: 1 }], lat: ZAHLE.lat + 0.004, lng: ZAHLE.lng, paymentMethod: 'cash' } })).status, 404);
  // Cairo order → only the Egyptian driver is offered it, even with the Lebanese driver online
  const o = await http('POST', '/api/orders', { cookie: custEG, body: { storeId: eg.id, items: [{ id: eg.item, qty: 1 }], lat: CAIRO.lat + 0.004, lng: CAIRO.lng, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: eg.cookie, body: {} });
  const s = await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: eg.cookie, body: {} });
  assert.equal(s.status, 200, JSON.stringify(s.data));
  const offEG = (await http('GET', '/api/driver/offers', { cookie: drvEG.cookie })).data.offers || [];
  const offLB = (await http('GET', '/api/driver/offers', { cookie: drvLB.cookie })).data.offers || [];
  assert.ok(offEG.some((x) => x.orderId === o.data.id), 'Egyptian driver gets the Cairo order');
  assert.ok(!offLB.some((x) => x.orderId === o.data.id), 'Lebanese driver never sees it');
  // the store's list of candidate drivers has no driver from another country
  const st = (await http('GET', '/api/store/orders', { cookie: eg.cookie })).data.orders.find((x) => x.id === o.data.id);
  assert.ok(!JSON.stringify(st?.candidates || []).includes('سائق LB'));
  // the Lebanese store never sees the Egyptian order
  assert.ok(!(await http('GET', '/api/store/orders', { cookie: lb.cookie })).data.orders.some((x) => x.id === o.data.id));
});

test('errands ("ask a driver"): offered only to drivers of the customer\'s country', async () => {
  const e = await http('POST', '/api/errands', { cookie: custLB, body: { kind: 'buy', description: 'ربطة خبز وحليب', price: 4, purchaseValue: 10, from: { lat: ZAHLE.lat + 0.003, lng: ZAHLE.lng, details: 'الفرن' }, to: { lat: ZAHLE.lat + 0.01, lng: ZAHLE.lng, details: 'البيت' } } });
  assert.ok([200, 201].includes(e.status), JSON.stringify(e.data));
  const offLB = JSON.stringify((await http('GET', '/api/driver/offers', { cookie: drvLB.cookie })).data);
  const offEG = JSON.stringify((await http('GET', '/api/driver/offers', { cookie: drvEG.cookie })).data);
  assert.ok(!offEG.includes('ربطة خبز وحليب'), 'the Egyptian driver never sees a Lebanese errand');
  assert.ok(offLB.includes('ربطة خبز وحليب'), 'the Lebanese driver does');
});

test('independent drivers\' listing and booking are per country', async () => {
  for (const d of [drvLB, drvEG]) await http('POST', '/api/driver/services', { cookie: d.cookie, body: { type: 'deliver', title: 'توصيل أغراض', price: 3, radiusKm: 10, lat: d === drvLB ? ZAHLE.lat : CAIRO.lat, lng: d === drvLB ? ZAHLE.lng : CAIRO.lng } });
  const L = names(await http('GET', '/api/delivery/drivers?country=LB'));
  const E = names(await http('GET', '/api/delivery/drivers?country=EG'));
  assert.ok(!L.includes('سائق EG') && !E.includes('سائق LB'));
  assert.equal((await http('GET', `/api/delivery/drivers/${drvEG.id}?country=LB`)).status, 404);
  const b = await http('POST', `/api/delivery/drivers/${drvEG.id}/book`, { cookie: custLB, body: { lat: ZAHLE.lat, lng: ZAHLE.lng, note: 'test' } });
  assert.ok(b.status >= 400 && b.status < 500, `a Lebanese customer cannot book an Egyptian driver (${b.status})`);
});

test('the owner sees each country separately; a hidden country shows nothing to its customers', async () => {
  const oEG = names(await A('GET', '/api/admin/orders?country=EG'));
  const oLB = names(await A('GET', '/api/admin/orders?country=LB'));
  assert.ok(oEG.includes('مطعم القاهرة') && !oEG.includes('مطعم زحلة'));
  assert.ok(!oLB.includes('مطعم القاهرة'));
  const s = (await A('GET', '/api/admin/settings')).data;
  const hidden = [...new Set([...(s.settings?.countriesHidden || s.countriesHidden || []), 'EG'])];
  const put = await A('PUT', '/api/admin/settings', { countriesHidden: hidden });
  if (put.status === 200) {
    assert.equal((await http('GET', '/api/delivery/stores?country=EG')).data.stores.length, 0);
    assert.equal((await http('GET', '/api/delivery/offers?country=EG')).data.offers.length, 0);
    assert.ok(names(await http('GET', '/api/delivery/stores?country=LB')).includes('مطعم زحلة'), 'other countries unaffected');
    await A('PUT', '/api/admin/settings', { countriesHidden: hidden.filter((c) => c !== 'EG') });
  }
});

test('inside one country: a customer in Beirut sees Beirut stores (nearest first, with distance) and not the Bekaa ones — every row; without a place he browses the whole country', async () => {
  const BEIRUT = { lat: 33.8938, lng: 35.5018 };
  const bey = await makeStore(BEIRUT, 'LB', 'مطعم بيروت');
  const near = (r) => r.data.stores.map((x) => x.name);
  for (const sec of ['', '&section=featured', '&section=new']) {
    const inBeirut = await http('GET', `/api/delivery/stores?country=LB&lat=${BEIRUT.lat}&lng=${BEIRUT.lng}${sec}`);
    const inZahle = await http('GET', `/api/delivery/stores?country=LB&lat=${ZAHLE.lat}&lng=${ZAHLE.lng}${sec}`);
    assert.ok(near(inBeirut).includes('مطعم بيروت') && !near(inBeirut).includes('مطعم زحلة'), `Beirut ${sec}`);
    assert.ok(near(inZahle).includes('مطعم زحلة') && !near(inZahle).includes('مطعم بيروت'), `Zahle ${sec}`);
    assert.ok(inBeirut.data.stores.every((x) => x.distanceM != null && x.distanceM <= 25_000), `distance shown ${sec}`);
  }
  const all = near(await http('GET', '/api/delivery/stores?country=LB'));
  assert.ok(all.includes('مطعم بيروت') && all.includes('مطعم زحلة'), 'no place yet → the whole country, titled «all stores»');
  await app.db.query('DELETE FROM cooks WHERE id = $1', [bey.id]);
});

test('the owner sets how far customers see stores and offers (admin → delivery settings)', async () => {
  const BEIRUT = { lat: 33.8938, lng: 35.5018 };
  const bey = await makeStore(BEIRUT, 'LB', 'مطعم بيروت 2');
  // Zahle ↔ Beirut ≈ 37 km: hidden at 25 km, visible at 50 km — stores and offers alike
  const from = `country=LB&lat=${ZAHLE.lat}&lng=${ZAHLE.lng}`;
  assert.ok(!JSON.stringify((await http('GET', `/api/delivery/stores?${from}`)).data).includes('مطعم بيروت 2'));
  assert.equal((await A('PUT', '/api/admin/delivery/settings', { storesRadiusKm: 50 })).status, 200);
  assert.ok(JSON.stringify((await http('GET', `/api/delivery/stores?${from}`)).data).includes('مطعم بيروت 2'));
  assert.ok(JSON.stringify((await http('GET', `/api/delivery/offers?${from}`)).data).includes('مطعم بيروت 2'));
  assert.equal((await A('PUT', '/api/admin/delivery/settings', { storesRadiusKm: 5 })).status, 200);
  const tight = (await http('GET', `/api/delivery/stores?${from}`)).data.stores;
  assert.ok(tight.every((x) => x.distanceM <= 5000));
  await A('PUT', '/api/admin/delivery/settings', { storesRadiusKm: 25 });
  await app.db.query('DELETE FROM promotions WHERE cook_id = $1', [bey.id]);
  await app.db.query('DELETE FROM menu_items WHERE cook_id = $1', [bey.id]);
  await app.db.query('DELETE FROM cooks WHERE id = $1', [bey.id]);
});
