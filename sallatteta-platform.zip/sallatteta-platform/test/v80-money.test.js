// v8 money between drivers and stores (the platform never holds it): invoices, two-sided confirmation, the 100 $ cap that
// counts the new order, the 150 $ big-order exception, the owner paying a store for a driver (debt → block), complaints,
// reminders, privacy, concurrency; delivery fee by road distance; drivers' visibility radius, stale GPS and widening.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/server.js';
import { createPayments } from '../src/services/payments.js';
import { feeForKm, quoteFee } from '../src/services/fees.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
const PAY_ENV = { PAY_CHECKOUT_URL: 'https://pay.example/create', PAY_API_KEY: 'k', PAY_WEBHOOK_SECRET: 'whsec' };
const fakePay = async (url, opts) => ({ ok: true, status: 200, json: async () => ({ url: `https://pay.example/c/${JSON.parse(opts.body).reference}` }) });
let app, base, admin, areaId, cust;
const pushed = [];
const fakePush = { notify: (type, id, msg) => pushed.push({ type, id, ...msg }), notifyAdmins: () => {}, subscribe: async () => {}, publicKey: async () => 'k' };

async function http(method, path, { body, cookie } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let n = 0;
async function makeDriver(lat, lng, extra = {}) {
  const phone = `7190${String(1000 + n++).padStart(4, '0')}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ' + phone.slice(-3), phone, password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: `7166${phone.slice(-4)}`, acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, ...extra } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  const cookie = await login('/api/driver/login', { phone, password: 'pass123' });
  await http('POST', '/api/driver/availability', { body: { available: true, lat, lng }, cookie });
  return { id: r.data.id, cookie, phone };
}
let sn = 0;
async function makeStore(lat, lng, { kind = 'restaurant', price = 10, pay = 'both' } = {}) {
  const wa = `+9617170${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل ' + sn, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat, lng, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/stores/${r.data.id}/delivery`, { mode: 'delivery' });
  await app.db.query(`INSERT INTO menu_items (cook_id, name, price, currency) VALUES ($1,'طبق',$2,'USD')`, [r.data.id, price]);
  const item = (await app.db.one('SELECT id FROM menu_items WHERE cook_id = $1', [r.data.id])).id;
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  const cookie = await login('/api/cook/login', { whatsapp: wa, password: pw });
  await http('POST', '/api/store/settings', { cookie, body: { deliveryFee: 2, payMethods: pay } });
  return { id: r.data.id, cookie, item, lat, lng, pw, wa };
}
async function deliver(d, st, qty = 1) {
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty }], lat: st.lat + 0.004, lng: st.lng, paymentMethod: 'cash' } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
  const s = await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: {} });
  assert.equal(s.status, 200, JSON.stringify(s.data));
  const off = (await http('GET', '/api/driver/offers', { cookie: d.cookie })).data.offers.find((x) => x.orderId === o.data.id);
  assert.ok(off, 'offered');
  assert.equal((await http('POST', `/api/driver/offers/${off.id}/accept`, { cookie: d.cookie, body: {} })).status, 200);
  await http('POST', `/api/driver/orders/${o.data.id}/delivered`, { cookie: d.cookie, body: {} });
  await http('POST', `/api/customer/orders/${o.data.id}/confirm`, { cookie: cust, body: {} });
  return o.data.id;
}
const fin = async (d) => (await http('GET', '/api/driver/finance', { cookie: d.cookie })).data.finance;

const km = (a, b) => { const R = 6371, r = (x) => (x * Math.PI) / 180; const h = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lng - a.lng) / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
// a map service stand-in: road = straight line × 1.2 (a real road distance, not an estimate)
const fakeRoads = {
  distance: async (a, b) => ({ m: Math.round(km(a, b) * 1200), approx: false }),
  many: async (list, to) => list.map((a) => ({ m: Math.round(km(a, to) * 1200), approx: false })),
};
const pos = async (d) => (await http('GET', '/api/driver/invoices', { cookie: d.cookie })).data.position;
const setS = (b) => A('PUT', '/api/admin/delivery/settings', b);
/** a cash order searching for drivers; returns { id, offer } for driver d (offer may be undefined) */
async function searching(st, qty, d, { method = 'cash', allowException } = {}) {
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty }], lat: st.lat + 0.004, lng: st.lng, paymentMethod: method } });
  assert.equal(o.status, 201, JSON.stringify(o.data));
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
  const s = await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: allowException === undefined ? {} : { allowException } });
  const offer = d && s.status === 200 ? (await http('GET', '/api/driver/offers', { cookie: d.cookie })).data.offers.find((x) => x.orderId === o.data.id) : undefined;
  return { id: o.data.id, search: s, offer };
}
const finish = async (d, id) => { await http('POST', `/api/driver/orders/${id}/delivered`, { cookie: d.cookie, body: {} }); await http('POST', `/api/customer/orders/${id}/confirm`, { cookie: cust, body: {} }); };
const forceOffer = async (orderId, d) => {
  await app.db.query(`INSERT INTO order_offers (order_id, driver_id, fee) VALUES ($1,$2,2)`, [orderId, d.id]);
  return (await app.db.one('SELECT id FROM order_offers WHERE order_id = $1 AND driver_id = $2 ORDER BY id DESC', [orderId, d.id])).id;
};
const cancel = (st, id) => http('POST', `/api/store/orders/${id}/cancel`, { cookie: st.cookie, body: {} });

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [], push: fakePush, roads: fakeRoads,
    payments: createPayments({ env: PAY_ENV, fetchImpl: fakePay, log: {} }),
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03999777', acceptTerms: true });
});
after(() => app?.close?.());

test('defaults after the upgrade: store orders are NOT sent to Aklatak drivers; cap 100 $, exception 150 $, reminders every 2 h', async () => {
  const s = (await A('GET', '/api/admin/delivery/settings')).data.settings;
  assert.deepEqual([s.driverService, s.cashLimit, s.exceptionCap, s.exceptionOn, s.financeRemindMin, s.feeMode], [0, 100, 150, 1, 120, 0]);
  const st = await makeStore(36.00, 35.50);
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: 36.004, lng: 35.50 } });
  assert.equal(o.status, 201, 'the store delivers by itself (its plan with drivers acts as own delivery)');
  await http('POST', `/api/store/orders/${o.data.id}/accept`, { cookie: st.cookie, body: {} });
  assert.deepEqual([(await http('POST', `/api/store/orders/${o.data.id}/search`, { cookie: st.cookie, body: {} })).data.error], ['driver_service_off']);
  await setS({ driverService: 1, claimWindowSec: 0, offerBatch: 5 });   // the owner turns the legacy dispatch back on for the rest
});

test('cap counts the NEW order: 90 $ owed + a 20 $ order = 110 $ > 100 $ → not offered, refused by the server; + 10 $ → allowed', async () => {
  const st = await makeStore(36.10, 35.50, { price: 10 });
  const d = await makeDriver(36.101, 35.501);
  await deliver(d, st, 9);                                              // 90 $ owed
  assert.deepEqual([(await pos(d)).owed, (await pos(d)).remaining], [90, 10]);
  const big = await searching(st, 2, d);                               // 20 $
  assert.equal(big.offer, undefined, 'not offered');
  const forced = await http('POST', `/api/driver/offers/${await forceOffer(big.id, d)}/accept`, { cookie: d.cookie, body: {} });
  assert.deepEqual([forced.status, forced.data.error, forced.data.owed, forced.data.order], [409, 'cash_limit_reached', 90, 20]);
  await cancel(st, big.id);
  const ok10 = await searching(st, 1, d);                              // 10 $ → exactly 100 $
  assert.ok(ok10.offer);
  assert.equal((await http('POST', `/api/driver/offers/${ok10.offer.id}/accept`, { cookie: d.cookie, body: {} })).data.won, true);
  assert.equal((await pos(d)).exposure, 100, 'the accepted order is reserved before it is delivered');
  await finish(d, ok10.id);
  // card orders: nothing owed by the driver → allowed at the cap; blocks (debt to the platform, open exception) still apply
  const { checkTake } = await import('../src/services/dues.js');
  const atCap = { blocked: null, exposureCents: 10000, capCents: 10000, adminDebtCents: 0, exceptionOn: true, exceptionCapCents: 15000 };
  assert.deepEqual(checkTake(atCap, {}, { customer_total: 12, payment_method: 'card', total: 10, self_delivery: 0 }), { exception: false });
  assert.throws(() => checkTake({ ...atCap, blocked: 'admin_debt', adminDebtCents: 100 }, {}, { customer_total: 12, payment_method: 'card', total: 10 }), /admin_debt_block/);
});

test('big-order exception: store must accept first; driver must accept explicitly; then blocked from every order until paid', async () => {
  const st = await makeStore(36.20, 35.50, { price: 10 });
  const free = await makeDriver(36.201, 35.501);
  const owing = await makeDriver(36.202, 35.501);
  const other = await makeStore(36.21, 35.50, { price: 10 });
  await deliver(owing, other, 1);                                       // owes 10 $ → can't take an exception
  // 16 items = 160 $ > 150 $: over the exception cap → refused
  const tooBig = await searching(st, 16, null);
  assert.deepEqual([tooBig.search.status, tooBig.search.data.error, tooBig.search.data.exceptionCap], [409, 'over_driver_cap', 150]);
  await cancel(st, tooBig.id);
  // 12 items = 120 $: the store is warned and must accept the exception before the search
  const ex = await searching(st, 12, null);
  assert.deepEqual([ex.search.status, ex.search.data.error, ex.search.data.amount, ex.search.data.limit], [409, 'exception_consent_required', 120, 100]);
  const ok = await http('POST', `/api/store/orders/${ex.id}/search`, { cookie: st.cookie, body: { allowException: true } });
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  const offFree = (await http('GET', '/api/driver/offers', { cookie: free.cookie })).data.offers.find((x) => x.orderId === ex.id);
  const offOwing = (await http('GET', '/api/driver/offers', { cookie: owing.cookie })).data.offers.find((x) => x.orderId === ex.id);
  assert.ok(offFree, 'a driver who owes nothing sees it');
  assert.equal(offOwing, undefined, 'a driver who owes something does not');
  const noConsent = await http('POST', `/api/driver/offers/${offFree.id}/accept`, { cookie: free.cookie, body: {} });
  assert.deepEqual([noConsent.status, noConsent.data.error, noConsent.data.amount], [409, 'exception_consent_required', 120]);
  const yes = await http('POST', `/api/driver/offers/${offFree.id}/accept`, { cookie: free.cookie, body: { exception: true } });
  assert.equal(yes.data.won, true);
  assert.equal((await app.db.one('SELECT exception FROM orders WHERE id = $1', [ex.id])).exception, 1);
  await finish(free, ex.id);
  assert.equal((await pos(free)).blocked, 'exception_open');
  // blocked from everything new, even a small order
  const small = await searching(other, 1, free);
  assert.equal(small.offer, undefined);
  const forced = await http('POST', `/api/driver/offers/${await forceOffer(small.id, free)}/accept`, { cookie: free.cookie, body: {} });
  assert.deepEqual([forced.status, forced.data.error], [409, 'exception_block']);
  await cancel(other, small.id);
  // partly paid → still blocked; fully paid (both sides) → free again
  await http('POST', '/api/driver/dues/pay', { cookie: free.cookie, body: { storeId: st.id, amount: 100 } });
  await http('POST', `/api/store/finance/drivers/${free.id}/received`, { cookie: st.cookie, body: { amount: 100 } });
  assert.deepEqual([(await pos(free)).owed, (await pos(free)).blocked], [20, 'exception_open']);
  await http('POST', '/api/driver/dues/pay', { cookie: free.cookie, body: { storeId: st.id } });
  await http('POST', `/api/store/finance/drivers/${free.id}/received`, { cookie: st.cookie, body: {} });
  assert.deepEqual([(await pos(free)).owed, (await pos(free)).blocked], [0, null]);
  // no exception to cover old debts: the owing driver can't get a 120 $ order even if he accepts
  const ex2 = await searching(st, 12, owing, { allowException: true });
  assert.equal(ex2.offer, undefined);
  const forced2 = await http('POST', `/api/driver/offers/${await forceOffer(ex2.id, owing)}/accept`, { cookie: owing.cookie, body: { exception: true } });
  assert.deepEqual([forced2.status, forced2.data.error], [409, 'cash_limit_reached']);
  await cancel(st, ex2.id);
  // the owner can switch the exception off
  await setS({ exceptionOn: 0 });
  const ex3 = await searching(st, 12, null, { allowException: true });
  assert.equal(ex3.search.data.error, 'over_driver_cap');
  await cancel(st, ex3.id);
  await setS({ exceptionOn: 1 });
  // cancelled before the obligation: no block left behind
  const ex4 = await searching(st, 12, free, { allowException: true });
  await http('POST', `/api/driver/offers/${ex4.offer.id}/accept`, { cookie: free.cookie, body: { exception: true } });
  assert.equal((await pos(free)).blocked, 'exception_open');
  await A('POST', `/api/admin/orders/${ex4.id}/cancel`, { reason: 'test' }).catch(() => {});
  await app.db.query(`UPDATE orders SET status = 'cancelled' WHERE id = $1`, [ex4.id]);
  assert.equal((await pos(free)).blocked, null);
});

test('two-sided confirmation: same amount → confirmed; different → review → the owner decides; no double confirmation', async () => {
  const st = await makeStore(36.30, 35.50, { price: 10 });
  const d = await makeDriver(36.301, 35.501);
  await deliver(d, st, 3); await deliver(d, st, 2);                     // two invoices: 30 + 20
  const inv = (await http('GET', '/api/driver/invoices', { cookie: d.cookie })).data.invoices;
  assert.deepEqual(inv.map((x) => [x.goods, x.deliveryFee, x.remaining, x.status]), [[30, 2, 30, 'open'], [20, 2, 20, 'open']]);
  assert.equal(inv[0].collected, 32, 'the delivery fee is kept apart from what is owed');
  // driver says 25, says it again (double tap) → once; a different amount → refused
  const a = await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id, amount: 25 } });
  assert.deepEqual([a.data.status, a.data.amount], ['pending', 25]);
  assert.equal((await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id, amount: 25 } })).data.again, true);
  assert.equal((await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id, amount: 40 } })).data.error, 'already_claimed');
  // the store says 20 → mismatch → review (nothing allocated)
  const b = await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: st.cookie, body: { amount: 20 } });
  assert.deepEqual([b.data.status, b.data.driver, b.data.store], ['review', 25, 20]);
  assert.equal((await pos(d)).owed, 50);
  assert.equal((await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id, amount: 20 } })).data.error, 'payment_in_review');
  const review = (await A('GET', '/api/admin/finance/payments?status=review')).data.payments.find((p) => p.driverId === d.id);
  assert.deepEqual([review.driverSays, review.storeSays], [25, 20]);
  assert.equal((await A('POST', `/api/admin/finance/payments/${review.id}/resolve`, { decision: 'confirm', amount: 60 })).status, 422, 'never more than owed');
  const r = await A('POST', `/api/admin/finance/payments/${review.id}/resolve`, { decision: 'confirm', amount: 20, note: 'checked with both' });
  assert.deepEqual([r.data.status, r.data.amount, r.data.left], ['confirmed', 20, 30]);
  assert.equal((await A('POST', `/api/admin/finance/payments/${review.id}/resolve`, { decision: 'confirm', amount: 20 })).status, 409, 'never twice');
  // partial: the first invoice (30) now has 20 paid
  const after = (await http('GET', '/api/driver/invoices', { cookie: d.cookie })).data.invoices;
  assert.deepEqual(after.map((x) => [x.remaining, x.status]), [[10, 'partial'], [20, 'open']]);
  // the rest, store first then driver: archive keeps both invoices
  await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: st.cookie, body: { amount: 30 } });
  const fin2 = await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id } });
  assert.deepEqual([fin2.data.status, fin2.data.amount, fin2.data.left], ['confirmed', 30, 0]);
  assert.equal((await http('GET', '/api/driver/invoices', { cookie: d.cookie })).data.invoices.length, 0);
  const arch = (await http('GET', '/api/store/invoices?state=archive', { cookie: st.cookie })).data.invoices;
  assert.deepEqual(arch.map((x) => x.status), ['settled', 'settled']);
  const det = (await http('GET', `/api/store/invoices/${arch[1].id}`, { cookie: st.cookie })).data.invoice;
  assert.deepEqual(det.payments.map((p) => p.amount), [20, 10]);
  // more than owed → nothing to settle / over-owed
  assert.equal((await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id, amount: 5 } })).data.error, 'nothing_to_settle');
});

test('two taps at the same moment: one payment record; two drivers on one offer: one winner; one driver on two offers: one job', async () => {
  const st = await makeStore(36.40, 35.50, { price: 10 });
  const d = await makeDriver(36.401, 35.501);
  const d2 = await makeDriver(36.4012, 35.501);
  await deliver(d, st, 2);
  const [p1, p2] = await Promise.all([1, 2].map(() => http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id, amount: 20 } })));
  assert.deepEqual([p1.status, p2.status], [200, 200]);
  assert.equal((await app.db.query(`SELECT id FROM due_payments WHERE driver_id = $1 AND status = 'pending'`, [d.id])).length, 1);
  await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: st.cookie, body: {} });
  const o = await searching(st, 1, d);
  const off2 = (await http('GET', '/api/driver/offers', { cookie: d2.cookie })).data.offers.find((x) => x.orderId === o.id);
  const both = await Promise.all([http('POST', `/api/driver/offers/${o.offer.id}/accept`, { cookie: d.cookie, body: {} }), http('POST', `/api/driver/offers/${off2.id}/accept`, { cookie: d2.cookie, body: {} })]);
  assert.equal(both.filter((r) => r.data.won).length, 1);
  assert.equal((await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM order_offers WHERE order_id = $1 AND status = $2', [o.id, 'won'])).n, 1);
  const winner = both[0].data.won ? d : d2;
  await finish(winner, o.id);
  const x = await searching(st, 1, null), y = await searching(st, 1, null);
  const fx = await forceOffer(x.id, d), fy = await forceOffer(y.id, d);
  const two = await Promise.all([http('POST', `/api/driver/offers/${fx}/accept`, { cookie: d.cookie, body: {} }), http('POST', `/api/driver/offers/${fy}/accept`, { cookie: d.cookie, body: {} })]);
  assert.equal(two.filter((r) => r.status === 200).length, 1, 'one job at a time');
});

test('owner pays the store for the driver (even 1 $): the driver is blocked from cash AND card until the owner confirms he paid back', async () => {
  const st = await makeStore(36.50, 35.50, { price: 40 });
  const d = await makeDriver(36.501, 35.501);
  await deliver(d, st, 1);                                               // owes 40 $
  assert.equal((await A('POST', '/api/admin/finance/pay-for-driver', { driverId: d.id, storeId: st.id, amount: 50 })).data.error, 'amount_over_owed');
  const paid = await A('POST', '/api/admin/finance/pay-for-driver', { driverId: d.id, storeId: st.id, amount: 15, method: 'whish', proof: 'WH-777', idem: 'k1' });
  assert.deepEqual([paid.status, paid.data.leftForStore, paid.data.driverOwesPlatform], [201, 25, 15]);
  const again = await A('POST', '/api/admin/finance/pay-for-driver', { driverId: d.id, storeId: st.id, amount: 15, method: 'whish', proof: 'WH-777', idem: 'k1' });
  assert.equal(again.data.replayed, true, 'the same request twice is done once');
  assert.equal((await A('GET', '/api/admin/finance/admin-debts')).data.debts.find((x) => x.driverId === d.id).amount, 15);
  // pays the store the rest himself (both sides) — he still owes the platform
  await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: st.id } });
  await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: st.cookie, body: {} });
  assert.deepEqual([(await pos(d)).owed, (await pos(d)).owesPlatform, (await pos(d)).blocked], [0, 15, 'admin_debt']);
  const small = await makeStore(36.51, 35.50, { price: 1 });
  const o = await searching(small, 1, d);
  assert.equal(o.offer, undefined, 'even a 1 $ order');
  const forced = await http('POST', `/api/driver/offers/${await forceOffer(o.id, d)}/accept`, { cookie: d.cookie, body: {} });
  assert.deepEqual([forced.status, forced.data.error, forced.data.amount], [409, 'admin_debt_block', 15]);
  await cancel(small, o.id);
  // a customer's direct request is blocked too
  assert.equal((await http('GET', '/api/driver/me', { cookie: d.cookie })).status, 200);
  // settles in two parts; more than owed is refused; the block lifts at zero
  assert.equal((await A('POST', `/api/admin/finance/drivers/${d.id}/settle-debt`, { amount: 20 })).data.error, 'amount_over_owed');
  assert.deepEqual((await A('POST', `/api/admin/finance/drivers/${d.id}/settle-debt`, { amount: 14, method: 'cash' })).data, { left: 1, unblocked: false });
  assert.equal((await pos(d)).blocked, 'admin_debt', '1 $ still blocks');
  assert.deepEqual((await A('POST', `/api/admin/finance/drivers/${d.id}/settle-debt`, { amount: 1 })).data, { left: 0, unblocked: true });
  assert.equal((await pos(d)).blocked, null);
  assert.equal((await A('POST', `/api/admin/finance/drivers/${d.id}/settle-debt`, { amount: 1 })).data.error, 'nothing_to_settle');
  // audit trail
  const acts = await app.db.query(`SELECT action FROM admin_actions WHERE action LIKE 'due_%'`);
  assert.ok(acts.some((a) => a.action === 'due_admin_paid_store') && acts.filter((a) => a.action === 'due_admin_debt_settled').length === 2);
});

test('complaints, reminders both ways (every 2 h), privacy between stores and drivers', async () => {
  const A1 = await makeStore(36.60, 35.50, { price: 10 }), B1 = await makeStore(36.601, 35.50, { price: 10 });
  const d = await makeDriver(36.6005, 35.501), d2 = await makeDriver(36.6006, 35.501);
  await deliver(d, A1, 2); await deliver(d2, B1, 1);
  const invA = (await http('GET', '/api/store/invoices', { cookie: A1.cookie })).data.invoices[0];
  const invB = (await http('GET', '/api/store/invoices', { cookie: B1.cookie })).data.invoices[0];
  // privacy
  assert.equal((await http('GET', `/api/store/invoices/${invB.id}`, { cookie: A1.cookie })).status, 404);
  assert.equal((await http('GET', `/api/driver/invoices/${invB.id}`, { cookie: d.cookie })).status, 404);
  assert.ok((await http('GET', '/api/store/invoices', { cookie: A1.cookie })).data.invoices.every((x) => x.storeId === A1.id));
  assert.equal((await http('GET', '/api/driver/invoices')).status, 401);
  // complaint (not on someone else's invoice, one open at a time, no automatic block)
  assert.equal((await http('POST', `/api/store/invoices/${invB.id}/complaint`, { cookie: A1.cookie, body: { body: 'لم يدفع حتى الآن' } })).status, 404);
  const c = await http('POST', `/api/store/invoices/${invA.id}/complaint`, { cookie: A1.cookie, body: { body: 'لم يدفع منذ أسبوع' } });
  assert.equal(c.status, 201);
  assert.equal((await http('POST', `/api/store/invoices/${invA.id}/complaint`, { cookie: A1.cookie, body: { body: 'مرة ثانية' } })).data.error, 'complaint_exists');
  assert.equal((await pos(d)).blocked, null, 'a complaint never blocks by itself');
  const file = (await A('GET', `/api/admin/finance/complaints/${c.data.id}`)).data;
  assert.ok(file.driver.phone.endsWith(d.phone));
  assert.ok(file.driver.documents.length >= 7 && file.driver.documents.every((x) => x.url.startsWith('/api/admin/')));
  assert.equal(file.invoice.remaining, 20);
  assert.equal((await http('GET', file.driver.documents[0].url, { cookie: A1.cookie })).status, 401, 'ID papers: the owner only');
  assert.equal((await A('POST', `/api/admin/finance/complaints/${c.data.id}/decision`, { status: 'resolved', decision: 'تم التواصل والدفع' })).status, 200);
  assert.deepEqual((await A('GET', `/api/admin/finance/complaints/${c.data.id}`)).data.log.map((x) => x.action), ['opened', 'resolved']);
  // reminders: store → driver; driver → store only when he said he paid; once per 2 hours
  assert.equal((await http('POST', `/api/store/finance/drivers/${d.id}/remind`, { cookie: A1.cookie, body: {} })).status, 200);
  assert.equal((await http('POST', `/api/store/finance/drivers/${d.id}/remind`, { cookie: A1.cookie, body: {} })).data.everyMin, 120);
  assert.equal((await http('POST', `/api/driver/dues/${A1.id}/remind`, { cookie: d.cookie, body: {} })).data.error, 'nothing_to_confirm');
  await http('POST', '/api/driver/dues/pay', { cookie: d.cookie, body: { storeId: A1.id } });
  pushed.length = 0;
  assert.equal((await http('POST', `/api/driver/dues/${A1.id}/remind`, { cookie: d.cookie, body: {} })).status, 200);
  assert.ok(pushed.some((p) => p.type === 'store' && p.id === A1.id && p.key === 'store_confirm_remind'));
  assert.equal((await http('POST', `/api/driver/dues/${A1.id}/remind`, { cookie: d.cookie, body: {} })).status, 429);
  // after it's paid, no reminder
  await http('POST', `/api/store/finance/drivers/${d.id}/received`, { cookie: A1.cookie, body: {} });
  await app.db.query(`DELETE FROM notif_log WHERE kind = 'store_remind'`);
  assert.equal((await http('POST', `/api/store/finance/drivers/${d.id}/remind`, { cookie: A1.cookie, body: {} })).data.error, 'nothing_to_settle');
});

test('delivery fee by ROAD distance store → customer with the owner\'s prices; no map → no invented price', async () => {
  const s = { feeBase: 1, feePerKm: 0.5, feeMin: 2, feeMax: 6, feeRound: 0.25 };
  assert.equal(feeForKm(1, s), 2);              // 1.5 → min 2
  assert.equal(feeForKm(4.3, s), 3.25);         // 3.15 → up to 3.25
  assert.equal(feeForKm(40, s), 6);             // max
  assert.equal(feeForKm(2, { ...s, feeMin: 0, feeTiers: [{ km: 3, price: 1.5 }, { km: 6, price: 2.5 }] }), 1.5);
  assert.equal(feeForKm(2, { ...s, feeTiers: [{ km: 3, price: 1.5 }] }), 2, 'the minimum still applies to a band');
  assert.equal(feeForKm(5, { ...s, feeMin: 0, feeTiers: [{ km: 3, price: 1.5 }, { km: 6, price: 2.5 }] }), 2.5);
  assert.equal((await setS({ feeTiers: [{ km: -1, price: 2 }] })).status, 422);
  // the map service is down (or gives only a straight-line guess): no price unless the owner allowed the estimate
  const down = { distance: async () => ({ m: 4000, approx: true }) };
  await assert.rejects(quoteFee(down, { ...s, roadFallback: 0 }, { lat: 33.9, lng: 35.5 }, { lat: 33.93, lng: 35.5 }), /route_unavailable/);
  await assert.rejects(quoteFee(null, { ...s, roadFallback: 0 }, { lat: 33.9, lng: 35.5 }, { lat: 33.93, lng: 35.5 }), /route_unavailable/);
  const est = await quoteFee(down, { ...s, roadFallback: 1 }, { lat: 33.9, lng: 35.5 }, { lat: 33.93, lng: 35.5 });
  assert.equal(est.approx, true, 'an estimate is marked as such');
  await setS({ feeMode: 1, feeBase: 1, feePerKm: 0.5, feeMin: 2, feeMax: 0, feeRound: 0.25, feeTiers: [] });
  const st = await makeStore(36.70, 35.50, { price: 10 });
  const to = { lat: 36.736, lng: 35.50 };                                 // ≈ 4 km straight, 4.8 km by "road"
  const qf = (await http('GET', `/api/delivery/quote?storeId=${st.id}&lat=${to.lat}&lng=${to.lng}`)).data;
  assert.deepEqual([qf.mode, qf.estimate, qf.fee], ['distance', false, 3.5]);   // 1 + 0.5 × 4.8 = 3.4 → 3.5
  const o = await http('POST', '/api/orders', { cookie: cust, body: { storeId: st.id, items: [{ id: st.item, qty: 1 }], ...to } });
  assert.deepEqual([o.data.deliveryFee, o.data.customerTotal], [3.5, 13.5], 'the fee is computed by the server and saved in the order');
  await setS({ feeMode: 0 });
});

test('drivers\' visibility: from the DRIVER to the STORE; the store\'s own radius first; stale GPS refused; widening step by step', async () => {
  await setS({ dispatchRadiusKm: 10, feeMode: 0 });
  const st = await makeStore(36.80, 35.50, { price: 5 });
  const near = await makeDriver(36.805, 35.50);                          // ≈ 0.6 km
  const mid = await makeDriver(36.83, 35.50);                            // ≈ 3.3 km
  assert.equal((await A('PUT', `/api/admin/stores/${st.id}/driver-radius`, { km: 2 })).status, 200);
  const o = await searching(st, 1, near);
  assert.ok(o.offer);
  assert.equal((await http('GET', '/api/driver/offers', { cookie: mid.cookie })).data.offers.some((x) => x.orderId === o.id), false, 'outside the store\'s 2 km');
  const forced = await http('POST', `/api/driver/offers/${await forceOffer(o.id, mid)}/accept`, { cookie: mid.cookie, body: {} });
  assert.deepEqual([forced.status, forced.data.error], [409, 'out_of_radius']);
  // stale GPS: refused even inside the radius
  await app.db.query(`UPDATE drivers SET loc_at = $1 WHERE id = $2`, [new Date(Date.now() - 3600_000).toISOString(), near.id]);
  const stale = await http('POST', `/api/driver/offers/${o.offer.id}/accept`, { cookie: near.cookie, body: {} });
  assert.deepEqual([stale.status, stale.data.error], [409, 'gps_stale']);
  await http('POST', '/api/driver/availability', { body: { available: true, lat: 36.805, lng: 35.50 }, cookie: near.cookie });
  await cancel(st, o.id);
  // widening: nobody near → after the steps the farther driver gets it (never past the maximum)
  await http('POST', '/api/driver/availability', { body: { available: false }, cookie: near.cookie });
  await setS({ expandOn: 1, expandStepKm: 2, expandMaxKm: 5, expandEverySec: 60 });
  const w = await searching(st, 1, mid);
  assert.equal(w.offer, undefined);
  await app.db.query(`UPDATE orders SET search_started_at = $1 WHERE id = $2`, [new Date(Date.now() - 125_000).toISOString(), w.id]);
  const { widenSearches } = await import('../src/services/delivery.js');
  const r = await widenSearches(app.db, (await A('GET', '/api/admin/delivery/settings')).data.settings);
  assert.equal(r.widened, 1);
  assert.equal((await app.db.one('SELECT radius_km FROM orders WHERE id = $1', [w.id])).radius_km, 5, '2 + 2 + 2 = 6 → capped at 5');
  const got = (await http('GET', '/api/driver/offers', { cookie: mid.cookie })).data.offers.find((x) => x.orderId === w.id);
  assert.ok(got, 'the farther driver gets it after widening');
  assert.equal((await http('POST', `/api/driver/offers/${got.id}/accept`, { cookie: mid.cookie, body: {} })).data.won, true);
  await setS({ expandOn: 0 });
});

test('card paid to the STORE: the store owes the driver his fee (no fake debt on the driver); the same "send" twice = one order', async () => {
  const st = await makeStore(36.90, 35.50, { price: 10 });
  const d = await makeDriver(36.901, 35.501);
  const o = await searching(st, 2, d);
  await http('POST', `/api/driver/offers/${o.offer.id}/accept`, { cookie: d.cookie, body: {} });
  await app.db.query(`UPDATE orders SET payment_method = 'card', payment_status = 'paid', paid_to = 'store' WHERE id = $1`, [o.id]);
  await finish(d, o.id);
  const e = await app.db.one('SELECT direction, due_cents FROM driver_cash_entries WHERE order_id = $1', [o.id]);
  assert.deepEqual([e.direction, e.due_cents], ['store_to_driver', 200]);
  assert.deepEqual([(await pos(d)).owed, (await pos(d)).exposure], [0, 0]);
  const body = { storeId: st.id, items: [{ id: st.item, qty: 1 }], lat: st.lat + 0.004, lng: st.lng, idem: 'tap-1' };
  const [x, y] = await Promise.all([http('POST', '/api/orders', { cookie: cust, body }), http('POST', '/api/orders', { cookie: cust, body })]);
  assert.equal(x.data.id, y.data.id);
  assert.equal((await http('POST', '/api/orders', { cookie: cust, body })).data.replayed, true);
});
