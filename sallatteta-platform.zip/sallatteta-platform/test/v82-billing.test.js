// v8.2 store-app subscriptions — Google Play (verify, RTDN, acknowledge, upgrades, refunds) and Apple (JWS + x5c chain).
// No network: Google is a fake fetch (it really checks our RS256 service-account JWT), Apple is a local test CA chain made
// here with node:crypto, trusted only through the test-only root fingerprint override (never an env var).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, createHash, sign, verify } from 'node:crypto';
import { createApp } from '../src/server.js';
import { oidDer, APPLE_LEAF_OID, APPLE_INTERMEDIATE_OID, GOOGLE_CERTS_URL, verifyAppleJws, APPLE_ROOT_G3_SHA256 } from '../src/services/billingCrypto.js';

const JPG = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDA==';
const DOCS = Object.fromEntries(['selfie', 'idFront', 'idBack', 'vehicleFront', 'vehicleBack', 'registration', 'criminalRecord'].map((k) => [k, JPG]));
const PKG = 'net.aklatak.app', BUNDLE = 'net.aklatak.ios', RTDN = 'rtdn-secret-1234567890', AUD = 'https://aklatak.test/api/billing/google/rtdn';
const DAY = 864e5;
const b64u = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');

/* ---------- fake Google ---------- */
const sa = generateKeyPairSync('rsa', { modulusLength: 2048 });
const SA_JSON = { type: 'service_account', client_email: 'play@aklatak-test.iam.gserviceaccount.com', private_key: sa.privateKey.export({ type: 'pkcs8', format: 'pem' }), token_uri: 'https://oauth2.googleapis.com/token' };
const oidc = generateKeyPairSync('rsa', { modulusLength: 2048 });
const OIDC_JWK = { ...oidc.publicKey.export({ format: 'jwk' }), kid: 'k1', alg: 'RS256', use: 'sig' };
const subs = new Map();       // purchase token → subscriptionsv2 answer
const oneTime = new Map();    // purchase token → products.get answer (the AI pack)
const consumed = [];
const acks = [];
let tokenCalls = 0, apiCalls = 0;
const reply = (status, body) => ({ ok: status < 300, status, json: async () => body, text: async () => JSON.stringify(body) });
async function fakeFetch(url, opts = {}) {
  url = String(url);
  if (url === 'https://oauth2.googleapis.com/token') {
    tokenCalls++;
    const assertion = new URLSearchParams(opts.body).get('assertion');
    const [h, p, s] = assertion.split('.');
    const claims = JSON.parse(Buffer.from(p, 'base64url').toString());
    const good = verify('RSA-SHA256', Buffer.from(`${h}.${p}`), sa.publicKey, Buffer.from(s, 'base64url'))
      && claims.iss === SA_JSON.client_email && claims.aud === 'https://oauth2.googleapis.com/token' && /androidpublisher/.test(claims.scope);
    return good ? reply(200, { access_token: 'ya29.test', expires_in: 3600, token_type: 'Bearer' }) : reply(400, { error: 'invalid_grant' });
  }
  if (url === GOOGLE_CERTS_URL) return reply(200, { keys: [OIDC_JWK] });
  if (opts.headers?.Authorization !== 'Bearer ya29.test') return reply(401, {});
  apiCalls++;
  const g = new RegExp(`/applications/${PKG}/purchases/subscriptionsv2/tokens/([^/]+)$`).exec(url);
  if (g) { const s = subs.get(decodeURIComponent(g[1])); return s ? reply(200, structuredClone(s)) : reply(404, { error: { code: 404 } }); }
  const op = new RegExp(`/applications/${PKG}/purchases/products/([^/]+)/tokens/([^/:]+)(:consume)?$`).exec(url);
  if (op) {
    const tok = decodeURIComponent(op[2]);
    const pr = oneTime.get(tok);
    if (!pr) return reply(404, { error: { code: 404 } });
    if (op[3]) { consumed.push(tok); pr.consumptionState = 1; return reply(200, {}); }
    return reply(200, structuredClone(pr));
  }
  const a = new RegExp(`/applications/${PKG}/purchases/subscriptions/([^/]+)/tokens/([^/]+):acknowledge$`).exec(url);
  if (a && opts.method === 'POST') {
    const tok = decodeURIComponent(a[2]);
    acks.push(tok);
    if (subs.get(tok)) subs.get(tok).acknowledgementState = 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED';
    return reply(200, {});
  }
  throw new Error(`unexpected network call ${url}`);
}
const gsub = (productId, { state = 'SUBSCRIPTION_STATE_ACTIVE', days = 30, order = 'GPA.1', linked, obf } = {}) => ({
  kind: 'androidpublisher#subscriptionPurchaseV2', subscriptionState: state, latestOrderId: order, regionCode: 'LB',
  acknowledgementState: 'ACKNOWLEDGEMENT_STATE_PENDING', ...(linked ? { linkedPurchaseToken: linked } : {}),
  ...(obf ? { externalAccountIdentifiers: { obfuscatedExternalAccountId: obf } } : {}),
  lineItems: [{ productId, expiryTime: new Date(Date.now() + days * DAY).toISOString(), autoRenewingPlan: { autoRenewEnabled: state === 'SUBSCRIPTION_STATE_ACTIVE' } }],
});
function oidcToken(claims = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u({ alg: 'RS256', kid: 'k1', typ: 'JWT' }), p = b64u({ iss: 'https://accounts.google.com', aud: AUD, iat: now, exp: now + 3600, email: 'pubsub@x.iam.gserviceaccount.com', email_verified: true, ...claims });
  return `${h}.${p}.${sign('RSA-SHA256', Buffer.from(`${h}.${p}`), oidc.privateKey).toString('base64url')}`;
}

/* ---------- local test CA (DER written by hand; node:crypto signs) ---------- */
const derLen = (n) => (n < 128 ? Buffer.from([n]) : n < 256 ? Buffer.from([0x81, n]) : Buffer.from([0x82, n >> 8, n & 255]));
const tlv = (tag, ...parts) => { const b = Buffer.concat(parts); return Buffer.concat([Buffer.from([tag]), derLen(b.length), b]); };
const seq = (...p) => tlv(0x30, ...p);
const TRUE = tlv(0x01, Buffer.from([0xff]));
const utc = (d) => tlv(0x17, Buffer.from(`${d.toISOString().replace(/[-:T]/g, '').slice(2, 14)}Z`));
const name = (cn) => seq(tlv(0x31, seq(oidDer('2.5.4.3'), tlv(0x0c, Buffer.from(cn)))));
const ECDSA_SHA256 = seq(oidDer('1.2.840.10045.4.3.2'));
let serial = 1;
function makeCert({ cn, issuer, pub, signer, ca, marker, from = Date.now() - DAY, to = Date.now() + 365 * DAY }) {
  const exts = [seq(oidDer('2.5.29.19'), TRUE, tlv(0x04, ca ? seq(TRUE) : seq()))];
  if (marker) exts.push(seq(oidDer(marker), tlv(0x04, Buffer.from([0x05, 0x00]))));
  const tbs = seq(tlv(0xa0, tlv(0x02, Buffer.from([2]))), tlv(0x02, Buffer.from([serial++])), ECDSA_SHA256, name(issuer), seq(utc(new Date(from)), utc(new Date(to))),
    name(cn), pub.export({ type: 'spki', format: 'der' }), tlv(0xa3, seq(...exts)));
  return seq(tbs, ECDSA_SHA256, tlv(0x03, Buffer.from([0]), sign('sha256', tbs, signer)));
}
function makeChain({ leafTo } = {}) {
  const ec = () => generateKeyPairSync('ec', { namedCurve: 'P-256' });
  const r = ec(), i = ec(), l = ec();
  const root = makeCert({ cn: 'Test Root CA - G3', issuer: 'Test Root CA - G3', pub: r.publicKey, signer: r.privateKey, ca: true });
  const inter = makeCert({ cn: 'Test WWDR', issuer: 'Test Root CA - G3', pub: i.publicKey, signer: r.privateKey, ca: true, marker: APPLE_INTERMEDIATE_OID });
  const leaf = makeCert({ cn: 'Test App Store Signing', issuer: 'Test WWDR', pub: l.publicKey, signer: i.privateKey, ca: false, marker: APPLE_LEAF_OID, ...(leafTo ? { to: leafTo } : {}) });
  return { key: l.privateKey, x5c: [leaf, inter, root].map((c) => c.toString('base64')), fp: createHash('sha256').update(root).digest('hex') };
}
const chain = makeChain();
const otherChain = makeChain();   // a valid-looking chain to a root we do NOT trust
const jws = (payload, c = chain) => {
  const h = b64u({ alg: 'ES256', x5c: c.x5c }), p = b64u(payload);
  return `${h}.${p}.${sign('sha256', Buffer.from(`${h}.${p}`), { key: c.key, dsaEncoding: 'ieee-p1363' }).toString('base64url')}`;
};
const appleTx = (o) => ({ bundleId: BUNDLE, environment: 'Production', type: 'Auto-Renewable Subscription', transactionId: String(o.originalTransactionId), expiresDate: Date.now() + 30 * DAY, purchaseDate: Date.now(), ...o });
let nUuid = 0;
const appleNote = (type, tx, { subtype, renewal, uuid = `uuid-${++nUuid}`, bundleId = BUNDLE, c = chain } = {}) => ({
  signedPayload: jws({ notificationType: type, subtype, notificationUUID: uuid, version: '2.0', signedDate: Date.now(),
    data: { bundleId, environment: 'Production', appAppleId: 1, signedTransactionInfo: tx ? jws(tx, c) : undefined, signedRenewalInfo: renewal ? jws(renewal, c) : undefined } }, c),
});

/* ---------- app ---------- */
const ENV = {
  GOOGLE_PLAY_PACKAGE: PKG, GOOGLE_PLAY_SERVICE_ACCOUNT_JSON: Buffer.from(JSON.stringify(SA_JSON)).toString('base64'),   // base64 form
  GOOGLE_RTDN_TOKEN: RTDN, APPLE_BUNDLE_ID: BUNDLE, APPLE_ENVIRONMENT: 'Production',
};
let app, base, admin, areaId;
async function http(method, path, { body, cookie, headers = {} } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, text };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
let sn = 0;
async function makeStore(kind = 'restaurant') {
  const wa = `+9617180${String(1000 + sn++).padStart(4, '0')}`;
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل ' + sn, whatsapp: wa, areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind, lat: 33.85, lng: 35.9, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  return { id: r.data.id, cookie: await login('/api/cook/login', { whatsapp: wa, password: pw }) };
}
let dn = 0;
async function makeDriver() {
  const phone = `7191${String(1000 + dn++).padStart(4, '0')}`;
  const r = await http('POST', '/api/driver/apply', { body: { fullName: 'سائق ' + phone.slice(-3), phone, password: 'pass123', vehicle: 'moto', walletProvider: 'whish', walletNumber: `7167${phone.slice(-4)}`, acceptTerms: true, adult: true, birthDate: '1990-01-01', docs: DOCS, jobsMonths: 1 } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  await A('POST', `/api/admin/drivers/${r.data.id}/status`, { status: 'active' });
  return { id: r.data.id, cookie: await login('/api/driver/login', { phone, password: 'pass123' }) };
}
const verifyG = (st, productId, purchaseToken) => http('POST', '/api/billing/google/verify', { cookie: st.cookie, body: { productId, purchaseToken } });
let msgN = 0;
async function rtdn(payload, { id = `msg-${++msgN}`, token = RTDN, bearer } = {}) {
  const body = { message: { data: Buffer.from(JSON.stringify({ version: '1.0', packageName: PKG, eventTimeMillis: String(Date.now()), ...payload })).toString('base64'), messageId: id, publishTime: new Date().toISOString() }, subscription: 'projects/p/subscriptions/s' };
  const res = await fetch(`${base}/api/billing/google/rtdn?token=${encodeURIComponent(token)}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}) }, body: JSON.stringify(body) });
  return { status: res.status, data: await res.json() };
}
const subNote = (purchaseToken, type, subscriptionId = 'x') => ({ subscriptionNotification: { version: '1.0', notificationType: type, purchaseToken, subscriptionId } });
const cook = (id) => app.db.one('SELECT ai_until FROM cooks WHERE id = $1', [id]);
const sub = (id) => app.db.one('SELECT status, expiry_date, tier FROM subscriptions WHERE cook_id = $1 ORDER BY id DESC LIMIT 1', [id]);
const ent = (token) => app.db.one('SELECT * FROM billing_entitlements WHERE purchase_token = $1', [token]);
const days = (isoStr) => (Date.parse(isoStr) - Date.now()) / DAY;
const appleNotify = (b) => http('POST', '/api/billing/apple/notify', { body: b });

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    push: { notify: () => {}, notifyAdmins: () => {}, subscribe: async () => {}, publicKey: async () => 'k' },
    billing: { env: ENV, fetch: fakeFetch, appleRootFingerprints: [chain.fp] },
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
});
after(() => app?.close?.());

test('not configured → 503 billing_not_configured, nothing breaks', async () => {
  const st = await makeStore();
  const saved = { ...ENV };
  for (const k of Object.keys(ENV)) delete ENV[k];
  try {
    assert.equal((await verifyG(st, 'aklatak.shop.ai.monthly', 'tok-unconfigured-1')).data.error, 'billing_not_configured');
    assert.equal((await verifyG(st, 'aklatak.shop.ai.monthly', 'tok-unconfigured-1')).status, 503);
    assert.equal((await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.ai.monthly', { cookie: st.cookie })).status, 503);
    assert.equal((await rtdn(subNote('tok-unconfigured-1', 4))).status, 503);
    assert.equal((await appleNotify({ signedPayload: 'x.y.z' })).status, 503);
    const p = await http('GET', '/api/billing/products', { cookie: st.cookie });
    assert.equal(p.status, 200);
    assert.deepEqual([p.data.google, p.data.apple], [false, false]);
    const cfg = (await A('GET', '/api/admin/billing/config')).data;
    assert.deepEqual([cfg.google, cfg.apple, cfg.env.GOOGLE_PLAY_PACKAGE], [false, false, false]);
  } finally { Object.assign(ENV, saved); }
  assert.equal(apiCalls, 0, 'Google never called while not configured');
});

test('products for this account only; prepare gives a stable opaque id', async () => {
  const st = await makeStore();
  const p = (await http('GET', '/api/billing/products', { cookie: st.cookie })).data;
  assert.equal(p.google, true);
  // v8.2: the main account's plans + the AI pack (branch plans are offered to branches only)
  assert.deepEqual(p.products.map((x) => x.productId).sort(), ['aklatak.shop.ai.monthly', 'aklatak.shop.aipack', 'aklatak.shop.basic.monthly']);
  const a1 = (await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.ai.monthly', { cookie: st.cookie })).data.accountId;
  const a2 = (await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.basic.monthly', { cookie: st.cookie })).data.accountId;
  assert.match(a1, /^[0-9a-f-]{36}$/);
  assert.equal(a1, a2);
  assert.equal((await http('GET', '/api/billing/google/prepare?productId=aklatak.driver.ai.monthly', { cookie: st.cookie })).data.error, 'product_not_for_account');
  assert.equal((await http('GET', '/api/billing/products')).status, 401, 'no account → no plans');
});

let shopA;
test('purchase verify → AI granted (after asking Google), then acknowledged once; access token cached', async () => {
  shopA = await makeStore();
  subs.set('tokA-purchase-0001', gsub('aklatak.shop.ai.monthly'));
  const r = await verifyG(shopA, 'aklatak.shop.ai.monthly', 'tokA-purchase-0001');
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.granted, true);
  assert.equal(r.data.entitlement.state, 'active');
  assert.ok(Math.abs(days((await cook(shopA.id)).ai_until) - 30) < 0.01, 'AI until Google\'s expiry');
  assert.equal((await sub(shopA.id)).tier, 'ai');
  assert.deepEqual(acks, ['tokA-purchase-0001']);
  assert.equal(Number((await ent('tokA-purchase-0001')).acknowledged), 1);
  // the same call again: nothing new, no second acknowledge
  assert.equal((await verifyG(shopA, 'aklatak.shop.ai.monthly', 'tokA-purchase-0001')).status, 200);
  assert.deepEqual(acks, ['tokA-purchase-0001']);
  assert.equal(tokenCalls, 1, 'one OAuth token for all calls (cached)');
  const me = (await http('GET', '/api/billing/me', { cookie: shopA.cookie })).data;
  assert.equal(me.entitlements.length, 1);
  assert.equal(me.entitlements[0].tier, 'ai');
});

test('a token bound to another account → 409; a store can never verify for another store', async () => {
  const shopB = await makeStore();
  const before1 = await cook(shopB.id);
  const r = await verifyG(shopB, 'aklatak.shop.ai.monthly', 'tokA-purchase-0001');
  assert.equal(r.status, 409);
  assert.equal(r.data.error, 'purchase_belongs_to_another_account');
  assert.deepEqual(await cook(shopB.id), before1, 'B got nothing');
  assert.equal(Number((await ent('tokA-purchase-0001')).owner_id), shopA.id, 'still A\'s');
  // Google says the purchase was made for A's opaque id: B can't claim it even first
  const accA = (await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.ai.monthly', { cookie: shopA.cookie })).data.accountId;
  subs.set('tokA-obf-0002', gsub('aklatak.shop.ai.monthly', { obf: accA }));
  assert.equal((await verifyG(shopB, 'aklatak.shop.ai.monthly', 'tokA-obf-0002')).status, 409);
  assert.equal(await ent('tokA-obf-0002'), null, 'nothing recorded');
  // product of another group / another kind of account
  const craft = await makeStore('electrician');
  subs.set('tok-craft-0003', gsub('aklatak.shop.basic.monthly'));
  assert.equal((await verifyG(craft, 'aklatak.shop.basic.monthly', 'tok-craft-0003')).data.error, 'product_not_for_account');
  const d = await makeDriver();
  assert.equal((await verifyG(d, 'aklatak.shop.basic.monthly', 'tok-craft-0003')).status, 403);
  // a product id that is not the one Google has for this token
  assert.equal((await verifyG(shopB, 'aklatak.shop.basic.monthly', 'tokA-obf-0002')).data.error, 'product_mismatch');
});

test('client claims without verification → nothing granted', async () => {
  const st = await makeStore();
  const r = await verifyG(st, 'aklatak.shop.ai.monthly', 'tok-made-up-by-client-9999');
  assert.equal(r.status, 400);
  assert.equal(r.data.error, 'invalid_purchase_token');
  assert.equal((await cook(st.id)).ai_until, null);
  // a pending purchase (payment not done yet): recorded, but no access and no acknowledge
  subs.set('tok-pending-0004', gsub('aklatak.shop.ai.monthly', { state: 'SUBSCRIPTION_STATE_PENDING' }));
  const p = await verifyG(st, 'aklatak.shop.ai.monthly', 'tok-pending-0004');
  assert.equal(p.data.granted, false);
  assert.equal((await cook(st.id)).ai_until, null);
  assert.ok(!acks.includes('tok-pending-0004'));
  // nothing in the API lets the client set its own dates
  assert.equal((await http('POST', '/api/billing/google/verify', { cookie: st.cookie, body: { productId: 'aklatak.shop.ai.monthly', purchaseToken: 'x' } })).status, 422);
  assert.equal((await http('POST', '/api/billing/google/verify', { body: { productId: 'aklatak.shop.ai.monthly', purchaseToken: 'tokA-purchase-0001' } })).status, 401);
});

test('RTDN: wrong secret → 401; renewal extends; the same message twice is processed once', async () => {
  assert.equal((await rtdn(subNote('tokA-purchase-0001', 2), { token: 'wrong-secret-1234567890' })).status, 401);
  const s = subs.get('tokA-purchase-0001');
  s.lineItems[0].expiryTime = new Date(Date.now() + 60 * DAY).toISOString();
  s.latestOrderId = 'GPA.1..0';
  const calls = apiCalls;
  const r1 = await rtdn(subNote('tokA-purchase-0001', 2), { id: 'dup-1' });
  assert.deepEqual([r1.status, r1.data.duplicate], [200, false]);
  const r2 = await rtdn(subNote('tokA-purchase-0001', 2), { id: 'dup-1' });
  assert.deepEqual([r2.status, r2.data.duplicate], [200, true]);
  assert.equal(apiCalls, calls + 1, 'Google asked once');
  assert.equal((await app.db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM billing_events WHERE event_id = 'dup-1'`)).n, 1);
  assert.ok(Math.abs(days((await cook(shopA.id)).ai_until) - 60) < 0.01);
  assert.ok(Math.abs(days((await sub(shopA.id)).expiry_date) - 60) < 0.01, 'store subscription extended too');
  // other package / test notification: acknowledged (200) and ignored
  assert.equal((await rtdn({ testNotification: { version: '1.0' } })).status, 200);
});

test('RTDN: grace keeps access until the grace end; account hold gives nothing more', async () => {
  const s = subs.get('tokA-purchase-0001');
  s.subscriptionState = 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD';
  s.lineItems[0].expiryTime = new Date(Date.now() + 63 * DAY).toISOString();
  await rtdn(subNote('tokA-purchase-0001', 6));
  assert.equal((await ent('tokA-purchase-0001')).state, 'grace');
  const ai = (await cook(shopA.id)).ai_until;
  assert.ok(Math.abs(days(ai) - 63) < 0.01);
  s.subscriptionState = 'SUBSCRIPTION_STATE_ON_HOLD';
  s.lineItems[0].expiryTime = new Date(Date.now() - DAY).toISOString();
  await rtdn(subNote('tokA-purchase-0001', 5));
  assert.equal((await ent('tokA-purchase-0001')).state, 'on_hold');
  assert.equal((await cook(shopA.id)).ai_until, ai, 'nothing extended on hold');
  // recovered
  s.subscriptionState = 'SUBSCRIPTION_STATE_ACTIVE';
  s.lineItems[0].expiryTime = new Date(Date.now() + 70 * DAY).toISOString();
  await rtdn(subNote('tokA-purchase-0001', 1));
  assert.ok(Math.abs(days((await cook(shopA.id)).ai_until) - 70) < 0.01);
});

test('refund (voided purchase) → access taken back at once; REVOKED notification too', async () => {
  const st = await makeStore();
  // the store had no paid time of its own: its subscription ran out
  await app.db.query(`UPDATE subscriptions SET status = 'expired', expiry_date = $1 WHERE cook_id = $2`, [new Date(Date.now() - DAY).toISOString(), st.id]);
  subs.set('tok-refund-0005', gsub('aklatak.shop.ai.monthly'));
  assert.equal((await verifyG(st, 'aklatak.shop.ai.monthly', 'tok-refund-0005')).data.granted, true);
  assert.equal((await sub(st.id)).status, 'active');
  const r = await rtdn({ voidedPurchaseNotification: { purchaseToken: 'tok-refund-0005', orderId: 'GPA.9', productType: 1, refundType: 1 } });
  assert.equal(r.status, 200);
  const e = await ent('tok-refund-0005');
  assert.deepEqual([e.state, e.reason], ['refunded', 'voided']);
  assert.ok(days((await cook(st.id)).ai_until) <= 0, 'AI cut to now');
  const s = await sub(st.id);
  assert.ok(days(s.expiry_date) <= 0);
  assert.equal(s.status, 'expired');
  const log = await app.db.one(`SELECT details FROM admin_actions WHERE cook_id = $1 AND action = 'billing_revoke'`, [st.id]);
  assert.match(log.details, /voided/);
  // a later "active" answer from Google never brings a refunded purchase back by itself
  await rtdn(subNote('tok-refund-0005', 2));
  assert.equal((await ent('tok-refund-0005')).state, 'refunded');
  assert.ok(days((await cook(st.id)).ai_until) <= 0);

  // REVOKED (type 12) on a store that ALSO paid the owner by hand: only the store-app part is taken back
  const st2 = await makeStore();
  const own = (await sub(st2.id)).expiry_date;   // its own paid month
  subs.set('tok-revoke-0006', gsub('aklatak.shop.ai.monthly', { days: 90 }));
  await verifyG(st2, 'aklatak.shop.ai.monthly', 'tok-revoke-0006');
  assert.ok(days((await sub(st2.id)).expiry_date) > 89);
  await rtdn(subNote('tok-revoke-0006', 12));
  assert.equal((await ent('tok-revoke-0006')).state, 'revoked');
  assert.equal(new Date((await sub(st2.id)).expiry_date).toISOString(), new Date(own).toISOString(), 'back to its own paid end, not to now');
  assert.ok(days((await cook(st2.id)).ai_until) <= 0);
});

test('upgrade: the new token (linkedPurchaseToken) gives its time, the old purchase ends', async () => {
  const st = await makeStore();
  await app.db.query(`UPDATE subscriptions SET status = 'expired', expiry_date = $1 WHERE cook_id = $2`, [new Date(Date.now() - DAY).toISOString(), st.id]);
  subs.set('tok-basic-0007', gsub('aklatak.shop.basic.monthly', { days: 30 }));
  await verifyG(st, 'aklatak.shop.basic.monthly', 'tok-basic-0007');
  assert.equal((await cook(st.id)).ai_until, null);
  assert.equal((await sub(st.id)).tier, 'basic');
  subs.set('tok-ai-0008', gsub('aklatak.shop.ai.monthly', { days: 20, linked: 'tok-basic-0007', order: 'GPA.20' }));
  const r = await verifyG(st, 'aklatak.shop.ai.monthly', 'tok-ai-0008');
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const old = await ent('tok-basic-0007');
  assert.deepEqual([old.state, old.reason], ['expired', 'replaced']);
  assert.ok(Math.abs(days((await cook(st.id)).ai_until) - 20) < 0.01);
  assert.ok(Math.abs(days((await sub(st.id)).expiry_date) - 20) < 0.01, 'old 30 days replaced by the new 20');
  assert.equal((await sub(st.id)).tier, 'ai');
  // an RTDN for the new token alone (unknown owner) would still find the account through the linked token
  subs.set('tok-ai-0009', gsub('aklatak.shop.ai.monthly', { days: 40, linked: 'tok-ai-0008', order: 'GPA.30' }));
  await rtdn(subNote('tok-ai-0009', 4));
  assert.equal(Number((await ent('tok-ai-0009')).owner_id), st.id);
  assert.equal((await ent('tok-ai-0008')).reason, 'replaced');
  assert.ok(Math.abs(days((await cook(st.id)).ai_until) - 40) < 0.01);
});

test('RTDN signed by Google (OIDC) when GOOGLE_RTDN_AUDIENCE is set', async () => {
  ENV.GOOGLE_RTDN_AUDIENCE = AUD;
  try {
    assert.equal((await rtdn({ testNotification: {} })).status, 401, 'no Google signature');
    assert.equal((await rtdn({ testNotification: {} }, { bearer: oidcToken({ aud: 'https://evil.example' }) })).status, 401);
    assert.equal((await rtdn({ testNotification: {} }, { bearer: oidcToken({ exp: Math.floor(Date.now() / 1000) - 3600 }) })).status, 401);
    const forged = oidcToken().split('.'); forged[1] = b64u({ iss: 'https://accounts.google.com', aud: AUD, exp: 9e9 });
    assert.equal((await rtdn({ testNotification: {} }, { bearer: forged.join('.') })).status, 401);
    assert.equal((await rtdn({ testNotification: {} }, { bearer: oidcToken() })).status, 200);
  } finally { delete ENV.GOOGLE_RTDN_AUDIENCE; }
});

let drv, drvAcc;
test('Apple: valid chain → granted (driver AI + customer-requests plan)', async () => {
  drv = await makeDriver();
  drvAcc = (await http('GET', '/api/billing/apple/prepare?productId=aklatak.driver.ai.monthly', { cookie: drv.cookie })).data.accountId;
  const tx = appleTx({ productId: 'aklatak.driver.ai.monthly', originalTransactionId: '2000001', appAccountToken: drvAcc });
  const r = await appleNotify(appleNote('SUBSCRIBED', tx, { subtype: 'INITIAL_BUY', uuid: 'apple-n1', renewal: { autoRenewStatus: 1, originalTransactionId: '2000001' } }));
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const d = await app.db.one('SELECT ai_until, jobs_until FROM drivers WHERE id = $1', [drv.id]);
  assert.ok(Math.abs(days(d.ai_until) - 30) < 0.01);
  assert.ok(Math.abs(days(d.jobs_until) - 30) < 0.01);
  // the client path with the same signed transaction (idempotent)
  const v = await http('POST', '/api/billing/apple/verify', { cookie: drv.cookie, body: { signedTransaction: jws(tx) } });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  assert.equal(v.data.granted, true);
  // the real Apple root is the only one trusted without the test override
  assert.throws(() => verifyAppleJws(jws(tx), { rootFingerprints: [APPLE_ROOT_G3_SHA256] }), /untrusted_root/);
});

test('Apple: tampered signature / untrusted root / expired cert → 401; wrong bundle → 400', async () => {
  const tx = appleTx({ productId: 'aklatak.driver.ai.monthly', originalTransactionId: '2000002', appAccountToken: drvAcc });
  const good = appleNote('SUBSCRIBED', tx).signedPayload.split('.');
  const p = JSON.parse(Buffer.from(good[1], 'base64url').toString());
  p.notificationUUID = 'tampered-1';
  const tampered = [good[0], b64u(p), good[2]].join('.');
  assert.equal((await appleNotify({ signedPayload: tampered })).status, 401);
  assert.equal((await appleNotify(appleNote('SUBSCRIBED', tx, { c: otherChain }))).status, 401, 'chain to an unknown root');
  const old = makeChain({ leafTo: Date.now() - 1000 });
  assert.throws(() => verifyAppleJws(jws(tx, old), { rootFingerprints: [old.fp] }), /cert_expired/);
  // the leaf must be signed by the intermediate: swap in another chain's leaf
  const mixed = { key: otherChain.key, x5c: [otherChain.x5c[0], chain.x5c[1], chain.x5c[2]] };
  assert.equal((await appleNotify(appleNote('SUBSCRIBED', tx, { c: mixed }))).status, 401);
  assert.equal((await appleNotify(appleNote('SUBSCRIBED', tx, { bundleId: 'com.someone.else' }))).status, 400);
  const otherBundleTx = { ...tx, bundleId: 'com.someone.else' };
  assert.equal((await http('POST', '/api/billing/apple/verify', { cookie: drv.cookie, body: { signedTransaction: jws(otherBundleTx) } })).data.error, 'wrong_bundle');
  assert.equal(await app.db.one(`SELECT id FROM billing_entitlements WHERE original_transaction_id = '2000002'`), null, 'nothing recorded');
});

test('Apple: duplicate notificationUUID → once; grace; refund takes it back; another account can\'t claim it', async () => {
  const tx = appleTx({ productId: 'aklatak.driver.ai.monthly', originalTransactionId: '2000001', appAccountToken: drvAcc, expiresDate: Date.now() + 45 * DAY, transactionId: '2000009' });
  const note = appleNote('DID_RENEW', tx, { uuid: 'apple-renew-1' });
  assert.equal((await appleNotify(note)).data.duplicate, false);
  assert.equal((await appleNotify(note)).data.duplicate, true);
  assert.equal((await app.db.one(`SELECT CAST(COUNT(*) AS INTEGER) AS n FROM billing_events WHERE event_id = 'apple-renew-1'`)).n, 1);
  assert.ok(Math.abs(days((await app.db.one('SELECT ai_until FROM drivers WHERE id = $1', [drv.id])).ai_until) - 45) < 0.01);
  await appleNotify(appleNote('DID_FAIL_TO_RENEW', tx, { subtype: 'GRACE_PERIOD', renewal: { autoRenewStatus: 1, gracePeriodExpiresDate: Date.now() + 50 * DAY } }));
  assert.equal((await app.db.one(`SELECT state FROM billing_entitlements WHERE original_transaction_id = '2000001'`)).state, 'grace');
  assert.ok(Math.abs(days((await app.db.one('SELECT ai_until FROM drivers WHERE id = $1', [drv.id])).ai_until) - 50) < 0.01);
  // another driver can't verify this purchase
  const d2 = await makeDriver();
  assert.equal((await http('POST', '/api/billing/apple/verify', { cookie: d2.cookie, body: { signedTransaction: jws(tx) } })).status, 409);
  await appleNotify(appleNote('REFUND', { ...tx, revocationDate: Date.now(), revocationReason: 0 }));
  const row = await app.db.one(`SELECT state FROM billing_entitlements WHERE original_transaction_id = '2000001'`);
  assert.equal(row.state, 'refunded');
  const d = await app.db.one('SELECT ai_until, jobs_until FROM drivers WHERE id = $1', [drv.id]);
  assert.ok(days(d.ai_until) <= 0 && days(d.jobs_until) <= 0);
});

test('admin: config shows which vars are set (never values), mapping editor, lists with filters', async () => {
  const c = await A('GET', '/api/admin/billing/config');
  assert.equal(c.status, 200);
  assert.equal(c.data.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON, 'ok');
  assert.equal(c.data.env.GOOGLE_RTDN_TOKEN, true);
  for (const secret of [RTDN, PKG, BUNDLE, SA_JSON.client_email, ENV.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON.slice(0, 30)]) assert.ok(!c.text.includes(secret), 'no values');
  const products = { ...c.data.products, 'aklatak.shop.ai.yearly': { subject: 'store', group: 'shops', tier: 'ai', months: 12 } };
  assert.equal((await A('PUT', '/api/admin/billing/products', { products: { ...products, 'BAD id': { subject: 'store', group: 'shops', tier: 'ai', months: 1 } } })).status, 422);
  assert.equal((await A('PUT', '/api/admin/billing/products', { products: { x1: { subject: 'driver', group: 'shops', tier: 'ai', months: 1 } } })).status, 422);
  assert.equal((await A('PUT', '/api/admin/billing/products', { products })).status, 200);
  const st = await makeStore();
  assert.ok((await http('GET', '/api/billing/products', { cookie: st.cookie })).data.products.some((x) => x.productId === 'aklatak.shop.ai.yearly' && x.months === 12));
  const list = (await A('GET', '/api/admin/billing/entitlements?state=refunded')).data.entitlements;
  assert.ok(list.length >= 2 && list.every((e) => e.state === 'refunded'));
  assert.ok((await A('GET', '/api/admin/billing/entitlements?platform=apple')).data.entitlements.every((e) => e.platform === 'apple'));
  assert.ok((await A('GET', '/api/admin/billing/events')).data.events.length > 5);
  assert.equal((await http('GET', '/api/admin/billing/config', { cookie: st.cookie })).status, 401, 'owner only');
  assert.ok(await app.db.one(`SELECT id FROM admin_actions WHERE action = 'billing_products'`));
  const id = (await ent('tokA-purchase-0001')).id;
  const rs = await A('POST', `/api/admin/billing/entitlements/${id}/resync`, {});
  assert.deepEqual([rs.status, rs.data.state], [200, 'active']);
});

test('tenant isolation: /me shows only the caller\'s own purchases', async () => {
  const me = (await http('GET', '/api/billing/me', { cookie: drv.cookie })).data;
  assert.ok(me.entitlements.every((e) => e.platform === 'apple'));
  assert.equal(me.entitlements.length, 1);
  const st = await makeStore();
  assert.deepEqual((await http('GET', '/api/billing/me', { cookie: st.cookie })).data.entitlements, []);
});


/* ---------------- v8.2: everything through Google Play (owner's decision, 12 Oct 2026) ---------------- */

const branchOf = async (st, name) => {
  const b = await http('POST', '/api/store/branches', { cookie: st.cookie, body: { name, lat: 33.86, lng: 35.91 } });
  assert.equal(b.status, 201, JSON.stringify(b.data));
  // the main account opens the branch's own account (same phone)
  const res = await fetch(`${base}/api/store/branches/${b.data.id}/switch`, { method: 'POST', headers: { 'X-Requested-With': 'fetch', Cookie: st.cookie } });
  return { id: b.data.id, cookie: res.headers.get('set-cookie').split(';')[0] };
};
const visible = async (id) => (await http('GET', `/api/delivery/stores/${id}`)).status === 200;

test('Google Play only: the receipt forms are closed for subscribers (renewal, branch, AI pack); the owner can reopen them', async () => {
  const st = await makeStore();
  const r = await http('POST', '/api/store/renewals', { cookie: st.cookie, body: { kind: 'basic', months: 1, method: 'whish', receipt: JPG } });
  assert.deepEqual([r.status, r.data.error], [409, 'google_play_only']);
  const sub0 = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.equal(sub0.googleOnly, true);
  assert.equal((await A('PUT', '/api/admin/settings', { googleOnly: 'yes' })).status, 422);
});

test('a branch pays its own Google Play plan from its own account: live until then, hidden when it ends; the main plans are not offered there', async () => {
  const st = await makeStore();
  subs.set('tok-main-basic-0001', gsub('aklatak.shop.basic.monthly'));
  assert.equal((await verifyG(st, 'aklatak.shop.basic.monthly', 'tok-main-basic-0001')).status, 200);
  assert.equal((await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.branch.monthly', { cookie: st.cookie })).data.error, 'product_not_for_account', 'not from the main account');
  const accM = (await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.basic.monthly', { cookie: st.cookie })).data.accountId;
  const br = await branchOf(st, 'فرع الكرك');   // (the phone is now in the branch's account)
  assert.equal(await visible(br.id), false, 'pending until paid');
  const list = (await http('GET', '/api/billing/products', { cookie: br.cookie })).data.products.map((x) => x.productId).sort();
  assert.deepEqual(list, ['aklatak.shop.aipack', 'aklatak.shop.branch.monthly', 'aklatak.shop.branchai.monthly']);
  const accB = (await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.branch.monthly', { cookie: br.cookie })).data.accountId;
  assert.notEqual(accB, accM, 'the branch is its own buyer');
  subs.set('tok-branch-0001', gsub('aklatak.shop.branch.monthly', { obf: accB }));
  const v = await verifyG(br, 'aklatak.shop.branch.monthly', 'tok-branch-0001');
  assert.equal(v.status, 200, JSON.stringify(v.data));
  const c = await app.db.one('SELECT status, branch_until, ai_until FROM cooks WHERE id = $1', [br.id]);
  assert.equal(c.status, 'approved'); assert.ok(days(c.branch_until) > 29);
  assert.equal(await visible(br.id), true);
  // the branch's AI MANAGER: its own plan, only that branch gets it
  subs.set('tok-branch-ai-0001', gsub('aklatak.shop.branchai.monthly', { obf: accB }));
  assert.equal((await verifyG(br, 'aklatak.shop.branchai.monthly', 'tok-branch-ai-0001')).status, 200);
  assert.ok((await cook(br.id)).ai_until);
  assert.equal((await cook(st.id)).ai_until, null, 'the main account does not get it');
  // the branch plan refunded → the branch is hidden again; the main subscription is untouched
  const r = await rtdn({ voidedPurchaseNotification: { purchaseToken: 'tok-branch-0001', orderId: 'GPA.1', productType: 1, refundType: 1 } });
  assert.equal(r.status, 200);
  assert.equal(await visible(br.id), false);
  assert.equal(await visible(st.id), true);
});

test('the AI pack (one-time): paid → budget added to this month once, consumed; refunded → taken back', async () => {
  const st = await makeStore();
  const acc = (await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.aipack', { cookie: st.cookie })).data.accountId;
  oneTime.set('tok-pack-0001', { kind: 'androidpublisher#productPurchase', purchaseState: 0, consumptionState: 0, acknowledgementState: 0, orderId: 'GPA.P1', obfuscatedExternalAccountId: acc, purchaseType: 0 });
  const v = await verifyG(st, 'aklatak.shop.aipack', 'tok-pack-0001');
  assert.equal(v.status, 200, JSON.stringify(v.data));
  const month = new Date().toISOString().slice(0, 7);
  const extra = async () => Number((await app.db.one('SELECT extra_cents FROM ai_usage WHERE owner_type = $1 AND owner_id = $2 AND month = $3', ['store', st.id, month]))?.extra_cents || 0);
  assert.equal(await extra(), 400);
  assert.deepEqual(consumed, ['tok-pack-0001']);
  // the same purchase again (verify twice, then Google's notification): still once
  await verifyG(st, 'aklatak.shop.aipack', 'tok-pack-0001');
  await rtdn({ oneTimeProductNotification: { version: '1.0', notificationType: 1, purchaseToken: 'tok-pack-0001', sku: 'aklatak.shop.aipack' } });
  assert.equal(await extra(), 400);
  // another account can't claim it
  const other = await makeStore();
  assert.equal((await verifyG(other, 'aklatak.shop.aipack', 'tok-pack-0001')).data.error, 'purchase_belongs_to_another_account');
  // refunded
  await rtdn({ voidedPurchaseNotification: { purchaseToken: 'tok-pack-0001', orderId: 'GPA.P1', productType: 2, refundType: 1 } });
  assert.equal(await extra(), 0);
  // a pending (not paid) purchase gives nothing
  oneTime.set('tok-pack-0002', { purchaseState: 2, consumptionState: 0, acknowledgementState: 0, orderId: 'GPA.P2', obfuscatedExternalAccountId: acc });
  await verifyG(st, 'aklatak.shop.aipack', 'tok-pack-0002');
  assert.equal(await extra(), 0);
});

test('v8.3 the AI pack bought on iPhone (App Store consumable): credited once; a refund takes it back once', async () => {
  const st = await makeStore();
  const acc = (await http('GET', '/api/billing/apple/prepare?productId=aklatak.shop.aipack', { cookie: st.cookie })).data.accountId;
  const month = new Date().toISOString().slice(0, 7);
  const extra = async () => Number((await app.db.one('SELECT extra_cents FROM ai_usage WHERE owner_type = $1 AND owner_id = $2 AND month = $3', ['store', st.id, month]))?.extra_cents || 0);
  const tx = { bundleId: BUNDLE, environment: 'Production', type: 'Consumable', productId: 'aklatak.shop.aipack', transactionId: '7000001', originalTransactionId: '7000001', purchaseDate: Date.now(), appAccountToken: acc };
  const v = await http('POST', '/api/billing/apple/verify', { cookie: st.cookie, body: { signedTransaction: jws(tx) } });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  assert.equal(await extra(), 400);
  await http('POST', '/api/billing/apple/verify', { cookie: st.cookie, body: { signedTransaction: jws(tx) } });
  await appleNotify(appleNote('ONE_TIME_CHARGE', tx, { uuid: 'apple-pack-1' }));
  assert.equal(await extra(), 400, 'still once');
  const other = await makeStore();
  assert.equal((await http('POST', '/api/billing/apple/verify', { cookie: other.cookie, body: { signedTransaction: jws(tx) } })).status, 409);
  await appleNotify(appleNote('REFUND', { ...tx, revocationDate: Date.now(), revocationReason: 0 }, { uuid: 'apple-pack-r1' }));
  assert.equal(await extra(), 0);
  await http('POST', '/api/billing/apple/verify', { cookie: st.cookie, body: { signedTransaction: jws(tx) } });
  await appleNotify(appleNote('REFUND', { ...tx, revocationDate: Date.now(), revocationReason: 0 }, { uuid: 'apple-pack-r2' }));
  assert.equal(await extra(), 0, 'not credited again, not taken twice');
  assert.equal((await app.db.one(`SELECT state FROM billing_entitlements WHERE original_transaction_id = '7000001'`)).state, 'refunded');
});

test('a category\'s own Google product (supermarkets at another price) replaces the general one, only for that category', async () => {
  const cfg0 = (await A('GET', '/api/admin/billing/config')).data.products;
  const products = { ...cfg0, 'aklatak.supermarket.basic.monthly': { subject: 'store', group: 'shops', tier: 'basic', months: 1, kinds: ['supermarket'] } };
  assert.equal((await A('PUT', '/api/admin/billing/products', { products })).status, 200);
  assert.equal((await A('PUT', '/api/admin/billing/products', { products: { ...products, bad: { subject: 'store', group: 'shops', tier: 'pack', months: 0 } } })).status, 422, 'a pack needs its cents');
  const sm = await makeStore('supermarket');
  const rest = await makeStore('restaurant');
  const ids = async (st) => (await http('GET', '/api/billing/products', { cookie: st.cookie })).data.products.map((x) => x.productId);
  assert.ok((await ids(sm)).includes('aklatak.supermarket.basic.monthly'));
  assert.ok(!(await ids(sm)).includes('aklatak.shop.basic.monthly'), 'the general one is replaced');
  assert.ok(!(await ids(rest)).includes('aklatak.supermarket.basic.monthly'));
  assert.equal((await http('GET', '/api/billing/google/prepare?productId=aklatak.supermarket.basic.monthly', { cookie: rest.cookie })).data.error, 'product_not_for_account');
  await A('PUT', '/api/admin/billing/products', { products: cfg0 });
});

test('the owner gives the AI MANAGER by hand (one account / branch only) or stops it; the AI pack receipt form is closed', async () => {
  const st = await makeStore();
  const r = await A('POST', `/api/admin/stores/${st.id}/ai`, { months: 1 });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok(days((await cook(st.id)).ai_until) > 27);
  assert.equal((await http('POST', '/api/ai/pack', { cookie: st.cookie, body: { method: 'whish', receipt: JPG } })).data.error, 'google_play_only');
  assert.equal((await A('POST', `/api/admin/stores/${st.id}/ai`, { months: 0 })).data.aiUntil, null);
  assert.equal((await cook(st.id)).ai_until, null);
  assert.equal((await A('POST', `/api/admin/stores/${st.id}/ai`, { months: 40 })).status, 422);
  assert.equal((await http('POST', `/api/admin/stores/${st.id}/ai`, { body: { months: 1 } })).status, 401);
});

test('v8.4 the owner hides the AI MANAGER from stores / drivers: gone from plans, sign-up, «my plan», store products; existing AI kept; switch back', async () => {
  const st = await makeStore();
  const drv = await makeDriver();
  const until = new Date(Date.now() + 20 * 864e5).toISOString();
  await app.db.query('UPDATE cooks SET ai_until = $1 WHERE id = $2', [until, st.id]);
  assert.equal((await A('PUT', '/api/admin/plans', { aiHidden: { stores: true, drivers: true } })).status, 200);
  const pub = (await http('GET', '/api/plans')).data;
  assert.deepEqual([pub.aiOffered, pub.ai.shops, pub.ai.drivers], [{ stores: false, drivers: false }, {}, {}]);
  assert.ok(Object.keys(pub.store.basic).length && Object.keys(pub.driverJobs).length, 'the normal plans stay');
  const sub = (await http('GET', '/api/store/subscription', { cookie: st.cookie })).data;
  assert.deepEqual([sub.aiOffered, sub.aiOptions.length, sub.aiActive], [false, 0, true], 'he keeps his AI until it ends');
  const ids = async (who) => (await http('GET', '/api/billing/products', { cookie: who.cookie })).data.products.map((p) => p.tier);
  assert.ok(!(await ids(st)).some((x) => ['ai', 'branch_ai'].includes(x)) && (await ids(st)).includes('basic'));
  assert.ok(!(await ids(drv)).includes('ai'));
  assert.equal((await http('GET', '/api/billing/google/prepare?productId=aklatak.shop.ai.monthly', { cookie: st.cookie })).data.error, 'ai_not_offered');
  // the admin page still shows the real per-duration choices (nothing was rewritten)
  const raw = (await A('GET', '/api/admin/plans')).data.plans;
  assert.equal(raw.ai.shops['1'].hidden, false);
  assert.deepEqual(raw.aiHidden, { stores: true, drivers: true });
  // back on
  await A('PUT', '/api/admin/plans', { aiHidden: { stores: false, drivers: false } });
  const pub2 = (await http('GET', '/api/plans')).data;
  assert.ok(Object.keys(pub2.ai.shops).length && Object.keys(pub2.ai.drivers).length);
  assert.ok((await ids(st)).includes('ai'));
});
