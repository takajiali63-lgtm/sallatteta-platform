// End-to-end tests against a real running server + real database (SQLite in-memory).
// Run: npm test
import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createApp } from '../src/server.js';
import { haversineKm } from '../src/lib/geo.js';
import { normalizePhone } from '../src/lib/whatsapp.js';

const ADMIN_WA = '96170999999';
const CUSTOMER = { lat: 33.8463, lng: 35.9020 }; // Zahle centre
const KM_LAT = 1 / 110.574;
const KM_LNG = 1 / (111.32 * Math.cos((33.8463 * Math.PI) / 180));

let app, base, cookie;

async function http(method, path, { body, auth = false, headers = {} } = {}) {
  const res = await fetch(base + path, {
    method,
    redirect: 'manual',
    headers: {
      ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      'X-Requested-With': 'fetch',
      ...(auth ? { Cookie: cookie } : {}),
      ...headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
}
const admin = (method, path, body) => http(method, path, { body, auth: true });
const search = (text, loc = { type: 'gps', ...CUSTOMER }, extra = {}) =>
  http('POST', '/api/search', { body: { text, location: loc, ...extra } });

async function addCook(name, phone, { north = 0, east = 0, radius = 5, services = ['home_cooking'], activate = true } = {}) {
  const r = await admin('POST', '/api/admin/cooks', {
    fullName: name, whatsapp: phone, areaId: 1, radiusKm: radius, services,
    lat: CUSTOMER.lat + north * KM_LAT, lng: CUSTOMER.lng + east * KM_LNG,
    ...(activate ? { activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } } : {}),
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  return r.data;
}
const names = (res) => res.data.cooks.map((c) => c.name);

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:',
    adminWhatsapp: ADMIN_WA,
    sessionSecret: 'test-secret-'.repeat(4),
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 10_000, applyLimit: 10_000, loginLimit: 10_000,
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  const login = await http('POST', '/api/admin/login', { body: { username: 'admin', password: 'correct-horse-battery' } });
  assert.equal(login.status, 200);
  cookie = login.headers.get('set-cookie').split(';')[0];
});
after(async () => { await app.close(); });

describe('unit helpers', () => {
  test('Haversine distance is geographic (Beirut → Zahle ≈ 37 km)', () => {
    const d = haversineKm(33.8938, 35.5018, 33.8463, 35.9020);
    assert.ok(d > 36 && d < 39, `got ${d}`);
  });
  test('WhatsApp numbers normalise to international digits', () => {
    assert.equal(normalizePhone('+961 71 123 456'), '96171123456');
    assert.equal(normalizePhone('0096171123456'), '96171123456');
    assert.equal(normalizePhone('71-123456'), '96171123456');
    assert.equal(normalizePhone('03 123 456'), '9613123456');
    assert.equal(normalizePhone('abc'), null);
    assert.equal(normalizePhone('+961 1'), null);
  });
});

describe('customer flow', () => {
  let ali, rana, suad, far, expired, suspended;

  before(async () => {
    ali = await addCook('أم علي', '+96171000001', { north: 0.8, services: ['home_cooking', 'pastries', 'sweets'] });
    rana = await addCook('رنا', '71000002', { north: -1.4, services: ['home_cooking', 'mouneh'] });
    suad = await addCook('سعاد', '03000003', { east: 2.3, services: ['home_cooking', 'sweets'] });
    far = await addCook('بعيدة', '71000004', { north: 8 });
    expired = await addCook('منتهية', '71000005', { north: 0.3 });
    suspended = await addCook('معلّقة', '71000006', { north: 0.4 });
    // make "منتهية" expired: started 2 months ago, ended yesterday
    const past = await admin('PATCH', `/api/admin/cooks/${expired.id}/subscription`, {
      startDate: new Date(Date.now() - 60 * 86400_000).toISOString(), expiryDate: new Date(Date.now() - 86400_000).toISOString(),
    });
    assert.equal(past.status, 200);
    assert.equal((await admin('POST', `/api/admin/cooks/${suspended.id}/subscription/suspend`, {})).status, 200);
    await addCook('بدون تفعيل', '71000007', { north: 0.2, activate: false }); // approved, no subscription
  });

  test('1. customer request is created and stored with approximate location only', async () => {
    const r = await search('بدي صينية كبة لـ 8 أشخاص نهار الجمعة');
    assert.equal(r.status, 200);
    assert.match(r.data.requestId, /^[\w-]{16}$/);
    const row = await app.db.one('SELECT * FROM requests WHERE public_id = $1', [r.data.requestId]);
    assert.equal(row.body, 'بدي صينية كبة لـ 8 أشخاص نهار الجمعة');
    assert.equal(row.approx_lat, 33.85); // rounded to 2 decimals (~1 km)
    assert.equal(row.approx_lng, 35.9);
    assert.equal(row.results_count, 3);
  });

  test('2. geographic search: inside radius shows, 8 km away with 5 km radius does not', async () => {
    const r = await search('بدي ورق عنب');
    assert.ok(names(r).includes('سعاد'), 'cook at 2.3 km with 5 km radius must appear');
    assert.ok(!names(r).includes('بعيدة'), 'cook at 8 km with 5 km radius must not appear');
    // widen her radius to 10 km → now she appears
    assert.equal((await admin('PATCH', `/api/admin/cooks/${far.id}`, { radiusKm: 10 })).status, 200);
    assert.ok(names(await search('بدي ورق عنب')).includes('بعيدة'));
    await admin('PATCH', `/api/admin/cooks/${far.id}`, { radiusKm: 5 });
  });

  test('2b. searching by area (no GPS) works', async () => {
    const r = await search('بدي معجنات', { type: 'area', areaId: 1 });
    assert.equal(r.status, 200);
    assert.equal(r.data.areaLabel, 'زحلة');
    assert.deepEqual(names(r), ['أم علي', 'رنا', 'سعاد']);
  });

  test('3. only Active cooks appear; public API never exposes WhatsApp numbers or coordinates', async () => {
    const r = await search('بدي كبة');
    assert.deepEqual(names(r).sort(), ['أم علي', 'رنا', 'سعاد'].sort());
    for (const c of r.data.cooks) {
      assert.equal(c.subscriptionStatus, 'active');
      assert.deepEqual(Object.keys(c).sort(), ['area', 'bio', 'distanceKm', 'id', 'name', 'photoUrl', 'services', 'subscriptionStatus']);
    }
    assert.ok(!JSON.stringify(r.data).includes('96171'), 'no phone numbers in search response');
  });

  test('4. expired cooks do not appear (even before the expiry sweep runs)', async () => {
    const r = await search('بدي كبة');
    assert.ok(!names(r).includes('منتهية'));
    assert.ok(!names(r).includes('معلّقة'));
    assert.ok(!names(r).includes('بدون تفعيل'));
  });

  test('5. results are ordered nearest first with correct distances', async () => {
    const r = await search('بدي كبة');
    assert.deepEqual(names(r), ['أم علي', 'رنا', 'سعاد']);
    const d = r.data.cooks.map((c) => c.distanceKm);
    assert.deepEqual([...d].sort((a, b) => a - b), d);
    assert.ok(Math.abs(d[0] - 0.8) <= 0.1 && Math.abs(d[1] - 1.4) <= 0.1 && Math.abs(d[2] - 2.3) <= 0.1, `distances ${d}`);
    assert.deepEqual(r.data.cooks[0].services, ['home_cooking', 'pastries', 'sweets']);
  });

  test('5b. optional service-type filter', async () => {
    const r = await search('بدي حلويات', undefined, { serviceType: 'mouneh' });
    assert.deepEqual(names(r), ['رنا']);
  });

  test('6 + 7. WhatsApp link is correct, URL-encoded and carries the full request', async () => {
    const text = 'بدي 3 كيلو ورق دوالي & 2 كيلو كبة؟ #عزومة 10 أشخاص\nيوم الجمعة 🙏';
    const r = await search(text, { type: 'area', areaId: 1 });
    const c = await http('POST', '/api/contact', { body: { requestId: r.data.requestId, cookId: ali.id } });
    assert.equal(c.status, 200);
    const url = new URL(c.data.whatsappUrl);
    assert.equal(url.origin, 'https://wa.me');
    assert.equal(url.pathname, '/96171000001');
    assert.ok(!c.data.whatsappUrl.includes(' '), 'must be URL-encoded');
    assert.equal(url.searchParams.get('text'),
      `مرحباً، لدي طلب من خلال سلة تيتا:\n\n${text}\n\nالمنطقة: زحلة\n\nأريد التواصل معك بخصوص الطلب.`);
    const ev = await app.db.one('SELECT CAST(COUNT(*) AS INTEGER) AS n FROM request_contact_events WHERE cook_id = $1', [ali.id]);
    assert.equal(ev.n, 1, 'click is logged for analytics');
  });

  test('7b. a WhatsApp link cannot be fetched for a cook that was not shown / is no longer active', async () => {
    const r = await search('بدي كبة');
    const notShown = await http('POST', '/api/contact', { body: { requestId: r.data.requestId, cookId: expired.id } });
    assert.equal(notShown.status, 404);
    await admin('POST', `/api/admin/cooks/${suad.id}/subscription/suspend`, {});
    const gone = await http('POST', '/api/contact', { body: { requestId: r.data.requestId, cookId: suad.id } });
    assert.equal(gone.status, 404);
    await admin('POST', `/api/admin/cooks/${suad.id}/subscription/activate`, { plan: 'monthly' });
  });

  test('validation: too-short request / missing location / bot honeypot are rejected', async () => {
    assert.equal((await search('كبة')).status, 422);
    assert.equal((await http('POST', '/api/search', { body: { text: 'بدي صينية كبة' } })).status, 422);
    assert.equal((await search('بدي صينية كبة', undefined, { website: 'spam.com' })).status, 400);
  });

  test('11. subscription expiry: sweep marks it expired, data is kept, admin can renew', async () => {
    const swept = await app.sweep();
    const sub = await app.db.one('SELECT status FROM subscriptions WHERE cook_id = $1', [expired.id]);
    assert.equal(sub.status, 'expired');
    const cook = await app.db.one('SELECT full_name, whatsapp FROM cooks WHERE id = $1', [expired.id]);
    assert.equal(cook.full_name, 'منتهية', 'data is kept');
    const list = await admin('GET', '/api/admin/cooks?filter=expired');
    assert.ok(list.data.cooks.some((c) => c.id === expired.id));
    // an active subscription whose expiry is moved into the past disappears immediately
    await admin('PATCH', `/api/admin/cooks/${rana.id}/subscription`, { expiryDate: new Date(Date.now() - 1000).toISOString() });
    assert.ok(!names(await search('بدي كبة')).includes('رنا'));
    // renew both → back in results
    assert.equal((await admin('POST', `/api/admin/cooks/${expired.id}/subscription/renew`, { plan: 'quarterly' })).status, 200);
    assert.equal((await admin('POST', `/api/admin/cooks/${rana.id}/subscription/renew`, { plan: 'monthly' })).status, 200);
    const after = await search('بدي كبة');
    assert.ok(names(after).includes('منتهية') && names(after).includes('رنا'));
    const renewed = await admin('GET', `/api/admin/cooks/${expired.id}`);
    const months = (new Date(renewed.data.subscription.expiry_date) - Date.now()) / (30 * 86400_000);
    assert.ok(months > 2.8 && months < 3.2, 'renewed for 3 months from today');
    void swept;
  });
});

describe('cook subscription applications', () => {
  let appId;

  test('8 + 9. application is saved as pending and routed to the admin WhatsApp', async () => {
    const r = await http('POST', '/api/cook-applications', {
      body: {
        fullName: 'أم جورج', whatsapp: '+961 76 555 444', areaId: 1, radiusKm: 5,
        services: ['home_cooking', 'pastries'], bio: 'معجنات وفطاير', plan: 'quarterly',
        startedAt: Date.now() - 60_000, website: '',
      },
    });
    assert.equal(r.status, 201, JSON.stringify(r.data));
    appId = r.data.applicationId;
    const url = new URL(r.data.whatsappUrl);
    assert.equal(url.pathname, `/${ADMIN_WA}`);
    const msg = url.searchParams.get('text');
    for (const part of ['طلب اشتراك جديد في سلة تيتا', 'الاسم: أم جورج', 'رقم WhatsApp: +96176555444', 'المنطقة: زحلة',
      'نطاق الخدمة: 5 km', 'نوع الطلبات: طبخ منزلي، معجنات', 'مدة الاشتراك: 3 أشهر', 'يرجى التواصل مع المتقدمة لإتمام الدفع.']) {
      assert.ok(msg.includes(part), `message should contain "${part}"\n${msg}`);
    }
    const cook = await app.db.one('SELECT status FROM cooks WHERE id = $1', [appId]);
    const sub = await app.db.one('SELECT status, payment_status, plan FROM subscriptions WHERE cook_id = $1', [appId]);
    assert.equal(cook.status, 'pending');
    assert.deepEqual({ ...sub }, { status: 'pending', payment_status: 'unpaid', plan: 'quarterly' });
    assert.ok(!names(await search('بدي معجنات')).includes('أم جورج'), 'pending cook is not visible');
    const pending = await admin('GET', '/api/admin/cooks?filter=pending');
    assert.ok(pending.data.cooks.some((c) => c.id === appId));
  });

  test('applications: duplicate, invalid phone, bot and too-fast submissions are rejected', async () => {
    const good = { fullName: 'أم جورج', whatsapp: '76555444', areaId: 1, radiusKm: 5, services: ['sweets'], plan: 'monthly', startedAt: Date.now() - 60_000 };
    assert.equal((await http('POST', '/api/cook-applications', { body: good })).status, 409);
    const bad = await http('POST', '/api/cook-applications', { body: { ...good, whatsapp: '+961 12 34' } });
    assert.equal(bad.status, 422);
    assert.equal(bad.data.fields.whatsapp, 'invalid_phone');
    assert.equal((await http('POST', '/api/cook-applications', { body: { ...good, whatsapp: '71999111', website: 'x' } })).status, 400);
    assert.equal((await http('POST', '/api/cook-applications', { body: { ...good, whatsapp: '71999112', startedAt: Date.now() } })).status, 400);
    const empty = await http('POST', '/api/cook-applications', { body: { startedAt: Date.now() - 60_000 } });
    assert.equal(empty.status, 422);
    assert.deepEqual(Object.keys(empty.data.fields).sort(), ['areaId', 'fullName', 'plan', 'radiusKm', 'services', 'whatsapp']);
  });

  test('without ADMIN_WHATSAPP_NUMBER the application is still saved (no link returned)', async () => {
    const saved = app.cfg.adminWhatsapp;
    app.cfg.adminWhatsapp = '';
    const r = await http('POST', '/api/cook-applications', { body: { fullName: 'هدى', whatsapp: '71888777', areaId: 1, radiusKm: 3, services: ['sweets'], plan: 'monthly', startedAt: Date.now() - 60_000 } });
    app.cfg.adminWhatsapp = saved;
    assert.equal(r.status, 201);
    assert.equal(r.data.whatsappUrl, null);
  });

  test('10. admin activates → visible; suspends → hidden; re-activates; expires now → hidden', async () => {
    const act = await admin('POST', `/api/admin/cooks/${appId}/subscription/activate`, { plan: 'quarterly', paymentStatus: 'paid' });
    assert.equal(act.status, 200);
    assert.equal(act.data.effectiveStatus, 'active');
    assert.equal(act.data.subscription.payment_status, 'paid');
    assert.ok(names(await search('بدي معجنات')).includes('أم جورج'));

    assert.equal((await admin('POST', `/api/admin/cooks/${appId}/subscription/suspend`, {})).data.effectiveStatus, 'suspended');
    assert.ok(!names(await search('بدي معجنات')).includes('أم جورج'));

    const start = '2026-01-01', end = '2030-01-01';
    const re = await admin('POST', `/api/admin/cooks/${appId}/subscription/activate`, { plan: 'yearly', startDate: start, expiryDate: end });
    assert.equal(re.data.subscription.start_date.slice(0, 10), start);
    assert.equal(re.data.subscription.expiry_date.slice(0, 10), end);
    assert.ok(names(await search('بدي معجنات')).includes('أم جورج'));

    const bad = await admin('POST', `/api/admin/cooks/${appId}/subscription/activate`, { plan: 'yearly', startDate: end, expiryDate: start });
    assert.equal(bad.status, 422);

    assert.equal((await admin('POST', `/api/admin/cooks/${appId}/subscription/expire`, {})).data.effectiveStatus, 'expired');
    assert.ok(!names(await search('بدي معجنات')).includes('أم جورج'));
  });

  test('admin can edit WhatsApp number, area and service radius', async () => {
    const r = await admin('PATCH', `/api/admin/cooks/${appId}`, { whatsapp: '03 222 333', areaId: 2, radiusKm: 12 });
    assert.equal(r.status, 200);
    assert.equal(r.data.whatsapp, '9613222333');
    assert.equal(r.data.area_label, 'شتورا');
    assert.equal(r.data.service_radius_km, 12);
    const rej = await admin('POST', `/api/admin/cooks/${appId}/reject`, {});
    assert.equal(rej.data.effectiveStatus, 'rejected');
  });

  test('analytics: searches, impressions and WhatsApp clicks are counted', async () => {
    const s = await admin('GET', '/api/admin/stats');
    assert.ok(s.data.searches_30d >= 10);
    assert.ok(s.data.whatsapp_clicks_30d >= 1);
    const list = await admin('GET', '/api/admin/cooks?filter=all');
    const ali = list.data.cooks.find((c) => c.fullName === 'أم علي');
    assert.ok(ali.impressions >= 5 && ali.whatsappClicks >= 1);
  });
});

describe('12. admin protection', () => {
  test('admin API requires a session', async () => {
    for (const [m, p] of [['GET', '/api/admin/cooks'], ['GET', '/api/admin/stats'], ['POST', '/api/admin/cooks'], ['PATCH', '/api/admin/cooks/1'], ['POST', '/api/admin/cooks/1/subscription/activate']]) {
      const r = await http(m, p, { body: m === 'GET' ? undefined : {} });
      assert.equal(r.status, 401, `${m} ${p}`);
    }
  });
  test('wrong password is rejected; password is stored hashed (scrypt)', async () => {
    const r = await http('POST', '/api/admin/login', { body: { username: 'admin', password: 'wrong-password' } });
    assert.equal(r.status, 401);
    const u = await app.db.one('SELECT password_hash FROM admin_users WHERE username = $1', ['admin']);
    assert.match(u.password_hash, /^scrypt\$/);
    assert.ok(!u.password_hash.includes('correct-horse'));
  });
  test('session cookie is HttpOnly + SameSite=Strict; token stored only as a hash', async () => {
    const r = await http('POST', '/api/admin/login', { body: { username: 'admin', password: 'correct-horse-battery' } });
    const sc = r.headers.get('set-cookie');
    assert.match(sc, /HttpOnly/);
    assert.match(sc, /SameSite=Strict/);
    const token = sc.split(';')[0].split('=')[1];
    assert.equal(await app.db.one('SELECT id FROM admin_sessions WHERE token_hash = $1', [token]), null);
  });
  test('CSRF: state-changing calls need the fetch header and a same-origin Origin', async () => {
    const noHeader = await fetch(base + '/api/admin/cooks/1/approve', { method: 'POST', headers: { Cookie: cookie, 'Content-Type': 'application/json' }, body: '{}' });
    assert.equal(noHeader.status, 403);
    const evil = await http('POST', '/api/admin/cooks/1/approve', { body: {}, auth: true, headers: { Origin: 'https://evil.example' } });
    assert.equal(evil.status, 403);
  });
  test('logout invalidates the session', async () => {
    const l = await http('POST', '/api/admin/login', { body: { username: 'admin', password: 'correct-horse-battery' } });
    const c = l.headers.get('set-cookie').split(';')[0];
    assert.equal((await http('POST', '/api/admin/logout', { body: {}, headers: { Cookie: c } })).status, 200);
    assert.equal((await http('GET', '/api/admin/me', { headers: { Cookie: c } })).status, 401);
  });
  test('admin page is not indexed; ADMIN_WHATSAPP_NUMBER never reaches public files or config', async () => {
    const page = await fetch(base + '/admin/');
    assert.equal(page.status, 200);
    assert.equal(page.headers.get('x-robots-tag'), 'noindex, nofollow');
    const cfg = await http('GET', '/api/config');
    assert.ok(!JSON.stringify(cfg.data).includes(ADMIN_WA));
    for (const f of ['public/index.html', 'public/join.html', 'public/assets/app.js', 'public/assets/join.js', 'admin-ui/admin.js']) {
      assert.ok(!(await readFile(new URL('../' + f, import.meta.url), 'utf8')).includes(ADMIN_WA), f);
    }
  });
  test('security headers and path traversal protection', async () => {
    const r = await fetch(base + '/');
    assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    const t = await fetch(base + '/assets/..%2f..%2fpackage.json');
    assert.equal(t.status, 404);
  });
});

describe('rate limiting', () => {
  test('search and login are rate limited per IP', async () => {
    const small = await createApp({ databaseUrl: 'sqlite::memory:', searchLimit: 3, loginLimit: 2, sessionSecret: 'y'.repeat(40) });
    await new Promise((r) => small.server.listen(0, r));
    const b = `http://127.0.0.1:${small.server.address().port}`;
    const post = (p, body) => fetch(b + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
    const codes = [];
    for (let i = 0; i < 5; i++) codes.push((await post('/api/search', { text: 'بدي صينية كبة', location: { type: 'area', areaId: 1 } })).status);
    assert.deepEqual(codes, [200, 200, 200, 429, 429]);
    const lc = [];
    for (let i = 0; i < 4; i++) lc.push((await post('/api/admin/login', { username: 'x', password: 'y' })).status);
    assert.deepEqual(lc, [401, 401, 429, 429]);
    await small.close();
  });
});
