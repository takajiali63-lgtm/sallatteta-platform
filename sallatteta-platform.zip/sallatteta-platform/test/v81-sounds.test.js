// v8.1 sound effects manager: owner-only admin API (global + per-event switches, volume, roles, library uploads checked
// by magic bytes, replace, restore defaults, audit), the per-role public config with ETag, the audio media route,
// and the pure client rules (autoplay gating, throttling, priority, user mute) from public/assets/x/sounds-core.js.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { request } from 'node:http';
import { createApp } from '../src/server.js';
import { createAdminUser } from '../src/routes/admin.js';
import { EVENTS, sniffAudio, parseSoundUpload } from '../src/services/sounds.js';
import * as core from '../public/assets/x/sounds-core.js';

let app, base, admin, agent, cust, storeCookie, areaId;

async function http(method, path, { body, cookie, headers = {} } = {}) {
  const res = await fetch(base + path, { method, redirect: 'manual', headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), 'X-Requested-With': 'fetch', ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
  const buf = Buffer.from(await res.arrayBuffer());
  let data; try { data = JSON.parse(buf.toString('utf8')); } catch { data = buf; }
  return { status: res.status, data, headers: res.headers, buf };
}
async function login(path, body) {
  const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: JSON.stringify(body) });
  return res.headers.get('set-cookie')?.split(';')[0];
}
/** A one-off connection (no keep-alive reuse) for requests the server rejects before reading the whole body. */
function rawPost(path, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body));
    const req = request(base + path, { method: 'POST', agent: false, headers: { 'Content-Type': 'application/json', 'Content-Length': data.length, 'X-Requested-With': 'fetch', Cookie: admin, Connection: 'close' } }, (res) => { res.resume(); resolve(res.statusCode); });
    req.on('error', reject);
    req.end(data);
  });
}
const A = (m, p, b) => http(m, p, { body: b, cookie: admin });
const cfgOf = async (role, headers) => http('GET', `/api/sounds/config?role=${role}`, { headers });
const dataUrl = (mime, buf) => `data:${mime};base64,${buf.toString('base64')}`;
const pad = (head, n = 64) => Buffer.concat([Buffer.isBuffer(head) ? head : Buffer.from(head, 'latin1'), Buffer.alloc(n)]);

const WAV = readFileSync(new URL('../public/assets/sounds/pop.wav', import.meta.url));
const MP3_ID3 = pad('ID3\x04\x00\x00\x00\x00\x00\x00');
const MP3_SYNC = pad(Buffer.from([0xff, 0xfb, 0x90, 0x64]));
const OGG = pad('OggS\x00\x02');
const M4A = pad(Buffer.concat([Buffer.from([0, 0, 0, 0x20]), Buffer.from('ftypM4A ', 'latin1')]));
const AAC = pad(Buffer.from([0xff, 0xf1, 0x50, 0x80]));
const EXE = pad('MZ\x90\x00\x03\x00\x00\x00');

before(async () => {
  app = await createApp({
    databaseUrl: 'sqlite::memory:', adminWhatsapp: '96170999999', sessionSecret: 'x'.repeat(40), quiet: true,
    bootstrapAdmin: { username: 'admin', password: 'correct-horse-battery' },
    searchLimit: 1e4, applyLimit: 1e4, loginLimit: 1e4, lookupLimit: 1e4, placesLimit: 1e4, feedbackLimit: 1e4, uploadLimit: 1e4, adminLimit: 1e5,
    placesFetcher: async () => [],
  });
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
  areaId = (await app.db.one(`SELECT id FROM service_areas WHERE slug = 'zahle'`)).id;
  admin = await login('/api/admin/login', { username: 'admin', password: 'correct-horse-battery' });
  await createAdminUser(app.db, 'helper', 'agent-password-123');
  await app.db.query(`UPDATE admin_users SET role = 'agent' WHERE username = 'helper'`);
  agent = await login('/api/admin/login', { username: 'helper', password: 'agent-password-123' });
  cust = await login('/api/customer/login', { name: 'زبون', phone: '03999777', acceptTerms: true });
  const r = await A('POST', '/api/admin/cooks', { fullName: 'محل', whatsapp: '+96171701234', areaId, services: ['home_cooking'], servedAreaIds: [areaId], kind: 'restaurant', lat: 33.85, lng: 35.9, activate: { plan: 'monthly', startDate: new Date(Date.now() - 60_000).toISOString() } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const pw = (await A('POST', `/api/admin/cooks/${r.data.id}/password`, {})).data.password;
  storeCookie = await login('/api/cook/login', { whatsapp: '+96171701234', password: pw });
});
after(() => app?.close?.());

test('defaults work with no admin action: every event has a built-in sound, config per role, critical alerts are high', async () => {
  const keys = EVENTS.map((e) => e.key);
  for (const k of ['cart_add', 'payment_failure', 'store_new_order', 'store_urgent_order', 'order_delayed', 'driver_new_request', 'ai_failed', 'announcement', 'incoming_communication'])
    assert.ok(keys.includes(k), k);
  assert.equal(new Set(keys).size, keys.length, 'unique keys');
  const v = await A('GET', '/api/admin/sounds');
  assert.equal(v.status, 200);
  assert.equal(v.data.events.length, EVENTS.length);
  assert.deepEqual(v.data.events.filter((e) => e.priority === 'high').map((e) => e.key).sort(), ['driver_new_request', 'order_delayed', 'store_customer_reminder', 'store_new_order', 'store_urgent_order']);
  const c = await cfgOf('customer');
  assert.equal(c.status, 200);
  assert.equal(c.data.enabled, 1);
  assert.ok(c.data.events.cart_add.url.startsWith('/media/sounds/default/pop.wav?v='));
  assert.ok(c.data.events.cart_add.volume > 0 && c.data.events.cart_add.volume <= 1);
  // every default URL really serves audio
  for (const e of Object.values(c.data.events)) {
    const r = await http('GET', e.url);
    assert.equal(r.status, 200, e.url);
    assert.equal(r.headers.get('content-type'), 'audio/wav');
    assert.equal(r.buf.toString('latin1', 8, 12), 'WAVE');
  }
});

test('role filter: each role only gets its own events; shared bus names resolve to the role-specific event', async () => {
  const [c, s, d] = await Promise.all(['customer', 'store', 'driver'].map(async (r) => (await cfgOf(r)).data.events));
  assert.ok(c.cart_add && !c.store_new_order && !c.driver_new_request);
  assert.ok(s.store_new_order && s.order_delayed && !s.cart_add && !s.driver_new_request);
  assert.ok(d.driver_new_request && !d.cart_add && !d.store_new_order);
  assert.equal(s.store_new_order.priority, 'high');
  assert.ok(c.new_message && s.new_message && d.new_message, 'new_message mapped for every role');
  assert.equal((await cfgOf('admin')).status, 422);
  assert.equal((await cfgOf('')).status, 422);
  // the owner sends store_new_message to customers too: customers still get their own new_message sound
  const own = (await A('GET', '/api/admin/sounds')).data.events.find((e) => e.key === 'new_message');
  const r = await A('PUT', '/api/admin/sounds/events/store_new_message', { roles: ['store', 'customer'], sound: 'default:ring' });
  assert.equal(r.status, 200);
  assert.equal((await cfgOf('customer')).data.events.new_message.url, own.url);
  assert.ok((await cfgOf('store')).data.events.new_message.url.includes('/ring.wav'));
  // roles: only known roles
  assert.equal((await A('PUT', '/api/admin/sounds/events/cart_add', { roles: ['customer', 'admin'] })).status, 422);
  // the owner moves cart_add to drivers only
  await A('PUT', '/api/admin/sounds/events/cart_add', { roles: ['driver'] });
  assert.ok(!(await cfgOf('customer')).data.events.cart_add);
  assert.ok((await cfgOf('driver')).data.events.cart_add);
  await A('POST', '/api/admin/sounds/restore', { confirm: true });
});

test('global on/off and per-event on/off; off events are not returned at all', async () => {
  const off = await A('PUT', '/api/admin/sounds/settings', { enabled: false });
  assert.equal(off.status, 200);
  let c = (await cfgOf('customer')).data;
  assert.equal(c.enabled, 0);
  assert.deepEqual(c.events, {});
  assert.equal((await A('PUT', '/api/admin/sounds/settings', { enabled: 'yes' })).status, 422);
  await A('PUT', '/api/admin/sounds/settings', { enabled: true });
  assert.equal((await A('PUT', '/api/admin/sounds/events/cart_remove', { enabled: false })).status, 200);
  c = (await cfgOf('customer')).data;
  assert.equal(c.enabled, 1);
  assert.ok(!('cart_remove' in c.events), 'disabled event absent');
  assert.ok(c.events.cart_add, 'others still there');
  assert.equal((await A('PUT', '/api/admin/sounds/events/not_an_event', { enabled: false })).status, 404);
  await A('PUT', '/api/admin/sounds/events/cart_remove', { enabled: true });
  assert.ok((await cfgOf('customer')).data.events.cart_remove);
});

test('volume validation and range: integers 0–100 only; the config returns 0..1; 0 means not returned', async () => {
  for (const bad of [-1, 101, 50.5, '50', null, true]) assert.equal((await A('PUT', '/api/admin/sounds/events/order_accepted', { volume: bad })).status, 422, String(bad));
  assert.equal((await A('PUT', '/api/admin/sounds/events/order_accepted', { volume: 100 })).status, 200);
  assert.equal((await cfgOf('customer')).data.events.order_accepted.volume, 1);
  await A('PUT', '/api/admin/sounds/events/order_accepted', { volume: 25 });
  assert.equal((await cfgOf('customer')).data.events.order_accepted.volume, 0.25);
  await A('PUT', '/api/admin/sounds/events/order_accepted', { volume: 0 });
  assert.ok(!('order_accepted' in (await cfgOf('customer')).data.events));
  assert.equal((await A('PUT', '/api/admin/sounds/events/order_accepted', { sound: 'default:../../etc/passwd' })).status, 422);
  assert.equal((await A('PUT', '/api/admin/sounds/events/order_accepted', { sound: 'file:99999' })).status, 422);
  await A('POST', '/api/admin/sounds/restore', { confirm: true });
});

test('magic bytes: real types recognised; executables / HTML / text are not audio', () => {
  assert.equal(sniffAudio(WAV), 'wav');
  assert.equal(sniffAudio(MP3_ID3), 'mp3');
  assert.equal(sniffAudio(MP3_SYNC), 'mp3');
  assert.equal(sniffAudio(OGG), 'ogg');
  assert.equal(sniffAudio(M4A), 'm4a');
  assert.equal(sniffAudio(AAC), 'aac');
  assert.equal(sniffAudio(EXE), null);
  assert.equal(sniffAudio(pad('<!doctype html><script>')), null);
  assert.equal(sniffAudio(Buffer.from('ID3')), null, 'too short');
  assert.equal(parseSoundUpload(dataUrl('audio/mp4', M4A), 'voice.m4a').ext, 'm4a');
  assert.equal(parseSoundUpload(dataUrl('audio/aac', M4A), 'voice.aac').mime, 'audio/mp4', 'phones label m4a as aac');
  assert.equal(parseSoundUpload(dataUrl('audio/ogg', OGG), 'a.ogg').mime, 'audio/ogg');
  assert.equal(parseSoundUpload('data:audio/wav;base64,!!!').error, 'invalid');
});

test('uploads: valid file stored (base64 + mime + sha256 + size) and served; invalid type, wrong MIME, fake extension, oversize refused', async () => {
  const before = Number((await app.db.one(`SELECT COUNT(*) AS n FROM sound_files`)).n);
  const ok = await A('POST', '/api/admin/sounds/files', { name: 'جرس', dataUrl: dataUrl('audio/mpeg', MP3_ID3), fileName: 'bell.mp3' });
  assert.equal(ok.status, 201, JSON.stringify(ok.data));
  const row = await app.db.one('SELECT * FROM sound_files WHERE id = $1', [ok.data.id]);
  assert.deepEqual([row.mime, row.ext, Number(row.size), row.sha256.length, Buffer.from(row.data, 'base64').equals(MP3_ID3)], ['audio/mpeg', 'mp3', MP3_ID3.length, 64, true]);
  const lib = ok.data.library.find((s) => s.id === ok.data.id);
  assert.ok(lib.url.startsWith(`/media/sounds/${ok.data.id}.mp3?v=`));

  const bad = async (body, code) => {
    const r = await A('POST', '/api/admin/sounds/files', body);
    assert.equal(r.status, code ?? 422, JSON.stringify(body).slice(0, 80));
    return r;
  };
  // an executable named .mp3 and labelled audio/mpeg
  assert.equal((await bad({ name: 'x', dataUrl: dataUrl('audio/mpeg', EXE), fileName: 'song.mp3' })).data.fields.dataUrl, 'invalid_type');
  // HTML pretending to be WAV
  await bad({ name: 'x', dataUrl: dataUrl('audio/wav', pad('<html><script>alert(1)</script>')), fileName: 'a.wav' });
  // a real WAV with the wrong MIME type
  assert.equal((await bad({ name: 'x', dataUrl: dataUrl('audio/mpeg', WAV), fileName: 'a.wav' })).data.fields.dataUrl, 'invalid_type');
  // a real WAV with a fake extension
  assert.equal((await bad({ name: 'x', dataUrl: dataUrl('audio/wav', WAV), fileName: 'a.mp3' })).data.fields.dataUrl, 'invalid_type');
  // non-audio MIME types, even with audio bytes
  await bad({ name: 'x', dataUrl: dataUrl('application/octet-stream', WAV) });
  await bad({ name: 'x', dataUrl: dataUrl('application/x-msdownload', EXE), fileName: 'a.exe' });
  await bad({ name: 'x', dataUrl: dataUrl('image/svg+xml', pad('<svg onload=alert(1)>')) });
  // over 300 KB
  const big = Buffer.concat([WAV.subarray(0, 44), Buffer.alloc(300 * 1024)]);
  assert.equal((await bad({ name: 'x', dataUrl: dataUrl('audio/wav', big), fileName: 'big.wav' })).data.fields.dataUrl, 'too_large');
  // far over: refused before parsing (own connection: the server stops reading the body mid-way)
  assert.equal(await rawPost('/api/admin/sounds/files', { name: 'x', dataUrl: dataUrl('audio/wav', Buffer.concat([WAV, Buffer.alloc(600 * 1024)])) }), 413);
  // exactly at the limit is fine
  const edge = Buffer.concat([WAV.subarray(0, 44), Buffer.alloc(300 * 1024 - 44)]);
  assert.equal((await A('POST', '/api/admin/sounds/files', { name: 'حد', dataUrl: dataUrl('audio/wav', edge), fileName: 'edge.wav' })).status, 201);
  assert.equal(Number((await app.db.one(`SELECT COUNT(*) AS n FROM sound_files`)).n), before + 2, 'only the 2 valid files stored');
});

test('media route: correct Content-Type, nosniff, long immutable cache, ETag 304, byte ranges; no other paths', async () => {
  const up = await A('POST', '/api/admin/sounds/files', { name: 'ogg', dataUrl: dataUrl('audio/ogg', OGG), fileName: 'x.ogg' });
  const url = up.data.library.find((s) => s.id === up.data.id).url;
  const r = await http('GET', url);
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('content-type'), 'audio/ogg');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.match(r.headers.get('cache-control'), /max-age=31536000.*immutable/);
  assert.ok(r.buf.equals(OGG));
  assert.equal((await http('GET', url, { headers: { 'If-None-Match': r.headers.get('etag') } })).status, 304);
  const part = await http('GET', url, { headers: { Range: 'bytes=0-3' } });
  assert.equal(part.status, 206);
  assert.equal(part.buf.toString('latin1'), 'OggS');
  assert.equal(part.headers.get('content-range'), `bytes 0-3/${OGG.length}`);
  assert.equal((await http('GET', url, { headers: { Range: 'bytes=99999-' } })).status, 416);
  assert.equal((await http('GET', `/media/sounds/${up.data.id}.mp3`)).status, 404, 'wrong extension');
  assert.equal((await http('GET', '/media/sounds/987654.ogg')).status, 404);
  assert.equal((await http('GET', '/media/sounds/default/nope.wav')).status, 404);
  assert.equal((await http('GET', '/media/sounds/default/..%2F..%2Fpackage.json')).status, 404);
  const d = await http('GET', '/media/sounds/default/pop.wav');
  assert.equal(d.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(d.headers.get('content-type'), 'audio/wav');
});

test('replacing a sound changes the URL and the config version (stale audio is never reused)', async () => {
  const c0 = (await cfgOf('store')).data;
  const url0 = c0.events.store_new_order.url;
  // replace from the event row: upload + assign in one step
  const up = await A('POST', '/api/admin/sounds/files', { name: 'طلب', dataUrl: dataUrl('audio/wav', WAV), fileName: 'order.wav', event: 'store_new_order' });
  assert.equal(up.status, 201);
  const c1 = (await cfgOf('store')).data;
  assert.ok(c1.version > c0.version);
  assert.equal(c1.events.store_new_order.url.split('?')[0], `/media/sounds/${up.data.id}.wav`);
  assert.notEqual(c1.events.store_new_order.url, url0);
  assert.equal(c1.events.store_new_order.priority, 'high', 'priority is fixed by the catalogue');
  // replace the library file's bytes in place → same id, new ?v=
  const rep = await A('PUT', `/api/admin/sounds/files/${up.data.id}`, { dataUrl: dataUrl('audio/mpeg', MP3_SYNC), fileName: 'order.mp3' });
  assert.equal(rep.status, 200, JSON.stringify(rep.data));
  const c2 = (await cfgOf('store')).data;
  assert.ok(c2.version > c1.version);
  assert.ok(c2.events.store_new_order.url.startsWith(`/media/sounds/${up.data.id}.mp3?v=`));
  assert.notEqual(c2.events.store_new_order.url, c1.events.store_new_order.url);
  assert.equal((await http('GET', c2.events.store_new_order.url)).headers.get('content-type'), 'audio/mpeg');
  assert.equal((await A('PUT', `/api/admin/sounds/files/${up.data.id}`, { dataUrl: dataUrl('audio/mpeg', EXE) })).status, 422);
  // deleting a file in use falls back to the built-in sound (never silence by accident)
  assert.equal((await A('DELETE', `/api/admin/sounds/files/${up.data.id}`)).status, 200);
  const c3 = (await cfgOf('store')).data;
  assert.ok(c3.events.store_new_order.url.startsWith('/media/sounds/default/new_order.wav'));
  assert.ok(c3.version > c2.version);
});

test('config ETag: 304 while unchanged, new body + ETag after any save; small payload', async () => {
  const a = await cfgOf('driver');
  const etag = a.headers.get('etag');
  assert.ok(etag);
  assert.match(a.headers.get('cache-control'), /no-cache/);
  assert.ok(a.buf.length < 4096, `small: ${a.buf.length} bytes`);
  const b = await cfgOf('driver', { 'If-None-Match': etag });
  assert.equal(b.status, 304);
  assert.equal(b.buf.length, 0);
  await A('PUT', '/api/admin/sounds/events/driver_new_request', { volume: 70 });
  const c = await cfgOf('driver', { 'If-None-Match': etag });
  assert.equal(c.status, 200);
  assert.notEqual(c.headers.get('etag'), etag);
  assert.equal(c.data.events.driver_new_request.volume, 0.7);
});

test('restore defaults: needs confirm, resets every event and the global switch, keeps the library', async () => {
  await A('PUT', '/api/admin/sounds/events/cart_add', { enabled: false, volume: 5, roles: ['store'] });
  await A('PUT', '/api/admin/sounds/settings', { enabled: false });
  const files = Number((await app.db.one('SELECT COUNT(*) AS n FROM sound_files')).n);
  assert.equal((await A('POST', '/api/admin/sounds/restore', {})).status, 422, 'needs an explicit confirm');
  const r = await A('POST', '/api/admin/sounds/restore', { confirm: true });
  assert.equal(r.status, 200);
  assert.equal(r.data.enabled, 1);
  assert.ok(r.data.events.every((e) => !e.changed));
  const ca = r.data.events.find((e) => e.key === 'cart_add');
  assert.deepEqual([ca.enabled, ca.volume, ca.roles, ca.sound], [1, 60, ['customer'], 'default:pop']);
  assert.equal(Number((await app.db.one('SELECT COUNT(*) AS n FROM sound_files')).n), files);
  assert.ok((await cfgOf('customer')).data.events.cart_add);
});

test('only the owner: agent admins get 403, stores / customers / anonymous get 401, CSRF header required; every change audited', async () => {
  const tries = [
    ['GET', '/api/admin/sounds'], ['PUT', '/api/admin/sounds/settings', { enabled: false }],
    ['PUT', '/api/admin/sounds/events/cart_add', { volume: 1 }], ['POST', '/api/admin/sounds/files', { name: 'x', dataUrl: dataUrl('audio/wav', WAV) }],
    ['POST', '/api/admin/sounds/restore', { confirm: true }], ['DELETE', '/api/admin/sounds/files/1'],
  ];
  for (const [m, p, b] of tries) {
    assert.equal((await http(m, p, { body: b, cookie: agent })).status, 403, `agent ${m} ${p}`);
    assert.equal((await http(m, p, { body: b, cookie: storeCookie })).status, 401, `store ${m} ${p}`);
    assert.equal((await http(m, p, { body: b, cookie: cust })).status, 401, `customer ${m} ${p}`);
    assert.equal((await http(m, p, { body: b })).status, 401, `anonymous ${m} ${p}`);
  }
  assert.equal((await A('GET', '/api/admin/sounds')).data.enabled, 1, 'nothing changed');
  // writes without the X-Requested-With header are refused (CSRF)
  const r = await fetch(base + '/api/admin/sounds/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json', Cookie: admin }, body: '{"enabled":false}' });
  assert.equal(r.status, 403);
  const n0 = Number((await app.db.one(`SELECT COUNT(*) AS n FROM admin_actions WHERE action LIKE 'sounds_%'`)).n);
  await A('PUT', '/api/admin/sounds/events/warning', { volume: 33 });
  const last = await app.db.one(`SELECT admin_id, action, details FROM admin_actions WHERE action LIKE 'sounds_%' ORDER BY id DESC LIMIT 1`);
  assert.equal(Number((await app.db.one(`SELECT COUNT(*) AS n FROM admin_actions WHERE action LIKE 'sounds_%'`)).n), n0 + 1);
  assert.equal(last.action, 'sounds_event');
  assert.equal(JSON.parse(last.details).volume, 33);
  assert.ok(last.admin_id);
  for (const a of ['sounds_global', 'sounds_upload', 'sounds_replace', 'sounds_delete', 'sounds_restore'])
    assert.ok(await app.db.one('SELECT id FROM admin_actions WHERE action = $1', [a]), a);
});

// ---------- pure client rules (public/assets/x/sounds-core.js) ----------
test('client: no sound before a user gesture (autoplay rules)', () => {
  assert.equal(core.canAutoplay({}), false);
  assert.equal(core.canAutoplay({ hasBeenActive: false, gestureSeen: false }), false);
  assert.equal(core.canAutoplay({ hasBeenActive: true }), true);
  assert.equal(core.canAutoplay({ gestureSeen: true }), true);
});

test('client: the same event at most once per 1.5 s; different events are independent', () => {
  const last = {};
  assert.equal(core.throttleOk(last, 'cart_add', 1000), true);
  assert.equal(core.throttleOk(last, 'cart_add', 1500), false);
  assert.equal(core.throttleOk(last, 'cart_add', 2499), false);
  assert.equal(core.throttleOk(last, 'cart_remove', 2499), true);
  assert.equal(core.throttleOk(last, 'cart_add', 2500), true);
  assert.equal(core.THROTTLE_MS, 1500);
});

test('client: one sound at a time — a higher priority interrupts, equal/lower is skipped (no overlap)', () => {
  assert.equal(core.decide(null, 'low'), 'play');
  assert.equal(core.decide({ playing: false, priority: 'high' }, 'low'), 'play');
  assert.equal(core.decide({ playing: true, priority: 'low' }, 'high'), 'interrupt');
  assert.equal(core.decide({ playing: true, priority: 'normal' }, 'high'), 'interrupt');
  assert.equal(core.decide({ playing: true, priority: 'low' }, 'normal'), 'interrupt');
  assert.equal(core.decide({ playing: true, priority: 'normal' }, 'normal'), 'skip');
  assert.equal(core.decide({ playing: true, priority: 'high' }, 'normal'), 'skip');
  assert.equal(core.decide({ playing: true, priority: 'high' }, 'high'), 'skip');
});

test('client: user mute — UI sounds can be muted, critical alerts only by "all sounds"; reduced motion quiets UI sounds', () => {
  assert.equal(core.allowedByUser('normal', {}), true);
  assert.equal(core.allowedByUser('normal', { ui: '1' }), false);
  assert.equal(core.allowedByUser('high', { ui: '1' }), true, 'critical still plays');
  assert.equal(core.allowedByUser('high', { all: '1' }), false);
  assert.equal(core.allowedByUser('low', { all: '1', ui: '0' }), false);
  assert.equal(core.allowedByUser('normal', { reducedMotion: true }), false);
  assert.equal(core.allowedByUser('high', { reducedMotion: true }), true);
  assert.equal(core.allowedByUser('normal', { reducedMotion: true, ui: '0' }), true, 'explicit opt-in wins');
});

test('client: preload only critical + cart_add; corrupted / foreign configs are rejected safely', async () => {
  const cfg = (await cfgOf('store')).data;
  const names = core.preloadNames(cfg.events);
  assert.deepEqual(names.sort(), ['order_delayed', 'store_customer_reminder', 'store_new_order', 'store_urgent_order']);
  assert.deepEqual(core.preloadNames({ cart_add: { priority: 'low' }, success: { priority: 'normal' } }), ['cart_add']);
  assert.equal(core.parseConfig('{not json'), null);
  assert.equal(core.parseConfig({ version: 'x', events: {} }), null);
  assert.equal(core.parseConfig(null), null);
  const p = core.parseConfig(JSON.stringify({ enabled: 1, version: 3, events: { a: { url: 'https://evil.example/x.mp3', volume: 1 }, b: { url: '/media/sounds/1.mp3', volume: 7, priority: 'weird' } } }));
  assert.deepEqual(p.events, { b: { url: '/media/sounds/1.mp3', volume: 1, priority: 'normal' } });
  assert.deepEqual(core.resolve(null, 'x'), { skip: 'no_config' });
  assert.deepEqual(core.resolve({ enabled: 0, events: {} }, 'x'), { skip: 'disabled' });
  assert.deepEqual(core.resolve(p, 'zzz'), { skip: 'unmapped' });
  assert.equal(core.resolve(p, 'b').url, '/media/sounds/1.mp3');
  assert.ok(core.parseConfig(cfg).events.store_new_order);
});

test('built-in library: short (0.1–0.6 s), quiet, valid WAV files', () => {
  const dir = new URL('../public/assets/sounds/', import.meta.url);
  for (const e of EVENTS) {
    const buf = readFileSync(new URL(`${e.sound}.wav`, dir));
    assert.equal(buf.toString('latin1', 0, 4), 'RIFF');
    const rate = buf.readUInt32LE(24), bytes = buf.readUInt32LE(40);
    const secs = bytes / (rate * 2);
    assert.ok(secs >= 0.09 && secs <= 0.61, `${e.key}: ${secs}s`);
    let peak = 0;
    for (let i = 44; i < buf.length; i += 2) peak = Math.max(peak, Math.abs(buf.readInt16LE(i)));
    assert.ok(peak / 32767 <= 0.56, `${e.key} quiet: ${peak / 32767}`);
  }
});
